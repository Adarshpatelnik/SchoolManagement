

import React, { useState, useEffect, useCallback } from 'react';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import 'bootstrap/dist/css/bootstrap.min.css';
// import Landing from '../ADMIN_MODEL/Landing';

const StaffAttendance = () => {
  const [selectedAcademicYear, setSelectedAcademicYear] = useState('All');
  const [searchStudentId, setSearchStudentId] = useState('');
  const [searchFirstName, setSearchFirstName] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  
  const [studentAcademic, setStudentAcademic] = useState([]);
  const [filteredStudentAcademic, setFilteredStudentAcademic] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchStudentAcademic();
  }, []);

  const fetchStudentAcademic = async () => {
    try {
      const response = await fetch('http://13.127.57.224:2081/api/staffAttendance');
      if (!response.ok) {
        throw new Error('Failed to fetch data');
      }
      const data = await response.json();
      setStudentAcademic(data);
      setFilteredStudentAcademic(data); // Initialize filtered data with full data set
      setIsLoading(false);
    } catch (error) {
      console.error('Error fetching data:', error);
      setError(error.message);
      setIsLoading(false);
    }
  };

  const filterData = useCallback(() => {
    let filteredData = [...studentAcademic];

    // Filter by selected academic year
    if (selectedAcademicYear !== 'All') {
      filteredData = filteredData.filter(student =>
        student.ACADEMIC_SESSION.toLowerCase() === selectedAcademicYear.toLowerCase()
      );
    }

    // Filter by student ID
    if (searchStudentId.trim() !== '') {
      filteredData = filteredData.filter(student =>
        student.STAFF_ID.toLowerCase().includes(searchStudentId.toLowerCase())
      );
    }

    // Filter by student first name
    if (searchFirstName.trim() !== '') {
      filteredData = filteredData.filter(student =>
        student.STAFF_NAME.toLowerCase().includes(searchFirstName.toLowerCase())
      );
    }

    // Filter by search term in multiple fields
    if (searchTerm.trim() !== '') {
      const lowerCaseSearchTerm = searchTerm.toLowerCase();
      filteredData = filteredData.filter(student =>
        student.STAFF_ID.toLowerCase().includes(lowerCaseSearchTerm) ||
        student.STAFF_NAME.toLowerCase().includes(lowerCaseSearchTerm) ||
        student.STAFF_ROLE.toLowerCase().includes(lowerCaseSearchTerm) ||
        student.SESSION.toLowerCase().includes(lowerCaseSearchTerm) ||
        new Date(student.DATE).toLocaleDateString('en-IN').toLowerCase().includes(lowerCaseSearchTerm) ||
        student.STATUS.toLowerCase().includes(lowerCaseSearchTerm)
      );
    }

    setFilteredStudentAcademic(filteredData);
  }, [selectedAcademicYear, searchStudentId, searchFirstName, searchTerm, studentAcademic]);

  useEffect(() => {
    filterData();
  }, [filterData]);

  const handleReset = () => {
    setSelectedAcademicYear('All');
    setSearchStudentId('');
    setSearchFirstName('');
    setSearchTerm('');
    setFilteredStudentAcademic(studentAcademic); // Reset to original data
  };

  const columnDefs = [
    { headerName: 'Staff ID', field: 'STAFF_ID', sortable: true, filter: true },
    { headerName: 'Staff Name', field: 'STAFF_NAME', sortable: true, filter: true },
    { headerName: 'Staff Role', field: 'STAFF_ROLE', sortable: true, filter: true },
    { headerName: 'Session', field: 'SESSION', sortable: true,  },
    { headerName: 'Date', field: 'DATE', sortable: true, filter: true, cellRenderer: (params) => new Date(params.value).toLocaleDateString('en-IN') },
    { headerName: 'Status', field: 'STATUS', sortable: true, filter: true },
  ];

  const defaultColDef = {
    sortable: true,
    floatingFilter: true,

    resizable: true,
    minWidth: 150,
    maxWidth: 180,
  };

  const paginationPageSize = 10;

  if (isLoading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>Error: {error}</div>;
  }

  return (
    <div className="container-fluid" style={{ padding: 0 }}>
      {/* <Landing /> */}
      <div className="container-fluid" style={{ marginLeft: '', marginTop: '7vh', width: '100%', padding: 0 }}>
        <div className="container-fluid d-flex flex-column" style={{ minHeight: '80vh' }}>
        
        
          <div className="ag-theme-alpine" style={{ height: '87vh', width: '100%', overflow: 'auto' }}>
          <AgGridReact
              rowData={filteredStudentAcademic}
              columnDefs={columnDefs}
              defaultColDef={defaultColDef}
              suppressPaginationPanel={true} // Disable pagination panel
              pagination={false} // Disable pagination
              suppressHorizontalScroll={false} // Allow horizontal scroll if needed
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default StaffAttendance;

      