

import React, { useState, useEffect } from 'react';
import { AgGridReact } from 'ag-grid-react';
import { Link } from 'react-router-dom';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import Landing from '../ADMIN_MODEL/Landing.jsx';

const StaffProfile = () => {
  const [studentAcademic, setStudentAcademic] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchStudentAcademic();
  }, []);

  const fetchStudentAcademic = async () => {
    try {
      const response = await fetch('http://13.127.57.224:2081/api/Staff_Profile');
      if (!response.ok) {
        throw new Error('Failed to fetch');
      }
      const data = await response.json();
      setStudentAcademic(data);
      setIsLoading(false);
    } catch (error) {
      console.error('Error fetching students:', error);
      setError(error.message);
      setIsLoading(false);
    }
  };

  const columnDefs = [
    {
      headerName: 'Staff ID',
      field: 'STAFF_ID',
      filter: true,
      cellRenderer: (params) => (
        <Link to={`/Staff_Detail/${params.value}`} style={{ textDecoration: 'none', color: 'primary' }}>
          {params.value}
        </Link>
      ),
    },
    { headerName: 'Staff User ID', field: 'STAFF_USER_ID', filter: true },
    { headerName: 'Staff Name', field: 'STAFF_NAME', filter: true },
    { headerName: 'Contact Number', field: 'CONTACT_NUMBER' },
    { headerName: 'Staff Role', field: 'STAFF_ROLE', filter: true },

    {
      headerName: 'Date of Joining',
      field: 'DATE_OF_JOINING',
      filter: true,
      valueGetter: (params) => {
        const date = new Date(params.data.DATE_OF_JOINING);
        const day = String(date.getDate()).padStart(2, '0');
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const year = date.getFullYear();
        return `${day}/${month}/${year}`;
      },
    },

    { headerName: 'Monthly Salary', field: 'MONTHLY_SALARY', filter: true },
    { headerName: 'Father Husband Name', field: 'FATHER_HUSBAND_NAME' },
    { headerName: 'Gender', field: 'GENDER', filter: true },
    { headerName: 'Experience', field: 'EXPERIENCE', filter: true },
    { headerName: 'Adhar ID', field: 'ADHAR_ID' },
    { headerName: 'Religion', field: 'RELIGION', filter: true },
    { headerName: 'Email', field: 'EMAIL' },
    { headerName: 'Education', field: 'EDUCATION', filter: true },

    { headerName: 'Blood Group', field: 'BLOOD_GROUP', filter: true },
    { headerName: 'Address', field: 'ADDRESS' },
    { headerName: 'City', field: 'CITY', filter: true },
    { headerName: 'State', field: 'STATE', filter: true },
    { headerName: 'Postal Code', field: 'POSTAL_CODE' },

    {
      headerName: 'Exit Date',
      field: 'EXIT_DATE',
      filter: true,
      valueGetter: (params) => {
        if (!params.data.EXIT_DATE) return ''; // Return an empty string if the date is not available
        const date = new Date(params.data.EXIT_DATE);
        if (isNaN(date)) return ''; // Return an empty string if the date is invalid
        const day = String(date.getDate()).padStart(2, '0');
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const year = date.getFullYear();
        return `${day}/${month}/${year}`;
      },
    },
    

    { headerName: 'Active', field: 'IS_ACTIVE', valueGetter: (params) => (params.data.IS_ACTIVE === 1 ? 'Yes' : 'No') },
  ];

  const defaultColDef = {
    floatingFilter: true,
    sortable: true,
    minWidth: 150,
    maxWidth: 180,
    resizable: true,
  };

  const paginationPageSize = 10; // Number of rows per page

  if (isLoading) {
    return <div>Loading...</div>;
  }

  return (
    <div className="header-container">
      {/* <Landing /> */}
      <div className="container-fluid" style={{ marginLeft: '', marginTop: '6vh', width: '100%', padding: 0 }}>
        <div className="container-fluid d-flex flex-column fixed-middle" style={{ minHeight: '80vh' }}>
          <div className="ag-theme-alpine" style={{ height: '88vh', width: '100%', overflow: 'auto' }}>
            <AgGridReact
              rowData={studentAcademic}
              columnDefs={columnDefs}
              defaultColDef={defaultColDef}
              suppressPaginationPanel={true} // Disable pagination panel
              pagination={false} // Disable pagination
              suppressHorizontalScroll={false} // Allow horizontal scroll if needed
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default StaffProfile;
