

import React, { useState, useEffect, useCallback } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import styled from 'styled-components';
import debounce from 'lodash/debounce';

// Function to format the date
function formatDate(dateString) {
  if (dateString === '0000-00-00') return '';
  const date = new Date(dateString);
  if (isNaN(date.getTime())) return '';
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}/${month}/${day}`;
}

// Custom cell renderer for dropdown
const DropdownRenderer = (props) => {
  const handleChange = (e) => {
    props.setValue(e.target.value); // Update the cell value on change
  };

  return (
    <select
      value={props.value}
      onChange={handleChange}
      style={{ width: '70%', height: '70%' }} // Adjust the width here
    >
      <option value="Yes">Yes</option>
      <option value="No">No</option>
    </select>
  );
};

// Styled components
const Container = styled.div`
  margin-left: vh;
  margin-top: 6vh;
  width: 100%;
  padding: 0;
`;

const StyledGrid = styled.div`
  height: 70vh; /* Reduced height for the grid */
  width: 100%;
  overflow: hidden; /* Prevent overflow on the grid itself */
`;

const SubmitButton = styled.button`
  background: linear-gradient(90deg, #012353, #27AE60);
  color: white;
  border: none;
  padding: 10px 25px;
  cursor: pointer;
  font-size: 16px;
  font-weight: bold;
  border-radius: 25px;
  box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.2);
  transition: all 0.3s ease;
  position: fixed;
  bottom: 10%; /* Position at the bottom */
  left: 50%; /* Center horizontally */
  transform: translateX(-50%); /* Exactly center it */
  
  &:hover {
    background: linear-gradient(90deg, #27AE60, #012353);
    transform: scale(1.05) translateX(-50%);
    box-shadow: 0px 6px 10px rgba(0, 0, 0, 0.3);
  }

  &:active {
    transform: scale(0.95) translateX(-50%);
    box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.2);
  }
`;


const Assignment = () => {
  const [assignments, setAssignments] = useState([]);
  const [filteredAssignments, setFilteredAssignments] = useState([]);

  // Fetch assignments from backend
  useEffect(() => {
    const fetchAssignments = async () => {
      try {
        const response = await fetch('http://13.127.57.224:2081/api/assignmentlist');
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        const data = await response.json();
        console.log('Fetched data:', data); // Debug fetched data

        const mappedData = data.map(item => ({
          'Student ID': item.STUDENT_ID,
          'Student Name': item.STUDENT_NAME,
          'Class Teacher': item.CLASS_TEACHER,
          'Start Date': formatDate(item.START_DATE),
          'Class': item.CLASS_ID,
          'Subject': item.SUBJECT,
          'Assignment Type': item.ASSIGNMENT_TYPE,
          'Assignment Description': item.ASSIGNMENT_DESC,
          'Submission Start Date': formatDate(item.SUBMISSION_START_DATE),
          'Submission End Date': formatDate(item.SUBMISSION_END_DATE),
          'Is Submitted': item.IS_SUBMITTED,
          'Status': item.STATUS,
          'Submission Date': formatDate(item.SUBMISSION_DATE),
          'ID': item.ID
        }));

        setAssignments(mappedData);
        setFilteredAssignments(mappedData);
      } catch (error) {
        console.error('Error fetching assignments:', error);
      }
    };

    fetchAssignments();
  }, []);

  // Handle search functionality with debounce
  const debouncedSearch = useCallback(debounce((searchTerm) => {
    const filteredAssignments = assignments.filter((assignment) => {
      return Object.values(assignment).some((value) =>
        value.toString().toLowerCase().includes(searchTerm.toLowerCase())
      );
    });
    setFilteredAssignments(filteredAssignments);
  }, 300), [assignments]);

  const handleSearch = (e) => {
    const term = e.target.value;
    debouncedSearch(term);
  };

  // Define columns for AG Grid
  const columns = [
    { headerName: "Student ID", field: "Student ID", editable: false, headerClass: 'header-class' },
    { headerName: "Student Name", field: "Student Name", editable: false, headerClass: 'header-class' },
    { headerName: "Class Teacher", field: "Class Teacher", editable: false, headerClass: 'header-class' },
    { headerName: "Start Date", field: "Start Date", editable: false, headerClass: 'header-class' },
    { headerName: "Class", field: "Class", editable: false, headerClass: 'header-class' },
    { headerName: "Subject", field: "Subject", editable: false, headerClass: 'header-class' },
    { headerName: "Assignment Type", field: "Assignment Type", editable: false, headerClass: 'header-class' },
    { headerName: "Assignment Description", field: "Assignment Description", editable: false, headerClass: 'header-class' },
    { headerName: "Submission Start Date", field: "Submission Start Date", editable: false, headerClass: 'header-class' },
    { headerName: "Submission End Date", field: "Submission End Date", editable: false, headerClass: 'header-class' },
    {
      headerName: "Is Submitted",
      field: "Is Submitted",
      cellRenderer: DropdownRenderer, // Use custom renderer to always show dropdown
      editable: true // Ensure the cell is editable
    },
    { headerName: "Status", field: "Status", editable: false, headerClass: 'header-class' },
    { headerName: "Submission Date", field: "Submission Date", editable: false, headerClass: 'header-class' }
  ];

  // Handle row edit event
  const onCellValueChanged = (params) => {
    const updatedAssignments = filteredAssignments.map((assignment) => {
      if (assignment['Student ID'] === params.data['Student ID']) {
        const updatedAssignment = {
          ...assignment,
          [params.colDef.field]: params.newValue
        };

        if (params.colDef.field === 'Is Submitted') {
          updatedAssignment['Status'] = params.newValue === 'Yes' ? 'On time' : 'Late';
          updatedAssignment['Submission Date'] = params.newValue === 'Yes' || params.newValue === 'No'
            ? new Date().toISOString().split('T')[0]
            : '';
        }

        return updatedAssignment;
      }
      return assignment;
    });

    setFilteredAssignments(updatedAssignments);
  };

  // Handle form submission
  const handleSubmit = async () => {
    console.log('Submitting data:', filteredAssignments);
    try {
      const updatePromises = filteredAssignments.map(assignment => {
        return fetch(`http://13.127.57.224:2081/api/assignmentupdate/${assignment['Student ID']}`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            IS_SUBMITTED: assignment['Is Submitted'],
            STATUS: assignment['Status'],
            SUBMISSION_DATE: assignment['Submission Date']
          })
        });
      });

      const responses = await Promise.all(updatePromises);
      const allSuccessful = responses.every(response => response.ok);

      if (allSuccessful) {
        alert('Data updated successfully!');
      } else {
        alert('Error updating some data.');
      }
    } catch (error) {
      console.error('Error updating data:', error);
      alert(`An unexpected error occurred: ${error.message}`);
    }
  };

  return (
    <Container className="container-fluid">
      <div className="d-flex justify-content-end align-items-center mb-3">
        <SubmitButton onClick={handleSubmit}>Submit</SubmitButton>
      </div>

      <StyledGrid className="ag-theme-alpine">
        <AgGridReact
          rowData={filteredAssignments}
          columnDefs={columns}
          onCellValueChanged={onCellValueChanged}
          domLayout='normal' // Set to normal to enable fixed header
          headerHeight={40} // Set header height
          suppressMovableColumns={true} // Make headers fixed
          getRowStyle={(params) => ({
            height: '70px', // Row height
          })}
          // Enable floating headers
          floatingFilter={true}
        />
      </StyledGrid>
    </Container>
  );
};

export default Assignment;
