
import React, { useState, useRef, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css'; // Import Bootstrap CSS

// SECURITY & OTHERS Pages
import { log } from './logger';
import ErrorBoundary from './SECURITY_OTHERS/ErrorBoundary'; // Import the ErrorBoundary
import NotFound from './SECURITY_OTHERS/NotFound'; // Import the NotFound component

import Login from './SECURITY_OTHERS/Login';
import Home from './SECURITY_OTHERS/Home';
import Signup from './SECURITY_OTHERS/Signup';
import MissionVision from './SECURITY_OTHERS/MissionVision';
import Contact from './SECURITY_OTHERS/Contact';
import Aboutus from './SECURITY_OTHERS/About_us';
import Services from './SECURITY_OTHERS/Services';
import PrivateRoutes from './SECURITY_OTHERS/PrivateRoutes'; // Import the PrivateRoutes component
import { AuthProvider } from './SECURITY_OTHERS/AuthContext';

// ADMIN_MODEL Pages
import Layout from './ADMIN_MODEL/MainLayout'; // Import the Layout component
import Landing from './ADMIN_MODEL/Landing';

import TimeTable from './ADMIN_MODEL/Time_Table';
import ExamSheduling from './ADMIN_MODEL/Exam_Sheduling';
import Event from './ADMIN_MODEL/Event';
import DashBoard from './ADMIN_MODEL/DashBoard';
import PerformanceSummary from './ADMIN_MODEL/Dashbord_Performance_Summary';
import EventCalender from './ADMIN_MODEL/Event_Calender';
import Applicationform from './ADMIN_MODEL/Application_form';
import Enrollment from './ADMIN_MODEL/Enrollment';
import AttendanceChart from './ADMIN_MODEL/Staff_Attendance_Chart';
import DashbordStudentAttendance from './ADMIN_MODEL/Student_Attendance_Chart';
import Studentpromotedform from './ADMIN_MODEL/Student_promoted_form';
import GradReport from './ADMIN_MODEL/Grad_Report';
import Messages from './ADMIN_MODEL/Messages';
import AdminNotification from './ADMIN_MODEL/Admin_Notification';
import StudentGradeBookEntry from './ADMIN_MODEL/Student_Grade_Book_Entry';
import GirlBoy from './ADMIN_MODEL/Girl_Boy';
import TimeTableschedule from './ADMIN_MODEL/Time_Table_schedule';
import JoiningLatter from './ADMIN_MODEL/Joining_Latter';
import NoticeForm from './ADMIN_MODEL/Notice_Form';
import Hiring from './ADMIN_MODEL/Teacher_Hiring';
import EventCard from './ADMIN_MODEL/Event_Card';
import AdminFess from './ADMIN_MODEL/Admin_Fess';

// STAFF_MODEL Pages
import StaffProfile from './STAFF_MODEL/Staff_Profile';
import StaffAttendance from './STAFF_MODEL/Staff_Attendance';
import AssignmentForm from './STAFF_MODEL/Assignment_Form';
import Assignment from './STAFF_MODEL/Assignment';
import StaffDetail from './STAFF_MODEL/Staff_Detail';

// STAFF_DASHBORD Pages
import Staffnavbar from './STAFF_DASHBORD/Staff_navbar';
import StaffAssignmentOverview from './STAFF_DASHBORD/Staff_Assignment_Overview';
import Staffcalendar from './STAFF_DASHBORD/Staff_calendar';
import StaffDashbord from './STAFF_DASHBORD/Staff_Dashbord';
import Staffshedule from './STAFF_DASHBORD/Staff_shedule';
import StaffGradeEntry from './STAFF_DASHBORD/Staff_Grade_Entry';
import StaffAssignmentsDashboard from './STAFF_DASHBORD/Staff_Assignments_Dashboard';
import StaffAssignmentForm from './STAFF_DASHBORD/Staff_Assignment_Form';
import StaffSelectAssignment from './STAFF_DASHBORD/Staff_Select_Assignment';
import StaffApproveAssignment from './STAFF_DASHBORD/Staff_Approve_Assignment';
import StaffStudentInformationAssignment from './STAFF_DASHBORD/Staff_Student_InformationAssignment';
import StaffTimeTableschedule from './STAFF_DASHBORD/Staff_TimeTable_schedule';
import StaffAssignmentTable from './STAFF_DASHBORD/Staff_Assignment_Table';
import StudentList from './STAFF_DASHBORD/Student_List';
import Staff_Assignment_List from './STAFF_DASHBORD/Staff_Assignment_List';
import StaffAssignmentDetail from './STAFF_DASHBORD/Staff_Assignment_Detail';
import StaffNoticeBoard from './STAFF_DASHBORD/Staff_Notice_Board';
import StaffMainAssignment from './STAFF_DASHBORD/Staff_Main_Assignment';
import StaffAttandanceCalendar from './STAFF_DASHBORD/Staff_Attandance_Calendar';

// STUDENT_MODEL Pages
import ParentProfile from './STUDENT_MODEL/parent_profile';
import Studenthealth from './STUDENT_MODEL/Student_health';
import AcademicPerformance from './STUDENT_MODEL/Student_Academic_Performance';
import StudentDetail from './STUDENT_MODEL/Student_Detail';
import ParentDetail from './STUDENT_MODEL/Parent_Detail';
import StudentAttendance from './STUDENT_MODEL/Student_Attendance';
import StudentProfile from './STUDENT_MODEL/Student_Profile';
import StudentFillAttendance from './STUDENT_MODEL/StudentFill_Attendance';
import StudentGradBook from './STUDENT_MODEL/Student_Grad_Book';
import Studentperformance from './STUDENT_MODEL/Student_performance';

// STUDENT_DASHBOARD Pages
import StudentDashboard from './STUDENT_DASHBOARD/Student_Dashboard';
import Studenteventcalendar from './STUDENT_DASHBOARD/Student_eventcalendar';
import Studenterformance from './STUDENT_DASHBOARD/Student_performance_Chart';
import StudentLanding from './STUDENT_DASHBOARD/Student_landing';
import EditForm from './STUDENT_DASHBOARD/Edit_Form';
import StudentDataTable from './STUDENT_DASHBOARD/Student_Data_Table';
import StudentAttendanceDashbord from './STUDENT_DASHBOARD/Student_Attendance_Dashbord'; // Ensure this file exists
import StudentAssignment from './STUDENT_DASHBOARD/Student_Assignment';
import StudentNoticeBoard from './STUDENT_DASHBOARD/Student_Notice_Board';
import StudentNavbar from './STUDENT_DASHBOARD/Student_Navbar';

import StudentTimeTableschedule from './STUDENT_DASHBOARD/Student_TimeTable_schedule';
import DeveloperDashboard from './SECURITY_OTHERS/DeveloperDashboard';
import BulkLoad from './ADMIN_MODEL/BulkLoad';

const App = () => {
  const [sidebarVisible, setSidebarVisible] = useState(false);
  const sidebarRef = useRef(null);

  const toggleSidebar = () => {
    setSidebarVisible(!sidebarVisible);
  };

  const handleClickOutside = (event) => {
    if (sidebarRef.current && !sidebarRef.current.contains(event.target)) {
      setSidebarVisible(false);
    }
  };

  // Close sidebar if clicked outside
  useEffect(() => {
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Helper function for Protected Routes with Layout
  const withLayout = (element) => (
    <Layout toggleSidebar={toggleSidebar} sidebarVisible={sidebarVisible} ref={sidebarRef}>
      {element}
    </Layout>
  );

  return (
    <AuthProvider>
      <Router>
        <ErrorBoundary>
          <Routes>
            {/* Public Routes */}
            <Route path="/" element={<Home />} />
            <Route path="/Login" element={<Login />} />
            <Route path="/Signup" element={<Signup />} />

            {/* Protected Routes */}
            <Route element={<PrivateRoutes requiredRoles={['administrator','developer', 'admin']} />}>
             <Route path="/Student_Profile" element={withLayout(<StudentProfile />)} />
             <Route path="/DashBoard" element={withLayout(<DashBoard />)} />
             <Route path="/Student_Attendance" element={withLayout(<StudentAttendance />)} />
             <Route path="/StudentFill_Attendance" element={withLayout(<StudentFillAttendance />)} />
             <Route path="/Staff_Profile" element={withLayout(<StaffProfile />)} />
             <Route path="/Staff_Attendance" element={withLayout(<StaffAttendance />)} />
             <Route path="/Time_Table" element={withLayout(<TimeTable />)} />
             <Route path="/Exam_Sheduling" element={withLayout(<ExamSheduling />)} />
             <Route path="/Event" element={withLayout(<Event />)} />
             <Route path="/Enrollment" element={withLayout(<Enrollment />)} />
             <Route path="/Student_Detail/:studentId" element={withLayout(<StudentDetail />)} />
             <Route path="/Staff_Detail/:staffId" element={withLayout(<StaffDetail />)} />
             <Route path="/Parent_Detail/:parentId" element={withLayout(<ParentDetail />)} />
             <Route path="/Landing" element={withLayout(<Landing />)} />
             <Route path="/AttendanceChart" element={withLayout(<AttendanceChart />)} />
             <Route path="/PerformanceSummary" element={withLayout(<PerformanceSummary />)} />
             <Route path="/EventCalender" element={withLayout(<EventCalender />)} />
             <Route path="/MissionVision" element={withLayout(<MissionVision />)} />
             <Route path="/Contact" element={withLayout(<Contact />)} />
             <Route path="/Aboutus" element={withLayout(<Aboutus />)} />
             <Route path="/Services" element={withLayout(<Services />)} />
             <Route path="/parent_profile" element={withLayout(<ParentProfile />)} />
             <Route path="/Application_form" element={withLayout(<Applicationform />)} />
             <Route path="/Student_health" element={withLayout(<Studenthealth />)} />
             <Route path="/Student_Academic_Performance" element={withLayout(<AcademicPerformance />)} />
             <Route path="/Assignment_Form" element={withLayout(<AssignmentForm />)} />
             <Route path="/Assignment" element={withLayout(<Assignment />)} />
             <Route path="/DashbordStudent_Attendance" element={withLayout(<DashbordStudentAttendance />)} />
             <Route path="/Student_Grade_Book_Entry" element={withLayout(<StudentGradeBookEntry />)} />
             <Route path="/Student_performance" element={withLayout(<Studentperformance />)} />
             <Route path="/Student_Grad_Book" element={withLayout(<StudentGradBook />)} />
             <Route path="/Student_promoted_form" element={withLayout(<Studentpromotedform />)} />
             <Route path="/Grad_Report" element={withLayout(<GradReport />)} />
             <Route path="/Messages" element={withLayout(<Messages />)} />
             <Route path="/Student_eventcalendar" element={withLayout(<Studenteventcalendar />)} />
             <Route path="/Student_performance_Chart" element={withLayout(<Studenterformance />)} />
             <Route path="/Student_landing" element={withLayout(<StudentLanding />)} />
             <Route path="/Student_Data_Table" element={withLayout(<StudentDataTable />)} />
             <Route path="/Student_TimeTable_schedule" element={withLayout(<StudentTimeTableschedule />)} />
             <Route path="/Admin_Fess" element={withLayout(<AdminFess />)} />

             {/* <Route path="/Student_landing" element={<StudentLanding />} /> */}
             <Route path="/BulkLoad" element={<BulkLoad />} />
             
             <Route path="/admin_notification" element={withLayout(<AdminNotification />)} />
             <Route path="/student_grade_book_entry" element={withLayout(<StudentGradeBookEntry />)} />
             <Route path="/girl_boy" element={withLayout(<GirlBoy />)} />
             <Route path="/time_table_schedule" element={withLayout(<TimeTableschedule />)} />
             <Route path="/joining_latter" element={withLayout(<JoiningLatter />)} />
             <Route path="/Staff_Assignment_Table" element={withLayout(<StaffAssignmentTable />)} />
             <Route path="/Student_List" element={withLayout(<StudentList />)} />
             <Route path="/Notice_Form" element={withLayout(<NoticeForm />)} />
             <Route path="/Staff_Attendance" element={withLayout(<StaffAttendance />)} />
             <Route path="/Teacher_Hiring" element={withLayout(<Hiring />)} />
             <Route path="/Event_Card" element={withLayout(<EventCard />)} />
            
              {/* Add other protected routes here */}
            </Route>

            <Route element={<PrivateRoutes requiredRoles={['staff']} />}>
              <Route path="/Staff_Dashbord" element={<StaffDashbord />} />
              <Route path="/Staff_navbar" element={<Staffnavbar />} />
              <Route path="/Staff_Notice_Board" element={withLayout(<StaffNoticeBoard />)} />
              <Route path="/Staff_Assignment_List/:countType" element={<Staff_Assignment_List />} />
              <Route path="/Staff_Assignment_Detail" element={withLayout(<StaffAssignmentDetail />)} />
              <Route path="/Staff_assignment_overview" element={withLayout(<StaffAssignmentOverview />)} />
             <Route path="/Staff_calendar" element={withLayout(<Staffcalendar />)} />
             <Route path="/Staff_schedule" element={withLayout(<Staffshedule />)} />
             <Route path="/Staff_Grade_Entry" element={withLayout(<StaffGradeEntry/>)} />
             <Route path="/Staff_assignments_dashboard" element={withLayout(<StaffAssignmentsDashboard />)} />
             <Route path="/Staff_assignment_form" element={withLayout(<StaffAssignmentForm />)} />
             <Route path="/Staff_select_assignment" element={withLayout(<StaffSelectAssignment />)} />
             <Route path="/Staff_approve_assignment" element={withLayout(<StaffApproveAssignment />)} />
             <Route path="/Staff_student_information_assignment" element={withLayout(<StaffStudentInformationAssignment />)} />
             <Route path="/Staff_time_table_schedule" element={withLayout(<StaffTimeTableschedule />)} />
             <Route path="/Staff_Main_Assignment" element={<StaffMainAssignment />} />
             <Route path="/Staff_Attandance_Calendar" element={<StaffAttandanceCalendar />} />

           
              {/* Add other staff-specific routes here */}
            </Route>

            <Route element={<PrivateRoutes requiredRoles={['student']} />}>
              <Route path="/Student_Dashboard" element={withLayout(<StudentDashboard />)} />
              <Route path="/Student_Navbar" element={withLayout(<StudentNavbar />)} />
              <Route path="/Student_attendance_dashboard" element={withLayout(<StudentAttendanceDashbord />)} />
              <Route path="/Student_Notice_Board" element={withLayout(<StudentNoticeBoard />)} />
              <Route path="/Student_Assignment" element={withLayout(<StudentAssignment />)} />
              <Route path="/Edit_Form" element={withLayout(<EditForm />)} />


              </Route>

            <Route element={<PrivateRoutes requiredRoles={['developer']} />}>
              <Route path="/DeveloperDashboard" element={<DeveloperDashboard />} />
              <Route path="/BulkLoad" element={<BulkLoad />} />
              {/* Add other developer-specific routes here */}
            </Route>

            {/* Default 404 Route */}
            <Route path="*" element={<NotFound />} />
          </Routes>
        </ErrorBoundary>
      </Router>
    </AuthProvider>
  );
};

export default App;