const logToServer = async (message) => {
    try {
        await fetch('http://13.127.57.224:2081/log', { // Adjust the URL if needed
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ message }),
        });
    } catch (error) {
        console.error('Failed to log to server:', error);
    }
};

export const log = (message) => {
    console.log(message); // Log to console
    logToServer(message); // Send log to backend
};
