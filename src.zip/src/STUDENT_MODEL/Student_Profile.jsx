
import React, { useState, useEffect } from 'react';
import { AgGridReact } from 'ag-grid-react';
import { Link } from 'react-router-dom';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import 'bootstrap/dist/css/bootstrap.min.css';
// import Landing from '/home/ec2-user/Edu360/SchoolManagement/frontend/src/ADMIN_MODEL/Landing.js';

const StudentProfile = () => {
  const [studentAcademic, setStudentAcademic] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchStudentAcademic();
  }, []);

  const fetchStudentAcademic = async () => {
    try {
      const response = await fetch('http://13.127.57.224:2081/api/studentprofile');
      if (!response.ok) {
        throw new Error('Failed to fetch');
      }
      const data = await response.json();
      setStudentAcademic(data);
      setIsLoading(false);
    } catch (error) {
      console.error('Error fetching students:', error);
      setError(error.message);
      setIsLoading(false);
    }
  };

  const columnDefs = [
    {
      headerName: 'Student ID',
      field: 'STUDENT_ID',
      cellRenderer: (params) => (
        <Link to={`/Student_Detail/${params.value}`} style={{ textDecoration: 'none', color: 'primary' }}>
          {params.value}
        </Link>
      ),
    },
    { headerName: 'First Name', field: 'FIRST_NAME', filter: true },
    { headerName: 'Middle Name', field: 'MIDDLE_NAME' },
    { headerName: 'Last Name', field: 'LAST_NAME' },
    { headerName: 'Gender', field: 'GENDER', filter: true },
    { headerName: 'Class', field: 'CLASS_ID', filter: true },
    { headerName: 'Class Teacher', field: 'CLASS_TEACHER' },
    { headerName: 'Contact Number', field: 'CONTACT_NUMBER' },
    { headerName: 'House Number', field: 'HOUSE_NUMBER' },
    { headerName: 'House Building Name', field: 'HOUSE_BUILDING_NAME' },
    { headerName: 'Street Name', field: 'STREET_NAME' },
    { headerName: 'Landmark', field: 'LANDMARK' },
    { headerName: 'City', field: 'CITY', filter: true },
    { headerName: 'State', field: 'STATE' },
    { headerName: 'Postal Code', field: 'POSTAL_CODE' },
    { headerName: 'Nationality', field: 'NATIONALITY' },
    {
      headerName: 'Date Of Birth',
      field: 'DATE_OF_BIRTH',
      valueGetter: (params) => {
        if (!params.data.DATE_OF_BIRTH) return ''; // Handle empty or null dates
        const date = new Date(params.data.DATE_OF_BIRTH);
        if (isNaN(date)) return ''; // Handle invalid dates
        const day = String(date.getDate()).padStart(2, '0');
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const year = date.getFullYear();
        return `${day}/${month}/${year}`;
      },
    },
        { headerName: 'Email', field: 'EMAIL' },
    {
      headerName: 'Enrollment Date',
      field: 'ENROLLMENT_DATE',
      valueFormatter: (params) => (params.value ? params.value.slice(0, 10) : ''),
    },
    { headerName: 'Birth Certificate Number', field: 'BIRTH_CERTIFICATE_NUMBER' },
    { headerName: 'Cast', field: 'CAST', filter: true },
    { headerName: 'Religion', field: 'RELIGION' },
    { headerName: 'Blood Group', field: 'BLOOD_GROUP' },
    { headerName: 'Identification Mark', field: 'IDENTIFICATION_MARK' },
    { headerName: 'Previous School', field: 'PREVIOUS_SCHOOL' },
    { headerName: 'Emergency Contact Name', field: 'EMERGENCY_CONTACT_NAME' },
    { headerName: 'Emergency Contact Number', field: 'EMERGENCY_CONTACT_NUMBER' },
    { headerName: 'Aadhaar Number', field: 'AADHAR_NUMBER' },
    { headerName: 'Disease If Any', field: 'DISEASE_IF_ANY' },
    { headerName: 'Additional Note', field: 'ADDITIONAL_NOTE' },
  ];

  const defaultColDef = {
    floatingFilter: true,
    sortable: true,
    minWidth: 150,
    maxWidth: 180,
    resizable: true,
  };

  if (isLoading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>Error: {error}</div>;
  }

  return (
    <div className="header-container">
      {/* <Landing /> */}
      <div className="container-fluid" style={{marginTop: '7vh', width: '100%', padding: 0 }}>
        <div className="container-fluid d-flex flex-column fixed-middle" style={{ minHeight: '80vh' }}>
          {/* Fixed height for the table container */}
          <div className="ag-theme-alpine" style={{ height: '88vh', width: '100%', overflow: 'auto' }}>
            <AgGridReact
              rowData={studentAcademic}
              columnDefs={columnDefs}
              defaultColDef={defaultColDef}
              suppressPaginationPanel={true} // Disable pagination panel
              pagination={false} // Disable pagination
              suppressHorizontalScroll={false} // Allow horizontal scroll if needed
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default StudentProfile;
