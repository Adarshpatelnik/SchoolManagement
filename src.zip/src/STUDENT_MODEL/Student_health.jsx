

import React, { useState, useEffect } from 'react';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import 'bootstrap/dist/css/bootstrap.min.css';

const Health = () => {
  const [studentAcademic, setStudentAcademic] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchStudentAcademic();
  }, []);

  const fetchStudentAcademic = async () => {
    try {
      const response = await fetch('http://13.127.57.224:2081/api/Student_health');
      if (!response.ok) {
        throw new Error('Failed to fetch');
      }
      const data = await response.json();

      // Format the LAST_CHECKUP_DATE field
      const formattedData = data.map((item) => ({
        ...item,
        LAST_CHECKUP_DATE: formatDate(item.LAST_CHECKUP_DATE),
      }));

      setStudentAcademic(formattedData);
      setIsLoading(false);
    } catch (error) {
      console.error('Error fetching students:', error);
      setError(error.message);
      setIsLoading(false);
    }
  };

  // Function to format date
  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    const date = new Date(dateString);
    const options = { day: '2-digit', month: '2-digit', year: 'numeric' };
    return new Intl.DateTimeFormat('en-GB', options).format(date);
  };

  const columnDefs = [
    { headerName: 'Student ID', field: 'STUDENT_ID', filter: true },
    { headerName: 'Student Name', field: 'STUDENT_NAME', filter: true },
    { headerName: 'Weight In Kg', field: 'WEIGHT_IN_KG' },
    { headerName: 'Height In Cm', field: 'HEIGHT_IN_CM' },
    { headerName: 'Bmi', field: 'BMI' },
    { headerName: 'Vision Left', field: 'VISION_LEFT' },
    { headerName: 'Vision Right', field: 'VISION_RIGHT' },
    { headerName: 'Allergies', field: 'ALLERGIES' },
    { headerName: 'Medical History', field: 'MEDICAL_HISTORY' },
    { headerName: 'Last Checkup Date', field: 'LAST_CHECKUP_DATE' },
    { headerName: 'Health Status', field: 'HEALTH_STATUS' },
    { headerName: 'Doctor Name', field: 'DOCTOR_NAME' },
    { headerName: 'Doctor Contact Number', field: 'DOCTOR_CONTACT_NUMBER' },
  ];

  const defaultColDef = {
    floatingFilter: true,
    sortable: true,
    minWidth: 150,
    maxWidth: 180,
    resizable: true,
  };

  if (isLoading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>Error: {error}</div>;
  }

  return (
    <div className="header-container">
      <div className="container-fluid" style={{ marginTop: '7vh', width: '100%', padding: 0 }}>
        <div className="container-fluid d-flex flex-column fixed-middle" style={{ minHeight: '80vh' }}>
          <div className="ag-theme-alpine" style={{ height: '88vh', width: '100%', overflow: 'auto' }}>
            <AgGridReact
              rowData={studentAcademic}
              columnDefs={columnDefs}
              defaultColDef={defaultColDef}
              suppressPaginationPanel={true}
              pagination={false}
              suppressHorizontalScroll={false}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Health;
