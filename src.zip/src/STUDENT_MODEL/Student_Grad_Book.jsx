
import React, { useState, useEffect } from 'react';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import 'bootstrap/dist/css/bootstrap.min.css';

const GradeBook = () => {
  const [studentAcademic, setStudentAcademic] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchStudentAcademic();
  }, []);

  const fetchStudentAcademic = async () => {
    try {
      const response = await fetch('http://13.127.57.224:2081/api/VWACADEMICMARKS');
      if (!response.ok) {
        throw new Error('Failed to fetch');
      }
      const data = await response.json();
      setStudentAcademic(data);
      setIsLoading(false);
    } catch (error) {
      console.error('Error fetching students:', error);
      setError(error.message);
      setIsLoading(false);
    }
  };

  // Utility function to format date
  const formatDate = (dateString) => {
    if (!dateString) return 'N/A'; // Return "N/A" if date is missing or invalid
    const date = new Date(dateString);
    if (isNaN(date.getTime())) return 'N/A'; // Return "N/A" if date is invalid
    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0'); // Month is 0-based
    const year = date.getFullYear();
    return `${day}-${month}-${year}`;
  };

  const columnDefs = [
    { headerName: 'Student ID', field: 'STUDENT_ID', filter: true },
    { headerName: 'Student Name', field: 'STUDENT_NAME', filter: true },
    { headerName: 'Academic Year', field: 'ACADEMIC_YEAR', filter: true },
    { headerName: 'Father Name', field: 'FATHER_NAME' },
    { headerName: 'Mother Name', field: 'MOTHER_NAME' },
    {
      headerName: 'Date of Birth',
      field: 'DATE_OF_BIRTH',
      valueFormatter: (params) => formatDate(params.value), // Apply date formatting
    },
    { headerName: 'Class', field: 'CLASS', filter: true },
    { headerName: 'Subject', field: 'SUBJECT', filter: true },
    { headerName: 'Periodic Test 1', field: 'PERIODIC_TEST_1', filter: true },
    { headerName: 'Note Book 1', field: 'NOTE_BOOK_1' },
    { headerName: 'Subject Enrichment 1', field: 'SUBJECT_ENRICHMENT_1' },
    { headerName: 'Half Yearly', field: 'HALF_YEARLY' },
    { headerName: 'Term 1 Total', field: 'TERM_1_TOTAL' },
    { headerName: 'Half Yearly Performance', field: 'HALF_YEARLY_PERFORAMCE' },
    { headerName: 'Work Education 1', field: 'WORK_EDUCATION_1' },
    { headerName: 'Art Education ', field: 'ART_EDUCATION_1' },
    { headerName: 'Health And Hygiene', field: 'HEALTH_AND_HYGIENE_1' },
    { headerName: 'Regularity And Punctuality 1', field: 'REGULARITY_AND_PUNCTUALLITY_1' },
    { headerName: 'Periodic Test  2', field: 'PERIODIC_TEST_2' },
    { headerName: 'Note Book 2', field: 'NOTE_BOOK_2' },
    { headerName: 'Subject Enrichment 2', field: 'SUBJECT_ENRICHMENT_2' },
    { headerName: 'Annual', field: 'ANNUAL' },
    { headerName: 'Term 2 Total', field: 'TERM_2_TOTAL' },
    { headerName: 'Annual Performance', field: 'ANNUAL_PERFORMANCE' },
    { headerName: 'Work Education 2', field: 'WORK_EDUCATION_2' },
    { headerName: 'Art Education 2', field: 'ART_EDUCATION_2' },
    { headerName: 'Health And Hygiene 2', field: 'HEALTH_AND_HYGIENE_2' },
    { headerName: 'Regularity And Punctuality 2', field: 'REGULARITY_AND_PUNCTUALLITY_2' },
    { headerName: 'Grand Total', field: 'GRAND_TOTAL', filter: true },
    { headerName: 'Grade', field: 'GRADE', filter: true },
    { headerName: 'Overall Marks', field: 'OVERALL_MARKS' },
    { headerName: 'Percent', field: 'OVERALL_MARKS', filter: true },
  ];

  const defaultColDef = {
    floatingFilter: true,
    sortable: true,
    minWidth: 150,
    maxWidth: 180,
    resizable: true,
  };

  if (isLoading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>Error: {error}</div>;
  }

  return (
    <div className="header-container">
      <div className="container-fluid" style={{ marginTop: '7vh', width: '100%', padding: 0 }}>
        <div className="container-fluid d-flex flex-column fixed-middle" style={{ minHeight: '80vh' }}>
          <div className="ag-theme-alpine" style={{ height: '88vh', width: '100%', overflow: 'auto' }}>
            <AgGridReact
              rowData={studentAcademic}
              columnDefs={columnDefs}
              defaultColDef={defaultColDef}
              suppressPaginationPanel={true}
              pagination={false}
              suppressHorizontalScroll={false}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default GradeBook;
