

import React, { useState, useContext, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { FiMail, FiLock, FiUser, FiEye, FiEyeOff } from 'react-icons/fi';
import Validation from './LoginValidation';
import { AuthContext } from './AuthContext';
import './Security.css';

function Login() {
  const { isAuthenticated, login } = useContext(AuthContext); // Access AuthContext
  const [values, setValues] = useState({
    UserName: '',
    Password: '',
    Role: 'administrator',
  });

  const [showPassword, setShowPassword] = useState(false);
  const togglePasswordVisibility = () => setShowPassword((prevState) => !prevState);

  const [errors, setErrors] = useState({});
  const [serverError, setServerError] = useState('');
  const [loading, setLoading] = useState(false); // Loader state
  const navigate = useNavigate();

  useEffect(() => {
    // Redirect authenticated users away from the login page
    if (isAuthenticated) {
      const roleRoutes = {
        administrator: '/DashBoard',
        admin: '/DashBoard',
        staff: '/Staff_Dashbord',
        student: '/Student_Dashboard',
        developer: '/DeveloperDashboard',
      };
      navigate(roleRoutes[values.Role] || '/');
    }
  }, [isAuthenticated, navigate, values.Role]);

  const handleInput = (event) => {
    const { name, value } = event.target;
    setValues((prevValues) => ({
      ...prevValues,
      [name]: value,
    }));
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    const validationErrors = Validation(values);
    setErrors(validationErrors);
    setServerError(''); // Reset server error message

    if (Object.keys(validationErrors).length === 0) {
      setLoading(true); // Start loading
      try {
        let apiUrl = 'http://13.127.57.224:2081/login'; // Default API for other roles

        // Check for developer role and use the dev login API if applicable
        if (values.Role === 'developer') {
          apiUrl = 'http://13.127.57.224:2081/logindev';
        }

        const response = await axios.post(apiUrl, values);

        if (response.status === 200) {
          login(values.Role);  // Call login function from AuthContext to set isAuthenticated to true
          const roleRoutes = {
            administrator: '/DashBoard',
            admin: '/DashBoard',
            staff: '/Staff_Dashbord',
            student: '/Student_Dashboard',
            developer: '/DeveloperDashboard', // New route for developer
          };
          navigate(roleRoutes[values.Role] || '/');
        } else {
          setServerError('Authentication failed: ' + response.data.message);
        }
      } catch (error) {
        if (error.response) {
          const { status, data } = error.response;

          if (status === 401) setServerError(data.error || 'Invalid Password');
          else if (status === 404) setServerError(data.error || 'UserName not registered');
          else setServerError(data.error || 'Unexpected error occurred');
        } else {
          setServerError('Network error. Please try again.');
        }
      } finally {
        setLoading(false); // Stop loading
      }
    }
  };

  return (
    <div className="Login_Container">
      <div className="Login_FormWrapper">
        <Link to="/" style={{ textDecoration: 'none' }}>
          <div className="Login_LogoContainer">
            <img src="02 1.jpg" alt="Logo" className="Login_LogoImage" />
            <span className="Login_LogoText">EDU360</span>
          </div>
        </Link>

        <h4 className="Login_SubHeading">Login To Your Account</h4>
        <form onSubmit={handleSubmit} className="Login_Form">
          {serverError && <p className="Login_Message">{serverError}</p>}
          <div className="Login_InputWrapper">
            <span className="Login_IconWrapper">
              <FiMail />
            </span>
            {errors.UserName && <p className="Login_Message">{errors.UserName}</p>}
            <input
              type="text"
              placeholder="Enter UserName"
              name="UserName"
              onChange={handleInput}
              value={values.UserName}
              className="Login_Input"
              required
            />
          </div>
          <div className="Login_InputWrapper">
            <span className="Login_IconWrapper">
              <FiLock />
            </span>
            {errors.Password && <p className="Login_Message">{errors.Password}</p>}
            <input
              type={showPassword ? 'text' : 'password'}
              placeholder="Enter Password"
              name="Password"
              onChange={handleInput}
              value={values.Password}
              className="Login_Input"
              required
            />
            <span className="Login_IconWrapperEye" onClick={togglePasswordVisibility}>
              {showPassword ? <FiEyeOff /> : <FiEye />}
            </span>
          </div>
          <div className="Login_InputWrapper">
            <span className="Login_IconWrapperSelect">
              <FiUser />
            </span>
            <select
              name="Role"
              onChange={handleInput}
              value={values.Role}
              className="Login_Select"
            >
              <option value="administrator">ADMINISTRATOR</option>
              <option value="admin">ADMIN</option>
              <option value="staff">STAFF</option>
              <option value="student">STUDENT</option>
              <option value="developer">DEVELOPER</option> {/* Added developer role */}
            </select>
          </div>
          <button type="submit" className="Login_Button" disabled={loading}>
            {loading ? <div className="Login_Loader"></div> : 'Login'}
          </button>
          <Link to="/signup" className="Login_LinkStyled">
            Don't have an account? <span>Signup</span>
          </Link>
        </form>
      </div>
    </div>
  );
}

export default Login;
