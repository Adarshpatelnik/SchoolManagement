
 
import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faUserGraduate, faChalkboardTeacher, faClipboard, faBookOpen } from '@fortawesome/free-solid-svg-icons';
import './Security.css';
 
// Card Component to reuse for each service
const ServiceCard = ({ icon, title, description }) => {
  return (
    <div className="col-md-4">
      <div className="info-card">
        <FontAwesomeIcon icon={icon} size="2x" className="Services_icon" />
        <h2 className="info-card-title">{title}</h2>
        <p className="info-card-description">{description}</p>
      </div>
    </div>
  );
};
 
const Services = () => {
  const services = [
    {
      id: 1,
      icon: faUserGraduate,
      title: 'Student Management',
      description: 'Managing student enrollment, attendance, grades, behavior, and communication'
    },
    {
      id: 2,
      icon: faChalkboardTeacher,
      title: 'Teacher Management',
      description: 'Streamlining teacher schedules, performance evaluations, and professional development'
    },
    {
      id: 3,
      icon: faClipboard,
      title: 'Attendance Management',
      description: 'Effortlessly monitor student and staff attendance with precision.'
    },
    {
      id: 4,
      icon: faBookOpen,
      title: 'Academic Management',
      description: 'Academic management encompasses curriculum development, teaching methodologies, assessments, teacher training, and student progress monitoring.'
    },
  ];
 
  return (
    <div className="services_container">
      <div className="services_row">
        <div className="services_header">
          <h2 className="section-title">Our Services</h2>
          <img src="girl_services copy.png" alt="A person engaging with educational services" className="section-image" />
        </div>
      </div>
 
      <div className="row justify-content-center service-cards">
        {services.map(service => (
          <ServiceCard
            key={service.id}
            icon={service.icon}
            title={service.title}
            description={service.description}
          />
        ))}
      </div>
    </div>
  );
};
 
export default Services;
 
 
 

