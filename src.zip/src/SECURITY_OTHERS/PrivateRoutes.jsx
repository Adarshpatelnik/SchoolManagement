// // PrivateRoutes.js

// import React, { useContext } from 'react';
// import { Navigate, Outlet } from 'react-router-dom';
// import { AuthContext } from './AuthContext';

// const PrivateRoutes = () => {
//   const { isAuthenticated } = useContext(AuthContext);

//   return isAuthenticated ? <Outlet /> : <Navigate to="/Login" />;
// };

// export default PrivateRoutes;


import React, { useContext } from 'react';
import { Navigate, Outlet } from 'react-router-dom';
import { AuthContext } from './AuthContext';

const PrivateRoutes = ({ requiredRoles }) => {
  const { isAuthenticated, role } = useContext(AuthContext);

  if (!isAuthenticated) {
    return <Navigate to="/Login" />;
  }

  // Check if the user has the required role
  if (requiredRoles && !requiredRoles.includes(role)) {
    return <Navigate to="/NotFound" />;
  }

  return <Outlet />;
};

export default PrivateRoutes;
