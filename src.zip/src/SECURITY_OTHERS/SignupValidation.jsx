


// validation.js

function SignupValidation(values) {
  let errors = {};

  // Regular expressions for validation
  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  const passwordPattern = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])[a-zA-Z0-9]{8,}$/;
  const mobilePattern = /^[0-9]{10}$/;

  // FullName validation
  if (!values.FullName.trim()) {
    errors.FullName = "Full Name should not be empty";
  }

  // SchoolName validation
  if (!values.SchoolName.trim()) {
    errors.SchoolName = "School Name should not be empty";
  }

  // SchoolBranch validation
  if (!values.SchoolBranch.trim()) {
    errors.SchoolBranch = "School Branch should not be empty";
  }

  // City validation
  if (!values.City.trim()) {
    errors.City = "City should not be empty";
  }

  // State validation
  if (!values.State.trim()) {
    errors.State = "State should not be empty";
  }

  // PostalCode validation
  if (!values.PostalCode.trim()) {
    errors.PostalCode = "Postal Code should not be empty";
  } else if (!/^\d{5,6}$/.test(values.PostalCode)) {
    errors.PostalCode = "Postal Code should be 5 or 6 digits";
  }

  // MobileNumber validation
  if (!values.MobileNumber.trim()) {
    errors.MobileNumber = "Mobile Number should not be empty";
  } else if (!mobilePattern.test(values.MobileNumber)) {
    errors.MobileNumber = "Mobile Number should be 10 digits";
  }

  // UserName validation
  if (!values.UserName.trim()) {
    errors.UserName = "User Name should not be empty";
  }

  // Email validation
  if (!values.Email.trim()) {
    errors.Email = "Email should not be empty";
  } else if (!emailPattern.test(values.Email)) {
    errors.Email = "Email is not valid";
  }

  // Password validation
  if (!values.Password.trim()) {
    errors.Password = "Password should not be empty";
  } else if (!passwordPattern.test(values.Password)) {
    errors.Password = "Password must contain at least one digit, one lowercase letter, one uppercase letter, and be at least 8 characters long";
  }

  return errors;
}

export default SignupValidation;