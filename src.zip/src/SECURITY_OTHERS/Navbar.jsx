
import React, { useState, useEffect, useRef } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faHome, faEnvelope, faUser, faBriefcase , faUserPlus} from '@fortawesome/free-solid-svg-icons';
import { Link } from 'react-router-dom';
import { Link as ScrollLink } from 'react-scroll';
import './Security.css'; // Import the external CSS file
 
const Navbar = () => {
  const [activeDropdown, setActiveDropdown] = useState(null);
  const [isSmallScreen, setIsSmallScreen] = useState(window.innerWidth < 768); // Assuming Bootstrap breakpoint for small screens
  const HomeRef = useRef(null);
 
  const handleDropdownToggle = (dropdownId) => {
    setActiveDropdown(activeDropdown === dropdownId ? null : dropdownId);
  };
 
  const handleMouseOver = (event) => {
    event.target.style.fontWeight = 'bold';
    event.target.style.textDecoration = 'none';
  };
 
  const handleMouseOut = (event) => {
    event.target.style.fontWeight = 'normal';
    event.target.style.textDecoration = 'none';
  };
 
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (HomeRef.current && !HomeRef.current.contains(event.target)) {
        setActiveDropdown(null);
      }
    };
 
    document.addEventListener('mousedown', handleClickOutside);
 
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);
 
  useEffect(() => {
    const handleResize = () => {
      setIsSmallScreen(window.innerWidth < 768); // Assuming Bootstrap breakpoint for small screens
    };
 
    window.addEventListener('resize', handleResize);
 
    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);
 
  const refreshPage = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  };
 
  return (
    <div>
      <div className="navbar-container">
        <nav className={`navbar navbar-expand-lg navbar-light mb-1 ${isSmallScreen && activeDropdown ? 'bg-transparent' : 'bg-white'}`}
          style={{ padding: '10px 20px' }}>
          <Link className="navbar-brand student-management-link" to="/" onClick={refreshPage}>
            <img src="02 1.jpg" alt="B2B360 Logo" />
            <span>EDU360</span>
          </Link>
 
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarNav"
            aria-controls="navbarNav"
            aria-expanded={activeDropdown !== null}
            aria-label="Toggle navigation"
            onClick={() => handleDropdownToggle('navbarNav')}
          >
            <span className="navbar-toggler-icon"></span>
          </button>
 
          <div className={`collapse navbar-collapse justify-content-end ${activeDropdown ? 'show' : ''}`} id="navbarNav" ref={HomeRef}>
            <ul className="navbar-nav">
              <li className="nav-item">
                <ScrollLink
                  to="top"
                  spy={true}
                  smooth={true}
                  offset={-70}
                  duration={600}
                  className="nav-link student-management-link"
                  style={activeDropdown === 'Home' ? { fontWeight: 'bold' } : {}}
                  onMouseOver={handleMouseOver}
                  onMouseOut={handleMouseOut}
                  label="Home"
                  onClick={() => { handleDropdownToggle('Home'); refreshPage(); }}
                >
                  <FontAwesomeIcon icon={faHome} className="Navbar_icon" />
                  Home
                </ScrollLink>
              </li>
              <li className="nav-item">
                <ScrollLink
                  to="Services"
                  spy={true}
                  smooth={true}
                  offset={-68}
                  duration={100}
                  className="nav-link student-management-link"
                  style={activeDropdown === 'Services' ? { fontWeight: 'bold' } : {}}
                  onMouseOver={handleMouseOver}
                  onMouseOut={handleMouseOut}
                   label="Services"
                  onClick={() => handleDropdownToggle('Services')}
                >
                  <FontAwesomeIcon icon={faBriefcase} className="Navbar_icon" />
                  Services
                </ScrollLink>
              </li>
              <li className="nav-item">
                <ScrollLink
                  to="Contact"
                  spy={true}
                  smooth={true}
                  offset={-60}
                  duration={100}
                  className="nav-link student-management-link"
                  style={activeDropdown === 'Contact' ? { fontWeight: 'bold' } : {}}
                  onMouseOver={handleMouseOver}
                  onMouseOut={handleMouseOut}
                   label="Contact Us"
                  onClick={() => handleDropdownToggle('Contact')}
                >
                  <FontAwesomeIcon icon={faEnvelope} className="Navbar_icon" />
                  Contact Us
                </ScrollLink>
              </li>
              <li className="nav-item">
                <Link to="/Login" className="btn btn-login nav-link" aria-label="Login link">
                  <FontAwesomeIcon icon={faUser} className="Navbar_icon" />
                  Login
                </Link>
              </li>
              <li className="nav-item">
                <Link to="/Signup" className="btn btn-signup nav-link"  aria-label="Signup link">
                  <FontAwesomeIcon icon={faUserPlus} className="Navbar_icon" />
                  Signup
                </Link>
              </li>
            </ul>
          </div>
        </nav>
      </div>
    </div>
  );
};
 
export default Navbar;
 
