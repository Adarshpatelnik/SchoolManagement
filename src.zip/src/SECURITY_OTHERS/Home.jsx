
import React, { Suspense } from 'react';
import { Link as Element } from 'react-scroll';
import Navbar from './Navbar.jsx';
// import MissionVision from './MissionVision.js';
// import Contact from './Contact.js';
// import Aboutus from './About_us.js';
// import Services from './Services.js';
import Footer from './Footer.jsx';
import './Security.css'; // Import the Security.css file
 
const MissionVision = React.lazy(() => import('./MissionVision.jsx'));
const Aboutus = React.lazy(() => import('./About_us.jsx'));
const Services = React.lazy(() => import('./Services.jsx'));
const Contact = React.lazy(() => import('./Contact.jsx'));
 
const mediaContent = {
  type: "video",
  src: "vdo_type.mp4",
  text: "Education is the passport to the future."
};
 
const Home = () => {
  return (
    <div>
      <Navbar />
      <div className="container-fluid" style={{ marginTop: '10vh', width: '100%', padding: 0 }}>
        <div className="media-container">
          <video src={mediaContent.src} autoPlay loop muted />
          <div className="overlay-text">{mediaContent.text}</div>
        </div>
        <Suspense fallback={<div>Loading Mission & Vision...</div>}>
  <MissionVision />
</Suspense>
<Suspense fallback={<div>Loading About Us...</div>}>
  <Aboutus />
</Suspense>
<Suspense fallback={<div>Loading Services...</div>}>
  <Element name="Services">
    <Services />
  </Element>
</Suspense>
<Suspense fallback={<div>Loading Contact...</div>}>
  <Element name="Contact">
    <Contact />
  </Element>
</Suspense>
 
        <div className="container-fluid">
          <div className="Home_footer-border">
            <div className="container-fluid"></div>
            <Footer />
          </div>
        </div>
      </div>
    </div>
  );
};
 
export default Home;
 

 
