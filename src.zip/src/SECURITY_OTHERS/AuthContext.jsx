
// import React, { createContext, useState, useEffect, useContext } from 'react';
 
// export const AuthContext = createContext();
 
// export const AuthProvider = ({ children }) => {
//   const [isAuthenticated, setIsAuthenticated] = useState(
//     sessionStorage.getItem('isAuthenticated') === 'true'
//   );
 
//   useEffect(() => {
//     const storedAuth = sessionStorage.getItem('isAuthenticated') === 'true';
//     setIsAuthenticated(storedAuth);
//   }, []);
 
//   const login = () => {
//     setIsAuthenticated(true);
//     sessionStorage.setItem('isAuthenticated', 'true');
//   };
 
//   const logout = () => {
//     setIsAuthenticated(false);
//     sessionStorage.removeItem('isAuthenticated');
//   };
 
//   return (
//     <AuthContext.Provider value={{ isAuthenticated, login, logout }}>
//       {children}
//     </AuthContext.Provider>
//   );
// };
 
// // Custom hook to use the auth context
// export const useAuth = () => {
//   return useContext(AuthContext);
// };
 

import React, { createContext, useState, useEffect, useContext } from 'react';

export const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(sessionStorage.getItem('isAuthenticated') === 'true');
  const [role, setRole] = useState(sessionStorage.getItem('role') || ''); // Add role state

  useEffect(() => {
    const storedAuth = sessionStorage.getItem('isAuthenticated') === 'true';
    const storedRole = sessionStorage.getItem('role') || '';
    setIsAuthenticated(storedAuth);
    setRole(storedRole);
  }, []);

  const login = (role) => {
    setIsAuthenticated(true);
    setRole(role);
    sessionStorage.setItem('isAuthenticated', 'true');
    sessionStorage.setItem('role', role);
  };

  const logout = () => {
    setIsAuthenticated(false);
    setRole('');
    sessionStorage.removeItem('isAuthenticated');
    sessionStorage.removeItem('role');
  };

  return (
    <AuthContext.Provider value={{ isAuthenticated, role, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

// Custom hook to use the auth context
export const useAuth = () => {
  return useContext(AuthContext);
};
