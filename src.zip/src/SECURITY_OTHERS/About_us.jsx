


import React from 'react';
import './Security.css'; // Import the CSS file
 
const Aboutus = () => {
  return (
    <div className="about_container">
      <div className="about_row">
        <div className="image-column">
          <div className="discover-image">
            <img
              alt="girl.png"
              loading="lazy"
              className="image"
              src="blackboard-1299841_1280.png"
            />
          </div>
        </div>
        <div className="content-column">
          <div className="discover-content">
            <h1 className="title">About Us</h1>
            <p className="text">
              BitTwoBye is a technology and professional services company specializing in analytics, operations, and product engineering. Through B2B EDU360, we facilitate the seamless transition of your school's management platform online, ensuring 24/7 accessibility. Our comprehensive solution efficiently manages vital administrative tasks, including grading, student attendance, exams and results, employee records and payroll, fee management, accounting, certificate issuance, front office operations, and transportation logistics, empowering educational institutions to enhance efficiency and deliver exceptional academic experiences.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
 
export default Aboutus;
 
