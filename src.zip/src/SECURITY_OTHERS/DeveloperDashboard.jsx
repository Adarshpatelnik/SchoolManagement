

import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

function DeveloperDashboard() {
  const [schoolData, setSchoolData] = useState([]);
  const [selectedSchool, setSelectedSchool] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  // Fetch school data on component mount
  useEffect(() => {
    const fetchSchoolData = async () => {
      setLoading(true);
      try {
        const response = await axios.get('http://13.127.57.224:2081/api/schooldata');
        setSchoolData(response.data);
      } catch (error) {
        handleError('Failed to load school data. Please try again later.', error);
      } finally {
        setLoading(false);
      }
    };

    fetchSchoolData();
  }, []);

  // Handle dropdown change
  const handleSchoolChange = (event) => {
    setSelectedSchool(event.target.value);
  };

  // Handle the next button click
  const handleNextClick = async () => {
    if (selectedSchool) {
      try {
        const response = await axios.post('http://13.127.57.224:2081/login/developer', { school: selectedSchool });
        
        if (response.status === 200) {
          navigate('/DashBoard');
        } else {
          setErrorMessage('Failed to select the school. Please try again.');
        }
      } catch (error) {
        handleError('Something went wrong while selecting the school.', error);
      }
    }
  };

  // Error handling function to log and set error message
  const handleError = (message, error) => {
    setErrorMessage(message);
    console.error(message, error);
    // Call a global error handler or send an error report (email/logging)
  };

  return (
    <div style={styles.dashboardContainer}>
      <h1 style={styles.heading}>Hi Developer</h1>
      <p style={styles.paragraph}>Welcome to your developer dashboard!</p>

      {loading ? (
        <p style={styles.paragraph}>Loading school data...</p>
      ) : (
        <>
          {errorMessage && <p style={styles.error}>{errorMessage}</p>}

          <div>
            <label htmlFor="school-select" style={styles.label}>
              Select School:
            </label>
            <select
              id="school-select"
              value={selectedSchool}
              onChange={handleSchoolChange}
              style={styles.select}
            >
              <option value="">-- Select a school --</option>
              {schoolData.map((school) => (
                <option key={school.DATABASE_NAME} value={school.DATABASE_NAME}>
                  {school.DATABASE_NAME}
                </option>
              ))}
            </select>
          </div>

          <button
            onClick={handleNextClick}
            style={styles.button}
            disabled={!selectedSchool}
          >
            Next
          </button>
        </>
      )}
    </div>
  );
}

// CSS-in-JS Styles
const styles = {
  dashboardContainer: {
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'center',
    height: '100vh',
    backgroundColor: '#f4f4f9',
    fontFamily: 'Arial, sans-serif',
    padding: '20px',
  },
  heading: {
    fontSize: '3rem',
    color: '#2d2d2d',
    textAlign: 'center',
  },
  paragraph: {
    fontSize: '1.5rem',
    color: '#555',
    textAlign: 'center',
    maxWidth: '600px',
  },
  error: {
    color: 'red',
    fontSize: '1.2rem',
    marginBottom: '20px',
  },
  label: {
    fontSize: '1.2rem',
    marginRight: '10px',
  },
  select: {
    fontSize: '1rem',
    padding: '10px',
  },
  button: {
    marginTop: '20px',
    padding: '10px 20px',
    fontSize: '1rem',
    backgroundColor: '#007bff',
    color: '#fff',
    border: 'none',
    cursor: 'pointer',
    opacity: '1',
    transition: 'opacity 0.3s',
  },
};

export default DeveloperDashboard;
