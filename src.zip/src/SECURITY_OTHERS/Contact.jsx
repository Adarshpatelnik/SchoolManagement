

import React, { useState, useEffect, useRef } from 'react';
import emailjs from 'emailjs-com';
import './Security.css';
 
const Contact = () => {
  const [phoneNumber, setPhoneNumber] = useState('');
  const [generatedCode, setGeneratedCode] = useState('');
  const [formSubmitted, setFormSubmitted] = useState(false);
  const [formComplete, setFormComplete] = useState(false);
 
  const [formFields, setFormFields] = useState({
    fullName: '',
    email: '',
    schoolName: '',
    schoolAddress: ''
  });
 
  useEffect(() => {
    generateCode('USA');
  }, []);
 
  useEffect(() => {
    const allFieldsFilled = Object.values(formFields).every(field => field !== '') && phoneNumber !== '';
    setFormComplete(allFieldsFilled);
  }, [formFields, phoneNumber]);
 
  const generateCode = (country) => {
    let code = '';
    switch (country) {
      default:
        code = ''; // Default country code
        break;
    }
    setGeneratedCode(code);
  };
 
  const handlePhoneNumberChange = (e) => {
    const value = e.target.value;
    const newPhoneNumber = value.startsWith(generatedCode) ? value.substring(generatedCode.length) : value;
    setPhoneNumber(generatedCode + newPhoneNumber);
  };
 
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormFields(prevFields => ({
      ...prevFields,
      [name]: value
    }));
  };
 
  const form = useRef();
 
  const sendEmail = (e) => {
    e.preventDefault();
 
    emailjs
      .sendForm('service_a6w89qh', 'template_r079207', form.current, 'ruNn-W1LNZy9t1sLM')
      .then(
        (result) => {
          console.log('SUCCESS!', result.text);
          form.current.reset();
          setPhoneNumber('');
          setFormFields({
            fullName: '',
            email: '',
            schoolName: '',
            schoolAddress: ''
          });
          setFormSubmitted(true);
        },
        (error) => {
          console.log('FAILED...', error.text);
          alert('Failed to send email. Please try again.');
        }
      );
  };
 
  return (
    <div className="Contact_container">
      <div className="Contact_content">
        <h1 className="Contact_heading">CONTACT US</h1>
        <div className="Contact_description"> Get in touch with BitTwoByte </div>
        <div className="Contact_form-container">
          {formSubmitted ? (
            <div className="success-message">
              <h2>Thank you for your submission!</h2>
              <p>We'll get back to you as soon as possible.</p>
            </div>
          ) : (
            <form ref={form} onSubmit={sendEmail} className="Contact_form">
              <input
                type="text"
                placeholder="Enter your full name"
                name="fullName"
                value={formFields.fullName}
                onChange={handleInputChange}
                required
                className="Contact_input"
              />
              <input
                type="email"
                placeholder="Enter your email"
                name="email"
                value={formFields.email}
                onChange={handleInputChange}
                required
                className="Contact_input"
              />
              <input
                type="tel"
                placeholder="Enter your number"
                name="phoneNumber"
                value={phoneNumber}
                onChange={handlePhoneNumberChange}
                required
                className="Contact_input"
              />
              <input
                type="text"
                placeholder="School Name"
                name="schoolName"
                value={formFields.schoolName}
                onChange={handleInputChange}
                required
                className="Contact_input"
              />
              <input
                type="text"
                placeholder="School Address"
                name="schoolAddress"
                value={formFields.schoolAddress}
                onChange={handleInputChange}
                required
                className="Contact_input"
              />
              <button type="submit" className={`Contact_submit-button ${formComplete ? 'complete' : ''}`}>Submit</button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
 
export default Contact;
 



