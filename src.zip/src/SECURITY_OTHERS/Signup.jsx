

import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import {
  FiMail,
  FiLock,
  FiUser,
  FiMap,
  FiBook,
  FiMapPin,
  FiPhone,
  FiEye,
  FiEyeOff,
  FiHome,
  FiHash,
  FiMap as FiState,
} from 'react-icons/fi';
import SignupValidation from './SignupValidation';
import './Security.css'

const InputField = React.memo(({ type, placeholder, name, value, onChange, Icon, required }) => (
  <div className="Signup_inputWrapper">
    <span className="Signup_iconWrapper">
      <Icon />
    </span>
    <input
      type={type}
      placeholder={placeholder}
      name={name}
      value={value}
      onChange={onChange}
      className="Signup_input"
      required={required}
    />
  </div>
));

const initialValues = {
  FullName: '',
  SchoolName: '',
  SchoolBranch: '',
  SchoolCode: '',
  City: '',
  State: '',
  PostalCode: '',
  Email: '',
  MobileNumber: '',
  UserName: '',
  Password: '',
  Role: 'administrator',
};

function Signup() {
  const [values, setValues] = useState(initialValues);
  const [showPassword, setShowPassword] = useState(false);
  const [status, setStatus] = useState({ loading: false, success: false, error: '' });
  const navigate = useNavigate();

  const handleInput = ({ target: { name, value } }) =>
    setValues((prev) => ({ ...prev, [name]: value }));

  const togglePasswordVisibility = () => {
    setShowPassword((prev) => !prev);
  };

  const handleSubmit = async (event) => {
    event.preventDefault();

    const errors = SignupValidation(values);

    if (Object.keys(errors).length > 0) {
      setStatus({ loading: false, success: false, error: Object.values(errors).join(', ') });
      return;
    }

    setStatus({ loading: true, success: false, error: '' });

    try {
      const response = await axios.post('http://13.127.57.224:2081/signup', values);

      if (response.status === 201) {
        alert('Signup successfully!');
        setValues(initialValues);
        setStatus({ loading: false, success: true, error: '' });
        setTimeout(() => navigate('/login'), 1000);
      } else {
        throw new Error('Unexpected response. Please try again.');
      }
    } catch (error) {
      const errorMessage = error.response?.data?.error || 'An error occurred. Please try again.';
      setStatus({ loading: false, success: false, error: errorMessage });
    }
  };

  const inputFields = [
    { type: 'text', placeholder: 'Enter Full Name', name: 'FullName', Icon: FiUser, required: true },
    { type: 'text', placeholder: 'Enter School Name', name: 'SchoolName', Icon: FiBook, required: true },
    { type: 'text', placeholder: 'Enter School Branch', name: 'SchoolBranch', Icon: FiMap, required: false },
    { type: 'text', placeholder: 'Enter School Code', name: 'SchoolCode', Icon: FiHash, required: true },
    { type: 'text', placeholder: 'Enter City', name: 'City', Icon: FiMapPin, required: false },
    { type: 'text', placeholder: 'Enter State', name: 'State', Icon: FiState, required: true },
    { type: 'text', placeholder: 'Enter Postal Code', name: 'PostalCode', Icon: FiHome, required: true },
    { type: 'email', placeholder: 'Enter Email', name: 'Email', Icon: FiMail, required: true },
    { type: 'text', placeholder: 'Enter Mobile Number', name: 'MobileNumber', Icon: FiPhone, required: true },
    { type: 'text', placeholder: 'Enter Username', name: 'UserName', Icon: FiUser, required: true },
  ];

  return (
    <div className="Signup_container">
      <div className="Signup_formWrapper">
        <h1 className="Signup_logoText">Create an Account</h1>
        <form onSubmit={handleSubmit} className="Signup_form">
          {inputFields.map(({ type, placeholder, name, Icon, required }) => (
            <InputField
              key={name}
              type={type}
              placeholder={placeholder}
              name={name}
              value={values[name]}
              onChange={handleInput}
              Icon={Icon}
              required={required}
            />
          ))}
          <div className="Signup_inputWrapper">
            <span className="Signup_iconWrapper">
              <FiLock />
            </span>
            <input
              type={showPassword ? 'text' : 'password'}
              placeholder="Enter Password"
              name="Password"
              value={values.Password}
              onChange={handleInput}
              className="Signup_input"
              required
            />
            <span
              className="Signup_iconWrapper_password"
              onClick={togglePasswordVisibility}
              style={{ cursor: 'pointer' }}
            >
              {showPassword ? <FiEyeOff /> : <FiEye />}
            </span>
          </div>
          <div className="Signup_Submit_Button_div">
            <button type="submit" className="Signup_button" disabled={status.loading}>
              {status.loading ? (
                <>
                  Loading <span className="signup_Loader"></span>
                </>
              ) : status.success ? (
                'Success!'
              ) : (
                'Sign Up'
              )}
            </button>
          </div>
        </form>
        {status.error && <p className="Signup_message">{status.error}</p>}
        {status.success && <p className="Signup_successMessage">Signup Successful!</p>}
        <Link to="/login" className="Signup_linkStyled">
          Already have an account? <span>Login</span>
        </Link>
      </div>
    </div>
  );
}

export default Signup;