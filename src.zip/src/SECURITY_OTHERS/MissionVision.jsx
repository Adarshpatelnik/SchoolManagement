
import React, { useState, useEffect } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faBullseye, faEye } from '@fortawesome/free-solid-svg-icons';
import './Security.css';  // Import the Security.css file
 
const MissionVision = () => {
  const [pointerPosition, setPointerPosition] = useState(0);
 
  useEffect(() => {
    const interval = setInterval(() => {
      const newPointerPosition = (pointerPosition + 1) % 101;
      setPointerPosition(newPointerPosition);
    }, 50);
 
    return () => clearInterval(interval);
  }, [pointerPosition]);
 
  return (
    <div className="mission-vision-container">
      <div className="mission-vision-header">
        <h2>Empowering Tomorrow</h2>
        <img src="pencil.png" alt="Empowering Tomorrow" />
      </div>
 
      <div className="mission-vision-bar">
        <div className="mission-vision-pointer" style={{ left: `${pointerPosition}%` }}></div>
      </div>
 
      <div className="mission_vision_row">
        <div className="col-md-4" style={{ textAlign: 'center' }}>
          <div className="mission-card">
            <div className="mission-card-content">
              <FontAwesomeIcon icon={faBullseye} size="3x" style={{ marginBottom: '10px', color: '#27AE60' }} />
              <h2 className="mission-card-title">Our Mission</h2>
              <p className="mission-card-text">
                To empower educational institutions with innovative technology solutions that enhance learning outcomes and operational efficiency.
              </p>
            </div>
            <div className="gradient-overlay"></div>
          </div>
        </div>
 
        <div className="col-md-4" style={{ textAlign: 'center' }}>
          <div className="vision-card">
            <div className="mission-card-content">
              <FontAwesomeIcon icon={faEye} size="3x" style={{ marginBottom: '10px', color: '#27AE60' }} />
              <h2 className="mission-card-title">Our Vision</h2>
              <p className="mission-card-text">
                To be the leading provider of comprehensive school management solutions globally, driving educational excellence through technology.
              </p>
            </div>
            <div className="gradient-overlay"></div>
          </div>
        </div>
      </div>
    </div>
  );
};
 
export default MissionVision;
 
 