import React from 'react';
import { useNavigate } from 'react-router-dom';
import Button from 'react-bootstrap/Button';
import 'bootstrap/dist/css/bootstrap.min.css';

const NotFound = () => {
  const navigate = useNavigate();

  const goHome = () => {
    navigate('/');
  };

  return (
    <div className="d-flex flex-column align-items-center justify-content-center vh-100">
      <h1 className="display-4 text-danger">404 - Page Not Found</h1>
      <p className="lead">The page you are looking for does not exist.</p>
      <Button variant="primary" onClick={goHome}>
        Go to Home
      </Button>
    </div>
  );
};

export default NotFound;
