

import React, { useState, useEffect } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import styled from 'styled-components';
import Staffnavbar from './Staff_navbar.jsx';

const Container = styled.div`
  width: 100%;
  padding: 20px;
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
`;
 
const Card = styled.div`
  max-width: 900px;
  margin: 0 auto;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
  border-radius: 12px;
  overflow: hidden;
  background: #ffffff;
`;
 
const CardHeader = styled.div`
  background: linear-gradient(to right, #012353, #27AE60);
  color: white;
  padding: 20px;
  text-align: center;
`;
 
const Title = styled.h1`
  font-size: 2rem;
  font-weight: 700;
  margin: 0;
`;
 
const CardBody = styled.div`
  padding: 20px;
  background-color: #f8f9fa;
`;
 
const FormGroup = styled.div`
  margin-bottom: 1.5rem;
`;
 
const FormLabel = styled.label`
  font-size: 1.1rem;
  font-weight: 600;
  margin-bottom: 0.5rem;
  color: #2c3e50;
  display: block;
`;
 
const FormControl = styled.input`
  width: 100%;
  height: 45px;
  font-size: 1rem;
  padding: 0.75rem;
  border: 1px solid #ced4da;
  border-radius: 5px;
  transition: border-color 0.3s ease, box-shadow 0.3s ease;
 
  &:focus {
    border-color: #3498db;
    box-shadow: 0 0 0 0.2rem rgba(52, 152, 219, 0.25);
    outline: none;
  }
`;
 
const FormSelect = styled.select`
  width: 100%;
  height: 45px;
  font-size: 1rem;
  padding: 0.75rem;
  border: 1px solid #ced4da;
  border-radius: 5px;
  transition: border-color 0.3s ease, box-shadow 0.3s ease;
 
  &:focus {
    border-color: #3498db;
    box-shadow: 0 0 0 0.2rem rgba(52, 152, 219, 0.25);
    outline: none;
  }
`;
 
const RadioButtonLabel = styled.label`
  font-size: 1rem;
  display: flex;
  align-items: center;
  margin-right: 15px;
  color: #2c3e50;
`;
 
const RadioButtonInput = styled.input`
  margin-right: 8px;
`;
 
const SubmitButton = styled.button`
  background: linear-gradient(to right, #012353, #27AE60);
  color: white;
  border: none;
  padding: 10px 50px;
  font-size: 1.2rem;
  cursor: pointer;
  border-radius: 5px;
  transition: background 0.3s ease, transform 0.3s ease, box-shadow 0.3s ease;
 
  &:hover {
    background: linear-gradient(to right, #2980b9, #27ae60);
    transform: scale(1.05);
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
  }
 
  &:active {
    background: linear-gradient(to right, #1f618d, #1e8449);
  }
 
  display: block;
  margin: 20px auto 0 auto;
`;
 
const Notification = styled.div`
  padding: 10px;
  margin-top: 10px;
  border-radius: 5px;
  color: white;
  background-color: ${props => (props.success ? '#27AE60' : '#e74c3c')};
`;
 
const StaffAssignmentForm = () => {
  const [formData, setFormData] = useState({
    Class: '',
    Subject: '',
    AssignmentType: '',
    AssignmentDescription: '',
    SubmissionStartDate: null,
    SubmissionEndDate: null,
    ClassOptions: [],
    SubjectOptions: {},
    filteredSubjects: []
  });
 
  const [assignments, setAssignments] = useState([]);
  const [notification, setNotification] = useState({ show: false, success: false, message: '' });
 
  useEffect(() => {
    fetch('http://13.127.57.224:2081/api/assignment')
      .then(response => response.json())
      .then(data => {
        if (Array.isArray(data)) {
          const classOptions = Array.from(new Set(data.map(item => item.CLASS_ID)));
          const subjectOptions = data.reduce((acc, item) => {
            if (!acc[item.CLASS_ID]) {
              acc[item.CLASS_ID] = [];
            }
            acc[item.CLASS_ID].push(item.SUBJECT_NAME);
            return acc;
          }, {});
 
          setFormData(prevState => ({
            ...prevState,
            ClassOptions: classOptions,
            SubjectOptions: subjectOptions
          }));
        }
      })
      .catch(error => console.error('Error fetching data:', error));
  }, []);
 
  const handleChange = (e) => {
    const { id, value } = e.target;
    setFormData(prevState => {
      const updatedFormData = { ...prevState, [id]: value };
 
      if (id === 'Class') {
        const selectedSubjects = prevState.SubjectOptions[value] || [];
        return {
          ...updatedFormData,
          filteredSubjects: selectedSubjects,
          Subject: ''
        };
      }
      return updatedFormData;
    });
  };
 
  const handleDateChange = (date, id) => {
    setFormData(prevState => ({ ...prevState, [id]: date }));
  };
 
  const handleAssignmentTypeChange = (e) => {
    const { value } = e.target;
    setFormData(prevState => ({ ...prevState, AssignmentType: value }));
  };
 
  const validateForm = () => {
    const { Class, Subject, AssignmentType, AssignmentDescription, SubmissionStartDate, SubmissionEndDate } = formData;
    return Class && Subject && AssignmentType && AssignmentDescription && SubmissionStartDate && SubmissionEndDate;
  };
  const handleAddRow = () => {
    if (!validateForm()) {
      setNotification({ show: true, success: false, message: 'Please fill all the fields.' });
      return;
    }
 
    // Show success message immediately after clicking the submit button
    setNotification({ show: true, success: true, message: 'Submitting assignment...' });
 
    fetch('http://13.127.57.224:2081/api/assignmentdata', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(formData),
    })
      .then(response => {
        if (response.ok) {
          setNotification({ show: true, success: true, message: 'Assignment added successfully!' });
          return response.json();
        } else {
          setNotification({ show: true, success: false, message: 'Error adding assignment.' });
          throw new Error('Error adding assignment.');
        }
      })
      .then(() => {
        setAssignments([...assignments, formData]);
 
        // Clear form after success
        setFormData({
          Class: '',
          Subject: '',
          AssignmentType: '',
          AssignmentDescription: '',
          SubmissionStartDate: null,
          SubmissionEndDate: null,
          ClassOptions: formData.ClassOptions,
          SubjectOptions: formData.SubjectOptions,
          filteredSubjects: []
        });
 
        // Automatically hide success message after 3 seconds
        setTimeout(() => {
          setNotification({ show: false, success: false, message: '' });
        }, 100); // Hide after 3 seconds
      })
      .catch(error => {
        console.error('Error:', error);
        setNotification({ show: true, success: false, message: 'Error adding assignment.' });
      });
  };
 
  return (
    <>   
     <Staffnavbar />
    <Container>
      <div className="container-fluid" style={{ marginTop: '6vh' }}>
        <Card>
          <CardHeader>
            <Title>Class Assignment</Title>
          </CardHeader>
          <CardBody>
            <div className="row">
              <div className="col-md-6">
                <FormGroup>
                  <FormLabel htmlFor="Class">Class</FormLabel>
                  <FormSelect id="Class" value={formData.Class} onChange={handleChange}>
                    <option value="">Select class</option>
                    {formData.ClassOptions.map((option, index) => (
                      <option key={index} value={option}>{option}</option>
                    ))}
                  </FormSelect>
                </FormGroup>
              </div>
              <div className="col-md-6">
                <FormGroup>
                  <FormLabel htmlFor="Subject">Subject</FormLabel>
                  <FormSelect id="Subject" value={formData.Subject} onChange={handleChange}>
                    <option value="">Select subject</option>
                    {formData.filteredSubjects.map((option, index) => (
                      <option key={index} value={option}>{option}</option>
                    ))}
                  </FormSelect>
                </FormGroup>
              </div>
              <div className="col-md-6">
                <FormGroup>
                  <FormLabel>Submission Start Date</FormLabel>
                  <DatePicker
                    selected={formData.SubmissionStartDate}
                    onChange={date => handleDateChange(date, 'SubmissionStartDate')}
                    className="form-control"
                    dateFormat="dd-MM-yyyy"
                  />
                </FormGroup>
              </div>
              <div className="col-md-6">
                <FormGroup>
                  <FormLabel>Submission End Date</FormLabel>
                  <DatePicker
                    selected={formData.SubmissionEndDate}
                    onChange={date => handleDateChange(date, 'SubmissionEndDate')}
                    className="form-control"
                    dateFormat="dd-MM-yyyy"
                  />
                </FormGroup>
              </div>
              <div className="col-md-6">
                <FormGroup>
                  <FormLabel htmlFor="AssignmentType">Assignment Type</FormLabel>
                  <FormSelect id="AssignmentType" value={formData.AssignmentType} onChange={handleAssignmentTypeChange}>
                    <option value="">Select Assignment Type</option>
                    <option value="Homework">Homework</option>
                    <option value="Project">Project</option>
                    <option value="Lab Work">Lab Work</option>
                  </FormSelect>
                </FormGroup>
              </div>
              <div className="col-md-6">
                <FormGroup>
                  <FormLabel htmlFor="AssignmentDescription">Assignment Description</FormLabel>
                  <FormControl
                    id="AssignmentDescription"
                    type="text"
                    value={formData.AssignmentDescription}
                    onChange={handleChange}
                  />
                </FormGroup>
              </div>
            </div>
            {notification.show && (
              <Notification success={notification.success}>{notification.message}</Notification>
            )}
            <SubmitButton onClick={handleAddRow}>Submit</SubmitButton>
          </CardBody>
        </Card>
      </div>
    </Container>
    </>
  );
};
 
export default StaffAssignmentForm;
 
