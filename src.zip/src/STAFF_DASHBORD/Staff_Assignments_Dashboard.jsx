
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Bar } from 'react-chartjs-2';
import styled from 'styled-components';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faClipboardList as faClipboardListSolid } from '@fortawesome/free-solid-svg-icons';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Tooltip,
  Legend,
} from 'chart.js';
import ChartDataLabels from 'chartjs-plugin-datalabels';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';

ChartJS.register(CategoryScale, LinearScale, BarElement, Tooltip, Legend, ChartDataLabels);

const ChartContainer = styled.div`
  display: flex;
  justify-content: center;
  margin: 0px 0;
`;

// Other styled components...

const ChartCard = styled.div`
  width: 100%;
  max-width: 1000px;
  background-color: #ffffff;
  border-radius: 1px;
  overflow: hidden;
  transition: transform 0.3s;
 
`;



const ChartContent = styled.div`
  padding: 10px;
  min-height: 200px;
  text-align: center;
`;

const LoadingSpinner = styled.div`
  text-align: center;
  font-size: 20px;
  color: #007bff;
`;

// Chart component definition
const Chart = ({ barData, barOptions, loading, error }) => (
  <ChartCard>

    <ChartContent>
      {loading ? (
        <LoadingSpinner>Loading...</LoadingSpinner>
      ) : error ? (
        <p style={{ color: 'red' }}>Error: {error}</p>
      ) : (
        <Bar data={barData} options={barOptions} />
      )}
    </ChartContent>
  </ChartCard>
);

const StaffAssignmentsDashboard = () => {
  const navigate = useNavigate();
  const [assignments, setAssignments] = useState([]);
  const [filteredAssignments, setFilteredAssignments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchAssignmentData = async () => {
      try {
        const response = await fetch('http://13.127.57.224:2081/api/StaffAssignmentDashboard');
        if (!response.ok) throw new Error(`Error: ${response.statusText}`);
        const data = await response.json();
        setAssignments(data);
        setFilteredAssignments(data);
        setLoading(false);
      } catch (error) {
        setError(error.message);
        setLoading(false);
      }
    };

    fetchAssignmentData();
  }, []);

  const onTimeCount = filteredAssignments.reduce((acc, assignment) => acc + assignment.OnTimeAssignments, 0);
  const lateCount = filteredAssignments.reduce((acc, assignment) => acc + assignment.LateAssignments, 0);
  const upcomingCount = filteredAssignments.reduce((acc, assignment) => acc + assignment.UpcomingAssignments, 0);

  const barData = {
    labels: ['DUE TODAY', 'DUE DATE PASSED', 'DUE LATER'],
    datasets: [{
      data: [onTimeCount, lateCount, upcomingCount],
      backgroundColor: [
        'rgba(46, 204, 113, 0.6)',
        'rgba(241, 196, 15, 0.6)',
        'rgba(155, 89, 182, 0.6)',
      ],
      borderColor: [
        'rgba(39, 174, 96, 1)',
        'rgba(241, 196, 15, 1)',
        'rgba(142, 68, 173, 1)',
      ],
      borderWidth: 2,
      barThickness: 40,
    }],
  };

  const barOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false,
      },
      datalabels: {
        anchor: 'end',
        align: 'end', // This will set the label to appear right above the top of the bar
        color: '#000000', // Ensure the label color contrasts with the background
        font: {
          weight: 'bold',
          size: 16,
        },
        padding: {
          top: 10, // Increase the top padding to separate the label from the bar
        },
        formatter: (value) => value,
      },
    },
    scales: {
      y: {
        beginAtZero: true,
        suggestedMax: Math.max(onTimeCount, lateCount, upcomingCount) * 1.2, // Adjust max to create space above bars
        title: {
          display: false,
        },
      },
      x: {
        categoryPercentage: 0.4,
        barPercentage: 0.9,
      },
    },
    onClick: (event, elements) => {
      if (elements.length > 0) {
        const clickedLabel = barData.labels[elements[0].index];
        navigate(`/Staff_Assignment_List/${clickedLabel}`);
      }
    },
  };


  return (
    <div>
      <ChartContainer>
        <Chart barData={barData} barOptions={barOptions} loading={loading} error={error} />
      </ChartContainer>
    </div>
  );
};

export default StaffAssignmentsDashboard;
