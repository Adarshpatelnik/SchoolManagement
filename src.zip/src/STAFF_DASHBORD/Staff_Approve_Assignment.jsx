

import React, { useEffect, useState } from 'react';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import axios from 'axios';

function StaffApproveAssignment() {
  const [rowData, setRowData] = useState([]); // Initialize with an empty array for row data

  const columnDefs = [
    {
      headerCheckboxSelection: true, // Enables select all checkbox in header
      checkboxSelection: true, // Enables checkbox for each row
      headerName: "Select",
      width: 50,
    },
    { field: "ASSIGNMENT_ID", headerName: "Assignment ID", filter: true },
    { field: "STUDENT_ID", headerName: "Student ID", filter: true },
    { field: "STUDENT_NAME", headerName: "Student Name", filter: true },
    { field: "CLASS_ID", headerName: "Class ID", filter: true },
    { field: "SUBJECT_NAME", headerName: "Subject Name", filter: true },
    { field: "CLASS_TEACHER", headerName: "Class Teacher", filter: true },
    { field: "ASSIGNMENT_TYPE", headerName: "Assignment Type", filter: true },
    { field: "ASSIGNMENT_DESC", headerName: "Assignment Description", filter: true },
    {
      field: "SUBMISSION_START_DATE",
      headerName: "Submission Start Date",
      filter: true,
      valueFormatter: ({ value }) => formatDate(value), // Format date
    },
    {
      field: "SUBMISSION_END_DATE",
      headerName: "Submission End Date",
      filter: true,
      valueFormatter: ({ value }) => formatDate(value), // Format date
    },
    {
      field: "TeacherApprovalStatus",
      headerName: "Teacher Approval Status",
      filter: true,
    },
    {
      field: "STUDENT_SUBMITTED_DATE",
      headerName: "Student Submitted Date",
      filter: true,
      valueFormatter: ({ value }) => formatDate(value), // Format date
    },
    {
      field: "SUBMISSION_DATE",
      headerName: "Submission Date",
      filter: true,
      valueFormatter: ({ value }) => formatDate(value), // Format date
    },
    { field: "IS_SUBMITTED", headerName: "Is Submitted", filter: true },
    {
      field: "STUDENT_STATUS",
      headerName: "Student Status",
      filter: true,
    },
  ];

  // Format the date to DD-MM-YYYY format
  const formatDate = (date) => {
    if (!date) return ''; // If date is empty, return an empty string
    const d = new Date(date);
    const day = String(d.getDate()).padStart(2, '0');
    const month = String(d.getMonth() + 1).padStart(2, '0'); // Months are 0-indexed
    const year = d.getFullYear();
    return `${day}-${month}-${year}`;
  };

  useEffect(() => {
    const fetchAssignments = async () => {
      try {
        const response = await axios.get('http://13.127.57.224:2081/api/get-assignmentrecord'); // API call to fetch data
        setRowData(response.data); // Set the fetched data to rowData state
      } catch (error) {
        console.error('Error fetching assignments:', error);
      }
    };

    fetchAssignments();
  }, []);

  return (
    <> 
    <div style={{ padding: '0px' ,marginTop: 'vh' }}>
      <div className="ag-theme-alpine" style={{ height: '600px', width: '100%' }}>
        <AgGridReact
          rowData={rowData} // Assign fetched data to rowData
          columnDefs={columnDefs} // Assign column definitions
          rowSelection="multiple" // Enable multiple row selection
          domLayout="autoHeight" // Adjust table height automatically
        />
      </div>
    </div>
    </>
  );
}

export default StaffApproveAssignment;