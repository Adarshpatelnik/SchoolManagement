import React, { useState } from 'react';
import StaffAssignmentForm from './Staff_Assignment_Form';
import StaffSelectAssignment from './Staff_Select_Assignment';
import StaffApproveAssignment from './Staff_Approve_Assignment';
import StaffAssignmentTable from './Staff_Assignment_Table';
import Staffnavbar from './Staff_navbar';

const StaffMainAssignment = () => {
  // State to track which component is active
  const [activeComponent, setActiveComponent] = useState(1);

  // Function to handle the toggle based on header click
  const handleToggle = (componentNumber) => {
    setActiveComponent(componentNumber);
  };

  return (
    <>
      <Staffnavbar handleToggle={handleToggle} />
      <div className="Main_Assignment_container">
        {/* Header with toggle buttons */}
        <header className="Main_Assignment_header">
          <button 
            onClick={() => handleToggle(1)} 
            className={activeComponent === 1 ? 'active' : ''}
          >
            Assignment Form
          </button>
          <button 
            onClick={() => handleToggle(2)} 
            className={activeComponent === 2 ? 'active' : ''}
          >
            Approval
          </button>
          <button 
            onClick={() => handleToggle(4)} 
            className={activeComponent === 4 ? 'active' : ''}
          >
            Table
          </button>
          <button 
            onClick={() => handleToggle(3)} 
            className={activeComponent === 3 ? 'active' : ''}
          >
            Record
          </button> 
        </header>

        {/* Conditional rendering based on activeComponent */}
        <div className="Main_Assignment_content">
          {activeComponent === 1 && <StaffAssignmentForm />}
          {activeComponent === 2 && <StaffSelectAssignment />}
          {activeComponent === 4 && <StaffAssignmentTable />}
          {activeComponent === 3 && <StaffApproveAssignment />}
        </div>
      </div>
    </>
  );
};

export default StaffMainAssignment;
