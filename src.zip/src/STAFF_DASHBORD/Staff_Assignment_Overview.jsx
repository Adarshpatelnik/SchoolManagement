import React, { useState, useEffect } from "react";
import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css"; // Import AG Grid styles
import "ag-grid-community/styles/ag-theme-alpine.css"; // Import the theme
import axios from 'axios';
import Staffnavbar from './Staff_navbar.jsx';

const  StaffAssignmentOverview = () => {
  const [rowData, setRowData] = useState([]);
  const [loading, setLoading] = useState(true);

  // Column definitions for AG Grid
  const columnDefs = [
    { headerName: "Assignment ID", field: "ASSIGNMENT_ID", sortable: true, filter: true },
    { headerName: "Student ID", field: "STUDENT_ID", sortable: true, filter: true },
    { headerName: "Student Name", field: "STUDENT_NAME", sortable: true, filter: true },
    { headerName: "Class ID", field: "CLASS_ID", sortable: true, filter: true },
    { headerName: "Subject Name", field: "SUBJECT_NAME", sortable: true, filter: true },
    { headerName: "Submission Start Date", field: "SUBMISSION_START_DATE", sortable: true, filter: true },
    { headerName: "Submission End Date", field: "SUBMISSION_END_DATE", sortable: true, filter: true },
    { headerName: "Submission Date", field: "SUBMISSION_DATE", sortable: true, filter: true },
    { headerName: "Is Submitted", field: "IS_SUBMITTED", sortable: true, filter: true },
    { headerName: "Student Status", field: "STUDENT_STATUS", sortable: true, filter: true },
    { headerName: "Status", field: "STATUS", sortable: true, filter: true }
  ];

  // Fetch data from the API
  useEffect(() => {
    console.log("Fetching data from the API..."); // Log before fetching
    const fetchAssignments = async () => {
      try {
        const response = await axios.get('http://13.127.57.224:2081/api/get-assignmentoverview-data');
        console.log('Fetched assignments:', response.data); // Log the fetched data
        setRowData(response.data); // Set the fetched data
      } catch (error) {
        console.error('There was an error fetching the assignments data!', error); // Log any errors
      } finally {
        setLoading(false); // Stop loading regardless of success or error
      }
    };
    
    fetchAssignments();
  }, []);

  return (
    <> 
      <Staffnavbar />
      
      {/* Add a container with margin-top to move the content down */}
      <div style={{ marginTop: '11vh' }}> {/* Adjust this value to move content more/less */}
        <div className="ag-theme-alpine" style={{ height: 500, width: "100%" }}>
          {loading ? (
            <p>Loading...</p>
          ) : (
            <AgGridReact 
              rowData={rowData}
              columnDefs={columnDefs}
              pagination={true}
              paginationPageSize={10} // Set page size
            />
          )}
        </div>
      </div>
    </>
  );
};

export default  StaffAssignmentOverview;
