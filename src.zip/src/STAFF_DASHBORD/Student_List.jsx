import React, { useState, useEffect, useCallback } from 'react';
import axios from 'axios';
import { AgGridReact } from 'ag-grid-react'; // Import AG-Grid React component
import 'ag-grid-community/styles/ag-grid.css'; // AG-Grid styles
import 'ag-grid-community/styles/ag-theme-alpine.css'; // AG-Grid theme styles

// TeacherMystudentTable component
const StudentList = ({ teacherName = 'Mr. John Doe' }) => {
  const [Mystudent, setMystudent] = useState([]); // Store Mystudent data
  const [filteredMystudent, setFilteredMystudent] = useState([]); // Store filtered Mystudent data
  const [loading, setLoading] = useState(true); // Initially loading
  const [error, setError] = useState(null); // Track error if any
  const [classFilter, setClassFilter] = useState(''); // Selected class filter state
  const [classes, setClasses] = useState([]); // Available classes (for dropdown)

  // Column Definitions for AG-Grid
  const columnDefs = [
    { headerName: 'Student Id', field: 'STUDENT_ID', sortable: true, filter: true },
    { headerName: 'Parent Id', field: 'PARENT_ID', sortable: true, filter: true },
    { headerName: 'Father Name', field: 'FATHER_NAME', sortable: true, filter: true },
    { headerName: 'Mother Name', field: 'MOTHER_NAME', sortable: true, filter: true },
    { headerName: 'Student Name', field: 'FULL_NAME', sortable: true, filter: true },
    { headerName: 'Gender', field: 'GENDER', sortable: true, filter: true },
    { headerName: 'Contact Number', field: 'CONTACT_NUMBER', sortable: true, filter: true },
    { headerName: 'Subject', field: 'SUBJECT', sortable: true, filter: true },
    { headerName: 'Teacher Name', field: 'TEACHER_NAME', sortable: true, filter: true },
    { headerName: 'Class', field: 'CLASS_SECTION', sortable: true, filter: true },
  ];

  // Fetch teacher's Mystudent data from API
  const fetchTeacherMystudent = useCallback(async () => {
    setLoading(true); // Set loading to true when fetching starts
    setError(null); // Clear any previous error state
    try {
      const response = await axios.get('http://13.127.57.224:2081/api/Mystudent', {
        params: { teacherName }, // Pass teacherName in the request
      });
      setMystudent(response.data); // Set the fetched data to state
      setFilteredMystudent(response.data); // Set initial filtered data to all students

      // Extract unique classes from the fetched data for the dropdown
      const uniqueClasses = [
        ...new Set(response.data.map(student => student.CLASS_SECTION))
      ];
      setClasses(uniqueClasses); // Set available classes
    } catch (error) {
      console.error('Error fetching teacher Mystudent:', error);
      setError('Failed to load data'); // Set error message if fetching fails
    } finally {
      setLoading(false); // Set loading to false once data is fetched
    }
  }, [teacherName]);

  // Filter Mystudent data by selected class
  const handleClassFilterChange = (event) => {
    const selectedClass = event.target.value;
    setClassFilter(selectedClass);

    if (selectedClass === '') {
      // If no class is selected, show all students
      setFilteredMystudent(Mystudent);
    } else {
      // Filter students by the selected class
      const filtered = Mystudent.filter(student => student.CLASS_SECTION === selectedClass);
      setFilteredMystudent(filtered);
    }
  };

  // Fetch data on component mount or when teacherName changes
  useEffect(() => {
    fetchTeacherMystudent();
  }, [teacherName]);

  return (
    <div className="Mystudent-card" style={styles.cardContainer}>
    

      {/* Class Filter Dropdown */}
      <div style={styles.filterContainer}>
        <label style={styles.filterLabel}> Class </label>
        <select 
          value={classFilter} 
          onChange={handleClassFilterChange} 
          style={styles.select}
        >
          <option value="">Classes</option>
          {classes.map((className, index) => (
            <option key={index} value={className}>{className}</option>
          ))}
        </select>
      </div>

      {/* If loading, show a loading message */}
      {loading ? (
        <p style={styles.noMystudent}>Loading...</p> // Show loading message if fetching is in progress
      ) : error ? (
        <p style={styles.noMystudent}>{error}</p> // Show error message if there's an error fetching data
      ) : filteredMystudent.length > 0 ? (
        <div className="ag-theme-alpine" style={styles.agGridContainer}>
          {/* AG-Grid Component */}
          <AgGridReact
            columnDefs={columnDefs}
            rowData={filteredMystudent}
            pagination={true}
            domLayout="autoHeight"
            suppressRowClickSelection={true}
          />
        </div>
      ) : (
        <p style={styles.noMystudent}>No MyStudentList available.</p> // If no data found
      )}
    </div>
  );
};

// Styles for the component
const styles = {
  cardContainer: {
    backgroundColor: '#fff',
    borderRadius: '8px',
    // boxShadow: '0 6px 20px rgba(0, 0, 0, 0.1)',
    padding: '0px',
    // maxWidth: '600px', // Adjusted width for the box-like appearance
    marginTop: '-9rem', // Added margin to push the box down a bit
    marginBottom: '0px', // Space below the box
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'flex-start', // Align content from top
    alignItems: 'center',
    overflow: 'auto',
    width:'100%', // Allow for scroll if needed
    height: '40vh', // Make the entire container almost full height of the viewport
  },
  cardHeader: {
    display: 'flex',
    justifyContent: 'center',  // Horizontally center the content
    alignItems: 'center',      // Vertically center the content
    borderBottom: '1px solid #ddd',
    paddingBottom: '0px',
    marginBottom: '5px',
    width: '100%',
    background: 'linear-gradient(#92ea89, #859d9d, #c2e2e2)',
    color: 'white',
    borderRadius: '8px 8px 0 0',
    paddingTop: '0px',
  },
  header: {
    fontSize: '1.5rem',
    fontWeight: '600',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',  // Horizontally center the content
    textAlign: 'center',       // Ensure text is also centered
  },
  icon: {
    marginRight: '10px',
    fontSize: '2.2rem',
    color: '#487b79',
  },
  noMystudent: {
    textAlign: 'center',
    fontSize: '1rem',
    color: '#7f8c8d',
    fontStyle: 'italic',
    marginTop: '1px',
  },
  filterContainer: {
    marginBottom: '5px',
    display: 'flex',
    // marginTop: 'rem', // Added margin to push the box down a bit

    justifyContent: 'center',
    alignItems: 'center',
    width: '100%',
  },
  filterLabel: {
    fontSize: '1rem',
    marginRight: '10px',
  },
  select: {
    padding: '6px',
    fontSize: '1rem',
    borderRadius: '4px',
    border: '1px solid #ddd',
    width: '200px',
  },
  agGridContainer: {
    width: '100%',
    height: '400px', // Set a fixed height for the table container
    overflowY: 'auto', // Enable vertical scrolling if content exceeds height
    overflowX: 'auto', // Enable horizontal scrolling if needed
  },
};

export default StudentList;






