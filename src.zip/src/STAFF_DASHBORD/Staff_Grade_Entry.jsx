
import React, { useEffect, useState } from 'react';
import Staffnavbar from './Staff_navbar';
import axios from 'axios';
import * as XLSX from 'xlsx';
import './Staff_Dashboard.css';

const API_BASE_URL = 'http://13.127.57.224:2081/api/marksfilter';

const StaffGradeEntry = () => {
  const [classOptions, setClassOptions] = useState([]);
  const [term, setTerm] = useState('Term 1');
  const [selectedClass, setSelectedClass] = useState('');
  const [formID, setFormID] = useState({
    STUDENT_ID: '',
    SUBJECT_NAME: '',
    PERIODIC_TEST_1: '',
    NOTE_BOOK_1: '',
    SUBJECT_ENRICHMENT_1: '',
    HALF_YEARLY: '',
    WORK_EDUCATION_1: '',
    ART_EDUCATION_1: '',
    HEALTH_AND_HYGIENE_1: '',
    REGULARITY_AND_PUNCTUALLITY_1: '',
    PERIODIC_TEST_2: '',
    NOTE_BOOK_2: '',
    SUBJECT_ENRICHMENT_2: '',
    ANNUAL: '',
    WORK_EDUCATION_2: '',
    ART_EDUCATION_2: '',
    HEALTH_AND_HYGIENE_2: '',
    REGULARITY_AND_PUNCTUALLITY_2: '',
  });
  const [students, setStudents] = useState([]);
  const [subjects, setSubjects] = useState([]);

  // Fetch classes on component mount
  useEffect(() => {
    const fetchClassOptions = async () => {
      try {
        const response = await axios.get(API_BASE_URL);
        
        // Filter out duplicate class values
        const uniqueClasses = Array.from(new Set(response.data.map(item => item.CLASS_ID)))
          .map(id => response.data.find(item => item.CLASS_ID === id));
        
        setClassOptions(uniqueClasses);
      } catch (error) {
        console.error('Error fetching class options:', error);
      }
    };
  
    fetchClassOptions();
  }, []);
  

  // Fetch students and subjects based on selected class
  useEffect(() => {
    const fetchStudentsAndSubjects = async () => {
      if (!selectedClass) return;

      try {
        const [studentsResponse, subjectsResponse] = await Promise.all([
          axios.get(API_BASE_URL, { params: { classId: selectedClass } }),
          axios.get(API_BASE_URL, { params: { classId: selectedClass } }),
        ]);

        setStudents(studentsResponse.data);
        setSubjects(subjectsResponse.data);
      } catch (error) {
        console.error('Error fetching students or subjects:', error);
        alert('Error fetching data. Please check the console for details.');
      }
    };

    fetchStudentsAndSubjects();
  }, [selectedClass]);

  const handleClassChange = (e) => {
    const selectedClass = e.target.value;
    setSelectedClass(selectedClass);
    setFormID({ ...formID, STUDENT_ID: '', SUBJECT_NAME: '' });
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormID(prevState => ({
      ...prevState,
      [name]: value,
    }));
  };

  const handleTermChange = (e) => {
    const selectedTerm = e.target.value;
    setTerm(selectedTerm);
    
    // Reset the form fields based on selected term
    if (selectedTerm === 'Term 1') {
      setFormID({
        ...formID,
        PERIODIC_TEST_1: '',
        NOTE_BOOK_1: '',
        SUBJECT_ENRICHMENT_1: '',
        HALF_YEARLY: '',
        WORK_EDUCATION_1: '',
        ART_EDUCATION_1: '',
        HEALTH_AND_HYGIENE_1: '',
        REGULARITY_AND_PUNCTUALLITY_1: '',
        PERIODIC_TEST_2: '',
        NOTE_BOOK_2: '',
        SUBJECT_ENRICHMENT_2: '',
        ANNUAL: '',
        WORK_EDUCATION_2: '',
        ART_EDUCATION_2: '',
        HEALTH_AND_HYGIENE_2: '',
        REGULARITY_AND_PUNCTUALLITY_2: '',
      });
    } else if (selectedTerm === 'Term 2') {
      setFormID({
        ...formID,
        PERIODIC_TEST_2: '',
        NOTE_BOOK_2: '',
        SUBJECT_ENRICHMENT_2: '',
        ANNUAL: '',
        WORK_EDUCATION_2: '',
        ART_EDUCATION_2: '',
        HEALTH_AND_HYGIENE_2: '',
        REGULARITY_AND_PUNCTUALLITY_2: '',
        PERIODIC_TEST_1: '',
        NOTE_BOOK_1: '',
        SUBJECT_ENRICHMENT_1: '',
        HALF_YEARLY: '',
        WORK_EDUCATION_1: '',
        ART_EDUCATION_1: '',
        HEALTH_AND_HYGIENE_1: '',
        REGULARITY_AND_PUNCTUALLITY_1: '',
      });
    }
  };

  const handleReset = () => {
    setFormID({
      STUDENT_ID: '',
      SUBJECT_NAME: '',
      PERIODIC_TEST_1: '',
      NOTE_BOOK_1: '',
      SUBJECT_ENRICHMENT_1: '',
      HALF_YEARLY: '',
      WORK_EDUCATION_1: '',
      ART_EDUCATION_1: '',
      HEALTH_AND_HYGIENE_1: '',
      REGULARITY_AND_PUNCTUALLITY_1: '',
      PERIODIC_TEST_2: '',
      NOTE_BOOK_2: '',
      SUBJECT_ENRICHMENT_2: '',
      ANNUAL: '',
      WORK_EDUCATION_2: '',
      ART_EDUCATION_2: '',
      HEALTH_AND_HYGIENE_2: '',
      REGULARITY_AND_PUNCTUALLITY_2: '',
    });
    setSelectedClass('');
    setStudents([]);
    setSubjects([]);
  };

  
  const handleSubmit = async (e) => {
    e.preventDefault();

    const formData = { ...formID, term, class: selectedClass };

    try {
      const response = await axios.post('http://13.127.57.224:2081/api/insertmarks', formData);
      console.log('Response:', response.data);
      alert('Data processed successfully!');
      handleReset(); // Reset the form after successful submission
    } catch (error) {
      console.error('Error:', error);
      alert('Error processing data. Please check the console for details.');
    }
  };


  const downloadExcel = () => {
    // Prepare the headers and entries based on the selected term
    let headers, studentEntries;

    if (term === 'Term 1') {
        headers = [
            'STUDENT_ID', 'SUBJECT_NAME', 'PERIODIC_TEST_1', 'NOTE_BOOK_1', 
            'SUBJECT_ENRICHMENT_1', 'HALF_YEARLY', 'WORK_EDUCATION_1', 
            'ART_EDUCATION_1', 'HEALTH_AND_HYGIENE_1', 'REGULARITY_AND_PUNCTUALLITY_1'
        ];
        
        studentEntries = students.map(student => ({
            STUDENT_ID: student.STUDENT_ID,
            SUBJECT_NAME: formID.SUBJECT_NAME,
            PERIODIC_TEST_1: formID.PERIODIC_TEST_1,
            NOTE_BOOK_1: formID.NOTE_BOOK_1,
            SUBJECT_ENRICHMENT_1: formID.SUBJECT_ENRICHMENT_1,
            HALF_YEARLY: formID.HALF_YEARLY,
            WORK_EDUCATION_1: formID.WORK_EDUCATION_1,
            ART_EDUCATION_1: formID.ART_EDUCATION_1,
            HEALTH_AND_HYGIENE_1: formID.HEALTH_AND_HYGIENE_1,
            REGULARITY_AND_PUNCTUALLITY_1: formID.REGULARITY_AND_PUNCTUALLITY_1,
        }));
    } else if (term === 'Term 2') {
        headers = [
            'STUDENT_ID', 'SUBJECT_NAME', 'PERIODIC_TEST_2', 'NOTE_BOOK_2', 
            'SUBJECT_ENRICHMENT_2', 'ANNUAL', 'WORK_EDUCATION_2', 
            'ART_EDUCATION_2', 'HEALTH_AND_HYGIENE_2', 'REGULARITY_AND_PUNCTUALLITY_2'
        ];
        
        studentEntries = students.map(student => ({
            STUDENT_ID: student.STUDENT_ID,
            SUBJECT_NAME: formID.SUBJECT_NAME,
            PERIODIC_TEST_2: formID.PERIODIC_TEST_2,
            NOTE_BOOK_2: formID.NOTE_BOOK_2,
            SUBJECT_ENRICHMENT_2: formID.SUBJECT_ENRICHMENT_2,
            ANNUAL: formID.ANNUAL,
            WORK_EDUCATION_2: formID.WORK_EDUCATION_2,
            ART_EDUCATION_2: formID.ART_EDUCATION_2,
            HEALTH_AND_HYGIENE_2: formID.HEALTH_AND_HYGIENE_2,
            REGULARITY_AND_PUNCTUALLITY_2: formID.REGULARITY_AND_PUNCTUALLITY_2,
        }));
    }

    const worksheet = XLSX.utils.json_to_sheet(studentEntries, { header: headers });
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Grades');
    XLSX.writeFile(workbook, 'student_grades.xlsx');
};


    const [selectedFile, setSelectedFile] = useState(null);

    const handleFileChange = (e) => {
        setSelectedFile(e.target.files[0]);
    };

    const handleUpload = () => {
        if (!selectedFile) {
            alert('Please select a file!');
            return;
        }

        const formData = new FormData();
        formData.append('file', selectedFile);

        fetch('http://13.127.57.224:2081/upload', { // Backend URL
            method: 'POST',
            body: formData,
        })
            .then((response) => {
                if (!response.ok) {
                    throw new Error('File upload failed.');
                }
                return response.text();
            })
            .then((data) => alert(data))
            .catch((error) => console.error('Error:', error));
    };

  return (
    <>
    <Staffnavbar/>
    <div className="staff_Entry_LoginContainer">
      <div className="staff_Entry_FormWrapper">
        <div className="staff_Entry_Header">
          <h2 className="staff_Entry_Heading">Grade Entry</h2>
        </div>

        <div className="staff_Entry_FiltersAndResetContainer">
          <div className="staff_Entry_FilterGroup">
            <div className="staff_Entry_FilterItem">
              <label className="staff_Entry_Label">Class:</label>
              <select
                className="staff_Entry_ClassSelect"
                value={selectedClass}
                onChange={handleClassChange}
              >
                <option value="">Select Class</option>
                {classOptions.map((option) => (
                  <option key={option.CLASS_ID} value={option.CLASS_ID}>
                    {option.CLASS_ID}
                  </option>
                ))}
              </select>
            </div>
            <div className="staff_Entry_FilterItem">
              <label className="staff_Entry_Label">Term:</label>
              <select
                className="staff_Entry_select"
                value={term}
                onChange={handleTermChange}
              >
                <option value="Term 1">Term 1</option>
                <option value="Term 2">Term 2</option>
              </select>
            </div>
          </div>
          <button
            className="staff_Entry_ResetButton"
            type="button"
            onClick={handleReset}
          >
            Reset
          </button>
        </div>

        <form className="staff_Entry_Form" onSubmit={handleSubmit}>
          <div className="staff_Entry_InputWrapper">
            <label className="staff_Entry_Label">Student ID:</label>
            <select
              className="staff_Entry_select"
              name="STUDENT_ID"
              value={formID.STUDENT_ID || ''}
              onChange={handleChange}
            >
              <option value="">Select Student</option>
              {students.map((student) => (
                <option key={student.STUDENT_ID} value={student.STUDENT_ID}>
                  {student.STUDENT_ID}
                </option>
              ))}
            </select>
          </div>
          <div className="staff_Entry_InputWrapper">
            <label className="staff_Entry_Label">Subject:</label>
            <select
              className="staff_Entry_select"
              name="SUBJECT_NAME"
              value={formID.SUBJECT_NAME || ''}
              onChange={handleChange}
            >
              <option value="">Select Subject</option>
              {subjects.map((subject) => (
                <option key={subject.SUBJECT_NAME} value={subject.SUBJECT_NAME}>
                  {subject.SUBJECT_NAME}
                </option>
              ))}
            </select>
          </div>

          {/* Term 1 fields */}
          {term === 'Term 1' && (
            <>
              <div className="staff_Entry_InputWrapper">
                <label className="staff_Entry_Label">Periodic Test 1:</label>
                <input
                  className="staff_Entry_Input"
                  name="PERIODIC_TEST_1"
                  value={formID.PERIODIC_TEST_1 || ''}
                  onChange={handleChange}
                />
              </div>
              <div className="staff_Entry_InputWrapper">
                <label className="staff_Entry_Label">Note Book 1:</label>
                <input
                  className="staff_Entry_Input"
                  name="NOTE_BOOK_1"
                  value={formID.NOTE_BOOK_1 || ''}
                  onChange={handleChange}
                />
              </div>
              <div className="staff_Entry_InputWrapper">
                <label className="staff_Entry_Label">Subject Enrichment 1:</label>
                <input
                  className="staff_Entry_Input"
                  name="SUBJECT_ENRICHMENT_1"
                  value={formID.SUBJECT_ENRICHMENT_1 || ''}
                  onChange={handleChange}
                />
              </div>
              <div className="staff_Entry_InputWrapper">
                <label className="staff_Entry_Label">Half Yearly:</label>
                <input
                  className="staff_Entry_Input"
                  name="HALF_YEARLY"
                  value={formID.HALF_YEARLY || ''}
                  onChange={handleChange}
                />
              </div>
              <div className="staff_Entry_InputWrapper">
                <label className="staff_Entry_Label">Work Education 1:</label>
                <input
                  className="staff_Entry_Input"
                  name="WORK_EDUCATION_1"
                  value={formID.WORK_EDUCATION_1 || ''}
                  onChange={handleChange}
                />
              </div>
              <div className="staff_Entry_InputWrapper">
                <label className="staff_Entry_Label">Art Education 1:</label>
                <input
                  className="staff_Entry_Input"
                  name="ART_EDUCATION_1"
                  value={formID.ART_EDUCATION_1 || ''}
                  onChange={handleChange}
                />
              </div>
              <div className="staff_Entry_InputWrapper">
                <label className="staff_Entry_Label">Health and Hygiene 1:</label>
                <input
                  className="staff_Entry_Input"
                  name="HEALTH_AND_HYGIENE_1"
                  value={formID.HEALTH_AND_HYGIENE_1 || ''}
                  onChange={handleChange}
                />
              </div>
              <div className="staff_Entry_InputWrapper">
                <label className="staff_Entry_Label">Regularity and Punctuality 1:</label>
                <input
                  className="staff_Entry_Input"
                  name="REGULARITY_AND_PUNCTUALLITY_1"
                  value={formID.REGULARITY_AND_PUNCTUALLITY_1 || ''}
                  onChange={handleChange}
                />
              </div>
            </>
          )}

          {/* Term 2 fields */}
          {term === 'Term 2' && (
            <>
              <div className="staff_Entry_InputWrapper">
                <label className="staff_Entry_Label">Periodic Test 2:</label>
                <input
                  className="staff_Entry_Input"
                  name="PERIODIC_TEST_2"
                  value={formID.PERIODIC_TEST_2 || ''}
                  onChange={handleChange}
                />
              </div>
              <div className="staff_Entry_InputWrapper">
                <label className="staff_Entry_Label">Note Book 2:</label>
                <input
                  className="staff_Entry_Input"
                  name="NOTE_BOOK_2"
                  value={formID.NOTE_BOOK_2 || ''}
                  onChange={handleChange}
                />
              </div>
              <div className="staff_Entry_InputWrapper">
                <label className="staff_Entry_Label">Subject Enrichment 2:</label>
                <input
                  className="staff_Entry_Input"
                  name="SUBJECT_ENRICHMENT_2"
                  value={formID.SUBJECT_ENRICHMENT_2 || ''}
                  onChange={handleChange}
                />
              </div>
              <div className="staff_Entry_InputWrapper">
                <label className="staff_Entry_Label">Annual:</label>
                <input
                  className="staff_Entry_Input"
                  name="ANNUAL"
                  value={formID.ANNUAL || ''}
                  onChange={handleChange}
                />
              </div>
              <div className="staff_Entry_InputWrapper">
                <label className="staff_Entry_Label">Work Education 2:</label>
                <input
                  className="staff_Entry_Input"
                  name="WORK_EDUCATION_2"
                  value={formID.WORK_EDUCATION_2 || ''}
                  onChange={handleChange}
                />
              </div>
              <div className="staff_Entry_InputWrapper">
                <label className="staff_Entry_Label">Art Education 2:</label>
                <input
                  className="staff_Entry_Input"
                  name="ART_EDUCATION_2"
                  value={formID.ART_EDUCATION_2 || ''}
                  onChange={handleChange}
                />
              </div>
              <div className="staff_Entry_InputWrapper">
                <label className="staff_Entry_Label">Health and Hygiene 2:</label>
                <input
                  className="staff_Entry_Input"
                  name="HEALTH_AND_HYGIENE_2"
                  value={formID.HEALTH_AND_HYGIENE_2 || ''}
                  onChange={handleChange}
                />
              </div>
              <div className="staff_Entry_InputWrapper">
                <label className="staff_Entry_Label">Regularity and Punctuality 2:</label>
                <input
                  className="staff_Entry_Input"
                  name="REGULARITY_AND_PUNCTUALLITY_2"
                  value={formID.REGULARITY_AND_PUNCTUALLITY_2 || ''}
                  onChange={handleChange}
                />
              </div>
            </>
          )}

          <div className="staff_Entry_ButtonContainer">
            <button className="staff_Entry_Button" type="submit">
              Submit
            </button>
            <button
              className="staff_Entry_Button"
              type="button"
              onClick={downloadExcel}
            >
              Download Excel
            </button>
          </div>

          <div>
            <input
              className="staff_Entry_fileInput"
              type="file"
              onChange={handleFileChange}
            />
            <button
              className="staff_Entry_uploadButton"
              type="button"
              onClick={handleUpload}
            >
              Upload File
            </button>
          </div>
        </form>
      </div>
    </div>
    </>
  );
};

export default StaffGradeEntry;