


import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import styled from 'styled-components';
import Staffcalendar from './Staff_calendar.jsx';
import Staffshedule from './Staff_shedule.jsx';
import Staffnavbar from './Staff_navbar.jsx';
import StaffAssignmentsDashboard from './Staff_Assignments_Dashboard.jsx';
import StaffAttandanceSummery from './Staff_Attandance_Summery.jsx';
import StaffTimeTableschedule from './Staff_TimeTable_schedule.jsx';
import StudentList from './Student_List.jsx';
import StaffNoticeBoard from './Staff_Notice_Board.jsx';

// Styled components for new UI
const Container = styled.div`
  padding-top: 10px;
  min-height: 100vh;
  padding: 0 20px;
  max-width: 100%;
  margin: 0 auto;
  background-color: #F0F6FA	;

  @media (max-width: 1200px) {
    max-width: 1000px;
  }
  @media (max-width: 992px) {
    max-width: 800px;
  }
  @media (max-width: 768px) {
    padding: 0 10px;
  }
  @media (max-width: 576px) {
    padding: 0 5px;
  }
`;


const Card = styled.div`
  background-color: #ffffff;
  border: 2px solid #ccc; /* Add this line for a 1px border */
  border-radius: 4px; /* Adjust the radius value as needed */
  padding: 0px;
  margin-bottom: 15%;
  min-height: 0;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  transition: transform 0.3s ease, box-shadow 0.3s ease;
  // box-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);

  @media (max-width: 768px) {
    padding: 15px;
    min-height: 250px;
  }
`;
const Section = styled.div`
  background-color: #ffffff;
  border-radius: 20px; /* Smoother rounded corners */
  padding: 0px;
  width: 100%; /* Take full width of the grid cell */
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1); /* Soft shadow for modern look */
  transition: all 0.3s ease;
  
  // &:hover {
  //   transform: translateY(-10px); /* Smooth hover effect */
  //   box-shadow: 0 15px 40px rgba(0, 0, 0, 0.15);
  // }

  @media (max-width: 768px) {
    padding: 20px;
  }
`;


const Heading = styled.h3`
font-size: 1.2rem; 
font-weight: 500; 
font-family: 'Lato', sans-serif; 
color: black; 
margin-bottom: 30px; 
padding: 4px 10px; 
width: 100%;
text-shadow: 1px 1px 4px rgba(0, 0, 0, 0.15); 
background: linear-gradient(to right, #d3d3d3, #e8e8e8); /* Light gradient background */
border-radius: 12px;
display: inline-block;
transition: all 0.4s ease; 

@media (max-width: 400px) {
  font-size: 1.4rem; 
  padding: 10px 12px; 
  margin-bottom: 20px;
}
`;



const Dashboard = () => {
  return (
    <div className="container-fluid" style={{ marginTop: '14vh', width: '100%', padding: 0 }}>
      <Staffnavbar />
      <Container>


        
      <div className="row"   style={{ marginTop: '-3vh'  }}>
          <div className="col-lg-4"style={{ padding: '0 4px' }}>
            <Card style={{ height: '45vh',  borderRadius: '16px', }}>
            <Heading>Attendance Summary</Heading>
            <StaffAttandanceSummery />
            </Card>
          </div>
     

          <div className="col-lg-4"style={{ padding: '0 4px' }}>
          <Card style={{ height: '45vh',  borderRadius: '16px', }}>
                      <Heading>Calendar</Heading>
          <Staffcalendar />
          </Card>
</div>    

<div className="col-lg-4"style={{ padding: '0 4px' }}>
<Card style={{ height: '45vh',  borderRadius: '16px', }}>   
         <Heading>Notice Board</Heading>
          < StaffNoticeBoard/>
          </Card>
          </div>
      
      


   <div className="row"  
   
   style={{ marginTop: '-9vh'  }}>


<div className="col-lg-4"style={{ padding: '0 4px' }}>
<Card style={{ height: '45vh',  borderRadius: '16px', }}>   
         <Heading>Assignments Overview</Heading>
          <StaffAssignmentsDashboard />
          </Card>
          </div>
       

        
      <div className="col-lg-8"style={{ padding: '0 8px' }}>
            <Card style={{ height: '45vh',  borderRadius: '16px', }}>        
        <Heading>Student List</Heading>
        <StudentList />
      </Card>
      </div>
      </div>


      <div className="row"  
   
   style={{ marginTop: '-16vh'  }}>
      <div className="col-lg-11"style={{ padding: '0 2px' }}>
            <Card style={{ height: '69vh',  borderRadius: '16px', }}>        
        <Heading>Staff Shedule</Heading>
        <StaffTimeTableschedule />
      </Card>
      </div>
       

       </div>
       </div>

        {/* <Section>
          <Heading>Time Table schedule</Heading>
          <StaffTimeTableschedule />
        </Section> */}
      </Container>
    </div>
  );
};

export default Dashboard;
