

import React, { useState, useContext } from 'react';
import { Navbar, Nav, Modal, Button } from 'react-bootstrap';
import { Link, useLocation } from 'react-router-dom';
import { FaPowerOff } from 'react-icons/fa';
import { AuthContext } from '../SECURITY_OTHERS/AuthContext';

const Staffnavbar = () => {
    const [showModal, setShowModal] = useState(false);
    const [showAttendanceModal, setShowAttendanceModal] = useState(false); // New state for Attendance Modal
    const location = useLocation(); // Get the current location
    const { logout } = useContext(AuthContext);
    const navbarStyle = {
        backgroundImage: "url('/background.avif')", // Replace with your image path
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        padding: '10px 20px',
        position: 'fixed',
        top: 0,
        left: 0,
        width: '100%',
        zIndex: 1000,
        boxShadow: '0 8px 9px rgba(0, 0, 0, 0.1)',
    };

    const navLinkStyle = (path) => ({
        margin: '0 20px',
        color: location.pathname === path ? '#012353' : 'black', // Adjusted for better visibility
        textDecoration: 'none',
        fontWeight: location.pathname === path ? 'bold' : '500',
        borderBottom: location.pathname === path ? '2px solid #012353' : 'none',
        transition: 'color 0.3s, border-bottom 0.3s',
    });

    const logoutStyle = {
        color: '#dc3545',
        fontWeight: 'bold',
        textDecoration: 'none',
        display: 'flex',
        alignItems: 'center',
        cursor: 'pointer',
    };

    const brandFontSize = 1.5;
    const brandLogoWidth = 2;
    const brandLogoHeight = 2;
    const brandLogoMarginRight = 0.2;
    const brandLogoMarginBottom = 0.2;

    const handleLogoutClick = () => {
        setShowModal(true);
    };

    const handleConfirmLogout = () => {
        window.location.href = "/Login";
    };

    const handleCloseModal = () => {
        setShowModal(false);
    };
    const confirmLogout = () => {
      logout(); // Call logout function from AuthContext
      setShowModal(false); // Close the modal
      navigate('/Login'); // Navigate to login page
    };

    const handleLogout = () => {
      setShowModal(true); // Show logout confirmation modal
    };

    const handleAttendanceClick = () => {
        setShowAttendanceModal(true); // Show Attendance Modal
    };

    const handleCloseAttendanceModal = () => {
        setShowAttendanceModal(false); // Close Attendance Modal
    };

    return (
        <>
            <Navbar style={navbarStyle} expand="lg">
                <img
                    src="02 1.jpg" 
                    alt="B2B360 Logo"
                    style={{
                        width: `${brandLogoWidth}rem`,
                        height: `${brandLogoHeight}rem`,
                        marginRight: `${brandLogoMarginRight}rem`,
                        marginBottom: `${brandLogoMarginBottom}rem`,
                    }}
                />

                <span
                    style={{
                        fontFamily: 'Playfair Display, serif',
                        fontSize: `${brandFontSize}em`,
                        fontWeight: 'bold',
                        backgroundImage: 'linear-gradient(to right, white, white)',
                        WebkitBackgroundClip: 'text',
                        WebkitTextFillColor: 'transparent',
                    }}
                >
                    EDU<span style={{ color: 'white' }}>3</span>6<span style={{ color: 'white' }}>0</span>
                </span>
                <Navbar.Toggle aria-controls="basic-navbar-nav" />
                <Navbar.Collapse id="basic-navbar-nav" className="justify-content-end">
                    <Nav className="d-flex justify-content-end">
                        <Nav.Link as={Link} to="/Staff_Dashbord" style={navLinkStyle('/Staff_Dashbord')}>
                            Home
                        </Nav.Link>
                        <Nav.Link as={Link} to="/Staff_Grade_Entry" style={navLinkStyle('/Staff_Grade_Entry')}>
                            Grade Entry
                        </Nav.Link>
                        <Nav.Link as={Link} to="/Staff_Main_Assignment" style={navLinkStyle('/Staff_Main_Assignment')}>
                            Assignment
                        </Nav.Link>
                        <Nav.Link onClick={handleAttendanceClick} style={navLinkStyle('#')}>
                            Attendance
                        </Nav.Link>
                        <Nav.Link onClick={handleLogout} style={logoutStyle}>
                            <FaPowerOff style={{ marginRight: '5px' }} />
                            Logout
                        </Nav.Link>
                    </Nav>
                </Navbar.Collapse>
            </Navbar>

            {/* Logout Confirmation Modal */}
            <Modal show={showModal} onHide={handleCloseModal}>
                <Modal.Header closeButton>
                    <Modal.Title>Confirm Logout</Modal.Title>
                </Modal.Header>
                <Modal.Body>Are you sure you want to log out?</Modal.Body>
                <Modal.Footer>
                    <Button variant="secondary" onClick={handleCloseModal}>
                        No
                    </Button>
                    <Button variant="primary" onClick={confirmLogout}>
                        Yes
                    </Button>
                </Modal.Footer>
            </Modal>

            {/* Attendance Modal with iframe */}
            <Modal
  show={showAttendanceModal}
  onHide={handleCloseAttendanceModal}
  size="lg"
  centered
  backdrop="static"
  keyboard={false}
  style={{ fontFamily: 'Arial, sans-serif' }}
>
  <Modal.Header
    closeButton
    style={{
      backgroundColor: '#2e4053',
      color: 'white',
      borderBottom: '2px solid #f39c12',
    }}
  >
    <Modal.Title style={{ fontWeight: 'bold' }}>Attendance</Modal.Title>
  </Modal.Header>
  <Modal.Body
    style={{
      backgroundColor: '#f4f6f7',
      padding: '20px',
      textAlign: 'center',
    }}
  >
    {/* Embed the Staff Attendance page via iframe */}
    <iframe
      src="/Staff_Attandance_Calendar" // Ensure this path is correct and the page is accessible
      style={{
        width: '100%',
        height: '400px',
        border: '2px solid #2e4053',
        borderRadius: '8px',
        boxShadow: '0 4px 8px rgba(0, 0, 0, 0.2)',
      }}
      title="Attendance Page"
    ></iframe>
  </Modal.Body>
  <Modal.Footer
    style={{
      backgroundColor: '#2e4053',
      borderTop: '2px solid #f39c12',
      justifyContent: 'space-between',
    }}
  >
    <Button
      variant="secondary"
      onClick={handleCloseAttendanceModal}
      style={{
        backgroundColor: '#f39c12',
        border: 'none',
        color: 'white',
        padding: '10px 20px',
        fontSize: '16px',
        fontWeight: 'bold',
        borderRadius: '4px',
        boxShadow: '0 4px 8px rgba(0, 0, 0, 0.2)',
      }}
    >
      Close
    </Button>
  </Modal.Footer>
</Modal>


        </>
    );
};

export default Staffnavbar;

