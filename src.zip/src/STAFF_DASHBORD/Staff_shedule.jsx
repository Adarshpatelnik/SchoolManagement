

import React, { useState, useEffect } from 'react';
import axios from 'axios';

const Staffshedule = ({ teacherName = 'Mr. John Doe' }) => {
  const [schedule, setSchedule] = useState([]);

  useEffect(() => {
    fetchTeacherSchedule();
  }, [teacherName]);

  // Fetch schedule data from the API
  const fetchTeacherSchedule = async () => {
    try {
      const response = await axios.get('http://13.127.57.224:2081/api/schedule', {
        params: { teacherName },
      });
      setSchedule(response.data);
    } catch (error) {
      console.error('Error fetching teacher schedule:', error);
    }
  };

  // Refresh the schedule (manually)
  const handleRefresh = () => {
    fetchTeacherSchedule(); // Trigger fetching the schedule again
  };

  return (
    <div style={styles.cardContainer}>
      {schedule.length > 0 ? (
        <div style={styles.tableContainer}>
          <table style={styles.scheduleTable}>
            <thead>
              <tr>
                <th style={styles.tableHeader}>Class ID</th>
                <th style={styles.tableHeader}>Subject</th>
                <th style={styles.tableHeader}>Time Slot</th>
                <th style={styles.tableHeader}>Period</th>
              </tr>
            </thead>
            <tbody>
              {schedule.map((classInfo) => (
                <tr key={classInfo.CLASS_ID} style={styles.scheduleRow}>
                  <td style={styles.scheduleCell}>{classInfo.CLASS_ID}</td>
                  <td style={styles.scheduleCell}>{classInfo.SUBJECT}</td>
                  <td style={styles.scheduleCell}>{classInfo.TIME_SLOT || "Not Scheduled"}</td>
                  <td style={styles.scheduleCell}>{classInfo.PERIOD || "N/A"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <p style={styles.noSchedule}>No schedule available.</p>
      )}
    </div>
  );
};

// Styles for the component
const styles = {
  cardContainer: {
    backgroundColor: '#ffffff',
    borderRadius: '0px',
    // boxShadow: '0 12px 40px rgba(0, 0, 0, 0.2)',
    padding: '0px',
    width: '100%',
    maxWidth: '100%',
    margin: '0px auto',
    overflow: 'hidden',
    transition: 'all 0.3s ease',
    hover: {
      transform: 'translateY(-5px)',
    },
  },
  tableContainer: {
    maxHeight: '300px', // Limit the height of the table
    overflowY: 'auto', // Enable vertical scrolling if the content overflows
    overflowX: 'hidden',
    paddingRight: '10px', // Add some space for scrollbar
  },
  scheduleTable: {
    width: '100%',
    borderCollapse: 'collapse',
    marginTop: '0px',
    backgroundColor: '#fdfdfd',
    borderRadius: '0 0 20px 20px',
    overflow: 'hidden',
  },
  tableHeader: {
    textAlign: 'left',
    padding: '5px 10px', // Adjusted padding for better spacing
    background: 'linear-gradient(135deg, #6c757d, #343a40)', // Subtle gradient background
    color: 'white',
    fontWeight: 'bold',
    fontSize: '0.9rem', // Slightly increased font size for better readability
    letterSpacing: '1px', // Add letter spacing for a cleaner look
    // borderRadius: '6px', // Rounded corners for a modern look
    boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)', // Light shadow for depth
    transition: 'background-color 0.3s ease', // Smooth hover transition
    textTransform: 'capitalize', // Better text casing for a modern feel
    textShadow: '1px 1px 3px rgba(0, 0, 0, 0.1)', // Subtle text shadow
  },
  
  scheduleRow: {
    transition: 'background-color 0.3s ease',
    backgroundColor: '#f6f6f6',
    ':hover': {
      backgroundColor: '#e0f7fa',
    },
  },
  scheduleCell: {
    padding: '10px',
    borderBottom: '1px solid #ddd',
    color: '#2c3e50',
    fontSize: '0.85rem',
  },
  noSchedule: {
    textAlign: 'center',
    fontSize: '1rem',
    color: '#7f8c8d',
    fontStyle: 'italic',
    marginTop: '20px',
  },
};

export default Staffshedule;

