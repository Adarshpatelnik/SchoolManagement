


import React, { useState, useEffect, useMemo } from 'react';
import axios from 'axios';
import { FaCalendarAlt } from 'react-icons/fa';
import Staffnavbar from './Staff_navbar.jsx';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
 import'./Staff_Dashboard.css';
const StaffStudentInformationAssignment = () => {
  const [assignments, setAssignments] = useState([]);
  const [error, setError] = useState(null);
 
  useEffect(() => {
    const fetchAssignments = async () => {
      try {
        const response = await axios.get('http://13.127.57.224:2081/api/StudentInformationForAssignment');
        setAssignments(response.data);
      } catch (err) {
        setError('Failed to fetch assignments. Please try again later.');
        console.error('Error fetching student assignments:', err);
      }
    };
 
    fetchAssignments();
  }, []);
 
  const columnDefs = useMemo(() => [
    { headerName: "Student ID", field: "STUDENT_ID" },
    { headerName: "Student Name", field: "STUDNET_NAME" },
    { headerName: "Class", field: "CLASS_ID" },
    { headerName: "Assignment Type", field: "ASSIGNMENT_TYPE" },
    { headerName: "Subject", field: "SUBJECT_NAME" },
    { headerName: "Assignment Description", field: "ASSIGNMENT_DESC" },
  ], []);
 
  const defaultColDef = useMemo(() => ({
    flex: 1,
    minWidth: 150,
    filter: true,
    sortable: true,
    resizable: true,
  }), []);
 
  return (
    <>
      <Staffnavbar />
      <div className="Staff__Student_Info_schedule-card">
        <div className="Staff__Student_Info_card-header">
          <div className="Staff__Student_Info_header">
            <FaCalendarAlt className="Staff__Student_Info_icon" />
            Student Assignment Information
          </div>
        </div>
 
        {error && <p className="error-message">{error}</p>}
        {assignments.length > 0 ? (
          <div className="ag-theme-alpine grid-container">
            <AgGridReact
              rowData={assignments}
              columnDefs={columnDefs}
              pagination={true}
              paginationPageSize={10}
              defaultColDef={defaultColDef}
              suppressPaginationPanel={true}
            />
          </div>
        ) : (
          <p className="Staff__Student_Info_no-schedule">No assignments available.</p>
        )}
      </div>
    </>
  );
};
 
export default StaffStudentInformationAssignment;
