


import React, { useEffect, useState } from 'react';
import { AgGridReact } from 'ag-grid-react';
import axios from 'axios';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import 'bootstrap/dist/css/bootstrap.min.css';

const TimeTableschedule = () => {
  const [classData, setClassData] = useState([]);
  const [gridData, setGridData] = useState([]);
  const [selectedClass, setSelectedClass] = useState('LKG A');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchClassData = async () => {
      setLoading(true);
      try {
        const response = await axios.get('http://13.127.57.224:2081/api/Stafftimetable');
        setClassData(response.data);
        setError('');
      } catch (error) {
        setError('Error fetching class data. Please try again later.');
      } finally {
        setLoading(false);
      }
    };

    fetchClassData();
  }, []);

  useEffect(() => {
    const fetchGridData = async () => {
      if (!selectedClass) return;

      setLoading(true);
      try {
        const response = await axios.get(`http://13.127.57.224:2081/api/class_data?class=${selectedClass}`);
        setGridData(response.data);
        setError('');
      } catch (error) {
        setError('Error fetching data for the selected class. Please try again.');
      } finally {
        setLoading(false);
      }
    };

    fetchGridData();
  }, [selectedClass]);

  const onClassSelect = (event) => {
    setSelectedClass(event.target.value);
  };

  // Determine the current day
  const currentDay = new Date().toLocaleString('en-us', { weekday: 'long' });

  // Column definitions with conditional cell styling based on the current day
  const columnDefs = [
    { headerName: 'PERIOD', field: 'PERIOD', sortable: true, filter: true, width: 100, cellStyle: { padding: '5px' } },
    { headerName: 'TIME SLOT', field: 'TIME_SLOT', sortable: true, filter: true, width: 150, cellStyle: { padding: '5px' } },
    {
      headerName: 'MONDAY',
      field: 'Monday',
      sortable: true,
      filter: true,
      width: 150,
      cellStyle: params => ({
        padding: '5px',
        backgroundColor: currentDay === 'Monday' ? '#088F8F' : undefined, // Highlight current day
        color: currentDay === 'Monday' ? '#fff' : '#000'
      })
    },
    {
      headerName: 'TUESDAY',
      field: 'Tuesday',
      sortable: true,
      filter: true,
      width: 150,
      cellStyle: params => ({
        padding: '5px',
        backgroundColor: currentDay === 'Tuesday' ? '#6495ED	' : undefined,
        color: currentDay === 'Tuesday' ? '#fff' : '#000'
      })
    },
    {
      headerName: 'WEDNESDAY',
      field: 'Wednesday',
      sortable: true,
      filter: true,
      width: 150,
      cellStyle: params => ({
        padding: '5px',
        backgroundColor: currentDay === 'Wednesday' ? '#4682B4	' : undefined,
        color: currentDay === 'Wednesday' ? '#fff' : '#000'
      })
    },
    {
      headerName: 'THURSDAY',
      field: 'Thursday',
      sortable: true,
      filter: true,
      width: 150,
      cellStyle: params => ({
        padding: '5px',
        backgroundColor: currentDay === 'Thursday' ? '#6F8FAF	' : undefined,
        color: currentDay === 'Thursday' ? '#fff' : '#000'
      })
    },
    {
      headerName: 'FRIDAY',
      field: 'Friday',
      sortable: true,
      filter: true,
      width: 150,
      cellStyle: params => ({
        padding: '5px',
        backgroundColor: currentDay === 'Friday' ? '#5F9EA0	' : undefined,
        color: currentDay === 'Friday' ? '#fff' : '#000'
      })
    },
    {
      headerName: 'SATURDAY',
      field: 'Saturday',
      sortable: true,
      filter: true,
      width: 150,
      cellStyle: params => ({
        padding: '5px',
        backgroundColor: currentDay === 'Saturday' ? '#566573 ' : undefined,
        color: currentDay === 'Saturday' ? '#fff' : '#000'
      })
    },
  ];

  return (
    <div className="container" style={{ backgroundColor: '#f9f9f9', borderRadius: '10px', marginTop: '-1rem' }}>
      <div className="mb-3 d-flex justify-content-center align-items-center">
        <label htmlFor="class-select" className="me-2 fw-semibold text-secondary">Class</label>
        <select
          id="class-select"
          onChange={onClassSelect}
          value={selectedClass}
          className="form-select w-auto shadow-sm"
          style={{ borderRadius: '8px' }}
        >
          <option value="">-- Select Class --</option>
          {classData.map((classItem) => (
            <option key={classItem.CLASS_ID} value={classItem.CLASS_ID}>
              {classItem.CLASS_ID}
            </option>
          ))}
        </select>
      </div>

      {loading && <p className="text-center text-info">Loading data...</p>}
      {error && <p className="text-center text-danger fw-bold">{error}</p>}

      <div className="ag-theme-alpine" style={{ height: '55vh', width: '100%' }}>
        {gridData.length > 0 ? (
          <AgGridReact
            columnDefs={columnDefs}
            rowData={gridData}
            pagination={true}
            paginationPageSize={10}
            suppressPaginationPanel={true}
          />
        ) : (
          !loading && <p className="text-center text-muted">No data available for the selected class.</p>
        )}
      </div>
    </div>
  );
};

export default TimeTableschedule;




