import React, { useState, useEffect } from 'react';
import axios from 'axios';

const StaffAttandanceCalendar = () => {
  const [attendanceType, setAttendanceType] = useState('attendance');
  const [currentDate, setCurrentDate] = useState(new Date());
  const [showPopup, setShowPopup] = useState(false);
  const [selectedDate, setSelectedDate] = useState(null);
  const [markedDates, setMarkedDates] = useState({});
  const [leaveData, setLeaveData] = useState({});
  const [leaveDetails, setLeaveDetails] = useState({
    leaveType: '',
    startDate: '',
    endDate: '',
    reason: '',
    contactNumber: ''
  });
  const [staffId, setStaffId] = useState(""); // Added for dynamic staffId
  const [leaveBalances, setLeaveBalances] = useState({});
  const [showLeaveBalancesPopup, setShowLeaveBalancesPopup] = useState(false);
  const today = new Date();

  useEffect(() => {
    fetchAttendanceData();
    fetchLeaveData();
    fetchLeaveBalances();
  }, []);
  
  const fetchAttendanceData = async () => {
    try {
      const staffId = '106'; // Replace with actual staff ID or user input
      const res = await axios.get(`http://13.127.57.224:2081/api/get-attendance?staffId=${staffId}`);
      if (res.status === 200) {
        const attendanceData = res.data;
        const newMarkedDates = {};
        attendanceData.forEach((record) => {
          const date = new Date(record.DATE).toDateString();
          newMarkedDates[date] = record.STATUS.toLowerCase();
        });
        setMarkedDates(newMarkedDates);
      }
    } catch (error) {
      console.error('Error fetching attendance data:', error);
    }
  };
  
  const fetchLeaveData = async () => {
    try {
      const res = await axios.get(`http://13.127.57.224:2081/api/get-leave?staffId=${staffId}`);
      if (res.status === 200) {
        const leaveData = res.data;
        const newLeaveData = {};
        leaveData.forEach((leave) => {
          const startDate = new Date(leave.START_DATE);
          const endDate = new Date(leave.END_DATE);
          for (let d = new Date(startDate); d <= endDate; d.setDate(d.getDate() + 1)) {
            newLeaveData[d.toDateString()] = leave.STATUS;
          }
        });
        setLeaveData(newLeaveData);
      }
    } catch (error) {
      console.error("Error fetching leave data:", error);
    }
  };

  const fetchLeaveBalances = async () => {
    try {
      const res = await axios.get(`http://13.127.57.224:2081/api/get-leave-balances?staffId=${staffId}`);
      if (res.status === 200) {
        setLeaveBalances(res.data);
      }
    } catch (error) {
      console.error("Error fetching leave balances:", error);
    }
  };

  const handleRadioChange = (e) => {
    setAttendanceType(e.target.value);
    setShowPopup(e.target.value === 'leave');
    setShowLeaveBalancesPopup(e.target.value === 'leavebalances');
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setLeaveDetails((prevDetails) => ({
      ...prevDetails,
      [name]: value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!leaveDetails.leaveType || !leaveDetails.startDate || !leaveDetails.endDate || !leaveDetails.reason || !leaveDetails.contactNumber) {
      alert("Please fill out all fields before submitting.");
      return;
    }

    try {
      const response = await axios.post("http://13.127.57.224:2081/submit-leave", {
        ...leaveDetails,
        staffId
      });
      if (response.status === 200) {
        alert("Leave application submitted successfully!");
        setLeaveDetails({
          leaveType: "",
          startDate: "",
          endDate: "",
          reason: "",
          contactNumber: ""
        });
        setShowPopup(false);
        fetchLeaveData();
      }
    } catch (error) {
      alert('Failed to submit leave application.');
      console.error('Error:', error);
    }
  };

  const markAttendance = async (status) => {
    try {
      const attendanceData = {
        DATE: selectedDate,
        STATUS: status
      };
      const res = await axios.post("http://13.127.57.224:2081/submit-attendance", attendanceData);
      if (res.status === 200) {
        alert(`Attendance marked as ${status} for ${selectedDate}`);
        setMarkedDates((prev) => ({ ...prev, [selectedDate]: status.toLowerCase() }));
        fetchAttendanceData(); // Refresh attendance data after marking
      }
    } catch (error) {
      alert(`Failed to mark attendance as ${status}.`);
    }
    setShowPopup(false);
  };

  const handleMarkPresent = () => markAttendance('Present');
  const handleMarkAbsent = () => markAttendance('Absent');

  const handleConfirmAttendance = (status) => {
    if (status === 'Present') {
      handleMarkPresent();
    } else {
      handleMarkAbsent();
    }
  };

  const getMonthName = () => {
    const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    return monthNames[currentDate.getMonth()];
  };

  const prevMonth = () => {
    setCurrentDate(new Date(currentDate.setMonth(currentDate.getMonth() - 1)));
  };

  const nextMonth = () => {
    setCurrentDate(new Date(currentDate.setMonth(currentDate.getMonth() + 1)));
  };

  const getDaysOfWeek = () => ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

  const getDaysInMonth = () => {
    const month = currentDate.getMonth();
    const year = currentDate.getFullYear();
    const date = new Date(year, month + 1, 0);
    const daysInMonth = [];
    for (let i = 1; i <= date.getDate(); i++) {
      daysInMonth.push(i);
    }
    return daysInMonth;
  };

  const isCurrentDate = (day) => (
    today.getDate() === day &&
    today.getMonth() === currentDate.getMonth() &&
    today.getFullYear() === currentDate.getFullYear()
  );

  const handleDateClick = (day) => {
    const selectedDateObj = new Date(currentDate.getFullYear(), currentDate.getMonth(), day);
    const formattedSelectedDate = selectedDateObj.toDateString();

    if (formattedSelectedDate === today.toDateString() && !markedDates[formattedSelectedDate]) {
      setSelectedDate(formattedSelectedDate);
      setShowPopup(true);
    } else if (markedDates[formattedSelectedDate]) {
      alert(`Attendance for this date is already marked as ${markedDates[formattedSelectedDate]}.`);
    } else {
      alert("You can only select today's date for marking attendance.");
    }
  };

  const closePopup = () => {
    setShowPopup(false);
    setShowLeaveBalancesPopup(false);
    setSelectedDate(null);
    if (attendanceType === 'leave' || attendanceType === 'leavebalances') {
      setAttendanceType('attendance');
    }
  };

  const getLeaveStatusColor = (date) => {
    const leaveStatus = leaveData[date];
    if (leaveStatus === 'PENDING') {
      return '#FFC107'; // Yellow
    } else if (leaveStatus === 'APPROVED') {
      return '#2196F3'; // Blue
    } else if (leaveStatus === 'REJECTED') {
      return '#A9A9A9'; // grey
    }
    return '';
  };

  const handleOutsideClick = (e) => {
    if ((showPopup || showLeaveBalancesPopup) && !e.target.closest('#popup-content')) {
      closePopup();
    }
  };

  useEffect(() => {
    document.addEventListener('mousedown', handleOutsideClick);
    return () => {
      document.removeEventListener('mousedown', handleOutsideClick);
    };
  }, [showPopup, showLeaveBalancesPopup]);

  const styles = {
    container: {
      fontFamily: 'Arial, sans-serif',
      maxWidth: '420px',
      margin: '0 auto',
      padding: '1px',
      border: '2px solid #ccc',
      borderRadius: '10px',
      boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)',
    },
    radioContainer: {
      display: 'flex',
      justifyContent: 'center',
      marginBottom: '10px',
      gap: '20px',
      fontWeight: '600', 
    },
    radioLabel: {
      display: 'flex',
      alignItems: 'center',
      gap: '4px',
      cursor: 'pointer',
    },
    radioInput: {
      margin: 0,
      cursor: 'pointer',
    },
    navContainer: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      padding: '5px',
      background: 'linear-gradient(to right, #012353, #27AE60)',
      color: 'white',
      marginBottom: '15px',
    },
    navButton: {
      background: 'none',
      border: 'none',
      color: 'white',
      cursor: 'pointer',
      fontSize: '18px',
      padding: '5px 10px',
    },
    monthYear: {
      fontSize: '18px',
      fontWeight: 'bold',
    },
    daysGrid: {
      display: 'grid',
      gridTemplateColumns: 'repeat(7, 1fr)',
      gap: '1px',
      textAlign: 'center',
      marginBottom: '10px',
    },
    dayHeader: {
      fontWeight: 'bold',
      padding: '1px',
      color: 'black',
    },
    dateCell: {
      padding: '8px',
      cursor: 'pointer',
      borderRadius: '50%',
      transition: 'background-color 0.2s',
      width: '40px',
      height: '40px',
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
    },
    today: {
      backgroundColor: '#e8f0fe',
      fontWeight: 'bold',
      borderRadius: '50%',
    },
    present: { backgroundColor: '#4CAF50', color: 'white' },
    absent: { backgroundColor: '#F44336', color: 'white' },
    popup: {
      position: 'fixed',
      top: '40%',
      left: '50%',
      transform: 'translate(-50%, -50%)',
      padding: '10px',
      width: attendanceType === 'leave' ? '280px' : '300px',
      height: attendanceType === 'leave' ? '400px' : 'auto',
      backgroundColor: 'white',
      border: '1px solid #ccc',
      borderRadius: '10px',
      boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)',
      zIndex: 1000,
    },
    popupHeader: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: '-1px',
    },
    closeButton: {
      background: 'none',
      border: 'none',
      fontSize: '18px',
      cursor: 'pointer',
    },
    form: {
      display: 'flex',
      flexDirection: 'column',
      gap: '10px',
    },
    input: {
      padding: '5px',
      borderRadius: '3px',
      border: '1px solid #ccc',
    },
    submitButton: {
      padding: '8px',
      backgroundColor: '#4285f4',
      color: 'white',
      border: 'none',
      borderRadius: '3px',
      cursor: 'pointer',
    },
    legendContainer: {
      display: 'flex',
      justifyContent: 'space-between',
      marginTop: '5px',
      gap: '1px',
      marginBottom: '5px',
    },
    legendItem: {
      display: 'flex',
      alignItems: 'center',
      gap: '5px',
      fontSize: '12px',
      fontWeight: '500',
    },
    legendColor: {
      width: '8px',
      height: '8px',
      borderRadius: '50%',
    },
    overlay: {
      position: 'fixed',
      top: 0,
      left: 0,
      width: '100%',
      height: '100%',
      backgroundColor: 'rgba(0, 0, 0, 0.5)',
      zIndex: 999,
    },
    attendanceButton: {
      padding: '1px 10px',
      color: 'white',
      border: 'none',
      borderRadius: '3px',
      cursor: 'pointer',
      marginTop: '-1px',
      marginRight: '2px',
      marginBottom: '1px',
    },
    leaveBalancesPopup: {
      position: 'fixed',
      top: '50%',
      left: '50%',
      transform: 'translate(-50%, -50%)',
      padding: '20px',
      backgroundColor: 'white',
      border: '1px solid #ccc',
      borderRadius: '10px',
      boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)',
      zIndex: 1000,
    },
    leaveBalancesList: {
      display: 'flex',
      flexDirection: 'column',
      gap: '10px',
    },
    leaveBalanceItem: {
      display: 'flex',
      justifyContent: 'space-between',
      fontSize: '14px',
    },
  };

  return (
    <div style={styles.container}>
      <div style={styles.radioContainer}>
        <label style={styles.radioLabel}>
          <input
            type="radio"
            value="attendance"
            checked={attendanceType === 'attendance'}
            onChange={handleRadioChange}
            style={styles.radioInput}
          />
          Attendance
        </label>
        <label style={styles.radioLabel}>
          <input
            type="radio"
            value="leave"
            checked={attendanceType === 'leave'}
            onChange={handleRadioChange}
            style={styles.radioInput}
          />
          Leave
        </label>
        {/* <label style={styles.radioLabel}>
          <input
            type="radio"
            value="leavebalances"
            checked={attendanceType === 'leavebalances'}
            onChange={handleRadioChange}
            style={styles.radioInput}
          />
          Leave Balances
        </label> */}
      </div>

      <div style={styles.navContainer}>
        <button onClick={prevMonth} style={styles.navButton}>{"<"}</button>
        <div style={styles.monthYear}>{getMonthName()} {currentDate.getFullYear()}</div>
        <button onClick={nextMonth} style={styles.navButton}>{">"}</button>
      </div>

      <div style={styles.daysGrid}>
        {getDaysOfWeek().map((day, index) => (
          <div key={index} style={styles.dayHeader}>{day}</div>
        ))}
        {getDaysInMonth().map((day) => {
          const dateObj = new Date(currentDate.getFullYear(), currentDate.getMonth(), day);
          const dateString = dateObj.toDateString();
          const leaveStatus = leaveData[dateString];
          const attendanceStatus = markedDates[dateString];

          let cellStyle = { ...styles.dateCell };
          if (isCurrentDate(day)) {
            cellStyle = { ...cellStyle, ...styles.today };
          }
          if (attendanceStatus === 'present') {
            cellStyle = { ...cellStyle, ...styles.present };
          } else if (attendanceStatus === 'absent') {
            cellStyle = { ...cellStyle, ...styles.absent };
          } else if (leaveStatus) {
            cellStyle = { ...cellStyle, backgroundColor: getLeaveStatusColor(dateString) };
          }

          return (
            <div
              key={day}
              data-date={dateString}
              onClick={() => handleDateClick(day)}
              style={cellStyle}
            >
              {day}
            </div>
          );
        })}
      </div>

      {showPopup && (
        <div style={styles.overlay}>
          <div style={styles.popup}>
            <div id="popup-content">
              <div style={styles.popupHeader}>
                <h3>{attendanceType === 'attendance' ? 'Mark Attendance' : 'Apply for Leave'}</h3>
                <button onClick={closePopup} style={styles.closeButton}>×</button>
              </div>
              {attendanceType === 'attendance' ? (
                <div>
                  <p>Mark attendance for {selectedDate}?</p>
                  <div style={{ display: 'flex', justifyContent: 'center' }}>
                    <button
                      onClick={() => handleConfirmAttendance('Present')}
                      style={{ ...styles.attendanceButton, backgroundColor: '#4CAF50' }}
                    >
                      Present
                    </button>
                    <button
                      onClick={() => handleConfirmAttendance('Absent')}
                      style={{ ...styles.attendanceButton, backgroundColor: '#F44336' }}
                    >
                      Absent
                    </button>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleSubmit} style={styles.form}>
                  <select
                    name="leaveType"
                    value={leaveDetails.leaveType}
                    onChange={handleInputChange}
                    required
                    style={styles.input}
                  >
                    <option value="">Select leave type</option>
                    <option value="CASUAL LEAVE">Casual Leave</option>
                    <option value="SICK LEAVE">Sick Leave</option>
                    <option value="MATERNITY LEAVE">Maternity Leave</option>
                    <option value="PATERNITY LEAVE">Paternity Leave</option>
                    <option value="EARNED LEAVE">Earned Leave</option>
                    <option value="COMPENSATORY LEAVE">Compensatory Leave</option>
                    <option value="SPECIAL LEAVE">Special Leave</option>
                    <option value="STUDY LEAVE">Study Leave</option>
                    <option value="EMERGENCY LEAVE">Emergency Leave</option>
                  </select>
                  <input
                    type="date"
                    name="startDate"
                    value={leaveDetails.startDate}
                    onChange={handleInputChange}
                    required
                    style={styles.input}
                  />
                  <input
                    type="date"
                    name="endDate"
                    value={leaveDetails.endDate}
                    onChange={handleInputChange}
                    required
                    style={styles.input}
                  />
                  <textarea
                    name="reason"
                    placeholder="Reason for leave"
                    value={leaveDetails.reason}
                    onChange={handleInputChange}
                    required
                    style={styles.input}
                  />
                  <input
                    type="text"
                    name="contactNumber"
                    placeholder="Contact details"
                    value={leaveDetails.contactNumber}
                    onChange={handleInputChange}
                    required
                    style={styles.input}
                  />
                  <button type="submit" style={styles.submitButton}>Submit</button>
                </form>
              )}
            </div>
          </div>
        </div>
      )}

      {showLeaveBalancesPopup && (
        <div style={styles.overlay}>
          <div style={styles.leaveBalancesPopup}>
            <div id="popup-content">
              <div style={styles.popupHeader}>
                <h3>Leave Balances</h3>
                <button onClick={closePopup} style={styles.closeButton}>×</button>
              </div>
              <div style={styles.leaveBalancesList}>
                {Object.entries(leaveBalances).map(([leaveType, balance]) => (
                  <div key={leaveType} style={styles.leaveBalanceItem}>
                    <span>{leaveType}:</span>
                    <span>{balance}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      <div style={styles.legendContainer}>
        <div style={styles.legendItem}>
          <div style={{ ...styles.legendColor, backgroundColor: '#4CAF50' }}></div>
          <span>Present</span>
        </div>
        <div style={styles.legendItem}>
          <div style={{ ...styles.legendColor, backgroundColor: '#F44336' }}></div>
          <span>Absent</span>
        </div>
        <div style={styles.legendItem}>
          <div style={{ ...styles.legendColor, backgroundColor: '#FFC107' }}></div>
          <span>Pending Leave</span>
        </div>
        <div style={styles.legendItem}>
          <div style={{ ...styles.legendColor, backgroundColor: '#2196F3' }}></div>
          <span>Approved Leave</span>
        </div>
        <div style={styles.legendItem}>
          <div style={{ ...styles.legendColor, backgroundColor: '#A9A9A9' }}></div>
          <span>Rejected Leave</span>
        </div>
      </div>
    </div>
  );
}

export default StaffAttandanceCalendar;