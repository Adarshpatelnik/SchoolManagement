

import React, { useState, useEffect } from "react";
import Calendar from "react-calendar";
import "react-calendar/dist/Calendar.css";
import axios from "axios";
import "./Admin_Model.css"; // Import the CSS

const EventCalendar = () => {
  const [view, setView] = useState("month");
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [events, setEvents] = useState([]); // To store fetched events
  const [selectedEvents, setSelectedEvents] = useState([]); // Events for the selected date

  // Fetch events from the backend API
  useEffect(() => {
    const fetchEvents = async () => {
      try {
        const response = await axios.get("http://13.127.57.224:2081/api/events");
        setEvents(response.data); // Assuming the response contains event data
      } catch (error) {
        console.error("Error fetching events:", error);
      }
    };

    fetchEvents();
  }, []);

  const handleDateChange = (date) => {
    setSelectedDate(date);

    // Filter events based on the selected date
    const selectedEventsForDate = events.filter(
      (event) => new Date(event.START_DATE).toDateString() === date.toDateString()
    );

    setSelectedEvents(selectedEventsForDate); // Set events for the selected date
    setView("day"); // Change the view to "day"
  };

  const handlePrevious = () => {
    const newDate = new Date(selectedDate);
    if (view === "month") newDate.setMonth(newDate.getMonth() - 1);
    else if (view === "week") newDate.setDate(newDate.getDate() - 7);
    else newDate.setDate(newDate.getDate() - 1);
    setSelectedDate(newDate);
  };

  const handleNext = () => {
    const newDate = new Date(selectedDate);
    if (view === "month") newDate.setMonth(newDate.getMonth() + 1);
    else if (view === "week") newDate.setDate(newDate.getDate() + 7);
    else newDate.setDate(newDate.getDate() + 1);
    setSelectedDate(newDate);
  };

  const formatDate = (date) => {
    // Format the date to DD-MM-YYYY format
    return date.toLocaleDateString("en-GB"); // en-GB format removes time zone
  };

  const renderViewContent = () => {
    if (view === "day") {
      return (
        <div className="Main_calender_div">
          <p>Day View: {formatDate(selectedDate)}</p>
          {selectedEvents.length > 0 ? (
            <div>
              <h4>Events for this day:</h4>
              <table className="event-table">
                <thead>
                  <tr>
                    <th>Name</th>
                    <th>Start Date</th>
                    <th>End Date</th>
                    <th>Type</th>
                  </tr>
                </thead>
                <tbody>
                  {selectedEvents.map((event, index) => (
                    <tr key={index}>
                      <td>{event.NAME}</td>
                      <td>{formatDate(new Date(event.START_DATE))}</td>
                      <td>{formatDate(new Date(event.END_DATE))}</td>
                      <td>{event.OCCUPANCYTYPE}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <p>No events for this day.</p>
          )}
        </div>
      );
    } else if (view === "week") {
      return (
        <div>
          <p>Week: Events for the week of {formatDate(selectedDate)}</p>
          {events.filter((event) => {
            const eventDate = new Date(event.START_DATE);
            const startOfWeek = new Date(selectedDate);
            startOfWeek.setDate(selectedDate.getDate() - selectedDate.getDay());
            const endOfWeek = new Date(startOfWeek);
            endOfWeek.setDate(startOfWeek.getDate() + 6);

            return eventDate >= startOfWeek && eventDate <= endOfWeek;
          }).map((event, index) => (
            <div key={index} className="event-details">
              <table className="event-table">
                <thead>
                  <tr>
                    <th>Name</th>
                    <th>Start Date</th>
                    <th>End Date</th>
                    <th>Type</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>{event.NAME}</td>
                    <td>{formatDate(new Date(event.START_DATE))}</td>
                    <td>{formatDate(new Date(event.END_DATE))}</td>
                    <td>{event.OCCUPANCYTYPE}</td>
                  </tr>
                </tbody>
              </table>
            </div>
          ))}
        </div>
      );
    } else {
      return (
        <Calendar
          onChange={handleDateChange}
          value={selectedDate}
          tileClassName={({ date }) => {
            const eventForDay = events.some(
              (event) => new Date(event.START_DATE).toDateString() === date.toDateString()
            );

            return eventForDay ? "highlight-event" : null;
          }}
        />
      );
    }
  };

  // Get the current month and year
  const currentMonthYear = selectedDate.toLocaleString('default', { month: 'long', year: 'numeric' });

  return (
    <div className="calendar-container">
      {/* Header */}
      <div className="calendar-header">
        {/* <h2>Event Calendar</h2> */}
        <div className="current-month-year">
          {/* <p>{currentMonthYear}</p> Display current month and year */}
        </div>
        <div className="nav-buttons">
          <button onClick={handlePrevious}></button>
          <button onClick={handleNext}></button>
        </div>
      </div>

      {/* Toggle Buttons */}
      <div className="toggle-buttons">
        <button
          className={`toggle-button ${view === "day" ? "active" : ""}`}
          onClick={() => setView("day")}
        >
          Day
        </button>
        <button
          className={`toggle-button ${view === "week" ? "active" : ""}`}
          onClick={() => setView("week")}
        >
          Week
        </button>
        <button
          className={`toggle-button ${view === "month" ? "active" : ""}`}
          onClick={() => setView("month")}
        >
          Month
        </button>
      </div>

      {/* Calendar Content */}
      <div className="toggle-buttons">{renderViewContent()}</div>
    </div>
  );
};

export default EventCalendar;