

import React, { useState, useEffect, useCallback } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
// import Landing from './Landing';
import styled from 'styled-components';

// Styled components
const HeaderContainer = styled.div`
  margin-left: vh;
  margin-top: 8vh;
  width: 100%;
  padding: 0;
`;

const StickyHeader = styled.div`
background: linear-gradient(to right, #012353, #27AE60);
  color: white;
  border-radius: 5px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  padding: 0.5rem 1rem;
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 1rem; /* Adjust font size as needed */
  font-weight: bold;
`;

const FilterContainer = styled.div`
  display: flex;
  align-items: center;
`;

const FilterGroup = styled.div`
  display: flex;
  align-items: center;
  margin-left: 20px;
`;

const FilterInput = styled.input`
  color: black;
  border: 1px solid #ced4da;
  padding: 3px;
  border-radius: 5px;
  width: 150px;
  margin-left: 5px;
`;

const Button = styled.button`
  background-color: ${props => props.bgColor || '#28a745'};
  color: white;
  border: none;
  border-radius: 5px;
  padding: 0.5rem 1rem;
  margin-right: 1rem;
  cursor: pointer;
  &:hover {
    background-color: ${props => props.hoverColor || '#218838'};
  }
`;
const ApplicationList = () => {
  const [selectedClass, setSelectedClass] = useState('All');
  const [selectedAcademicYear, setSelectedAcademicYear] = useState('All');
  const [searchStudentId, setSearchStudentId] = useState('');
  const [searchFirstName, setSearchFirstName] = useState('');
  const [selectedStudentIds, setSelectedStudentIds] = useState([]);
  const [studentAcademic, setStudentAcademic] = useState([]);
  const [filteredStudentAcademic, setFilteredStudentAcademic] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchStudentAcademic();
  }, []);

  const fetchStudentAcademic = async () => {
    try {
      const response = await fetch('http://13.127.57.224:2081/api/enrollment');
      if (!response.ok) {
        throw new Error('Failed to fetch data');
      }
      const data = await response.json();
      setStudentAcademic(data);
      setFilteredStudentAcademic(data); // Initialize filtered data with all data
      setIsLoading(false);
    } catch (error) {
      console.error('Error fetching data:', error);
      setError(error.message);
      setIsLoading(false);
    }
  };

  const filterData = useCallback(() => {
    let filteredData = studentAcademic;

    if (selectedClass !== 'All') {
      filteredData = filteredData.filter(student => student.CLASS === selectedClass);
    }

    if (selectedAcademicYear !== 'All') {
      filteredData = filteredData.filter(student => student.ACADEMIC_SESSION === selectedAcademicYear);
    }

    if (searchStudentId.trim() !== '') {
      filteredData = filteredData.filter(student =>
        student.APPLICATION_ID && student.APPLICATION_ID.toString().toLowerCase().includes(searchStudentId.toLowerCase())
      );
    }

    if (searchFirstName.trim() !== '') {
      filteredData = filteredData.filter(student =>
        student.FIRST_NAME && student.FIRST_NAME.toLowerCase().includes(searchFirstName.toLowerCase())
      );
    }

    setFilteredStudentAcademic(filteredData);
  }, [selectedClass, selectedAcademicYear, searchStudentId, searchFirstName, studentAcademic]);

  useEffect(() => {
    filterData();
  }, [filterData]);

  const handleReset = () => {
    setSelectedClass('All');
    setSelectedAcademicYear('All');
    setSearchStudentId('');
    setSearchFirstName('');
    setFilteredStudentAcademic(studentAcademic); // Reset filtered data to original state
    setSelectedStudentIds([]);
  };

  const handleCheckboxChange = (studentId) => {
    const newSelectedStudentIds = selectedStudentIds.includes(studentId)
      ? selectedStudentIds.filter(id => id !== studentId)
      : [...selectedStudentIds, studentId];

    setSelectedStudentIds(newSelectedStudentIds);
  };

  const handleMasterCheckboxChange = () => {
    if (selectedStudentIds.length === filteredStudentAcademic.length) {
      setSelectedStudentIds([]);
    } else {
      const allStudentIds = filteredStudentAcademic.map(student => student.APPLICATION_ID);
      setSelectedStudentIds(allStudentIds);
    }
  };

  const handleApproveSelected = async () => {
    try {
      // Check if studentAcademic has data, if not fetch it
      if (studentAcademic.length === 0) {
        await fetchStudentAcademic();
      }

      for (const applicationId of selectedStudentIds) {
        const studentData = studentAcademic.find(student => student.APPLICATION_ID === applicationId);
        if (!studentData) {
          console.error(`Student data not found for application ID: ${applicationId}`);
          continue; // Skip processing this ID
        }

        const response = await fetch('http://13.127.57.224:2081/api/enroll', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            enrollmentid: studentData.ENROLLMENT_ID,
            applicationId: studentData.APPLICATION_ID,
            firstName: studentData.FIRST_NAME,
            middleName: studentData.MIDDLE_NAME,
            lastName: studentData.LAST_NAME,
            gender: studentData.GENDER,
            contactNumber: studentData.CONTACT_NUMBER,
            city: studentData.CITY,
            state: studentData.STATE,
            postalCode: studentData.POSTAL_CODE,
            dateOfBirth: studentData.DATE_OF_BIRTH,
            email: studentData.EMAIL,
            enrollmentDate: studentData.ENROLLMENT_DATE,
            nationality: studentData.NATIONALITY,
            orphanStudent: studentData.ORPHAN_STUDENT,
            birthCertificateNumber: studentData.BIRTH_CERTIFICATE_NUMBER,
            cast: studentData.CAST,
            religion: studentData.RELIGION,
            bloodGroup: studentData.BLOOD_GROUP,
            diseaseIfAny: studentData.DISEASE_IF_ANY,
            additionalNote: studentData.ADDITIONAL_NOTE,
            identificationMark: studentData.IDENTIFICATION_MARK,
            previousschool: studentData.PREVIOUS_SCHOOL,
            emergencyContactName: studentData.EMERGENCY_CONTACT_NAME,
            emergencyContactNumber: studentData.EMERGENCY_CONTACT_NUMBER,
            aadharnumber: studentData.AADHAAR_NUMBER,
            isactive: studentData.IS_ACTIVE,
            fatherName: studentData.FATHER_NAME,
            fatherAadharId: studentData.FATHER_ADHAR_ID,
            fatherOccupation: studentData.FATHER_OCCUPATION,
            fatherEducation: studentData.FATHER_EDUCATION,
            fatherMobileNumber: studentData.FATHER_MOBILE_NUMBER,
            fatherIncome: studentData.FATHER_INCOME,
            motherName: studentData.MOTHER_NAME,
            motherAadharId: studentData.MOTHER_ADHAR_ID,
            motherOccupation: studentData.MOTHER_OCCUPATION,
            motherEducation: studentData.MOTHER_EDUCATION,
            motherMobileNumber: studentData.MOTHER_MOBILE_NUMBER,
            motherIncome: studentData.MOTHER_INCOME,
            primaryContactNumber: studentData.PRIMARY_CONTACT_NUMBER,
            isenroll: studentData.IS_ENROLL,
            academicyear: studentData.ACADEMIC_YEAR,
            class: studentData.CLASS,
            isEnroll: true // Assuming this field is for enrollment approval
          }),
        });

        if (!response.ok) {
          throw new Error('Network response was not ok');
        }

        const data = await response.json();
        console.log('Approval response:', data);
        if (data.message === 'Data inserted successfully into all tables.') {
          alert('Approval successful for application ID: ' + applicationId);
          // Optionally refresh data after approval
          fetchStudentAcademic();
        } else {
          alert('Approval failed for application ID: ' + applicationId + ' - ' + data.error);
        }
      }
    } catch (error) {
      console.error('Error approving applications:', error);
      alert('Approval failed: ' + error.message);
    }
  };

  const handleEditField = async (applicationId, fieldName, value) => {
    try {
      const updatedStudentAcademic = filteredStudentAcademic.map(student => {
        if (student.APPLICATION_ID === applicationId) {
          return {
            ...student,
            [fieldName]: value === 'yes' ? true : false // Assuming IS_ENROLL is a boolean
          };
        }
        return student;
      });

      setFilteredStudentAcademic(updatedStudentAcademic);

      // Make API call to update the IS_ENROLL field in backend
      const response = await fetch(`http://13.127.57.224:2081/api/enroll/${applicationId}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          [fieldName]: value === 'yes' ? true : false // Assuming IS_ENROLL is a boolean
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to update data');
      }

      const data = await response.json();
      console.log('Update response:', data);
    } catch (error) {
      console.error('Error updating data:', error);
      alert('Failed to update data: ' + error.message);
    }
  };

  if (isLoading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>Error: {error}</div>;
  }

  // Define column definitions for AG Grid
  const columnDefs = [
    {
      headerCheckboxSelection: true, // Allow master checkbox to select all rows
      checkboxSelection: true, // Allow individual row checkboxes
      width: 50,
      pinned: 'left',
    },
    { headerName: 'Application ID', field: 'APPLICATION_ID' },
    { headerName: 'First Name', field: 'FIRST_NAME' },
    { headerName: 'Last Name', field: 'LAST_NAME' },
    { headerName: 'Class', field: 'CLASS' },
    { headerName: 'Strem', field: 'STREAM' },
    { headerName: 'Optional', field: 'OPTIONAL' },

    { headerName: ' House Number', field: ' HOUSE_NUMBER' },
    { headerName: 'House Bulding Name', field: 'HOUSE_BUILDING_NAME' },
    { headerName: 'Street Name', field: 'STREET_NAME' },
    { headerName: 'Landmark', field: 'LANDMARK' },

    { headerName: 'Father Name', field: 'FATHER_NAME' },
    { headerName: 'Father Aadhar ID', field: 'FATHER_ADHAR_ID' },
    { headerName: 'Mother Name', field: 'MOTHER_NAME' },
    { headerName: 'Mother Aadhar ID', field: 'MOTHER_ADHAR_ID' },
    {
      headerName: 'Is Enroll',
      field: 'IS_ENROLL',
      cellRenderer: (params) => (
        <select
          value={params.value ? 'yes' : 'no'}
          onChange={(e) => handleEditField(params.data.APPLICATION_ID, 'IS_ENROLL', e.target.value)}
        >
          <option value="yes">Yes</option>
          <option value="no">No</option>
        </select>
      ),
    },
  ];

  return (
    <HeaderContainer>
    <div className="header-container">
      {/* <Landing /> */}
      <div className="container-fluid" style={{  width: '100%', padding: 0 }}>
      
        <div className="container-fluid" style={{ marginTop: '1vh', width: '100%', padding: 0 }}>
          <div className="container-fluid d-flex flex-column">
          <StickyHeader>
              <FilterContainer>
                <FilterGroup>
                  <input
                    type="checkbox"
                    checked={selectedStudentIds.length === filteredStudentAcademic.length && filteredStudentAcademic.length > 0}
                    onChange={handleMasterCheckboxChange}
                    className="master-checkbox"
                  />
                  <span>Select All</span>
                </FilterGroup>
               
              
              </FilterContainer>
              <div className="d-flex align-items-center">
                <Button onClick={handleApproveSelected}>Approve Selected</Button>
                <Button bgColor="#6c757d" hoverColor="#5a6268" onClick={handleReset}>Reset</Button>
              </div>
            </StickyHeader>
            <div className="ag-theme-alpine" style={{ height: '80vh', width: '100%' }}>
              <AgGridReact
                rowData={filteredStudentAcademic}
                columnDefs={columnDefs}
                rowSelection="multiple"
                onSelectionChanged={(event) => {
                  const selectedRows = event.api.getSelectedRows();
                  setSelectedStudentIds(selectedRows.map(row => row.APPLICATION_ID));
                }}
              />
            </div>
          </div>
        </div>
      </div>
      </div>
      </HeaderContainer>

      
    
  );
};

export default ApplicationList;
