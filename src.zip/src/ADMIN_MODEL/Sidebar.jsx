
import React, { useState,useEffect } from 'react';
import styled from 'styled-components';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {
  faTachometerAlt,
  faUserGraduate,
  faChevronRight,
  faMoneyBillWave,
  faChalkboardTeacher,
  faFileSignature,
  faChevronDown,
  faFileAlt,
  faUserFriends,
  faEnvelope
} from '@fortawesome/free-solid-svg-icons';
import { Link, useNavigate, useLocation } from 'react-router-dom';

// Styled Sidebar
const Sidebar = styled.div`
  height: 100vh;
  width: ${(props) => (props.isExpanded ? '17%' : '5%')};
  position: fixed;
  top: 0;
  left: 0;
  background: linear-gradient(#343a40, #36454f);  color: #ecf0f1;
  transition: width 0.3s ease;
  overflow-x: hidden;
  z-index: 1000;
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  padding-top: 8.6rem;

  &:hover {
    width: 250px; // Expand width on hover
  }
`;

// Sidebar item styles
const Logo = styled.img`
  width: 40px;
  height: 40px;
  border-radius: 50%;
  background: white;
  border: 1px solid #fff;
  object-fit: contain;
  position: fixed;
  top: 10px;
  left: 17px;
  transition: transform 0.3s ease, box-shadow 0.3s ease;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);

  &:hover {
    transform: scale(1.05);
    box-shadow: 0 8px 16px rgba(0, 0, 0, 0.3);
  }

  @media (max-width: 768px) {
    width: 30px;
    height: 30px;
    top: 15px;
    left: 20px;
  }
`;

const Text = styled.span`
  font-size: 1.3rem;
  padding: 11px 50px;
  font-weight: bold;
  text-transform: uppercase;
  position: absolute;
  top: 0px;
  left: 14px;
  background: linear-gradient(145deg, #012353, #27ae60);
  -webkit-background-clip: text;
  -webkit-text-fill-color: white;
  color: white;

  @media (max-width: 1200px) {
    font-size: 1.2rem;
    padding: 10px 40px;
  }

  @media (max-width: 992px) {
    font-size: 1.2rem;
    padding: 8px 30px;
  }

  @media (max-width: 768px) {
    font-size: 1.2rem;
    padding: 7px 45px;
    top: 5px;
    left: 10px;
  }

  @media (max-width: 576px) {
    font-size: 1.2rem;
    padding: 4px 15px;
    left: 10px;
  }
`;

const Icon = styled.div`
  margin-right: 14px;
  display: flex;
  font-size: 1.5rem;
  align-items: center;

  svg {
    margin-left: 5px;
  }
`;

const SidebarItem = styled.div`
  padding: 10px 9px;
  display: flex;
  border-radius: 4px;
  align-items: center;
  cursor: pointer;
  font-size: 1rem;
  color: ${(props) => (props.isActive ? '#fff' : 'white')};
  background: ${(props) => (props.isActive ? '#0096FF' : 'transparent')};
  transition: background 0.2s ease;
  white-space: nowrap;
  overflow: hidden;
  margin: 1px 11px 15px 2px;

  &:hover {
    background: #2980b9;
  }

  ${(props) => props.isExpanded && `
      padding: 1rem 1rem; 
  `}
`;

const SidebarLink = styled(Link)`
  color: inherit;
  text-decoration: none;
  display: flex;
  align-items: center;
  width: 100%;
  height: 100%;
`;

const SidebarDropdownMenu = styled.div`
  display: ${(props) => (props.isVisible ? 'block' : 'none')};
  padding: 0 13px;
`;

const SidebarDropdownItem = styled.div`
  padding: 8px 2px;
  display: flex;
  align-items: center;
  border-radius: 4px;
  cursor: pointer;
  font-size: 1rem;
  color: ${(props) => (props.isActive ? 'black' : '#e5e8e8')};
  background: ${(props) => (props.isActive ? 'white' : 'transparent')};
  transition: background 0.3s ease;
  margin: 12px 11px 11px 5px;

  &:hover {
    background: #5d6d7e;
    color: white;
  }

  &.active {
    background: #fff;
  }

  span {
    display: ${(props) => (props.isSidebarVisible ? 'inline' : 'none')};
    margin-left: 10px;
  }
`;

const CircleIcon = styled.div`
  width: 16px;
  height: 16px;
  border-radius: 50%;
  border: 2px solid gray;
  margin-right: 8px;
  background: transparent;

  display: flex;
  align-items: center;
  justify-content: center;
  transition: background 0.3s ease;
`;


// SidebarComponent function
const SidebarComponent = ({ isVisible }) => {
  const [isSidebarVisible, setSidebarVisible] = useState(true);
  const [sidebarHovered, setSidebarHovered] = useState(false);
  const [visibleDropdown, setVisibleDropdown] = useState(null);

  const location = useLocation();
  const navigate = useNavigate();
  const toggleSidebar = () => {
    setSidebarVisible((prev) => !prev);
  };

  const showDropdown = (dropdown) => {
    setVisibleDropdown(visibleDropdown === dropdown ? null : dropdown);
  };

  const handleSidebarLinkClick = (path) => {
    if (location.pathname === path) {
      setVisibleDropdown(null);
    }
  };

  const determineDropdownVisibility = () => {
    const paths = {
      '/DashBoard': 'DashBoard',
      '/Application_form': 'Admission',
      '/Enrollment': 'Admission',
      '/Student_Grade_Book_Entry': 'Report',
      '/Grad_Report': 'Report',
      '/Student_promoted_form': 'Report',
      '/StudentFill_Attendance': 'Report',
      '/Assignment': 'Assignment',
      '/Student_Profile': 'student',
      '/parent_profile': 'student',
      '/Student_Attendance': 'student',
      '/Student_Academic_Performance': 'student',
      '/Student_health': 'student',
      '/Student_Grad_Book': 'student',
      '/Student_performance': 'student',
      '/Teacher_Hiring': 'Add Teacher',
       '/Joining_Latter': 'Add Teacher',
      '/Staff_Profile': 'Staff',
      '/Staff_Attendance': 'Staff',
      '/Admin_Fess': 'Fess',

    };
    return paths[location.pathname] || null;
  };

  useEffect(() => {
    setVisibleDropdown(determineDropdownVisibility());
  }, [location.pathname, isVisible]);

  return (
    <Sidebar isExpanded={isVisible}>
    <div>
        <Logo src="02 1 copy.jpg" alt="Logo" />
        {isVisible || sidebarHovered ? <Text>Edu360</Text> : null}
        <hr style={{ width: '100%', height: '1px', backgroundColor: 'grey', margin: '0', padding: '0', border: 'none' }} />

         {/* dashboard */}
              
         <SidebarItem isActive={location.pathname === '/DashBoard'} onClick={() => handleSidebarLinkClick('/DashBoard')}>
                <SidebarLink to="/DashBoard">
                <Icon style={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-start', marginLeft: '4px' }}>
                <FontAwesomeIcon icon={faTachometerAlt} />
                  </Icon>
                  {isVisible || sidebarHovered ? 'DashBoard' : null}
                </SidebarLink>
              </SidebarItem>



    {/* form */}
    
    <SidebarItem isActive={['/Application_form','/Enrollment',].includes(location.pathname)} onClick={() => showDropdown('Admission')}>
              <Icon style={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-start', marginLeft: '7px' }}>
                  <FontAwesomeIcon icon={faFileSignature} />
                </Icon>
                { isVisible || sidebarHovered ? 'Admission  ' : null}
                {(isVisible || sidebarHovered) && (<FontAwesomeIcon icon={visibleDropdown === 'Admission' ? faChevronDown : faChevronRight}style={{marginLeft: '3.9rem',fontSize: '0.9rem',transform: visibleDropdown === 'Admission' ? 'rotate(1deg)' : 'rotate(180deg)', transition: 'transform 0.1s ease'}}/>)}  
    
              </SidebarItem>
              <SidebarDropdownMenu isVisible={visibleDropdown === 'Admission' && (isVisible || sidebarHovered ?'Admission':null)}>
    
              <SidebarDropdownItem isActive={location.pathname === '/Application_form'}>
                  <CircleIcon isActive={location.pathname === '/Application_form'} />
                  <SidebarLink to="/Application_form" onClick={() => handleSidebarLinkClick('/Application_form')}> Application Form</SidebarLink>
                </SidebarDropdownItem>

                <SidebarDropdownItem isActive={location.pathname === '/Enrollment'}>
                  <CircleIcon isActive={location.pathname === '/Enrollment'} />
                  <SidebarLink to="/Enrollment" onClick={() => handleSidebarLinkClick('/Enrollment')}>Enrollment</SidebarLink>
                </SidebarDropdownItem>
               
                </SidebarDropdownMenu>


   {/* ADDnew */}
                <SidebarItem isActive={['/Teacher_Hiring','/Joining_Latter',].includes(location.pathname)} onClick={() => showDropdown('Add Teacher')}>
              <Icon style={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-start', marginLeft: '7px' }}>
                  <FontAwesomeIcon icon={faChalkboardTeacher} />
                </Icon>
                { isVisible || sidebarHovered ? 'Add Teacher  ' : null}
                {(isVisible || sidebarHovered) && (<FontAwesomeIcon icon={visibleDropdown === 'Add Teacher' ? faChevronDown : faChevronRight}style={{marginLeft: '3rem',fontSize: '0.9rem',transform: visibleDropdown === 'Add Teacher' ? 'rotate(1deg)' : 'rotate(180deg)', transition: 'transform 0.1s ease'}}/>)}  
    
              </SidebarItem>
              <SidebarDropdownMenu isVisible={visibleDropdown === 'Add Teacher' && (isVisible || sidebarHovered ?'Add Teacher':null)}>
              <SidebarDropdownItem isActive={location.pathname === '/Teacher_Hiring'}>
                  <CircleIcon isActive={location.pathname === '/Teacher_Hiring'} />
                  <SidebarLink to="/Teacher_Hiring" onClick={() => handleSidebarLinkClick('/Teacher_Hiring')}>Teacher Hiring</SidebarLink>
                </SidebarDropdownItem>
              <SidebarDropdownItem isActive={location.pathname === '/Joining_Latter'}>
                  <CircleIcon isActive={location.pathname === '/Joining_Latter'} />
                  <SidebarLink to="/Joining_Latter" onClick={() => handleSidebarLinkClick('/Joining_Latter')}>Joining Letter</SidebarLink>
                </SidebarDropdownItem>
             
               
                </SidebarDropdownMenu>







              {/* Addmision */}
    
    
              <SidebarItem isActive={[ '/Grad_Report','/StudentFill_Attendance','/Student_Grade_Book_Entry','/Student_promoted_form'].includes(location.pathname)} onClick={() => showDropdown('Report')}>
              <Icon style={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-start',marginLeft: '4px' }}>
                  <FontAwesomeIcon icon={faUserGraduate} />
                </Icon>
                  { isVisible || sidebarHovered ? 'Report ' : null}
                  {(isVisible || sidebarHovered) && (<FontAwesomeIcon icon={visibleDropdown === 'Report' ? faChevronDown : faChevronRight}style={{marginLeft: '5.9rem',fontSize: '0.9rem',transform: visibleDropdown === 'Report' ? 'rotate(1deg)' : 'rotate(180deg)', transition: 'transform 0.3s ease'}}/>)}  
    
              </SidebarItem>
              <SidebarDropdownMenu isVisible={visibleDropdown === 'Report' && (isVisible || sidebarHovered ?'Report':null)}>
    

              <SidebarDropdownItem isActive={location.pathname === '/Student_Grade_Book_Entry'}>
                  <CircleIcon isActive={location.pathname === '/Student_Grade_Book_Entry'} />
                  <SidebarLink to="/Student_Grade_Book_Entry" onClick={() => handleSidebarLinkClick('/Student_Grade_Book_Entry')}>Grade Entry</SidebarLink>
                </SidebarDropdownItem>
                <SidebarDropdownItem isActive={location.pathname === '/Grad_Report'}>
                  <CircleIcon isActive={location.pathname === '/Grad_Report'} />
                  <SidebarLink to="/Grad_Report" onClick={() => handleSidebarLinkClick('/Grad_Report')}> Grade Report </SidebarLink>
                </SidebarDropdownItem>

              <SidebarDropdownItem isActive={location.pathname === '/Student_promoted_form'}>
                  <CircleIcon isActive={location.pathname === '/Student_promoted_form'} />
                  <SidebarLink to="/Student_promoted_form" onClick={() => handleSidebarLinkClick('/Student_promoted_form')}>Student Promoted Form</SidebarLink>
                </SidebarDropdownItem>
              {/* <SidebarDropdownItem isActive={location.pathname === '/Assignment_Form'}>
                  <CircleIcon isActive={location.pathname === '/Assignment_Form'} />
                  <SidebarLink to="/Assignment_Form" onClick={() => handleSidebarLinkClick('/Assignment_Form')}>Assignment Form</SidebarLink>
                </SidebarDropdownItem> */}
                <SidebarDropdownItem isActive={location.pathname === '/StudentFill_Attendance'}>
                  <CircleIcon isActive={location.pathname === '/StudentFill_Attendance'} />
                  <SidebarLink to="/StudentFill_Attendance" onClick={() => handleSidebarLinkClick('/StudentFill_Attendance')}>Fill Attendance</SidebarLink>
                </SidebarDropdownItem>
                 
    
               
              </SidebarDropdownMenu>



                {/* assiment */}
    
                <SidebarItem isActive={['/Assignment'].includes(location.pathname)} onClick={() => showDropdown('Assignment')}>
      <Icon style={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-start', marginLeft: '4px' }}>
      <FontAwesomeIcon icon={faFileAlt} />
          </Icon>
          {isVisible || sidebarHovered ? 'Assignment  ' : null}
          {(isVisible || sidebarHovered) && (
            <FontAwesomeIcon 
              icon={visibleDropdown === 'Assignment' ? faChevronDown : faChevronRight}
              style={{
                marginLeft: '3.4rem',
                fontSize: '0.9rem',
                transform: visibleDropdown === 'Assignment' ? 'rotate(1deg)' : 'rotate(180deg)',
                transition: 'transform 0.3s ease'
              }}
            />
          )}
        </SidebarItem>
        <SidebarDropdownMenu isVisible={visibleDropdown === 'Assignment' && (isVisible || sidebarHovered ?'Assignment':null)}>
          <SidebarDropdownItem isActive={location.pathname === '/Assignment'}>
            <CircleIcon isActive={location.pathname === '/Assignment'} />
            <SidebarLink to="/Assignment" onClick={() => handleSidebarLinkClick('/Assignment')}>Assignment</SidebarLink>
          </SidebarDropdownItem>
        </SidebarDropdownMenu>
    
 



      {/* student */}
    
    
      <SidebarItem isActive={['/Student_Profile', '/parent_profile', '/Student_Attendance',  '/Student_Academic_Performance', '/Student_health','/Student_Grad_Book','/Student_performance'].includes(location.pathname)} onClick={() => showDropdown('student')}>
              <Icon style={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-start', marginLeft: '3px' }}>
                  <FontAwesomeIcon icon={faUserGraduate} />
                </Icon>
                  { isVisible || sidebarHovered ? 'Student  ' : null}
                  {(isVisible || sidebarHovered) && (<FontAwesomeIcon icon={visibleDropdown === 'Student' ? faChevronDown : faChevronRight}style={{marginLeft: '5.2rem',fontSize: '0.9rem',transform: visibleDropdown === 'Student' ? 'rotate(1deg)' : 'rotate(180deg)', transition: 'transform 0.1s ease'}}/>)}  
    
              </SidebarItem>
                
              <SidebarDropdownMenu isVisible={visibleDropdown === 'student' && (isVisible || sidebarHovered ?'student':null)}>
    
                <SidebarDropdownItem isActive={location.pathname === '/Student_Profile'}>
                  <CircleIcon isActive={location.pathname === '/Student_Profile'} />
                  <SidebarLink to="/Student_Profile" onClick={() => handleSidebarLinkClick('/Student_Profile')}>Student Profile</SidebarLink>
                </SidebarDropdownItem>
                <SidebarDropdownItem isActive={location.pathname === '/parent_profile'}>
                  <CircleIcon isActive={location.pathname === '/parent_profile'} />
                  <SidebarLink to="/parent_profile" onClick={() => handleSidebarLinkClick('/parent_profile')}>Parent Profile</SidebarLink>
                </SidebarDropdownItem>
                <SidebarDropdownItem isActive={location.pathname === '/Student_Attendance'}>
                  <CircleIcon isActive={location.pathname === '/Student_Attendance'} />
                  <SidebarLink to="/Student_Attendance" onClick={() => handleSidebarLinkClick('/Student_Attendance')}>Student Attendance</SidebarLink>
                </SidebarDropdownItem>
              <SidebarDropdownItem isActive={location.pathname === '/Student_Grad_Book'}>
                  <CircleIcon isActive={location.pathname === '/Student_Grad_Book'} />
                  <SidebarLink to="/Student_Grad_Book" onClick={() => handleSidebarLinkClick('/Student_Grad_Book')}>Grade Book</SidebarLink>
                </SidebarDropdownItem>
                <SidebarDropdownItem isActive={location.pathname === '/Student_Academic_Performance'}>
                  <CircleIcon isActive={location.pathname === '/Student_Academic_Performance'} />
                  <SidebarLink to="/Student_Academic_Performance" onClick={() => handleSidebarLinkClick('/Student_Academic_Performance')}>Academic Performance</SidebarLink>
                </SidebarDropdownItem>
                <SidebarDropdownItem isActive={location.pathname === '/Student_health'}>
                  <CircleIcon isActive={location.pathname === '/Student_health'} />
                  <SidebarLink to="/Student_health" onClick={() => handleSidebarLinkClick('/Student_health')}>Student Health</SidebarLink>
                </SidebarDropdownItem>
                <SidebarDropdownItem isActive={location.pathname === '/Student_performance'}>
                  <CircleIcon isActive={location.pathname === '/Student_performance'} />
                  <SidebarLink to="/Student_performance" onClick={() => handleSidebarLinkClick('/Student_performance')}>Student performance</SidebarLink>
                </SidebarDropdownItem>
              </SidebarDropdownMenu>
    
    

      {/* staff */}
    
    
    
      <SidebarItem isActive={['/Staff_Profile', '/Staff_Attendance',].includes(location.pathname)} onClick={() => showDropdown('Staff')}>
              <Icon style={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-start', marginLeft: '3px' }}>
      <FontAwesomeIcon icon={faUserFriends}  />
    </Icon>
    
        { isVisible || sidebarHovered ? 'Staff  ' : null}
        {(isVisible || sidebarHovered) && (<FontAwesomeIcon icon={visibleDropdown === 'Staff' ? faChevronDown : faChevronRight}style={{marginLeft: '6.2rem',fontSize: '0.9rem',transform: visibleDropdown === 'Staff' ? 'rotate(1deg)' : 'rotate(180deg)', transition: 'transform 0.1s ease'}}/>)}  
              </SidebarItem>
              <SidebarDropdownMenu isVisible={visibleDropdown === 'Staff' && (isVisible || sidebarHovered ?'Staff':null)}>
    
                <SidebarDropdownItem isActive={location.pathname === '/Staff_Profile'}>
                  <CircleIcon isActive={location.pathname === '/Staff_Profile'} />
                  <SidebarLink to="/Staff_Profile" onClick={() => handleSidebarLinkClick('/Staff_Profile')}>Staff Profile</SidebarLink>
                </SidebarDropdownItem>
              <SidebarDropdownItem isActive={location.pathname === '/Staff_Attendance'}>
                  <CircleIcon isActive={location.pathname === '/Staff_Attendance'} />
                  <SidebarLink to="/Staff_Attendance" onClick={() => handleSidebarLinkClick('/Staff_Attendance')}>Staff Attendance</SidebarLink>
                </SidebarDropdownItem>
              
                <SidebarDropdownItem isActive={location.pathname === '/BulkLoad'}>
                  <CircleIcon isActive={location.pathname === '/BulkLoad'} />
                  <SidebarLink to="/BulkLoad" onClick={() => handleSidebarLinkClick('/BulkLoad')}>Bulk Load</SidebarLink>
                </SidebarDropdownItem>
              </SidebarDropdownMenu>




               {/* Admin_Fess */}

        <SidebarItem isActive={location.pathname === '/Admin_Fess'} onClick={() => handleSidebarLinkClick('/Admin_Fess')}>
                <SidebarLink to="/Admin_Fess">
                <Icon style={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-start', marginLeft: '4px' }}>
                <FontAwesomeIcon icon={faMoneyBillWave} />
                  </Icon>
                  {isVisible || sidebarHovered ? 'Fess' : null}
                </SidebarLink>
              </SidebarItem>
 </div>
 <div>
 </div>
 </Sidebar>
  );
  };
 export default SidebarComponent;
