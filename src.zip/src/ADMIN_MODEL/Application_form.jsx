
import React, { useState } from "react";
import axios from "axios";
import "./Admin_Model.css";
import "bootstrap/dist/css/bootstrap.min.css";
import {
  validateEmail,
  validatePhoneNumber,
  validateAadhar,
  validatePinCode,
  sanitizeAndFormatAadhar,
  sanitizeAndFormatPhoneNumber,
} from "./Application_Form_Validation";

const ApplicationForm = () => {
  const [formData, setFormData] = useState({
    FIRST_NAME: "",
    MIDDLE_NAME: "",
    LAST_NAME: "",
    GENDER: "",
    CONTACT_NUMBER: "",
    CLASS: "",
    STREAM: "",
    OPTIONAL: "",
    DATE_OF_BIRTH: "",
    EMAIL: "",
    ENROLLMENT_DATE: "",
    BIRTH_CERTIFICATE_NUMBER: "",
    CAST: "",
    RELIGION: "",
    PREVIOUS_SCHOOL: "",
    EMERGENCY_CONTACT_NAME: "",
    EMERGENCY_CONTACT_NUMBER: "",
    AADHAR_NUMBER: "",
    BLOOD_GROUP: "",
    DISEASE_IF_ANY: "",
    ADDITIONAL_NOTE: "",
    IDENTIFICATION_MARK: "",
    HOUSE_NUMBER: "",
    HOUSE_BUILDING_NAME: "",
    STREET_NAME: "",
    LANDMARK: "",
    CITY: "",
    STATE: "",
    POSTAL_CODE: "",
    FATHER_NAME: "",
    FATHER_ADHAR_ID: "",
    FATHER_OCCUPATION: "",
    FATHER_EDUCATION: "",
    FATHER_MOBILE_NUMBER: "",
    FATHER_INCOME: "",
    MOTHER_NAME: "",
    MOTHER_ADHAR_ID: "",
    MOTHER_OCCUPATION: "",
    MOTHER_EDUCATION: "",
    MOTHER_MOBILE_NUMBER: "",
    MOTHER_INCOME: "",
  });

  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;

    const aadhaarFields = [
      "AADHAR_NUMBER",
      "FATHER_ADHAR_ID",
      "MOTHER_ADHAR_ID",
    ];
    if (aadhaarFields.includes(name)) {
      // Use the utility function to sanitize and format Aadhaar
      const formattedValue = sanitizeAndFormatAadhar(value);
      setFormData((prevState) => ({
        ...prevState,
        [name]: formattedValue,
      }));
      return;
    }

    const phoneFields = [
      "CONTACT_NUMBER",
      "EMERGENCY_CONTACT_NUMBER",
      "FATHER_MOBILE_NUMBER",
      "MOTHER_MOBILE_NUMBER",
    ];
    if (phoneFields.includes(name)) {
      // Use the utility function to sanitize and format phone numbers
      const formattedValue = sanitizeAndFormatPhoneNumber(value);
      setFormData((prevState) => ({
        ...prevState,
        [name]: `+${formattedValue}`, // Ensure the "+" is always present
      }));
      return;
    }

    // Handle other fields
    setFormData((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };
 
  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    // Validate Email
    if (!validateEmail(formData.EMAIL)) {
      alert("Please enter a valid email address.");
      setLoading(false);
      return;
    }

    // Validate Phone Numbers
    const phoneFields = [
      { field: "CONTACT_NUMBER", label: "Primary Contact Number" },
      { field: "EMERGENCY_CONTACT_NUMBER", label: "Emergency Contact Number" },
      { field: "FATHER_MOBILE_NUMBER", label: "Father's Mobile Number" },
      { field: "MOTHER_MOBILE_NUMBER", label: "Mother's Mobile Number" },
    ];

    for (const { field, label } of phoneFields) {
      if (formData[field] && !validatePhoneNumber(formData[field])) {
        alert(`Invalid phone number for ${label}.`);
        setLoading(false);
        return;
      }
    }

    // Validate Aadhaar Numbers
    const aadhaarFields = [
      { field: "AADHAR_NUMBER", label: "Aadhaar Number" },
      { field: "FATHER_ADHAR_ID", label: "Father's Aadhaar Number" },
      { field: "MOTHER_ADHAR_ID", label: "Mother's Aadhaar Number" },
    ];

    for (const { field, label } of aadhaarFields) {
      if (formData[field] && !validateAadhar(formData[field])) {
        alert(`Invalid ${label}.`);
        setLoading(false);
        return;
      }
    }

    // Validate Postal Code
    if (formData.POSTAL_CODE && !validatePinCode(formData.POSTAL_CODE)) {
      alert("Please enter a valid 6-digit postal code.");
      setLoading(false);
      return;
    }

    // Format phone numbers and Aadhaar numbers for backend submission
    const formattedFormData = { ...formData };

    // Format phone numbers (remove the +91 and spaces)
    const phoneFieldsToFormat = [
      "CONTACT_NUMBER",
      "EMERGENCY_CONTACT_NUMBER",
      "FATHER_MOBILE_NUMBER",
      "MOTHER_MOBILE_NUMBER",
    ];

    phoneFieldsToFormat.forEach((field) => {
      if (formattedFormData[field]) {
        // Remove non-digit characters and the +91 prefix
        const phoneNumber = formattedFormData[field].replace(/\D/g, ''); // Remove non-digit characters
        formattedFormData[field] = phoneNumber.slice(2); // Remove "+91" (first 2 digits), keeping only 10 digits
      }
    });

    // Format Aadhaar numbers (remove spaces and retain 12 digits)
    const aadhaarFieldsToFormat = [
      "AADHAR_NUMBER",
      "FATHER_ADHAR_ID",
      "MOTHER_ADHAR_ID",
    ];

    aadhaarFieldsToFormat.forEach((field) => {
      if (formattedFormData[field]) {
        // Remove non-digit characters
        const aadhaar = formattedFormData[field].replace(/\D/g, ''); // Remove non-digit characters
        formattedFormData[field] = aadhaar.slice(0, 12); // Keep only the first 12 digits, no spaces
      }
    });

    try {
      const response = await axios.post(
        "http://13.127.57.224:2081/api/application",
        formattedFormData
      );

      if (response.status === 200) {
        alert("Application has been submitted!");
        setFormData({}); // Reset form data
      } else {
        alert("Failed to submit the application. Please try again.");
      }
    } catch (error) {
      if (error.response) {
        alert(
          `Server error: ${error.response.status} - ${error.response.data}`
        );
      } else {
        alert(
          "Error submitting the application. Please check the console for details."
        );
      }
    } finally {
      setLoading(false);
    }
};



  const personalFields = [
    {
      label: "First Name",
      name: "FIRST_NAME",
      type: "text",
      required: true,
      placeholder: "Enter first name",
    },
    {
      label: "Middle Name",
      name: "MIDDLE_NAME",
      type: "text",
      placeholder: "Enter middle name",
    },
    {
      label: "Last Name",
      name: "LAST_NAME",
      type: "text",
      required: true,
      placeholder: "Enter last name",
    },
    {
      label: "Gender",
      name: "GENDER",
      type: "select",
      options: ["Male", "Female", "Other"],
      required: true,
      placeholder: "Select gender",
    },
    {
      label: "Class",
      name: "CLASS",
      required: true,
      type: "select",
      placeholder: "Select class",
      options: [
        "LKG",
        "UKG",
        "1",
        "2",
        "3",
        "4",
        "5",
        "6",
        "7",
        "8",
        "9",
        "10",
        "11",
        "12",
      ],
    },
    {
      label: "Stream",
      name: "STREAM",
      type: "select",
      placeholder: "Enter stream",
      options: ["Science", "Commerce", "Arts"],
    },
    {
      label: "Optional Subject",
      name: "OPTIONAL",
      type: "select",
      placeholder: "Enter optional subject",
      options: ["Hindi/Bio", "Hindi/Maths", "Computer/Bio", "Computer/Maths"],
    },
    {
      label: "Date of Birth",
      name: "DATE_OF_BIRTH",
      type: "date",
      placeholder: "Select date of birth",
    },
    {
      label: "Email",
      name: "EMAIL",
      type: "email",
      required: true,
      placeholder: "Enter email",
    },
    {
      label: "Enrollment Date",
      name: "ENROLLMENT_DATE",
      type: "date",
      placeholder: "Select enrollment date",
    },
    {
      label: "Nationality",
      name: "NATIONALITY",
      type: "text",
      placeholder: "Enter Your Nationality",
    },
    {
      label: "Birth Certificate Number",
      name: "BIRTH_CERTIFICATE_NUMBER",
      type: "text",
      placeholder: "Enter birth certificate number",
    },
    {
      label: "Caste",
      name: "CAST",
      type: "select",
      options: ["General", "EWS", "OBC", "SC", "ST"],
      placeholder: "Select caste",
    },
    {
      label: "Religion",
      name: "RELIGION",
      type: "select",
      placeholder: "Select religion",
      options: ["HINDU", "MUSLIM", "CHRISTIAN", "SIKH", "BUDDHISM", "JAIN"],
    },
    {
      label: "Previous School",
      name: "PREVIOUS_SCHOOL",
      type: "text",
      placeholder: "Enter previous school",
    },
    {
      label: "Emergency Contact Name",
      name: "EMERGENCY_CONTACT_NAME",
      type: "tel",
      placeholder: "Enter name",
    },
    {
      label: "Emergency Contact Number",
      name: "EMERGENCY_CONTACT_NUMBER",
      type: "tel",
      placeholder: "XXXXXXXXXX",
    },
    {
      label: "Aadhar Number",
      name: "AADHAR_NUMBER",
      maxLength: "14",
      type: "text",
      required: true,
      placeholder: "Enter 12 digit Student's Aadhaar ID",
    },
    {
      label: "Blood Group",
      name: "BLOOD_GROUP",
      type: "text",
      placeholder: "Enter blood group",
    },
    {
      label: "Disease (if any)",
      name: "DISEASE_IF_ANY",
      type: "text",
      placeholder: "Enter disease if any",
    },
    {
      label: "Additional Note",
      name: "ADDITIONAL_NOTE",
      type: "text",
      placeholder: "Enter additional note",
    },
    {
      label: "Identification Mark",
      name: "IDENTIFICATION_MARK",
      type: "text",
      placeholder: "Enter identification mark",
    },
    {
      label: "Contact Number",
      name: "CONTACT_NUMBER",
      type: "tel",
      placeholder: "XXXXXXXXXX",
    }
  ];

  const addressFields = [
{
      label: "House Number",
      name: "HOUSE_NUMBER",
      type: "text",
      placeholder: "Enter house number",
    },
    {
      label: "House/Building Name",
      name: "HOUSE_BUILDING_NAME",
      type: "text",
      placeholder: "Enter building name",
    },
    {
      label: "Street Name",
      name: "STREET_NAME",
      type: "text",
      placeholder: "Enter street name",
    },
    {
      label: "Landmark",
      name: "LANDMARK",
      type: "text",
      placeholder: "Enter landmark",
    },
    { label: "City", name: "CITY", type: "text", placeholder: "Enter city" },
    { label: "State", name: "STATE", type: "text", placeholder: "Enter state" },
    {
      label: "Postal Code",
      name: "POSTAL_CODE",
      type: "text",
      placeholder: "Enter postal code",
    },
  ];

  const parentsFields = [
    {
      label: "Father's Name",
      name: "FATHER_NAME",
      type: "text",
      placeholder: "Enter father's name",
    },
    {
      label: "Father's Aadhaar ID",
      name: "FATHER_ADHAR_ID",
      maxLength: "14",
      type: "text",
      placeholder: "Enter father's 12 digit Aadhaar ID",
    },
    {
      label: "Father's Occupation",
      name: "FATHER_OCCUPATION",
      type: "text",
      placeholder: "Enter father's occupation",
    },
    {
      label: "Father's Education",
      name: "FATHER_EDUCATION",
      type: "text",
      placeholder: "Enter father's education",
    },
    {
      label: "Father's Mobile Number",
      name: "FATHER_MOBILE_NUMBER",
      type: "text",
      placeholder: "XXXXXXXXXX",
    },
    {
      label: "Father's Income",
      name: "FATHER_INCOME",
      type: "text",
      placeholder: "Enter father's income",
    },
    {
      label: "Mother's Name",
      name: "MOTHER_NAME",
      type: "text",
      placeholder: "Enter mother's name",
    },
    {
      label: "Mother's Aadhaar ID",
      name: "MOTHER_ADHAR_ID",
      type: "text",
      maxLength: "14",
      placeholder: "Enter 12 digit Mother's Aadhaar ID",
    },
    {
      label: "Mother's Occupation",
      name: "MOTHER_OCCUPATION",
      type: "text",
      placeholder: "Enter mother's occupation",
    },
    {
      label: "Mother's Education",
      name: "MOTHER_EDUCATION",
      type: "text",
      placeholder: "Enter mother's education",
    },
    {
      label: "Mother's Mobile Number",
      name: "MOTHER_MOBILE_NUMBER",
      type: "text",
      placeholder: "XXXXXXXXXX",
    },
    {
      label: "Mother's Income",
      name: "MOTHER_INCOME",
      type: "text",
      placeholder: "Enter mother's income",
    },
  ];

  const renderField = (field) => {
    return field.type === "select" ? (
      <select
        id={field.name}
        name={field.name}
        value={formData[field.name] || ""}
        onChange={handleChange}
        className="ApplicationForm_input"
        required={field.required}
      >
        <option value="">{field.placeholder}</option>
        {field.options?.map((option, idx) => (
          <option key={idx} value={option}>
            {option}
          </option>
        ))}
      </select>
    ) : (
      <input
        type={field.type}
        id={field.name}
        name={field.name}
        value={formData[field.name] || ""}
        onChange={handleChange}
        className="ApplicationForm_input"
        required={field.required}
        placeholder={field.placeholder}
      />
    );
  };

  return (
    <div className="ApplicationForm_container container-fluid">
      <form onSubmit={handleSubmit}>
        {/* Personal Information Section */}
        <div className="ApplicationForm_section">
          <h3 className="ApplicationForm_sectionTitle">Personal Information</h3>
          <div className="row">
            {personalFields.map((field, index) => (
              <div className="col-md-4 mb-3" key={index}>
                <label htmlFor={field.name} className="ApplicationForm_label">
                  {field.label}
                </label>
                {renderField(field)}
              </div>
            ))}
          </div>
        </div>

        {/* Address Information Section */}
        <div className="ApplicationForm_section">
          <h3 className="ApplicationForm_sectionTitle">Address Information</h3>
          <div className="row">
            {addressFields.map((field, index) => (
              <div className="col-md-4 mb-3" key={index}>
                <label htmlFor={field.name} className="ApplicationForm_label">
                  {field.label}
                </label>
                {renderField(field)}
              </div>
            ))}
          </div>
        </div>

        {/* Parents' Information Section */}
        <div className="ApplicationForm_section">
          <h3 className="ApplicationForm_sectionTitle">Parents' Information</h3>
          <div className="row">
            {parentsFields.map((field, index) => (
              <div className="col-md-4 mb-3" key={index}>
                <label htmlFor={field.name} className="ApplicationForm_label">
                  {field.label}
                </label>
                {renderField(field)}
              </div>
            ))}
          </div>
        </div>

        {/* Submit Button */}
        <div className="ApplicationForm_Button_div">
          <button
            type="submit"
            className="ApplicationForm_button btn btn-primary"
          >
            {loading ? "Loading..." : "Submit"}
          </button>
        </div>
      </form>
    </div>
  );
};

export default ApplicationForm;