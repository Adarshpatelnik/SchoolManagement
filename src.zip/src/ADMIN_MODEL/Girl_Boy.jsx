

import React, { useEffect, useState, useMemo } from 'react';
import axios from 'axios';
import { AgCharts } from 'ag-charts-react';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Container, Row, Col } from 'reactstrap';
import './Admin_Model.css';

const GirlBoy = () => {
  const [attendanceData, setAttendanceData] = useState([]);
  const [selectedClass, setSelectedClass] = useState('');
  const [classes, setClasses] = useState([]);
  const [loading, setLoading] = useState(true);

  // Fetch attendance data
  useEffect(() => {
    const fetchAttendanceData = async () => {
      setLoading(true);
      try {
        const response = await axios.get('http://13.127.57.224:2081/api/studentcount');
        const formattedData = response.data.map(record => ({
          GENDER: record.GENDER === 'MALE' ? 'Male' : 'Female',
          count: record.STUDENT_COUNT,
          CLASS: record.CLASS,
        }));

        setAttendanceData(formattedData);

        // Extract unique class names for the dropdown
        const uniqueClasses = [...new Set(formattedData.map(item => item.CLASS))];
        setClasses(uniqueClasses);
      } catch (error) {
        console.error('Error fetching student attendance data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchAttendanceData();
  }, []);

  // Filter data based on selected class
  const filteredData = useMemo(
    () =>
      selectedClass
        ? attendanceData.filter(record => record.CLASS === selectedClass)
        : attendanceData,
    [selectedClass, attendanceData]
  );

  // Calculate gender counts
  const { boys, girls, totalStudents } = useMemo(() => {
    let boys = 0;
    let girls = 0;

    filteredData.forEach(record => {
      if (record.GENDER === 'Male') boys += record.count;
      if (record.GENDER === 'Female') girls += record.count;
    });

    return {
      boys,
      girls,
      totalStudents: boys + girls,
    };
  }, [filteredData]);

  // Chart options
  const donutChartOptions = useMemo(
    () => ({
      data: [
        { asset: `Boys (${boys})`, amount: boys },
        { asset: `Girls (${girls})`, amount: girls },
      ],
      series: [
        {
          type: 'donut',
          legendItemKey: 'asset',
          angleKey: 'amount',
          innerRadiusRatio: 0.7,
          innerLabels: [
            {
              text: 'Students',
              fontWeight: 'bold',
              fontSize: 13,
            },
            {
              text: totalStudents.toString(),
              fontSize: 10,
              color: 'green',
            },
          ],
          fills: ['#012353', '#27AE60'],
        },
      ],
      legend: {
        enabled: true, // Enable the legend
        position: 'bottom',
        item: {
          label: {
            fontSize: 10,
            color: '#000',
          },
        },
        itemSpacing: 8, // Adds spacing between legend items
        label: {
          fontSize: 10,
          color: '#000',
        }, // Position at the bottom
      },
    }),
    [boys, girls, totalStudents]
  );

  return (
    <Container>
      <Row className="justify-content-center">
        {loading ? (
          <Col xs={12}>
            <div className="text-center">Loading...</div>
          </Col>
        ) : (
          <Col xs={12} md={8}>
            <div className="Girl_Boy_chart-container">
              {/* Combined Filter Dropdown and Chart */}
              <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                {/* Filter Dropdown inside the chart container */}
                <select
                  className="Girl_Boy_select"
                  value={selectedClass}
                  onChange={e => setSelectedClass(e.target.value)}
                  style={{
                    marginTop: 'rem',
                    marginLeft:'-3rem',
                    marginBottom: '0rem', // Added margin for spacing
                    width: '100%',
                  }}
                >
                  <option value="">All Classes</option>
                  {classes.map((classItem, index) => (
                    <option key={index} value={classItem}>
                      {classItem}
                    </option>
                  ))}
                </select>

                {/* Chart Component */}
                <AgCharts
                  options={donutChartOptions}
                  style={{ width: '100%', height: '30vh',marginLeft:'-3rem'  }}
                />
              </div>
            </div>
          </Col>
        )}
      </Row>
    </Container>
  );
};

export default GirlBoy;
