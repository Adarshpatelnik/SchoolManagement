

import React, { useEffect, useState, useCallback, useMemo } from 'react';
import { AgGridReact } from 'ag-grid-react';
import axios from 'axios';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import 'bootstrap/dist/css/bootstrap.min.css';

const TimeTableschedule = () => {
  const [classData, setClassData] = useState([]);
  const [gridData, setGridData] = useState([]);
  const [selectedClass, setSelectedClass] = useState('LKG A');
  const [loading, setLoading] = useState(false);
  const [classError, setClassError] = useState('');
  const [gridError, setGridError] = useState('');
  const [currentTime, setCurrentTime] = useState(new Date());

  // Memoize the current day for efficiency
  const currentDay = useMemo(() => new Date().toLocaleString('en-us', { weekday: 'long' }), []);

  // Update the current time every minute
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTime(new Date());
    }, 60000); // Update every 60 seconds
    return () => clearInterval(interval);
  }, []);

  // Determine if the current time falls within a specific time slot
  const isActiveTimeSlot = (timeSlot) => {
    const [startTime, endTime] = timeSlot.split('-').map((t) => t.trim());
    const current = currentTime.getHours() * 60 + currentTime.getMinutes();

    const parseTime = (timeStr) => {
      const [hours, minutes] = timeStr.split(':').map(Number);
      return hours * 60 + minutes;
    };

    const start = parseTime(startTime);
    const end = parseTime(endTime);

    return current >= start && current < end;
  };

  // Memoized column definitions
  const columnDefs = useMemo(
    () => [
      { headerName: 'PERIOD', field: 'PERIOD', sortable: true, filter: true, width: 100, cellStyle: { padding: '5px' } },
      { headerName: 'TIME SLOT', field: 'TIME_SLOT', sortable: true, filter: true, width: 150, cellStyle: { padding: '5px' } },
      ...['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'].map((day) => ({
        headerName: day.toUpperCase(),
        field: day,
        sortable: true,
        filter: true,
        width: 150,
        cellStyle: (params) => ({
          backgroundColor: day === currentDay ? '#088F8F' : undefined,
          color: day === currentDay ? '#fff' : '#000',
        }),
      })),
    ],
    [currentDay]
  );

  // Add row styling to highlight the active time slot
  const getRowStyle = (params) => {
    if (isActiveTimeSlot(params.data.TIME_SLOT)) {
      return { backgroundColor: '#FFDD44', fontWeight: 'bold' };
    }
    return null;
  };

  // Fetch data with combined logic
  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      const [classResponse, gridResponse] = await Promise.all([
        axios.get('http://13.127.57.224:2081/api/schedule_class'),
        axios.get(`http://13.127.57.224:2081/api/class_data?class=${selectedClass}`),
      ]);
      setClassData(classResponse.data);
      setGridData(gridResponse.data);
      setClassError('');
      setGridError('');
    } catch (error) {
      setClassError('Error fetching class data.');
      setGridError('Error fetching grid data.');
    } finally {
      setLoading(false);
    }
  }, [selectedClass]);

  // Handle class selection changes
  const handleClassChange = (event) => {
    const selected = event.target.value;
    if (selected !== selectedClass) setSelectedClass(selected);
  };

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  return (
    <div className="container" style={{ backgroundColor: '#f9f9f9', borderRadius: '10px', marginTop: '-1.8rem' }}>
      <div className="mb-3 d-flex justify-content-center align-items-center">
        <label htmlFor="class-select" className="me-2 fw-semibold text-secondary">Class</label>
        <select
          id="class-select"
          onChange={handleClassChange}
          value={selectedClass}
          className="form-select w-auto shadow-sm"
          style={{ borderRadius: '8px' }}
        >
          <option value="">-- Select Class --</option>
          {classData.map((classItem) => (
            <option key={classItem.CLASS_ID} value={classItem.CLASS_ID}>
              {classItem.CLASS_ID}
            </option>
          ))}
        </select>
      </div>

      {loading && <p className="text-center text-info">Loading data...</p>}
      {classError && <p className="text-center text-danger">{classError}</p>}
      {gridError && <p className="text-center text-danger">{gridError}</p>}

      <div className="ag-theme-alpine" style={{ height: '40vh', width: '100%' }}>
        {gridData.length > 0 ? (
          <AgGridReact
            columnDefs={columnDefs}
            rowData={gridData}
            rowStyle={getRowStyle}
            pagination={true}
            paginationPageSize={10}
            suppressPaginationPanel={true}
          />
        ) : (
          !loading && <p className="text-center text-muted">No data available for the selected class.</p>
        )}
      </div>
    </div>
  );
};

export default TimeTableschedule;
