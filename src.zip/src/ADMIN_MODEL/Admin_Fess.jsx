import React, { useState, useEffect, useRef } from "react";
import "bootstrap/dist/css/bootstrap.min.css";

const AdminFess = () => {
  const [model, setModel] = useState("TERM");
  const [feeForms, setFeeForms] = useState([]);
  const [showFeeEntry, setShowFeeEntry] = useState(false);
  const [isModelLocked, setIsModelLocked] = useState(false);
  const [feeEntries, setFeeEntries] = useState([{
    class: '',
    session: '',
    term: '',
    sessionModel: '',
  }]);
  const [currentPage, setCurrentPage] = useState(1);
  const [classOptions, setClassOptions] = useState([]);
  const [sessionOptions, setSessionOptions] = useState([]);
  const [selectedFile, setSelectedFile] = useState(null);
  const [selectedTerm, setSelectedTerm] = useState("");
  const fileInputRef = useRef(null);

  const termOptions = ["Term 1", "Term 2", "Term 3"];
  const page2TermOptions = ["Term 1", "Term 2"];
  const sessionModelOptions = ["Half-Yearly", "Quarterly", "Annual"];

  useEffect(() => {
    fetchClassSessionData();
  }, []);

  const fetchClassSessionData = async () => {
    try {
      const response = await fetch('http://13.127.57.224:2081/api/get-class-session');
      const data = await response.json();
      if (data.success) {
        const uniqueClasses = [...new Set(data.data.map(item => item.CLASS))];
        const uniqueSessions = [...new Set(data.data.map(item => item.ACADEMIC_YEAR))];
        setClassOptions(uniqueClasses);
        setSessionOptions(uniqueSessions);
      } else {
        console.error('Failed to fetch class and session data');
      }
    } catch (error) {
      console.error('Error fetching class and session data:', error);
    }
  };

  const handleAddFeeBox = () => {
    setFeeForms([...feeForms, { type: "" }]);
  };

  const handleAddRow = () => {
    setFeeEntries([...feeEntries, {
      class: '',
      session: '',
      term: model === 'TERM' ? selectedTerm : '',
      sessionModel: model === 'SESSION' ? '' : '',
      ...feeForms.reduce((acc, form) => {
        acc[form.type] = '';
        return acc;
      }, {})
    }]);
  };

  const handleDownload = () => {
    const rows = [];
    const header = ["CLASS", "SESSION", model === "TERM" ? "TERM_MODEL" : "SESSION_MODEL"];

    feeForms.forEach((form) => {
      header.push(form.type.replace(/\s+/g, '_').toUpperCase());
    });
    header.push("TOTAL_AMOUNT");

    rows.push(header);

    feeEntries.forEach((entry) => {
      const dataRow = [
        entry.class.toUpperCase(),
        entry.session.toUpperCase(),
        model === "TERM" ? entry.term.toUpperCase() : entry.sessionModel.toUpperCase(),
        ...feeForms.map((form) => entry[form.type] || ""),
        calculateTotal(entry).toString()
      ];
      rows.push(dataRow);
    });

    const csvContent = rows.map(row => row.join(",")).join("\n");
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = "fee_structure.csv";
    link.click();
  };

  const handleFileChange = (event) => {
    setSelectedFile(event.target.files[0]);
  };

  const handleUpload = async () => {
    if (!selectedFile) {
      alert("Please select a file first!");
      return;
    }

    const formData = new FormData();
    formData.append("file", selectedFile);
    formData.append("model", model);

    try {
      const response = await fetch("http://13.127.57.224:2081/api/upload-fee-structure", {
        method: "POST",
        body: formData,
      });

      const data = await response.json();

      if (data.success) {
        alert("File uploaded and data inserted successfully!");
        setSelectedFile(null);
        if (fileInputRef.current) {
          fileInputRef.current.value = "";
        }
      } else {
        console.error("Error response:", data);
        alert("Error uploading file: " + (data.message || "Unknown error"));
      }
    } catch (error) {
      console.error("Error:", error);
      alert("An error occurred while uploading the file. Check the console for more details.");
    }
  };

  const handleFeeChange = (index, field, value) => {
    const updatedForms = [...feeForms];
    updatedForms[index][field] = value;
    setFeeForms(updatedForms);
  };

  const handleSubmitFee = async () => {
    const filledFees = feeForms.filter((form) => form.type);
    if (filledFees.length === feeForms.length && model) {
      if (model === "TERM" && !selectedTerm) {
        alert("Please select a Term.");
        return;
      }
      try {
        const createTableResponse = await fetch("http://13.127.57.224:2081/api/create-fee-table", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ model, feeForms }),
        });
        const createTableData = await createTableResponse.json();

        if (!createTableData.success) {
          alert("Error creating fee structure table.");
          return;
        }

        const feeTypeRequests = filledFees.map((fee) =>
          fetch("http://13.127.57.224:2081/api/add-fee-type", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ feeType: fee.type, model }),
          })
        );

        const feeTypeResponses = await Promise.all(feeTypeRequests);
        const feeTypeResults = await Promise.all(feeTypeResponses.map((res) => res.json()));

        const failedFeeTypes = feeTypeResults.filter((res) => !res.success);

        if (failedFeeTypes.length > 0) {
          alert("Fee Table Created successfully!");
        } else {
          alert("New fee type added successfully!");
        }
        
        setShowFeeEntry(true);
        setCurrentPage(2);
      } catch (error) {
        console.error("Error:", error);
        alert("An error occurred while processing the request.");
      }
    } else {
      alert("Please fill in all required fields.");
    }
  };

  const handleCancelFee = () => {
    setFeeForms([]);
    setShowFeeEntry(false);
    setCurrentPage(1);
    setModel("TERM");
    setIsModelLocked(false);
    setSelectedTerm("");
    setFeeEntries([{
      class: '',
      session: '',
      term: '',
      sessionModel: '',
    }]);
  };

  const handleModelChange = (value) => {
    if (!isModelLocked) {
      setModel(value);
      setFeeEntries(prev => prev.map(entry => ({ ...entry, term: '', sessionModel: '' })));
      setIsModelLocked(true);
      if (value === "TERM") {
        setSelectedTerm("");
      }
    }
  };

  const handleFeeEntryChange = (index, field, value) => {
    const updatedEntries = [...feeEntries];
    updatedEntries[index] = {
      ...updatedEntries[index],
      [field]: value
    };
    setFeeEntries(updatedEntries);
  };

  const calculateTotal = (entry) => {
    return feeForms.reduce((total, form) => {
      const amount = Number(entry[form.type]) || 0;
      return total + amount;
    }, 0);
  };

  const handleSubmitFeeEntry = async () => {
    try {
      const invalidEntries = feeEntries.filter(entry => !entry.class || !entry.session);
      if (invalidEntries.length > 0) {
        alert("Please select both Class and Session for all entries.");
        return;
      }

      if (model === "TERM" && feeEntries.some(entry => !entry.term)) {
        alert("Please enter a Term for all entries.");
        return;
      }

      if (model === "SESSION" && feeEntries.some(entry => !entry.sessionModel)) {
        alert("Please select a Session Model for all entries.");
        return;
      }
      
      
      const feeData = feeEntries.map(entry => ({
        CLASS: entry.class,
        SESSION: entry.session,
        SESSION_MODEL: model === "SESSION" ? entry.sessionModel : null,
        TERM_MODEL: model === "TERM" ? entry.term : null,
        ...feeForms.reduce((acc, form) => {
          acc[form.type.replace(/\s+/g, '_').toUpperCase()] = parseFloat(entry[form.type]) || 0;
          return acc;
        }, {}),
        TOTAL_AMOUNT: calculateTotal(entry)
      }));

      console.log("Sending data to server:", feeData);

      const response = await fetch("http://13.127.57.224:2081/api/insert-fee-structure", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(feeData),
      });

      const data = await response.json();

      if (data.success) {
        alert("Fee structure data inserted successfully!");
        handleCancelFee();
      } else {
        alert("Error inserting fee structure data: " + data.message);
      }
    } catch (error) {
      console.error("Error:", error);
      alert("An error occurred while submitting the fee structure data.");
    }
  };

  const renderPage1 = () => (
    <>
      <h2 
        className="text-center mb-4" 
        style={{ 
          background: "linear-gradient(to right, #012353, #27ae60)", 
          color: "white", 
          padding: "10px", 
          borderRadius: "5px" 
        }}
      >
        Academic Assessment Fee
      </h2>
      
      <div className="mb-3 d-flex align-items-center">
        <label className="form-label fw-bold me-3">Academic Assessment Patterns:</label>
        <div>
          <input
            type="radio"
            id="term"
            name="model"
            value="TERM"
            checked={model === "TERM"}
            onChange={(e) => handleModelChange(e.target.value)}
            className="form-check-input me-2"
            disabled={isModelLocked}
          />
          <label htmlFor="term" className="form-check-label me-3">
            Term Based Model
          </label>
          <input
            type="radio"
            id="session"
            name="model"
            value="SESSION"
            checked={model === "SESSION"}
            onChange={(e) => handleModelChange(e.target.value)}
            className="form-check-input me-2"
            disabled={isModelLocked}
          />
          <label htmlFor="session" className="form-check-label">
            Session Based Model
          </label>
        </div>
      </div>

      {model === "TERM" && (
        <div className="mb-3">
          <label htmlFor="termSelect" className="form-label fw-bold me-3"> Term</label>
          <select
            id="termSelect"
            className="form-select"
            style={{ width: "200px", display: "inline-block" }}
            value={selectedTerm}
            onChange={(e) => setSelectedTerm(e.target.value)}
          >
            <option value="">Select Term</option>
            {termOptions.map((term, index) => (
              <option key={index} value={term}>{term}</option>
            ))}
          </select>
        </div>
      )}

      <div className="mb-3">
        <button 
          className="btn ms-3" 
          onClick={handleAddFeeBox}
          style={{ 
            backgroundColor: '#f0f0f0', 
            color: '#333', 
            fontSize: '0.9rem',
            padding: '0.25rem 0.5rem'
          }}
        >
          Add fee type
        </button>
      </div>

      {feeForms.length > 0 && (
        <div className="d-flex justify-content-center">
          <div className="table-responsive" style={{ width: "30%" }}>
            <table className="table table-bordered mt-3 text-center" style={{ tableLayout: "fixed", backgroundColor: '#f8f9fa', '--bs-table-bg': '#f8f9fa', '--bs-table-th-bg': '#1e40af', '--bs-table-th-color': 'white' }}>
              <thead>
                <tr>
                  <th style={{ width: "60%" }}>Fee Type</th>
                </tr>
              </thead>
              <tbody>
                {feeForms.map((form, index) => (
                  <tr key={index}>
                    <td>
                      <input
                        type="text"
                        placeholder="Enter Fee Type"
                        className="form-control"
                        style={{ width: "100%" }}
                        value={form.type}
                        onChange={(e) => handleFeeChange(index, "type", e.target.value)}
                      />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
      <div className="d-flex justify-content-center mt-3">
        {currentPage === 2 && (
          <button className="btn btn-secondary me-3" onClick={() => setCurrentPage(1)}>
            Previous
          </button>
        )}
        
        <button
          className="btn"
          style={{
            background: "linear-gradient(to right, #012353, #27ae60)",
            color: "white",
            height: "30px",
            border: "none",
            padding: "0 10px",
            borderRadius: "5px",
          }}
          onClick={handleSubmitFee}
        >
          Submit
        </button>
        {currentPage === 1 && (
          <button
            className="btn btn-secondary"
            style={{ marginLeft: "10px", height: "30px", padding: "0 10px", borderRadius: "5px" }}
            onClick={handleCancelFee}
          >
            Cancel
          </button>
        )}
      </div>
    </>
  );

  const renderPage2 = () => (
    <>
      <h3 className="mb-4">Enter Fee Details</h3>
      <div className="d-flex justify-content-start mb-3">
        <button 
          className="btn" 
          onClick={handleAddRow}
          style={{ 
            backgroundColor: '#f0f0f0', 
            color: '#333'
          }}
        >
          Add row
        </button>
      </div>
      <div className="table-responsive">
        <table
          className="table table-bordered"
          style={{
            backgroundColor: '#f8f9fa',
            '--bs-table-bg': '#f8f9fa',
            '--bs-table-th-bg': '#1e40af',
            '--bs-table-th-color': 'white',
          }}
        >
          <thead>
            <tr>
              <th>Class</th>
              <th>Session</th>
              <th>{model === 'TERM' ? 'Term' : 'Session Model'}</th>
              {feeForms.map((form, index) => (
                <th key={index}>{form.type}</th>
              ))}
              <th>Total Amount</th>
            </tr>
          </thead>
          <tbody>
            {feeEntries.map((entry, rowIndex) => (
              <tr key={rowIndex}>
                <td>
                  <select
                    className="form-control"
                    value={entry.class}
                    onChange={(e) => handleFeeEntryChange(rowIndex, 'class', e.target.value)}
                  >
                    <option value="">Select Class</option>
                    {classOptions.map((classOption) => (
                      <option key={classOption} value={classOption}>
                        {classOption}
                      </option>
                    ))}
                  </select>
                </td>
                <td>
                  <select
                    className="form-control"
                    value={entry.session}
                    onChange={(e) => handleFeeEntryChange(rowIndex, 'session', e.target.value)}
                  >
                    <option value="">Select Session</option>
                    {sessionOptions.map((sessionOption) => (
                      <option key={sessionOption} value={sessionOption}>
                        {sessionOption}
                      </option>
                    ))}
                  </select>
                </td>
                <td>
                  {model === 'TERM' ? (
                    <select
                      className="form-control"
                      value={entry.term}
                      onChange={(e) => handleFeeEntryChange(rowIndex, 'term', e.target.value)}
                    >
                      <option value="">Select Term</option>
                      {page2TermOptions.map((term, index) => (
                        <option key={index} value={term}>{term}</option>
                      ))}
                    </select>
                  ) : (
                    <select
                      className="form-control"
                      value={entry.sessionModel}
                      onChange={(e) => handleFeeEntryChange(rowIndex, 'sessionModel', e.target.value)}
                    >
                      <option value="">Select Session Model</option>
                      {sessionModelOptions.map((option, index) => (
                        <option key={index} value={option}>{option}</option>
                      ))}
                    </select>
                  )}
                </td>
                {feeForms.map((form, index) => (
                  <td key={index}>
                    <input
                      type="number"
                      className="form-control"
                      value={entry[form.type] || ''}
                      onChange={(e) => handleFeeEntryChange(rowIndex, form.type, e.target.value)}
                      placeholder={`Enter ${form.type}`}
                    />
                  </td>
                ))}
                <td>
                  <input type="number" className="form-control" value={calculateTotal(entry)} readOnly />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    
      <div
        className="d-flex align-items-center mt-3"
        style={{ gap: "10px", justifyContent: "start" }}
      >
        <button
          className="btn btn-secondary"
          onClick={() => setCurrentPage(1)}
          style={{ height: "30px", padding: "0 10px" }}
        >
          Previous
        </button>

        <button
          className="btn"
          style={{
            background: "linear-gradient(to right, #012353, #27ae60)",
            color: "white",
            height: "30px",
            border: "none",
            padding: "0 10px",
            borderRadius: "5px",
          }}
          onClick={handleSubmitFeeEntry}
        >
          Submit
        </button>

        <button
          className="btn"
          onClick={handleDownload}
          style={{
            height: "30px",
            padding: "0 10px",
            backgroundColor: "#00BFFF",
            color: "white",
          }}
        >
          Download
        </button>

        <div className="d-flex flex-column align-items-center ms-auto">
          <input
            type="file"
            onChange={handleFileChange}
            ref={fileInputRef}
            className="form-control mb-2"
          />
          
          <button
            onClick={handleUpload}
            disabled={!selectedFile}
            style={{
              height: "30px",
              padding: "0 10px",
              backgroundColor: "#FF9800",
              color: "white",
              border: "none",
              borderRadius: "5px",
            }}
          >
            Upload
          </button>
        </div>
      </div>
    </>
  );

  return (
    <div style={{ minHeight: '100vh', background: 'white', paddingTop: '2rem', paddingBottom: '2rem' }}>
      <div className="container mt-4 p-4" style={{
        backgroundColor: 'white',
        borderRadius: '8px',
        boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)',
        border: '1px solid #e5e7eb',
        padding: '2rem'
      }}>
        <div style={{ backgroundColor: '#f0f2f5', padding: '2rem', borderRadius: '8px' }}>
          {currentPage === 1 ? renderPage1() : renderPage2()}
        </div>
      </div>
    </div>
  );
};

export default AdminFess;