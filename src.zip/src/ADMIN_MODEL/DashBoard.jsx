
import React, { useState, useEffect, Suspense } from 'react';
import axios from 'axios';
import styled from 'styled-components';
import 'bootstrap/dist/css/bootstrap.min.css';
import { FaUsers, FaChalkboardTeacher, FaUserAlt } from 'react-icons/fa';

const GirlBoy = React.lazy(() => import('./Girl_Boy.jsx'));
const TimeTableschedule = React.lazy(() => import('./Time_Table_schedule.jsx'));
const NoticeBoard = React.lazy(() => import('./Notice_Board.jsx'));
const PerformanceSummary = React.lazy(() => import('./Dashbord_Performance_Summary.jsx'));
const EventCalender = React.lazy(() => import('./Event_Calender.jsx'));
const DashBoardStaffAttendance = React.lazy(() => import('./Staff_Attendance_Chart.jsx'));
const DashbordStudentAttendance = React.lazy(() => import('./Student_Attendance_Chart.jsx'));

const Container = styled.div`
  padding-top: 10px;
  min-height: 100vh;
  padding: 20px 10px;
  max-width: 100%;
  margin: 0 auto;
  background-color: #f0f6fa;

  @media (max-width: 1200px) {
    max-width: 1000px;
  }
  @media (max-width: 992px) {
    max-width: 800px;
  }
  @media (max-width: 768px) {
    padding: 0 10px;
  }
  @media (max-width: 576px) {
    padding: 0 5px;
  }
`;

const Card = styled.div`
  background-color: #ffffff;
  border: 1px solid #ccc;
  border-radius: 4px;
  padding: 0px;
  margin-bottom: 15%;
  min-height: 0;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  transition: transform 0.3s ease, box-shadow 0.3s ease;

  @media (max-width: 768px) {
    padding: 15px;
    min-height: 250px;
  }
`;

const Heading = styled.h3`
  font-size: 1.1rem;
  font-weight: 600;
  font-family: 'Lato', sans-serif;
  color: #333;
        borderRadius: '8px',

  margin-bottom: 30px;
  padding: 5px 10px;
  display: inline-block;
  background: linear-gradient(135deg, #f0f0f0, #e0e0e0);
  border-bottom: 1px solid #b0b0b0;
  transition: transform 0.3s ease, box-shadow 0.3s ease, background 0.3s ease;

  @media (max-width: 400px) {
    font-size: 1.2rem;
    padding: 8px 16px;
    margin-bottom: 20px;
  }
`;

const InfoCard = ({ icon, title, value }) => (
  <div
    className="mb-3"
    style={{
      display: 'flex',
      alignItems: 'center',
      padding: '10px',
      background: 'white',
      border: '1px solid #ddd',
      borderRadius: '8px',
    }}
  >
    <div
      style={{
        width: '60px',
        height: '60px',
        borderRadius: '50%',
        backgroundColor: '#f0f0f0',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        marginRight: '15px',
      }}
    >
      {icon}
    </div>
    <div style={{ textAlign: 'center' }}>
      <strong>{title}</strong>
      <div>{value}</div>
    </div>
  </div>
);

const Dashboard = () => {
  const [data, setData] = useState({
    totalStudents: 0,
    totalStaff: 0,
    workingStaff: 0,
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const responses = await Promise.all([
          axios.get('http://13.127.57.224:2081/api/studentcountdetails'),
          axios.get('http://13.127.57.224:2081/api/staffcount'),
          axios.get('http://13.127.57.224:2081/api/workingStaff'),
        ]);

        const [responseStudents, responseStaff, responseWorkingStaff] = responses;

        setData({
          totalStudents: responseStudents.data.totalStudents,
          totalStaff: responseStaff.data.totalStaff,
          workingStaff: responseWorkingStaff.data.workingStaff,
        });
      } catch (error) {
        setError(error.message);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error: {error}</div>;

  return (
    <div className="container-fluid" style={{  width: '100%', }}>
     <Container style={{ padding: '0' }}>
  <div className="row" style={{ display: 'flex', padding: '30px 1px', }}>
    {/* Left Column - Info Cards */}
    <div className="col-lg-2 col-md-4 col-12" style={{ padding: '0 15px' }}>
      <div>
        <InfoCard
          icon={<FaUserAlt size={30} color="#3498db" />}
          title="Students"
          value={data.totalStudents}
        />
        <InfoCard
          icon={<FaUsers size={30} color="#2ecc71" />}
          title="Staff"
          value={data.totalStaff}
        />
        <InfoCard
          icon={<FaChalkboardTeacher size={30} color="#e74c3c" />}
          title="Teaching"
          value={data.workingStaff}
        />
      </div>
    </div>

    {/* Right Column - Main Content */}
    <div className="col-lg-10 " style={{ padding: '0 px' }}>
      <div className="row">
        {/* First Row */}
        <div className="col-md-4 mb-4" style={{ padding: '0 1px' }}>
          <Card style={{ height: '41vh' }}>
            <Heading>Student Ratio</Heading>
            <Suspense fallback={<div>Loading...</div>}>
              <GirlBoy />
            </Suspense>
          </Card>
        </div>
        <div className="col-md-4 mb-4" style={{ padding: '0 1px' }}>
          <Card style={{ height: '41vh' }}>
            <Heading>Student Attendance</Heading>
            <Suspense fallback={<div>Loading...</div>}>
              <DashbordStudentAttendance />
            </Suspense>
          </Card>
        </div>
        <div className="col-md-4 mb-4" style={{padding: '0 1px' }}>
          <Card style={{ height: '41vh' }}>
            <Heading>Staff Attendance</Heading>
            <Suspense fallback={<div>Loading...</div>}>
              <DashBoardStaffAttendance />
            </Suspense>
          </Card>
        </div>
      </div>
    </div>
  </div>
</Container>

<Container style={{ padding: '0' }}>
  {/* Second Row */}
  <div className="row" style={{ display: 'flex', padding: '0 16px' ,marginTop:'-53vh'}}>
    <div className="col-lg-5 md-4 mb-4" style={{padding: '0 1px'  }}>
      <Card style={{ height: '50vh' }}>
        <Heading>Student Performance</Heading>
        <Suspense fallback={<div>Loading...</div>}>
          <PerformanceSummary />
        </Suspense>
      </Card>
    </div>

    <div className="col-lg-4 md-4 mb-4" style={{ padding: '0 1px' }}>
      <Card style={{ height: '50vh' }}>
        <Heading>Event Calendar</Heading>
        <Suspense fallback={<div>Loading...</div>}>
          <EventCalender />
        </Suspense>
      </Card>
    </div>

    <div className="col-lg-3 md-4 mb-4" style={{ padding: '0 1px' }}>
      <Card style={{ height: '50vh' }}>
        <Heading>Notice Board</Heading>
        <Suspense fallback={<div>Loading...</div>}>
          <NoticeBoard />
        </Suspense>
      </Card>
    </div>
  </div>
</Container>

<Container style={{ padding: '0' }}>
  {/* Third Row */}
  <div className="row" style={{ display: 'flex', padding: '0 15px',marginTop:'-49vh' }}>
    <div className="md-4 mb-4" style={{ padding: '0 1px' }}>
    <Card style={{ height: '55vh' }}>
    <Heading>Time Table</Heading>
        <Suspense fallback={<div>Loading...</div>}>
          <TimeTableschedule />
        </Suspense>
      </Card>
    </div>
  </div>
</Container>

    </div>
  );
};

export default Dashboard;
