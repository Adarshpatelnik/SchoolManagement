import React, { useState, useEffect } from 'react';
  import 'bootstrap/dist/css/bootstrap.min.css';
  import Button from 'react-bootstrap/Button';
  import Form from 'react-bootstrap/Form';
  import axios from 'axios';
  
  const styles = {
    container: {
      maxWidth: '60%',
      margin: 'auto',
      padding: '3px',
      backgroundColor: '',
      borderRadius: '8px',
    },
    toggleContainer: {
      cursor: 'pointer',
      display: 'flex',
      alignItems: 'center',
      padding: '12px 0',
      marginBottom: '20px',
    },
    toggleText: {
      marginLeft: '1px',
      color: '#007bff',
      fontSize: '18px',
      fontWeight: '600',
      transition: 'color 0.3s',
    },
    formControl: {
      marginLeft: '0px',
      maxWidth: '200px',
      flex: '1',
    },
    fileInfo: {
      marginTop: '5px',
      fontSize: '14px',
      color: '#6c757d',
    },
    messageCount: {
      fontSize: '14px',
      color: '#6c757d',
    },
    button: {
      marginTop: '20px',
      fontSize: '16px',
      padding: '10px 20px',
    },
    hoverEffect: {
      color: '#0056b3',
      transition: 'color 0.3s',
    },
    formContainer: {
      padding: '10px',
      borderRadius: '8px',
      backgroundColor: '#f8f9fa',
      marginRight: '100px',
    },
    pencilIcon: {
      fontSize: '24px',
      color: '#007bff',
      marginRight: '20%',
      transition: 'color 0.3s',
    },
  };
  
  const Message = () => {
    const [message, setMessage] = useState('');
    const [recipientsOption, setRecipientsOption] = useState('All Students');
    const [specificClass, setSpecificClass] = useState('');
    const [specificTeacher, setSpecificTeacher] = useState('');
    const [specificStudent, setSpecificStudent] = useState('');
    const [file, setFile] = useState(null);
    const [classes, setClasses] = useState([]);
    const [teachers, setTeachers] = useState([]);
    const [students, setStudents] = useState([]);
    const [searchTerm, setSearchTerm] = useState('');
  
    useEffect(() => {
      const fetchClasses = async () => {
        try {
          const response = await fetch('http://13.127.57.224:2081/api/classestwilio');
          if (!response.ok) throw new Error('Failed to fetch classes');
          const data = await response.json();
          setClasses(data);
        } catch (error) {
          console.error('Error fetching classes:', error);
        }
      };
  
      const fetchTeachers = async () => {
        try {
          const response = await fetch('http://13.127.57.224:2081/api/stafftwilio');
          if (!response.ok) throw new Error('Failed to fetch teachers');
          const data = await response.json();
          setTeachers(data);
        } catch (error) {
          console.error('Error fetching teachers:', error);
        }
      };
  
      const fetchStudents = async () => {
        try {
          const response = await fetch('http://13.127.57.224:2081/api/studentstwilio');
          if (!response.ok) throw new Error('Failed to fetch students');
          const data = await response.json();
          setStudents(data);
        } catch (error) {
          console.error('Error fetching students:', error);
        }
      };
  
      fetchClasses();
      fetchTeachers();
      fetchStudents();
    }, []);
  
    const handleSendBroadcast = async () => {
      const formData = new FormData();
      formData.append('message', message);
      formData.append('recipientsOption', recipientsOption);
      formData.append('specificClass', specificClass);
      formData.append('specificTeacher', specificTeacher);
      formData.append('specificStudent', specificStudent);
      if (file) formData.append('file', file);
  
      try {
        console.log('Sending broadcast with data:', formData);
        await axios.post('http://13.127.57.224:2081/api/broadcast', formData, {
          headers: {
            'Content-Type': 'multipart/form-data'
          }
        });
        alert('Broadcast sent successfully.');
        setMessage('');
        setRecipientsOption('All Students');
        setSpecificClass('');
        setSpecificTeacher('');
        setSpecificStudent('');
        setFile(null);
      } catch (error) {
        console.error('Error sending broadcast:', error);
        alert('Failed to send broadcast: ' + error.message);
      }
    };
  
    const handleFileChange = (event) => {
      setFile(event.target.files[0]);
    };
  
    const filteredClasses = classes.filter(cls =>
      cls.CLASS && cls.CLASS.toLowerCase().includes(searchTerm.toLowerCase())
    );
  
    const filteredTeachers = teachers.filter(teacher =>
      teacher.STAFF_NAME && teacher.STAFF_NAME.toLowerCase().includes(searchTerm.toLowerCase())
    );
  
    const filteredStudents = students.filter(student =>
      student.name && student.name.toLowerCase().includes(searchTerm.toLowerCase())
    );
  
    return (
      <div className="container" style={styles.container}>
        <div style={styles.formContainer}>
          <h5 style={styles.toggleText}>Message</h5>
          <Form>
            <Form.Group controlId="formRecipients">
              <Form.Label>Send Message To</Form.Label>
              <div className="d-flex align-items-center">
                <Form.Control
                  as="select"
                  value={recipientsOption}
                  onChange={(e) => setRecipientsOption(e.target.value)}
                  style={styles.formControl}
                >
                  <option>All Students</option>
                  <option>All Teachers</option>
                  <option>Specific Class</option>
                  <option>Specific Teacher</option>
                  <option>Specific Student</option>
                </Form.Control>
  
                {recipientsOption === 'Specific Class' && (
                  <Form.Control
                    as="select"
                    value={specificClass}
                    onChange={(e) => setSpecificClass(e.target.value)}
                    className="ml-2"
                    style={styles.formControl}
                  >
                    <option value="">Select Class</option>
                    {filteredClasses.map((cls, index) => (
                      <option key={index} value={cls.CLASS}>
                        {cls.CLASS}
                      </option>
                    ))}
                  </Form.Control>
                )}
  
                {recipientsOption === 'Specific Teacher' && (
                  <Form.Control
                    as="select"
                    value={specificTeacher}
                    onChange={(e) => setSpecificTeacher(e.target.value)}
                    className="ml-2"
                    style={styles.formControl}
                  >
                    <option value="">Select Teacher</option>
                    {filteredTeachers.map((teacher, index) => (
                      <option key={index} value={teacher.STAFF_NAME}>
                        {teacher.STAFF_NAME}
                      </option>
                    ))}
                  </Form.Control>
                )}
  
                {recipientsOption === 'Specific Student' && (
                  <Form.Control
                    as="select"
                    value={specificStudent}
                    onChange={(e) => setSpecificStudent(e.target.value)}
                    className="ml-2"
                    style={styles.formControl}
                  >
                    <option value="">Select Student</option>
                    {filteredStudents.map((student, index) => (
                      <option key={index} value={student.name}>
                        {student.name}
                      </option>
                    ))}
                  </Form.Control>
                )}
              </div>
            </Form.Group>
  
            <Form.Group controlId="formMessage">
              <Form.Label>Message</Form.Label>
              <Form.Control
                as="textarea"
                rows={3}
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                style={styles.formControl}
              />
            </Form.Group>
  
            <Form.Group>
              <Form.Label>Attach File</Form.Label>
              <input type="file" onChange={handleFileChange} />
              {file && <div style={styles.fileInfo}>{file.name}</div>}
            </Form.Group>
  
            <Button variant="primary" onClick={handleSendBroadcast} style={styles.button}>
              Send Message
            </Button>
          </Form>
        </div>
      </div>
    );
  };
  
  export default Message;
  