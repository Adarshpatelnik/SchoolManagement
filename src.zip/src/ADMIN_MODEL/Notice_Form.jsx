
import React, { useState } from 'react';
import styled from 'styled-components';
import 'bootstrap/dist/css/bootstrap.min.css';
import axios from 'axios';

const LoginContainer = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  background-size: cover;
`;

const FormWrapper = styled.div`
  padding: 20px;
  border-radius: 5px;
  max-width: 40%;
  width: 70%;
  text-align: center;
  background-color: #f8f9fa;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
  transition: transform 0.3s ease, box-shadow 0.3s ease;
`;

const Title = styled.h2`
  margin-bottom: 20px;
  color: #012353;
`;

const FormGroup = styled.div`
  margin-bottom: 15px;
  text-align: left;
`;

const Input = styled.input`
  width: 100%;
  padding: 8px;
  border: 1px solid #ced4da;
  border-radius: 5px;
`;

const Textarea = styled.textarea`
  width: 100%;
  padding: 8px;
  border: 1px solid #ced4da;
  border-radius: 5px;
  resize: none;
`;

const Button = styled.button`
  padding: 5px 20px;
  background: linear-gradient(to right, #012353, #27ae60);
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  font-size: 14px;
  margin: 10px 5px;
  &:hover {
    transform: translateY(-2px);
  }
`;

const ResetButton = styled(Button)`
  background: rgb(0, 0, 153);
  &:hover {
    background: #e74c3c;
  }
`;

const NoticeForm = () => {
  const [formData, setFormData] = useState({
    title: '',
    message: '',
    todate: '',
    fromdate: '',
  });

  const [loading, setLoading] = useState(false); // For loading state
  const [error, setError] = useState(''); // To handle error messages

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  // Date validation function
  const validateDates = () => {
    const { fromdate, todate } = formData;
    if (new Date(fromdate) > new Date(todate)) {
      setError('From Date cannot be later than To Date.');
      return false;
    }
    setError('');
    return true;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!validateDates()) return; // Only proceed if dates are valid

    try {
      setLoading(true); // Show loading spinner when submitting

      const response = await axios.post('http://13.127.57.224:2081/api/noticeform', {
        TITLE: formData.title,
        MESSAGE: formData.message,
        TO_DATE: formData.todate,
        FROM_DATE: formData.fromdate,
      });

      console.log('Form submitted:', response.data.message);
      alert('Announcement submitted successfully!');
      handleReset(); // Reset the form after submission

    } catch (err) {
      console.error('Error submitting form:', err.message);
      alert('Error submitting announcement');
    } finally {
      setLoading(false); // Hide loading spinner
    }
  };

  const handleReset = () => {
    setFormData({
      title: '',
      message: '',
      todate: '',
      fromdate: '',
    });
    setError(''); // Reset error message on reset
  };

  return (
    <LoginContainer>
      <FormWrapper>
        <Title>Notice Board Form</Title>
        <form onSubmit={handleSubmit}>
          {error && <p style={{ color: 'red' }}>{error}</p>} {/* Show error if any */}
          <FormGroup>
            <label>Title</label>
            <Input
              type="text"
              name="title"
              value={formData.title}
              onChange={handleChange}
              placeholder="Enter title"
            />
          </FormGroup>
          <FormGroup>
            <label>Message</label>
            <Textarea
              name="message"
              rows="4"
              value={formData.message}
              onChange={handleChange}
              placeholder="Enter message"
            />
          </FormGroup>
          <FormGroup>
            <label>To Date</label>
            <Input
              type="date"
              name="todate"
              value={formData.todate}
              onChange={handleChange}
            />
          </FormGroup>
          <FormGroup>
            <label>From Date</label>
            <Input
              type="date"
              name="fromdate"
              value={formData.fromdate}
              onChange={handleChange}
            />
          </FormGroup>
          <Button type="submit" disabled={loading}>
            {loading ? 'Submitting...' : 'Submit'}
          </Button>
          <ResetButton type="button" onClick={handleReset}>
            Reset
          </ResetButton>
        </form>
      </FormWrapper>
    </LoginContainer>
  );
};

export default NoticeForm;
