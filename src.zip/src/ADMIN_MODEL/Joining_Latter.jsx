import React, { useState, useEffect } from 'react';
import html2pdf from 'html2pdf.js';
import './Admin_Model.css'; // Import the CSS file

const JoiningLetter = () => {
    const [staffData, setStaffData] = useState([]);
    const [loading, setLoading] = useState(true);
    const [searchTerm, setSearchTerm] = useState('');
    const [selectedStaff, setSelectedStaff] = useState(null);

    useEffect(() => {
        const fetchStaffData = async () => {
            try {
                const response = await fetch('http://13.127.57.224:2081/api/JoiningLatter');
                const data = await response.json();
                setStaffData(data);
            } catch (error) {
                console.error("Error fetching staff data:", error);
            } finally {
                setLoading(false);
            }
        };
        fetchStaffData();
    }, []);

    const filteredStaff = staffData.filter((staff) =>
        staff.TEACHER_NAME?.toLowerCase().includes(searchTerm.toLowerCase())
    );

    const handleSelectStaff = (staff) => {
        setSelectedStaff(staff);
        setSearchTerm('');
    };

    const handleSearchChange = (e) => setSearchTerm(e.target.value);

    if (loading) return <div>Loading...</div>;

    // Generate Joining Letter Text
    const generateJoiningLetterText = (staff) => {
        const {
            TEACHER_NAME,
            SCHOOL_NAME,
            DATE_OF_JOINING,
            STAFF_ROLE,
            PRINCIPAL_NAME,
            ADDRESS,
            CITY,
            POSTAL_CODE,
            CONTACT_NUMBER,
            EMAIL,
        } = staff;

        const formattedDate = new Date(DATE_OF_JOINING).toLocaleDateString('en-US');

        return `
            <div style="font-family: Arial, sans-serif; padding: 30px; max-width: 600px; margin: 0 auto; background: #fff; border-radius: 12px; box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);">
                <div style="text-align: center; font-size: 18px; font-weight: bold; background: linear-gradient(to right, #3f87a6, #ebf8e1); padding: 10px; color: black; border-radius: 12px;">
                    <img src="school_logo_euro.png" alt="${SCHOOL_NAME}" style="width: 50px; height: 50px; vertical-align: middle; margin-right: 20px;" />
                    ${SCHOOL_NAME}
                </div>
                <div style="text-align: left; margin-top: 20px; font-size: 14px;">
                    <p style="margin: 0; line-height: 1.2;">${SCHOOL_NAME}</p>
                    <p style="margin: 0; line-height: 1.2;">${ADDRESS}</p>
                    <p style="margin: 0; line-height: 1.2;">${CITY}, ${POSTAL_CODE}</p>
                    <p style="margin: 0; line-height: 1.2;"> ${CONTACT_NUMBER} </p>
                    <p style="margin: 0; line-height: 1.2;">${EMAIL}</p>
                </div>
                <hr style="margin: 20px 0; border: 1px solid #ccc;">
                <p>Dear ${TEACHER_NAME},</p>
                <p>We are pleased to welcome you to ${SCHOOL_NAME}! It is our pleasure to have you join our dynamic teaching team. Your experience, passion for education, and commitment to student success are highly valued, and we are confident you will be an asset to our school community.</p>
                <p>Starting on ${formattedDate}, you will be a ${STAFF_ROLE}, responsible for [Briefly Mention Teaching responsibilities]. We look forward to working with you and supporting you in your role.</p>
                <p>Your monthly salary will be [Insert Salary], and we encourage you to review the contract for additional benefits. If you have any questions or need further assistance, please don't hesitate to contact ${PRINCIPAL_NAME} in Human Resources at ${EMAIL}.</p>
                <p>Once again, welcome to the ${SCHOOL_NAME} family. We are excited to see the contributions you will make in the years to come.</p>
                <br><br>
                <p style="margin: 0; line-height: 1.2;">Sincerely,</p>
                <p style="margin: 0; line-height: 1.2;">${PRINCIPAL_NAME}</p>
                <p style="margin: 0; line-height: 1.2;">${SCHOOL_NAME}</p>
            </div>
        `;
    };

    // Generate Experience Letter Text
    const generateExperienceLetterText = (staff) => {
        const {
            TEACHER_NAME,
            SCHOOL_NAME,
            DATE_OF_JOINING,
            EXIT_DATE,
            STAFF_ROLE,
            STAFF_INITIALS,
            PRINCIPAL_NAME,
            ADDRESS,
            CITY,
            POSTAL_CODE,
            CONTACT_NUMBER,
            EMAIL,
        } = staff;

        const formattedJoiningDate = new Date(DATE_OF_JOINING).toLocaleDateString('en-US');
        const formattedExitDate = EXIT_DATE ? new Date(EXIT_DATE).toLocaleDateString('en-US') : 'Present';

        return `
            <div style="font-family: Arial, sans-serif; padding: 30px; max-width: 600px; margin: 0 auto; background: #fff; border-radius: 12px; box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);">
                <div style="text-align: center; font-size: 18px; font-weight: bold; background: linear-gradient(to right, #3f87a6, #ebf8e1); padding: 10px; color: black; border-radius: 12px;">
                    <img src="school_logo_euro.png" alt="${SCHOOL_NAME}" style="width: 50px; height: 50px; vertical-align: middle; margin-right: 10px;" />
                    ${SCHOOL_NAME}
                </div>
                <div style="text-align: left; margin-top: 20px; font-size: 14px;">
                    <p style="margin: 0; line-height: 1.2;">${SCHOOL_NAME}</p>
                    <p style="margin: 0; line-height: 1.2;">${ADDRESS}</p>
                    <p style="margin: 0; line-height: 1.2;">${CITY}, ${POSTAL_CODE}</p>
                    <p style="margin: 0; line-height: 1.2;">Phone: ${CONTACT_NUMBER}</p>
                    <p style="margin: 0; line-height: 1.2;">Email: ${EMAIL}</p>
                </div>
                <hr style="margin: 20px 0; border: 1px solid #ccc;">
                <p>Dear ${TEACHER_NAME},</p>
                <p>This is to certify that ${STAFF_INITIALS} served as a ${STAFF_ROLE} at ${SCHOOL_NAME} from ${formattedJoiningDate} to ${formattedExitDate}. ${STAFF_INITIALS} was responsible for teaching [specify subject], planning lessons, and assessing student progress. ${STAFF_INITIALS} dedication to management was evident throughout ${STAFF_INITIALS} tenure.</p>
                <p>${STAFF_INITIALS} consistently demonstrated professionalism, reliability, and a passion for teaching. ${STAFF_INITIALS} maintained positive relationships with students and colleagues, contributing to a supportive learning environment.</p>
                <p>We are confident in ${STAFF_INITIALS} abilities and wish ${STAFF_INITIALS} continued success in ${STAFF_INITIALS} future endeavors.</p>
                <br><br>
                <p style="margin: 0; line-height: 1.2;">Sincerely,</p>
                <p style="margin: 0; line-height: 1.2;">${PRINCIPAL_NAME}</p>
                <p style="margin: 0; line-height: 1.2;">${SCHOOL_NAME}</p>
            </div>
        `;
    };

    // Handle generate PDF for Joining Letter
    const handleGenerateJoiningLetterPDF = (staff) => {
        const pdfOptions = {
            margin: 10,
            filename: 'JoiningLetter.pdf',
            jsPDF: { unit: 'pt', format: 'letter', orientation: 'portrait' },
        };

        const contentHTML = generateJoiningLetterText(staff);

        const contentElement = document.createElement('div');
        contentElement.innerHTML = contentHTML;
        html2pdf().from(contentElement).set(pdfOptions).save();
    };

    // Handle generate PDF for Experience Letter
    const handleGenerateExperienceLetterPDF = (staff) => {
        const pdfOptions = {
            margin: 10,
            filename: 'ExperienceLetter.pdf',
            jsPDF: { unit: 'pt', format: 'letter', orientation: 'portrait' },
        };

        const contentHTML = generateExperienceLetterText(staff);

        const contentElement = document.createElement('div');
        contentElement.innerHTML = contentHTML;
        html2pdf().from(contentElement).set(pdfOptions).save();
    };

    return (
        <div className="container-fluid" style={{ marginTop: '5vh' }}>
            <div className="Joining_letter_container">
                <div className="Joining_letter_title-container">
                    <h2 className="Joining_letter_title">Generate Letter</h2>
                </div>

                {!selectedStaff && (
                    <div className="Joining_letter_search-container">
                        <input
                            type="text"
                            value={searchTerm}
                            onChange={handleSearchChange}
                            placeholder="Search by Teacher Name"
                            className="Joining_letter_input"
                        />
                        {searchTerm && filteredStaff.length > 0 && (
                            <ul className="Joining_letter_suggestions-list">
                                {filteredStaff.map((staff) => (
                                    <li
                                        key={staff.ID}
                                        onClick={() => handleSelectStaff(staff)}
                                        className="Joining_letter_suggestion-item"
                                    >
                                        {staff.TEACHER_NAME}
                                    </li>
                                ))}
                            </ul>
                        )}
                        {searchTerm && filteredStaff.length === 0 && (
                            <div>No matching staff found</div>
                        )}
                    </div>
                )}

                {selectedStaff && (
                    <div className="Joining_letter_staff-details">
                        <div className="Joining_letter_left-side">
                            <img
                                src="https://img.freepik.com/free-photo/3d-cartoon-business-character_1048-16637.jpg"
                                alt="Staff Img"
                                style={{ width: '25%', borderRadius: '10px' }}
                            />
                            <div className="Joining_letter_text-below-image">
                                {selectedStaff.TEACHER_NAME}
                            </div>
                        </div>

                        <div className="Joining_letter_right-side">
                            <div className="Joining_letter_details-grid">
                                <div className="Joining_letter_detail-item">
                                    <div><strong>Registration/ID:</strong> {selectedStaff.STAFF_ID}</div>
                                </div>
                                <div className="Joining_letter_detail-item">
                                    <div><strong>Role:</strong> {selectedStaff.STAFF_ROLE}</div>
                                </div>
                                <div className="Joining_letter_detail-item">
                                    <div><strong>Date of Joining:</strong> {selectedStaff.DATE_OF_JOINING}</div>
                                </div>
                                <div className="Joining_letter_detail-item">
                                    <div><strong>School:</strong> {selectedStaff.SCHOOL_NAME}</div>
                                </div>
                                <div className="Joining_letter_detail-item">
                                    <div><strong>Principal:</strong> {selectedStaff.PRINCIPAL_NAME}</div>
                                </div>
                            </div>

                            <div style={{ display: 'flex', justifyContent: 'space-around' }}>
                                <button
                                    className="Joining_letter_button"
                                    onClick={() => handleGenerateJoiningLetterPDF(selectedStaff)}
                                >
                                    Generate Joining Letter
                                </button>
                                <button
                                    className="Joining_letter_button"
                                    onClick={() => handleGenerateExperienceLetterPDF(selectedStaff)}
                                >
                                    Generate Experience Letter
                                </button>
                            </div>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};

export default JoiningLetter;