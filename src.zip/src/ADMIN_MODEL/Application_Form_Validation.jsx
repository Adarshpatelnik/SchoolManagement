// Function to validate email
export const validateEmail = (email) => {
    const emailRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    return emailRegex.test(email);
};

// Function to validate phone number (India format:+91 followed by a space and 10 digits)
export const validatePhoneNumber = (phone) => {
    const phoneRegex = /^\+91\s[6-9]\d{9}$/;
    return phoneRegex.test(phone);
};

// Function to validate Aadhaar number (India format: 12 digits)
export const validateAadhar = (aadhar) => {
    const aadharRegex = /^\d{4} \d{4} \d{4}$/; // Matches "XXXX XXXX XXXX"
    return aadharRegex.test(aadhar);
};




// Function to validate pin code (India format: 6 digits)
export const validatePinCode = (pinCode) => {
    const pinCodeRegex = /^\d{6}$/; // Ensures 6-digit pin code
    return pinCodeRegex.test(pinCode);
};


// Function to sanitize and format Aadhaar number
export const sanitizeAndFormatAadhar = (aadhar) => {
    // Remove any non-digit characters
    let sanitizedValue = aadhar.replace(/\D/g, '');

    // Limit to 12 digits
    sanitizedValue = sanitizedValue.slice(0, 12);

    // Format as XXXX XXXX XXXX
    return sanitizedValue.replace(/(\d{4})(\d{4})(\d{0,4})/, (_, p1, p2, p3) => {
        return [p1, p2, p3].filter(Boolean).join(' ');
    });
};

// Function to sanitize and format phone number (+91 prefix)
export const sanitizeAndFormatPhoneNumber = (phone) => {
    // Remove any non-digit characters except spaces
    let sanitizedValue = phone.replace(/[^0-9 ]/g, '');

    // Ensure "+91 " prefix is retained
    if (!sanitizedValue.startsWith("91")) {
        sanitizedValue = "91 " + sanitizedValue.replace(/91 ?/, ''); // Add space if missing
    }
    // Extract the 10 digits after "+91 "
    const digitsAfterPrefix = sanitizedValue.slice(3).replace(/\s+/g, ''); // Remove accidental spaces
    return `91 ${digitsAfterPrefix.slice(0, 10)}`; // Limit to 10 digits
};