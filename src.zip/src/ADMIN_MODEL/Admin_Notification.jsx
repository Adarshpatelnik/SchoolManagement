
 
import React, { useState, useEffect, useMemo } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import './Admin_Model.css'; // 

const AdminNotification = () => {
  const [notifications, setNotifications] = useState([]);
  const [leaveRequests, setLeaveRequests] = useState([]);
  const [studentEditRequests, setStudentEditRequests] = useState([]);
  const [isOpen, setIsOpen] = useState(false);
  const navigate = useNavigate();

  const fetchNotifications = async () => {
    try {
      const res = await axios.get("http://13.127.57.224:2081/api/get-staff-notification");
      setNotifications(res.data);
    } catch (error) {
      console.error("Failed to fetch notifications", error);
    }
  };

  const fetchLeaveRequests = async () => {
    try {
      const res = await axios.get("http://13.127.57.224:2081/api/get-leave-requests");
      setLeaveRequests(res.data);
    } catch (error) {
      console.error("Failed to fetch leave requests", error);
    }
  };

  const fetchStudentEditRequests = async () => {
    try {
      const response = await axios.get("http://13.127.57.224:2081/api/student-edit-request");
      const data = response.data.map((notif) => ({ ...notif, isNew: notif.isNew || false }));
      setStudentEditRequests(data);
    } catch (error) {
      console.error('Error fetching student edit requests:', error);
    }
  };

  useEffect(() => {
    fetchNotifications();
    fetchLeaveRequests();
    fetchStudentEditRequests();
  }, []);

  const toggleNotifications = () => {
    setIsOpen(!isOpen);
  };

  const markAsRead = async (notificationId) => {
    try {
      await axios.post("http://13.127.57.224:2081/api/mark-notification-read", { notificationId });
      fetchNotifications();
    } catch (error) {
      console.error("Failed to mark notification as read", error);
    }
  };

  const updateLeaveStatus = async (staff_id, status) => {
    try {
      const response = await axios.post("http://13.127.57.224:2081/api/update-leave-status", { staff_id, status });
      if (response.data.success) {
        alert(`Leave request ${status.toLowerCase()} successfully.`);
        setLeaveRequests((prevRequests) => prevRequests.filter((request) => request.staff_id !== staff_id));
      } else {
        alert(`Error: ${response.data.error}`);
      }
    } catch (error) {
      console.error("Failed to update leave status", error);
      alert("Error updating leave status");
    }
  };

  const handleShowStudentEditRequest = (request) => {
    if (request.isNew) {
      setStudentEditRequests((prevRequests) =>
        prevRequests.map((req) =>
          req.REQUEST_ID === request.REQUEST_ID
            ? { ...req, isNew: false }
            : req
        )
      );
    }
    navigate(`/Student_Data_Table?REQUEST_ID=${request.REQUEST_ID}`);
    setIsOpen(false);
  };

  const newNotificationCount = useMemo(() => {
    const newNotifs = notifications.filter((notif) => !notif.read).length;
    const newLeaveRequests = leaveRequests.length;
    const newStudentEditRequests = studentEditRequests.filter((req) => req.isNew).length;
    return newNotifs + newLeaveRequests + newStudentEditRequests;
  }, [notifications, leaveRequests, studentEditRequests]);

  return (
    <div className="notification-container">
      <button onClick={toggleNotifications} className="notification-button">
        🔔
        {newNotificationCount > 0 && (
          <span className="notification-count"></span>
        )}
      </button>
      {isOpen && (
        <div className="notification-popup">
          <h4>Notifications</h4>
          <ul className="notification-list">
            {notifications.length === 0 ? (
              <li>No new notifications</li>
            ) : (
              notifications.map((note) => (
                <li key={note.ID} className="notification-item">
                  <span>{note.MESSAGE}</span>
                  <button onClick={() => markAsRead(note.ID)}>Mark as Read</button>
                </li>
              ))
            )}
          </ul>
          <h4>Leave Requests</h4>
          <ul className="notification-list">
            {leaveRequests.length === 0 ? (
              <li>No leave requests</li>
            ) : (
              leaveRequests.map((request) => (
                <li key={request.id} className="notification-item">
                  <span>Staff ID: {request.STAFF_ID}, Staff Name: {request.STAFF_NAME}, Status: {request.STATUS}</span>
                  <div className="leave-request-actions">
                    <button onClick={() => updateLeaveStatus(request.STAFF_ID, 'APPROVED')} className="approve">Approve</button>
                    <button onClick={() => updateLeaveStatus(request.STAFF_ID, 'REJECTED')} className="reject">Reject</button>
                  </div>
                </li>
              ))
            )}
          </ul>
          <h4>Student Edit Requests</h4>
          <ul className="notification-list">
            {studentEditRequests.length === 0 ? (
              <li>No student edit requests</li>
            ) : (
              studentEditRequests.map((request) => (
                <li
                  key={request.REQUEST_ID}
                  className={`student-edit-request ${request.isNew ? 'new' : ''}`}
                  onClick={() => handleShowStudentEditRequest(request)}
                >
                  <span>{request.ISSUE}</span>
                </li>
              ))
            )}
          </ul>
        </div>
      )}
    </div>
  );
}

export default AdminNotification;