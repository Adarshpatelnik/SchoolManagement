
import React, { useState, useEffect, useMemo } from 'react';
import { AgCharts } from 'ag-charts-react';
import axios from 'axios';
import './Admin_Model.css';

const Dropdown = ({ label, value, options, onChange }) => (
  <select value={value} onChange={onChange} className="Performance_Dashboard_Select">
    <option value="">{label}</option>
    {options.map((option) => (
      <option key={option} value={option}>{option}</option>
    ))}
  </select>
);

const DashboardPerformanceSummary = () => {
  const [filters, setFilters] = useState({
    selectedClass: '',
    selectedTerm: '',
    selectedPerformance: '',
    selectedAcademicYear: '',
  });

  const [data, setData] = useState({
    classes: [],
    terms: [],
    performances: [],
    academicYears: [],
    chartData: [],
  });

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const fetchData = async () => {
    setLoading(true);
    setError('');
    try {
      const response = await axios.get('http://13.127.57.224:2081/api/PerformanceSummary', {
        params: filters,
      });
      const fetchedData = response.data;

      const getUniqueValues = (key) => [...new Set(fetchedData.map((item) => item[key]))];

      setData({
        classes: getUniqueValues('CLASS'),
        terms: getUniqueValues('TERM'),
        performances: getUniqueValues('PERFORMANCE'),
        academicYears: getUniqueValues('ACADEMIC_YEAR'),
        chartData: getUniqueValues('PERFORMANCE').map((performance) => {
          const item = fetchedData.find((d) => d.PERFORMANCE === performance);
          return { performance, percent: item ? parseFloat(item.PERCENT) : 0 };
        }),
      });
    } catch (error) {
      setError('Error fetching data. Please try again later.');
      console.error('Error:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [filters]);

  const handleFilterChange = (key) => (event) =>
    setFilters((prev) => ({ ...prev, [key]: event.target.value }));

  const chartOptions = useMemo(() => ({
    data: data.chartData,
    series: [
      {
        type: 'bar',
        xKey: 'performance',
        yKey: 'percent',
        label: {
          enabled: false,
          formatter: (params) => `${params.value}%`,
        },
        barWidth: 0.5,
        fill: '#012353', // Set the bars to blue
      },
    ],
    axes: [
      { type: 'category', position: 'bottom', title: { text: '' } },
      { type: 'number', position: 'left', title: { text: 'Percentage' }, min: 0 },
    ],
  }), [data.chartData]);

  return (
    <div className="card card-success">
      <div>
        {loading && <p className="loading">Loading...</p>}
        {error && <p className="error">{error}</p>}
        <div className="Performance_Dashboard">
          <Dropdown
            label="Class"
            value={filters.selectedClass}
            options={data.classes}
            onChange={handleFilterChange('selectedClass')}
          />
          <Dropdown
            label="Term"
            value={filters.selectedTerm}
            options={data.terms}
            onChange={handleFilterChange('selectedTerm')}
          />
          <Dropdown
            label="Year"
            value={filters.selectedAcademicYear}
            options={data.academicYears}
            onChange={handleFilterChange('selectedAcademicYear')}
          />
          <Dropdown
            label="Performance"
            value={filters.selectedPerformance}
            options={data.performances}
            onChange={handleFilterChange('selectedPerformance')}
          />
        </div>
        <AgCharts options={chartOptions} style={{ height: '35vh', width: '100%' }} />
      </div>
    </div>
  );
};

export default DashboardPerformanceSummary;

