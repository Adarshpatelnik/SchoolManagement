

import React, { useEffect, useState, useRef, useMemo } from 'react';
import axios from 'axios';
import { AgCharts } from 'ag-charts-react';
import { FaEllipsisV } from 'react-icons/fa';
import styled from 'styled-components';
import 'bootstrap/dist/css/bootstrap.min.css';
import './Admin_Model.css';
 
const Dropdown = ({ label, options, selectedValue, onChange }) => (
  <div className="Student_Attendance_DropdownItem">
    <select className="Student_Attendance_Select" value={selectedValue} onChange={onChange}>
      <option value="">{label}</option>
      {options.map((option, index) => (
        <option key={index} value={option}>
          {option}
        </option>
      ))}
    </select>
  </div>
);
 
const DashbordStudentAttendance = () => {
  const [attendanceData, setAttendanceData] = useState([]);
  const [classes, setClasses] = useState([]);
  const [dates, setDates] = useState([]);
  const [sessions, setSessions] = useState([]);
  const [selectedClass, setSelectedClass] = useState('');
  const [selectedDate, setSelectedDate] = useState('');
  const [selectedSession, setSelectedSession] = useState('');
  const [dropdownVisible, setDropdownVisible] = useState(false);
 
  const dropdownRef = useRef(null);
 
  useEffect(() => {
    const fetchAttendanceData = async () => {
      try {
        const response = await axios.get('http://13.127.57.224:2081/api/studentattendance');
        const data = response.data.map((record) => ({
          ...record,
          DATE: new Date(record.DATE).toLocaleDateString(),
        }));
 
        if (JSON.stringify(data) !== JSON.stringify(attendanceData)) {
          setAttendanceData(data);
          setClasses([...new Set(data.map((record) => record.CLASS))]);
          setDates([...new Set(data.map((record) => record.DATE))]);
          setSessions([...new Set(data.map((record) => record.SESSION))]);
        }
      } catch (error) {
        console.error('Error fetching student attendance data:', error);
      }
    };
 
    fetchAttendanceData();
  }, [attendanceData]);
 
  const filteredData = useMemo(() => {
    return attendanceData.filter(
      (record) =>
        (!selectedClass || record.CLASS === selectedClass) &&
        (!selectedDate || record.DATE === selectedDate) &&
        (!selectedSession || record.SESSION === selectedSession)
    );
  }, [attendanceData, selectedClass, selectedDate, selectedSession]);
 
  const processData = (data) => {
    const totalCount = data.length;
    const statusCount = data.reduce((acc, record) => {
      acc[record.STATUS] = (acc[record.STATUS] || 0) + 1;
      return acc;
    }, {});
  
    return Object.entries(statusCount).map(([key, value]) => ({
      label: `${key} (${Math.round((value / totalCount) * 100)}%)`, // Round percentage to nearest integer
      value,
      percentage: Math.round((value / totalCount) * 100), // Store the rounded percentage
    }));
  };
  
  const chartData = useMemo(() => processData(filteredData), [filteredData]);
  
  const donutChartOptions = useMemo(
    () => ({
      data: chartData,
      series: [
        {
          type: 'donut',
          legendItemKey: 'label',
          angleKey: 'value',
          innerRadiusRatio: 0.7,
          fills: ['#27AE60', '#012353', '#E0E0E0', '#F7B7A3', '#F0E3E4'],
          strokes: ['#FFFFFF'],
          innerLabels: [
            {
              text: 'Attendance',
              color:'black',
              // fontWeight: 'bold',
              fontSize: 12,
            },
            {
              text: `${Math.round(chartData.reduce((acc, curr) => acc + curr.percentage, 0))}%`, // Show total percentage as a rounded integer
              fontSize: 14,
              color: 'black',
            },
          ],
        },
      ],
      tooltip: {
        renderer: ({ datum }) =>
          `${datum.label}: ${datum.value} (${Math.round(datum.percentage)}%)`, // Round percentage in tooltip
      },
      legend: {
        enabled: true,
        position: 'bottom',
        item: {
          label: {
            fontSize: 12,
            color: '#000',
            formatter: ({ value }) => {
              return value.charAt(0).toUpperCase() + value.slice(1).toLowerCase();

              // Remove decimals and show percentage without decimals
              const percentage = value.match(/\((\d+)%\)/); // Match the percentage in the label
              if (percentage) {
                return value.replace(percentage[1], `${parseInt(percentage[1], 10)}`);
                // Remove decimal in percentage
              }
            },
          },
        },
        itemSpacing: 8, // Adds spacing between legend items
      },
    }),
    [chartData]
  );
  
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setDropdownVisible(false);
      }
    };
 
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);
 
  return (
    <div className="Student_Attendance_FilterChartContainer">
      <div className="Student_Attendance_CombinedContainer">
        <div className="Student_Attendance_ChartContainer">
          <div className="Student_Attendance_ChartWrapper">
            <AgCharts
              options={donutChartOptions}
              style={{ width: '100%', height: '33vh', marginTop: '1vh',marginRight:'-3vh'  }}
            />
          </div>
          <FaEllipsisV
            className="Student_Attendance_MenuIcon"
            onClick={() => setDropdownVisible(!dropdownVisible)}
          />
          {dropdownVisible && (
            <div
              className="Student_Attendance_DropdownContainer"
              ref={dropdownRef}
            >
              <Dropdown
                label="Class"
                options={classes}
                selectedValue={selectedClass}
                onChange={(e) => setSelectedClass(e.target.value)}
              />
              <Dropdown
                label="Date"
                options={dates}
                selectedValue={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
              />
              <Dropdown
                label="Session"
                options={sessions}
                selectedValue={selectedSession}
                onChange={(e) => setSelectedSession(e.target.value)}
              />
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
 
export default DashbordStudentAttendance;
 
 



// import React, { useEffect, useState, useRef, useMemo } from 'react';
// import axios from 'axios';
// import { AgCharts } from 'ag-charts-react';
// import { FaEllipsisV } from 'react-icons/fa';
// import styled from 'styled-components';
// import 'bootstrap/dist/css/bootstrap.min.css';
// import './Admin_Model.css';
// import { useNavigate } from 'react-router-dom'; // Import useNavigate

// const Dropdown = ({ label, options, selectedValue, onChange }) => (
//   <div className="Student_Attendance_DropdownItem">
//     <select className="Student_Attendance_Select" value={selectedValue} onChange={onChange}>
//       <option value="">{label}</option>
//       {options.map((option, index) => (
//         <option key={index} value={option}>
//           {option}
//         </option>
//       ))}
//     </select>
//   </div>
// );
 
// const DashbordStudentAttendance = () => {
//   const [attendanceData, setAttendanceData] = useState([]);
//   const [classes, setClasses] = useState([]);
//   const [dates, setDates] = useState([]);
//   const [sessions, setSessions] = useState([]);
//   const [selectedClass, setSelectedClass] = useState('');
//   const [selectedDate, setSelectedDate] = useState('');
//   const [selectedSession, setSelectedSession] = useState('');
//   const [dropdownVisible, setDropdownVisible] = useState(false);
 
//   const dropdownRef = useRef(null);
//   const navigate = useNavigate(); // Hook to navigate to another page

//   useEffect(() => {
//     const fetchAttendanceData = async () => {
//       try {
//         const response = await axios.get('http://13.127.57.224:2081/api/studentattendance');
//         const data = response.data.map((record) => ({
//           ...record,
//           DATE: new Date(record.DATE).toLocaleDateString(),
//         }));
 
//         if (JSON.stringify(data) !== JSON.stringify(attendanceData)) {
//           setAttendanceData(data);
//           setClasses([...new Set(data.map((record) => record.CLASS))]);
//           setDates([...new Set(data.map((record) => record.DATE))]);
//           setSessions([...new Set(data.map((record) => record.SESSION))]);
//         }
//       } catch (error) {
//         console.error('Error fetching student attendance data:', error);
//       }
//     };
 
//     fetchAttendanceData();
//   }, [attendanceData]);
  
//   const handleChartClick = () => {
//     navigate('/Student_Attendance'); // Replace with the route you want to navigate to
//   };

//   const filteredData = useMemo(() => {
//     return attendanceData.filter(
//       (record) =>
//         (!selectedClass || record.CLASS === selectedClass) &&
//         (!selectedDate || record.DATE === selectedDate) &&
//         (!selectedSession || record.SESSION === selectedSession)
//     );
//   }, [attendanceData, selectedClass, selectedDate, selectedSession]);
 
  // const processData = (data) => {
  //   const totalCount = data.length;
  //   const statusCount = data.reduce((acc, record) => {
  //     acc[record.STATUS] = (acc[record.STATUS] || 0) + 1;
  //     return acc;
  //   }, {});
  
  //   return Object.entries(statusCount).map(([key, value]) => ({
  //     label: `${key} (${Math.round((value / totalCount) * 100)}%)`, // Round percentage to nearest integer
  //     value,
  //     percentage: Math.round((value / totalCount) * 100), // Store the rounded percentage
  //   }));
  // };
  
  // const chartData = useMemo(() => processData(filteredData), [filteredData]);
  
  // const donutChartOptions = useMemo(
  //   () => ({
  //     data: chartData,
  //     series: [
  //       {
  //         type: 'donut',
  //         legendItemKey: 'label',
  //         angleKey: 'value',
  //         innerRadiusRatio: 0.7,
  //         fills: ['#27AE60', '#012353', '#E0E0E0', '#F7B7A3', '#F0E3E4'],
  //         strokes: ['#FFFFFF'],
  //         innerLabels: [
  //           {
  //             text: 'Attendance',
  //             color:'black',
  //             // fontWeight: 'bold',
  //             fontSize: 12,
  //           },
  //           {
  //             text: `${Math.round(chartData.reduce((acc, curr) => acc + curr.percentage, 0))}%`, // Show total percentage as a rounded integer
  //             fontSize: 14,
  //             color: 'black',
  //           },
  //         ],
  //       },
  //     ],
  //     tooltip: {
  //       renderer: ({ datum }) =>
  //         `${datum.label}: ${datum.value} (${Math.round(datum.percentage)}%)`, // Round percentage in tooltip
  //     },
  //     legend: {
  //       enabled: true,
  //       position: 'bottom',
  //       item: {
  //         label: {
  //           fontSize: 12,
  //           color: '#000',
  //           formatter: ({ value }) => {
  //             return value.charAt(0).toUpperCase() + value.slice(1).toLowerCase();

  //             // Remove decimals and show percentage without decimals
  //             const percentage = value.match(/\((\d+)%\)/); // Match the percentage in the label
  //             if (percentage) {
  //               return value.replace(percentage[1], `${parseInt(percentage[1], 10)}`);
  //               // Remove decimal in percentage
  //             }
  //           },
  //         },
  //       },
  //       itemSpacing: 8, // Adds spacing between legend items
  //     },
  //   }),
  //   [chartData]
  // );
  
//   useEffect(() => {
//     const handleClickOutside = (event) => {
//       if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
//         setDropdownVisible(false);
//       }
//     };
 
//     document.addEventListener('mousedown', handleClickOutside);
//     return () => {
//       document.removeEventListener('mousedown', handleClickOutside);
//     };
//   }, []);
 
//   return (
//     <div className="Student_Attendance_FilterChartContainer">
//       <div className="Student_Attendance_CombinedContainer">
//         <div className="Student_Attendance_ChartContainer" onClick={handleChartClick} style={{ cursor: 'pointer' }}>
//           <div className="Student_Attendance_ChartWrapper">
//             <AgCharts
//               options={donutChartOptions} // Assuming donutChartOptions is defined elsewhere
//               style={{ width: '100%', height: '33vh', marginTop: '1vh', marginRight: '-3vh' }}
//             />
//           </div>
          
//           <FaEllipsisV
//             className="Student_Attendance_MenuIcon"
//             onClick={() => setDropdownVisible(!dropdownVisible)}
//           />

//           {dropdownVisible && (
//             <div className="Student_Attendance_DropdownContainer" ref={dropdownRef}>
//               <Dropdown
//                 label="Class"
//                 options={classes} // Assuming classes is an array of options
//                 selectedValue={selectedClass}
//                 onChange={(e) => setSelectedClass(e.target.value)}
//               />
//               <Dropdown
//                 label="Date"
//                 options={dates} // Assuming dates is an array of options
//                 selectedValue={selectedDate}
//                 onChange={(e) => setSelectedDate(e.target.value)}
//               />
//               <Dropdown
//                 label="Session"
//                 options={sessions} // Assuming sessions is an array of options
//                 selectedValue={selectedSession}
//                 onChange={(e) => setSelectedSession(e.target.value)}
//               />
//             </div>
//           )}
//         </div>
//       </div>
//     </div>
//   );
// };
// export default DashbordStudentAttendance;