



import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './Admin_Model.css';

const StudentGradeBookEntry = () => {
  // State to manage form data
  const [formID, setFormID] = useState({
    STUDENT_ID: '',
    SUBJECT_NAME: '',
    PERIODIC_TEST_1: '',
    NOTE_BOOK_1: '',
    SUBJECT_ENRICHMENT_1: '',
    HALF_YEARLY: '',
    WORK_EDUCATION_1: '',
    ART_EDUCATION_1: '',
    HEALTH_AND_HYGIENE_1: '',
    REGULARITY_AND_PUNCTUALLITY_1: '',
    PERIODIC_TEST_2: '',
    NOTE_BOOK_2: '',
    SUBJECT_ENRICHMENT_2: '',
    ANNUAL: '',
    WORK_EDUCATION_2: '',
    ART_EDUCATION_2: '',
    HEALTH_AND_HYGIENE_2: '',
    REGULARITY_AND_PUNCTUALLITY_2: ''
  });

  // State for form errors
  const [errors, setErrors] = useState({});
  // State for the selected term
  const [term, setTerm] = useState('Term 1');
  // State to hold class options fetched from the API
  const [classOptions, setClassOptions] = useState([]);
  // State for the selected class
  const [selectedClass, setSelectedClass] = useState('');

  // Fetch class options when the component is mounted
  useEffect(() => {
    const fetchClasses = async () => {
      try {
        const response = await fetch('http://13.127.57.224:2081/api/classfilter'); // API call for class options
        if (!response.ok) {
          throw new Error('Failed to fetch data');
        }
        const data = await response.json();
        setClassOptions(data); // Populate class options
      } catch (error) {
        console.error('Error fetching data:', error);
        setErrors((prevErrors) => ({ ...prevErrors, fetchError: error.message })); // Set fetch error
      }
    };

    fetchClasses();
  }, []); // Run only once when the component is mounted

  // Handle changes to form fields
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormID((prevState) => ({
      ...prevState,
      [name]: value // Update the specific form field
    }));
  };

  // Reset form fields and errors
  const handleReset = () => {
    setFormID({
      STUDENT_ID: '',
      SUBJECT_NAME: '',
      PERIODIC_TEST_1: '',
      NOTE_BOOK_1: '',
      SUBJECT_ENRICHMENT_1: '',
      HALF_YEARLY: '',
      WORK_EDUCATION_1: '',
      ART_EDUCATION_1: '',
      HEALTH_AND_HYGIENE_1: '',
      REGULARITY_AND_PUNCTUALLITY_1: '',
      PERIODIC_TEST_2: '',
      NOTE_BOOK_2: '',
      SUBJECT_ENRICHMENT_2: '',
      ANNUAL: '',
      WORK_EDUCATION_2: '',
      ART_EDUCATION_2: '',
      HEALTH_AND_HYGIENE_2: '',
      REGULARITY_AND_PUNCTUALLITY_2: ''
    });
    setTerm('Term 1'); // Reset term to default
    setSelectedClass(''); // Reset selected class
    setErrors({}); // Clear all errors
  };

  // Submit the form data
  const handleSubmit = async (e) => {
    e.preventDefault(); // Prevent default form submission behavior

    const formData = { ...formID, term, class: selectedClass }; // Combine form data with selected term and class

    try {
      const response = await axios.post('http://13.127.57.224:2081/api/insertmarks', formData); // API call to submit form data
      console.log('Response:', response.data);
      alert('Data processed successfully!'); // Alert success
      handleReset(); // Reset the form
    } catch (error) {
      console.error('Error:', error);
      alert('Error processing data. Please check the console for details.'); // Alert failure
    }
  };

  // Get placeholder text dynamically based on the type of field
  const getPlaceholderText = (field) => {
    return ['PERIODIC_TEST', 'HALF_YEARLY', 'ANNUAL', 'NOTE_BOOK', 'SUBJECT_ENRICHMENT'].includes(field)
      ? 'Enter Marks'
      : 'Enter Grade';
  };

  // Render fields for grades dynamically based on the selected term
  const renderGradeFields = (prefix) => {
    const fields = [
      'PERIODIC_TEST',
      'NOTE_BOOK',
      'SUBJECT_ENRICHMENT',
      term === 'Term 1' ? 'HALF_YEARLY' : 'ANNUAL', // "HALF_YEARLY" for Term 1 and "ANNUAL" for Term 2
      'WORK_EDUCATION',
      'ART_EDUCATION',
      'HEALTH_AND_HYGIENE',
      'REGULARITY_AND_PUNCTUALLITY'
    ];

    return fields.map((field) => {
      // Add prefix for all fields except "HALF_YEARLY" and "ANNUAL"
      const fieldKey = field === 'HALF_YEARLY' || field === 'ANNUAL' ? field : `${field}_${prefix}`;

      return (
        <div className="Grade_Entry_Book_InputWrapper" key={fieldKey}>
          <label htmlFor={fieldKey} className="Grade_Entry_Book_Label">
            {`${field.replace(/_/g, ' ')}${fieldKey.includes('_') ? ` (${prefix})` : ''}`} {/* Format label */}
          </label>
          <input
            id={fieldKey}
            name={fieldKey}
            type="text"
            value={formID[fieldKey] || ''} // Bind input value to state
            onChange={handleChange}
            className="Grade_Entry_Book_Input"
            placeholder={getPlaceholderText(field)} // Set dynamic placeholder
            required
          />
          {errors[fieldKey] && <p className="Grade_Entry_Book_Message">{errors[fieldKey]}</p>} {/* Display validation error */}
        </div>
      );
    });
  };

  return (
    <div className="Grade_Entry_Book_Container">
      <div className="Grade_Entry_Book_FormWrapper">
        <div className="Grade_Entry_Heading_div">
          <h2>Grade Entry</h2> {/* Heading */}
        </div>
        <div className="Grade_Entry_Book_FiltersAndResetContainer">
          <div className="Grade_Entry_Book_FilterGroup">
            {/* Dropdown for selecting class */}
            <div className="Grade_Entry_Book_FilterItem">
              <label htmlFor="class" className="Grade_Entry_Book_Label">Class</label>
              <select
                id="class"
                name="class"
                value={selectedClass}
                onChange={(e) => setSelectedClass(e.target.value)}
                className="Grade_Entry_Book_ClassSelect"
              >
                <option value="">Class</option>
                {classOptions.map((cls) => (
                  <option key={cls.class} value={cls.class}>
                    {cls.class}
                  </option>
                ))}
              </select>
            </div>

            {/* Dropdown for selecting term */}
            <div className="Grade_Entry_Book_FilterItem">
              <label htmlFor="term" className="Grade_Entry_Book_Label">Term</label>
              <select
                id="term"
                name="term"
                value={term}
                onChange={(e) => setTerm(e.target.value)}
                className="Grade_Entry_Book_TermSelect"
              >
                <option value="Term 1">Term 1</option>
                <option value="Term 2">Term 2</option>
              </select>
            </div>
            {/* Reset button */}
            <button onClick={handleReset} className="Grade_Entry_Book_ResetButton">Reset</button>
          </div>
        </div>

        {/* Form for grade entry */}
        <form onSubmit={handleSubmit}>
          <div className="Grade_Entry_Book_FormContainer">
            {/* Input for student ID */}
            <div className="Grade_Entry_Book_InputWrapper">
              <label htmlFor="STUDENT_ID" className="Grade_Entry_Book_Label">STUDENT ID</label>
              <input
                id="STUDENT_ID"
                name="STUDENT_ID"
                type="text"
                value={formID.STUDENT_ID}
                onChange={handleChange}
                className="Grade_Entry_Book_Input"
                placeholder="Enter student ID"
                required
              />
              {errors.STUDENT_ID && <p className="Grade_Entry_Book_Message">{errors.STUDENT_ID}</p>}
            </div>

            {/* Input for subject name */}
            <div className="Grade_Entry_Book_InputWrapper">
              <label htmlFor="SUBJECT_NAME" className="Grade_Entry_Book_Label">SUBJECT NAME</label>
              <input
                id="SUBJECT_NAME"
                name="SUBJECT_NAME"
                type="text"
                value={formID.SUBJECT_NAME}
                onChange={handleChange}
                className="Grade_Entry_Book_Input"
                placeholder="Enter subject name"
                required
              />
              {errors.SUBJECT_NAME && <p className="Grade_Entry_Book_Message">{errors.SUBJECT_NAME}</p>}
            </div>

            {/* Render fields based on selected term */}
            {term === 'Term 1' && renderGradeFields('1')}
            {term === 'Term 2' && renderGradeFields('2')}
          </div>

          {/* Submit button */}
          <div className="Grade_Entry_Book_Submit_Btn_Main">
            <button type="submit" className="Grade_Entry_Book_SubmitButton">Submit</button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default StudentGradeBookEntry;