import React, { useState } from 'react';
import styled from 'styled-components';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faBars, faSearch } from '@fortawesome/free-solid-svg-icons';
import { Link } from 'react-router-dom';

// Styled components
const Navbar = styled.nav`
  height: 60px;
  background-color: #2c3e50;
  color: white;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 1rem;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  position: relative;
  z-index: 1000;
`;

const ToggleButton = styled.button`
  background: none;
  border: none;
  color: white;
  font-size: 1.5rem;
  cursor: pointer;
  padding: 0.5rem;
  transition: color 0.3s ease;
  &:hover {
    color: #3498db;
  }
`;

const NavbarSearch = styled.div`
  display: ${props => (props.isSearchVisible ? 'flex' : 'none')};
  align-items: center;
  input {
    padding: 0.5rem;
    border: none;
    border-radius: 4px;
    margin-left: 1rem;
  }
`;

const NavbarLink = styled(Link)`
  color: white;
  text-decoration: none;
  font-size: 1rem;
  padding: 0.5rem 1rem;
  transition: background 0.3s ease, color 0.3s ease;
  &:hover {
    background: #34495e;
    border-radius: 4px;
  }
`;

const LandingNavbar = ({ sidebarVisible, toggleSidebar }) => {
  const [isSearchVisible, setIsSearchVisible] = useState(false);

  return (
    <Navbar>
      <ToggleButton onClick={toggleSidebar}>
        <FontAwesomeIcon icon={faBars} />
      </ToggleButton>

      <div>
        <NavbarLink to="/home">Home</NavbarLink>
        <NavbarLink to="/about">About</NavbarLink>
        <NavbarLink to="/contact">Contact</NavbarLink>
        <NavbarSearch isSearchVisible={isSearchVisible}>
          <FontAwesomeIcon icon={faSearch} onClick={() => setIsSearchVisible(!isSearchVisible)} />
          {isSearchVisible && <input type="text" placeholder="Search..." />}
        </NavbarSearch>
      </div>
    </Navbar>
  );
};

export default LandingNavbar;
