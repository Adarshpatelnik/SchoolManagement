
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import 'bootstrap/dist/css/bootstrap.min.css';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';

const StudentPromote = () => {
  const [students, setStudents] = useState([]);
  const [selectedStudents, setSelectedStudents] = useState([]);
  const [classFilter, setClassFilter] = useState('');
  const [academicyearFilter, setAcademicyearFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [classes, setClasses] = useState([]);
  const [academicyears, setAcademicyears] = useState([]);
  const [statuses, setStatuses] = useState([]);
  const [loading, setLoading] = useState(false);
  const [promotedStudents, setPromotedStudents] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    const fetchOptionsAndStudents = async () => {
      setLoading(true);
      try {
        const response = await axios.get('http://13.127.57.224:2081/api/options');
        setClasses(response.data.classes);
        setAcademicyears(response.data.academicyears);
        setStatuses(response.data.statuses);
        await fetchStudents();
      } catch (error) {
        console.error('Error fetching options or students:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchOptionsAndStudents();
  }, []);

  useEffect(() => {
    fetchStudents();
  }, [classFilter, academicyearFilter, statusFilter, searchTerm]);

  const fetchStudents = async () => {
    try {
      const response = await axios.get('http://13.127.57.224:2081/api/promotestudent', {
        params: {
          classFilter: classFilter || undefined,
          academicyearFilter: academicyearFilter || undefined,
          statusFilter: statusFilter || undefined,
          searchTerm: searchTerm || undefined,
        },
      });
      setStudents(response.data);
    } catch (error) {
      console.error('Error fetching students:', error);
    }
  };

  const handlePromoteStudents = async () => {
    try {
      await axios.post('http://13.127.57.224:2081/api/promoteStudents', { selectedStudents });
      setPromotedStudents([...promotedStudents, ...selectedStudents]);
      fetchStudents();
      setSelectedStudents([]);
      alert('Students promoted successfully!');
    } catch (error) {
      console.error('Error promoting students:', error);
      alert('Error promoting students. Please try again.');
    }
  };

  const onSelectionChanged = (event) => {
    const selectedRows = event.api.getSelectedRows();
    setSelectedStudents(selectedRows.map(row => row.STUDENT_ID));
  };

  const handleSearchChange = (event) => {
    setSearchTerm(event.target.value);
  };

  const columnDefs = [
    {
      headerCheckboxSelection: true,
      checkboxSelection: true,
    },
    { headerName: 'Student ID', field: 'STUDENT_ID', filter: true },
    { headerName: 'Student Name', field: 'STUDENT_NAME', filter: true },
    { headerName: 'Academic Year', field: 'ACADEMIC_YEAR', filter: true },
    { headerName: 'Class', field: 'CLASS', filter: true },
    { headerName: 'Percent', field: 'PERCENT', filter: true },
    { headerName: 'Result', field: 'STATUS', filter: true },
  ];
  const defaultColDef = {
    floatingFilter: true,
    sortable: true,
    minWidth: 150,
    maxWidth: 180,
    resizable: true,
  };

  return (
    <div className="container">
      <div className="container-fluid" style={{ marginTop: '8vh', width: '100%', padding: 0 }}>
        <div className="ag-theme-alpine" style={{ height: '75vh', width: '100%' }}>
          <AgGridReact
            rowData={students}
            columnDefs={columnDefs}
            onSelectionChanged={onSelectionChanged}
            defaultColDef={defaultColDef}
            rowSelection="multiple"
            suppressRowClickSelection={true}
            enableFilter={true} // Ensures filters are enabled
          />
        </div>

        <div className="row mt-3 justify-content-center">
          <div className="col-md-2 mb-1 text-center">
          <button
  className="btn"
  onClick={handlePromoteStudents}
  style={{
    background: 'linear-gradient( #0b1a32, #1f6d3a)', // Darker gradient background
    border: 'none',
    color: 'white', // White text color
  }}
  disabled={selectedStudents.length === 0}
>
  Promote Selected
</button>


          </div>
        </div>
      </div>
    </div>
  );
};

export default StudentPromote;
