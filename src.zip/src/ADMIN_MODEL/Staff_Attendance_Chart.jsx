
import React, { useEffect, useState, useMemo, useRef } from 'react';
import axios from 'axios';
import { AgCharts } from 'ag-charts-react';
import { FaEllipsisV } from 'react-icons/fa';
import 'bootstrap/dist/css/bootstrap.min.css';
import './Admin_Model.css';

const AttendanceChart = () => {
  const [attendanceData, setAttendanceData] = useState([]);
  const [filters, setFilters] = useState({
    selectedDateRange: '',
    customStartDate: '',
    customEndDate: '',
    selectedStatus: '',
    selectedRole: '',
    selectedSession: '',
  });
  const [dropdownVisible, setDropdownVisible] = useState(false);
  const dropdownRef = useRef(null);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setDropdownVisible(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  useEffect(() => {
    const fetchAttendanceData = async () => {
      try {
        const response = await axios.get('http://13.127.57.224:2081/api/staffattendance');
        const data = response.data.map((record) => ({
          ...record,
          DATE: new Date(record.DATE).toISOString().split('T')[0],
        }));
        setAttendanceData(data);
      } catch (error) {
        console.error('Error fetching staff attendance data:', error);
      }
    };

    fetchAttendanceData();
  }, []);

  const {
    selectedDateRange,
    customStartDate,
    customEndDate,
    selectedStatus,
    selectedRole,
    selectedSession,
  } = filters;

  const applyDateFilter = (recordDate) => {
    const recordTimestamp = new Date(recordDate).getTime();
    const now = Date.now();
    switch (selectedDateRange) {
      case '1Month':
        return recordTimestamp >= now - 30 * 24 * 60 * 60 * 1000;
      case '3Months':
        return recordTimestamp >= now - 3 * 30 * 24 * 60 * 60 * 1000;
      case '6Months':
        return recordTimestamp >= now - 6 * 30 * 24 * 60 * 60 * 1000;
      case '1Year':
        return recordTimestamp >= now - 365 * 24 * 60 * 60 * 1000;
      case 'Custom':
        return (
          (!customStartDate || recordTimestamp >= new Date(customStartDate).getTime()) &&
          (!customEndDate || recordTimestamp <= new Date(customEndDate).getTime())
        );
      default:
        return true;
    }
  };

  const filteredData = useMemo(() => {
    return attendanceData.filter((record) => {
      return (
        applyDateFilter(record.DATE) &&
        (!selectedStatus || record.STATUS === selectedStatus) &&
        (!selectedRole || record.STAFF_ROLE === selectedRole) &&
        (!selectedSession || record.SESSION === selectedSession)
      );
    });
  }, [attendanceData, selectedDateRange, customStartDate, customEndDate, selectedStatus, selectedRole, selectedSession]);

  const processData = (data) => {
    const totalCount = data.length;
    const statusCount = data.reduce((acc, record) => {
      acc[record.STATUS] = (acc[record.STATUS] || 0) + 1;
      return acc;
    }, {});

    return Object.entries(statusCount).map(([key, value]) => {
      const percentage = Math.round((value / totalCount) * 100);
      return {

      name: key,
      value,
      percentage: `${percentage}%`,
      displayLabel: `${key} (${percentage}%)`,
    };
  });
};
  const chartData = useMemo(() => processData(filteredData), [filteredData]);

  const totalStaffCount = useMemo(() => filteredData.length, [filteredData]);

  const options = {
    data: chartData,
    series: [
      {
        type: 'donut',
        legendItemKey: 'displayLabel',
        angleKey: 'value',
        innerRadiusRatio: 0.7,
        fills: ['#27AE60', '#012353', '#012353', '#27AE60'],
        tooltip: {
          renderer: ({ datum }) => `${datum.name} (${datum.percentage})`,
        },
        innerLabels: [
          {
            text: 'Attendance',
            fontWeight: 'bold',
            fontSize: 12,
          },
          {
            text: chartData.reduce((acc, item) => acc + parseFloat(item.percentage), 0).toFixed(0) + '%',            fontSize: 14,
            color: '#000000', // You can change the color as needed
          },
        ],
      },
    ],
    legend: {
      enabled: true,
      position: 'bottom',
      item: {
        label: {
          fontSize: 12,
          color: '#333',
          formatter: ({ value }) => {
            // Capitalize the first letter and make the rest lowercase
            return value.charAt(0).toUpperCase() + value.slice(1).toLowerCase();
          },
        },
        marker: {
          shape: 'square',
          size: 10,
        },
        paddingX: 10,
        paddingY: 10,
      },
    },
    layout: {
      padding: {
        bottom: 0,
      },
    },
    
  };
  const handleFilterChange = (filterName) => (event) => {
    setFilters((prev) => ({
      ...prev,
      [filterName]: event.target.value,
    }));
  };

  const categoryCounts = useMemo(() => {
    const statuses = attendanceData.reduce((acc, record) => {
      acc[record.STATUS] = (acc[record.STATUS] || 0) + 1;
      return acc;
    }, {});
    const roles = attendanceData.reduce((acc, record) => {
      acc[record.STAFF_ROLE] = (acc[record.STAFF_ROLE] || 0) + 1;
      return acc;
    }, {});
    const sessions = attendanceData.reduce((acc, record) => {
      acc[record.SESSION] = (acc[record.SESSION] || 0) + 1;
      return acc;
    }, {});
    return { statuses, roles, sessions };
  }, [attendanceData]);

  return (
    <div className="Staff_Chart_filter-chart-container">
      <div className="Staff_Chart_combined-container">
        <div className="Staff_Chart_chart-container">
          <div className="Staff_Chart_chart-wrapper">
            <AgCharts options={options} style={{ width: '100%', height: '33vh' }} />
          </div>
          <FaEllipsisV className="Staff_Chart_menu-icon" onClick={() => setDropdownVisible(!dropdownVisible)} />
          {dropdownVisible && (
            <div className="Staff_Chart_dropdown-container" ref={dropdownRef}>
              <div className="Staff_Chart_dropdown-item">
                <select
                  className="Staff_Chart_select-input"
                  value={filters.selectedDateRange}
                  onChange={handleFilterChange('selectedDateRange')}
                >
                  <option value="">Select Date Range</option>
                  <option value="1Month">Last 1 Month</option>
                  <option value="3Months">Last 3 Months</option>
                  <option value="6Months">Last 6 Months</option>
                  <option value="1Year">Last 1 Year</option>
                  <option value="Custom">Custom</option>
                </select>
              </div>
              {filters.selectedDateRange === 'Custom' && (
                <>
                  <div className="Staff_Chart_dropdown-item">
                    <input
                      type="date"
                      className="Staff_Chart_date-input"
                      value={filters.customStartDate}
                      onChange={handleFilterChange('customStartDate')}
                    />
                  </div>
                  <div className="Staff_Chart_dropdown-item">
                    <input
                      type="date"
                      className="Staff_Chart_date-input"
                      value={filters.customEndDate}
                      onChange={handleFilterChange('customEndDate')}
                    />
                  </div>
                </>
              )}
              <div className="Staff_Chart_dropdown-item">
                <select
                  className="Staff_Chart_select-input"
                  value={filters.selectedStatus}
                  onChange={handleFilterChange('selectedStatus')}
                >
                  <option value="">Status</option>
                  {Object.entries(categoryCounts.statuses).map(([status, count]) => (
                    <option key={status} value={status}>
                      {`${status} (${count})`}
                    </option>
                  ))}
                </select>
              </div>
              <div className="Staff_Chart_dropdown-item">
                <select
                  className="Staff_Chart_select-input"
                  value={filters.selectedRole}
                  onChange={handleFilterChange('selectedRole')}
                >
                  <option value="">Role</option>
                  {Object.entries(categoryCounts.roles).map(([role, count]) => (
                    <option key={role} value={role}>
                      {`${role} (${count})`}
                    </option>
                  ))}
                </select>
              </div>
              <div className="Staff_Chart_dropdown-item">
                <select
                  className="Staff_Chart_select-input"
                  value={filters.selectedSession}
                  onChange={handleFilterChange('selectedSession')}
                >
                  <option value="">Session</option>
                  {Object.entries(categoryCounts.sessions).map(([session, count]) => (
                    <option key={session} value={session}>
                      {`${session} (${count})`}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AttendanceChart;



// import React, { useEffect, useState, useMemo, useRef } from 'react';
// import axios from 'axios';
// import { AgCharts } from 'ag-charts-react';
// import { FaEllipsisV } from 'react-icons/fa';
// import { useNavigate } from 'react-router-dom'; // Import useNavigate
// import 'bootstrap/dist/css/bootstrap.min.css';
// import './Admin_Model.css';

// const AttendanceChart = () => {
//   const [attendanceData, setAttendanceData] = useState([]);
//   const [filters, setFilters] = useState({
//     selectedDateRange: '',
//     customStartDate: '',
//     customEndDate: '',
//     selectedStatus: '',
//     selectedRole: '',
//     selectedSession: '',
//   });
//   const [dropdownVisible, setDropdownVisible] = useState(false);
//   const dropdownRef = useRef(null);
//   const navigate = useNavigate(); // Hook to navigate to another page

//   useEffect(() => {
//     const handleClickOutside = (event) => {
//       if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
//         setDropdownVisible(false);
//       }
//     };

//     document.addEventListener('mousedown', handleClickOutside);
//     return () => {
//       document.removeEventListener('mousedown', handleClickOutside);
//     };
//   }, []);

//   useEffect(() => {
//     const fetchAttendanceData = async () => {
//       try {
//         const response = await axios.get('http://13.127.57.224:2081/api/staffattendance');
//         const data = response.data.map((record) => ({
//           ...record,
//           DATE: new Date(record.DATE).toISOString().split('T')[0],
//         }));
//         setAttendanceData(data);
//       } catch (error) {
//         console.error('Error fetching staff attendance data:', error);
//       }
//     };

//     fetchAttendanceData();
//   }, []);

//   const handleChartClick = () => {
//     navigate('/Staff_Attendance'); // Replace with the route you want to navigate to
//   };



//   const {
//     selectedDateRange,
//     customStartDate,
//     customEndDate,
//     selectedStatus,
//     selectedRole,
//     selectedSession,
//   } = filters;

//   const applyDateFilter = (recordDate) => {
//     const recordTimestamp = new Date(recordDate).getTime();
//     const now = Date.now();
//     switch (selectedDateRange) {
//       case '1Month':
//         return recordTimestamp >= now - 30 * 24 * 60 * 60 * 1000;
//       case '3Months':
//         return recordTimestamp >= now - 3 * 30 * 24 * 60 * 60 * 1000;
//       case '6Months':
//         return recordTimestamp >= now - 6 * 30 * 24 * 60 * 60 * 1000;
//       case '1Year':
//         return recordTimestamp >= now - 365 * 24 * 60 * 60 * 1000;
//       case 'Custom':
//         return (
//           (!customStartDate || recordTimestamp >= new Date(customStartDate).getTime()) &&
//           (!customEndDate || recordTimestamp <= new Date(customEndDate).getTime())
//         );
//       default:
//         return true;
//     }
//   };

//   const filteredData = useMemo(() => {
//     return attendanceData.filter((record) => {
//       return (
//         applyDateFilter(record.DATE) &&
//         (!selectedStatus || record.STATUS === selectedStatus) &&
//         (!selectedRole || record.STAFF_ROLE === selectedRole) &&
//         (!selectedSession || record.SESSION === selectedSession)
//       );
//     });
//   }, [attendanceData, selectedDateRange, customStartDate, customEndDate, selectedStatus, selectedRole, selectedSession]);

//   const processData = (data) => {
//     const totalCount = data.length;
//     const statusCount = data.reduce((acc, record) => {
//       acc[record.STATUS] = (acc[record.STATUS] || 0) + 1;
//       return acc;
//     }, {});


//     return Object.entries(statusCount).map(([key, value]) => {
//       const percentage = Math.round((value / totalCount) * 100);
//       return {

//       name: key,
//       value,
//       percentage: `${percentage}%`,
//       displayLabel: `${key} (${percentage}%)`,
//     };
//   });
// };
//   const chartData = useMemo(() => processData(filteredData), [filteredData]);

//   const totalStaffCount = useMemo(() => filteredData.length, [filteredData]);

//   const options = {
//     data: chartData,
//     series: [
//       {
//         type: 'donut',
//         legendItemKey: 'displayLabel',
//         angleKey: 'value',
//         innerRadiusRatio: 0.7,
//         fills: ['#27AE60', '#012353', '#012353', '#27AE60'],
//         tooltip: {
//           renderer: ({ datum }) => `${datum.name} (${datum.percentage})`,
//         },
//         innerLabels: [
//           {
//             text: 'Attendance',
//             fontWeight: 'bold',
//             fontSize: 12,
//           },
//           {
//             text: chartData.reduce((acc, item) => acc + parseFloat(item.percentage), 0).toFixed(0) + '%',            fontSize: 14,
//             color: '#000000', // You can change the color as needed
//           },
//         ],
//       },
//     ],
//     legend: {
//       enabled: true,
//       position: 'bottom',
//       item: {
//         label: {
//           fontSize: 12,
//           color: '#333',
//           formatter: ({ value }) => {
//             // Capitalize the first letter and make the rest lowercase
//             return value.charAt(0).toUpperCase() + value.slice(1).toLowerCase();
//           },
//         },
//         marker: {
//           shape: 'square',
//           size: 10,
//         },
//         paddingX: 10,
//         paddingY: 10,
//       },
//     },
//     layout: {
//       padding: {
//         bottom: 0,
//       },
//     },
    
//   };


//   const handleFilterChange = (filterName) => (event) => {
//     setFilters((prev) => ({
//       ...prev,
//       [filterName]: event.target.value,
//     }));
//   };

//   const categoryCounts = useMemo(() => {
//     const statuses = attendanceData.reduce((acc, record) => {
//       acc[record.STATUS] = (acc[record.STATUS] || 0) + 1;
//       return acc;
//     }, {});
//     const roles = attendanceData.reduce((acc, record) => {
//       acc[record.STAFF_ROLE] = (acc[record.STAFF_ROLE] || 0) + 1;
//       return acc;
//     }, {});
//     const sessions = attendanceData.reduce((acc, record) => {
//       acc[record.SESSION] = (acc[record.SESSION] || 0) + 1;
//       return acc;
//     }, {});
//     return { statuses, roles, sessions };
//   }, [attendanceData]);

//   return (
//     <div className="Staff_Chart_filter-chart-container">
//       <div className="Staff_Chart_combined-container">
//         <div
//           className="Staff_Chart_chart-container"
//           onClick={handleChartClick} // Navigate on click
//           style={{ cursor: 'pointer' }} // Add cursor pointer for clarity
//         >
//           <div className="Staff_Chart_chart-wrapper">
//             <AgCharts options={options} style={{ width: '100%', height: '33vh' }} />
//           </div>
         
//           <FaEllipsisV className="Staff_Chart_menu-icon" onClick={() => setDropdownVisible(!dropdownVisible)} />
//           {dropdownVisible && (
//             <div className="Staff_Chart_dropdown-container" ref={dropdownRef}>
//               <div className="Staff_Chart_dropdown-item">
//                 <select
//                   className="Staff_Chart_select-input"
//                   value={filters.selectedDateRange}
//                   onChange={handleFilterChange('selectedDateRange')}
//                 >
//                   <option value="">Select Date Range</option>
//                   <option value="1Month">Last 1 Month</option>
//                   <option value="3Months">Last 3 Months</option>
//                   <option value="6Months">Last 6 Months</option>
//                   <option value="1Year">Last 1 Year</option>
//                   <option value="Custom">Custom</option>
//                 </select>
//               </div>
//               {filters.selectedDateRange === 'Custom' && (
//                 <>
//                   <div className="Staff_Chart_dropdown-item">
//                     <input
//                       type="date"
//                       className="Staff_Chart_date-input"
//                       value={filters.customStartDate}
//                       onChange={handleFilterChange('customStartDate')}
//                     />
//                   </div>
//                   <div className="Staff_Chart_dropdown-item">
//                     <input
//                       type="date"
//                       className="Staff_Chart_date-input"
//                       value={filters.customEndDate}
//                       onChange={handleFilterChange('customEndDate')}
//                     />
//                   </div>
//                 </>
//               )}
//               <div className="Staff_Chart_dropdown-item">
//                 <select
//                   className="Staff_Chart_select-input"
//                   value={filters.selectedStatus}
//                   onChange={handleFilterChange('selectedStatus')}
//                 >
//                   <option value="">Status</option>
//                   {Object.entries(categoryCounts.statuses).map(([status, count]) => (
//                     <option key={status} value={status}>
//                       {`${status} (${count})`}
//                     </option>
//                   ))}
//                 </select>
//               </div>
//               <div className="Staff_Chart_dropdown-item">
//                 <select
//                   className="Staff_Chart_select-input"
//                   value={filters.selectedRole}
//                   onChange={handleFilterChange('selectedRole')}
//                 >
//                   <option value="">Role</option>
//                   {Object.entries(categoryCounts.roles).map(([role, count]) => (
//                     <option key={role} value={role}>
//                       {`${role} (${count})`}
//                     </option>
//                   ))}
//                 </select>
//               </div>
//               <div className="Staff_Chart_dropdown-item">
//                 <select
//                   className="Staff_Chart_select-input"
//                   value={filters.selectedSession}
//                   onChange={handleFilterChange('selectedSession')}
//                 >
//                   <option value="">Session</option>
//                   {Object.entries(categoryCounts.sessions).map(([session, count]) => (
//                     <option key={session} value={session}>
//                       {`${session} (${count})`}
//                     </option>
//                   ))}
//                 </select>
//               </div>
//             </div>
//           )}
//         </div>
//       </div>
//     </div>
//   );
// };

// export default AttendanceChart;

