import React, { useState } from "react";
import * as XLSX from "xlsx";
import Papa from "papaparse";
import axios from "axios";

const BulkLoad = () => {
  const [file, setFile] = useState(null);
  const [error, setError] = useState(null);

  const handleFileChange = (event) => {
    setFile(event.target.files[0]);
  };

  const parseFile = (file) => {
    const fileExtension = file.name.split(".").pop().toLowerCase();

    if (fileExtension === "xlsx" || fileExtension === "xls") {
      const reader = new FileReader();
      reader.onload = (e) => {
        const workbook = XLSX.read(e.target.result, { type: "binary" });
        const sheetName = workbook.SheetNames[0];
        const data = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName]);
        sendToBackend(data);
      };
      reader.readAsBinaryString(file);
    } else if (fileExtension === "csv") {
      Papa.parse(file, {
        header: true,
        skipEmptyLines: true,
        complete: (results) => {
          sendToBackend(results.data);
        },
        error: (err) => {
          setError("Error parsing CSV file");
        },
      });
    } else {
      setError("Unsupported file format. Please upload an Excel or CSV file.");
    }
  };

  const sendToBackend = async (data) => {
    try {
      const response = await axios.post("http://13.127.57.224:2081/api/BulkLoad", { data });
      if (response.status === 200) {
        alert("Data uploaded successfully!");
      }
    } catch (error) {
      setError("Error uploading data to the backend");
    }
  };

  const handleUpload = () => {
    if (!file) {
      setError("Please select a file first.");
      return;
    }
    parseFile(file);
  };

  return (
    <div>
      <h3>Upload Application Data</h3>
      <input type="file" onChange={handleFileChange} />
      <button onClick={handleUpload}>Upload</button>
      {error && <p style={{ color: "red" }}>{error}</p>}
    </div>
  );
};

export default BulkLoad;
