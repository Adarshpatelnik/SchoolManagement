import React, { useState } from 'react';
import styled from 'styled-components';
import 'bootstrap/dist/css/bootstrap.min.css';


const Container = styled.div`
  width: 100%;
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px;
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
`;

const Card = styled.div`
//   box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
  border-radius: 12px;
  background: #ffffff;
    width: 100%;

  min-height: 800px;
`;





const CardBody = styled.div`
  padding: 20px;
  background-color: #f8f9fa;
  display: flex;
  flex-direction: column;
`;

const FormGroup = styled.div`
  margin-bottom: 1rem;
  flex: 1;
  min-width: 150px;
  margin-right: 20px;
`;

const FormLabel = styled.label`
  font-size: 1rem;
  font-weight: 600;
  color: #2c3e50;
`;

const FormControl = styled.input`
  width: 100%;
  height: 50px;
  font-size: 1rem;
  padding: 0.75rem;
  border: 1px solid #ced4da;
  border-radius: 5px;
  transition: border-color 0.3s ease;

  &:focus {
    border-color: #3498db;
    outline: none;
  }
`;

const Select = styled.select`
  width: 100%;
  height: 50px;
  font-size: 1rem;
  padding: 0.75rem;
  border: 1px solid #ced4da;
  border-radius: 5px;
  transition: border-color 0.3s ease;

  &:focus {
    border-color: #3498db;
    outline: none;
  }
`;

const Button = styled.button`
  background: linear-gradient(to right, #012353, #27AE60);
  color: white;
  border: none;
  padding: 10px 20px;
  font-size: 1.1rem;
  cursor: pointer;
  border-radius: 5px;
  transition: background 0.3s ease;
  margin-right: 10px;

  &:hover {
    background: linear-gradient(to right, #2980b9, #27ae60);
  }
`;

const Row = styled.div`
  display: flex;
  flex-wrap: wrap;
  gap: 5px;
  margin-bottom: 2rem;
`;

// Main Component
const Hiring = () => {
  const [teacher, setTeacher] = useState({
    staffName: '',
    contactNumber: '',
    staffRole: '',
    fatherHusbandName: '',
    gender: '',
    experience: '',
    aadhaarId: '',
    religion: '',
    education: '',
    bloodGroup: '',
    dateOfBirth: '',
    Address: '',
    email: '',
    city: '',
    state: '',
    postalCode: '',
    maritalStatus: '',
    class: '',
    section: '',
    subject: '',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setTeacher((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const requestBody = {
      staff_name: teacher.staffName,
      contact_number: teacher.contactNumber,
      staff_role: teacher.staffRole,
      father_husband_name: teacher.fatherHusbandName,
      gender: teacher.gender,
      experience: teacher.experience,
      adhar_id: teacher.aadhaarId,
      religion: teacher.religion,
      email: teacher.email,
      education: teacher.education,
      blood_group: teacher.bloodGroup,
      date_of_birth: teacher.dateOfBirth,
      address: teacher.homeAddress,
      city: teacher.city,
      state: teacher.state,
      postal_code: teacher.postalCode,
      marital_status: teacher.maritalStatus,
      class: teacher.class,
      section: teacher.section,
      subject: teacher.subject,
    };

    try {
      const response = await fetch('http://localhost:2082/api/staff', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(requestBody),
      });

      if (response.ok) {
        const data = await response.json();
        alert(data.message); // Show success message
        handleReset(); // Reset the form fields
      } else {
        const errorData = await response.json();
        alert(errorData.error || 'Error occurred while adding teacher.');
      }
    } catch (error) {
      console.error('Error:', error);
      alert('Error occurred while adding teacher.');
    }
  };

  const handleReset = () => {
    setTeacher({
      staffName: '',
      contactNumber: '',
      staffRole: '',
      fatherHusbandName: '',
      gender: '',
      experience: '',
      aadhaarId: '',
      religion: '',
      education: '',
      bloodGroup: '',
      dateOfBirth: '',
      Address: '',
      email: '',
      city: '',
      state: '',
      postalCode: '',
      maritalStatus: '',
      class: '',
      section: '',
      subject: '',
    });
  };

  return (
    <Container>
      <Card>
       
        <CardBody>
          <h3>Basic Information</h3>
          <form onSubmit={handleSubmit} style={{ width: '100%' }}>
            <Row>
              <FormGroup style={{ flex: 1 }}>
                <FormLabel>Staff Name</FormLabel>
                <FormControl
                  type="text"
                  name="staffName"
                  value={teacher.staffName}
                  onChange={handleChange}
                  placeholder="Enter Staff Name"
                  required
                />
              </FormGroup>

              <FormGroup style={{ flex: 1 }}>
                <FormLabel>Contact Number</FormLabel>
                <FormControl
                  type="text"
                  name="contactNumber"
                  value={teacher.contactNumber}
                  onChange={handleChange}
                  placeholder="Enter Contact Number"
                  required
                />
              </FormGroup>
              <FormGroup style={{ flex: 1 }}>
                <FormLabel>Staff Role</FormLabel>
                <Select
                  name="staffRole"
                  value={teacher.staffRole}
                  onChange={handleChange}
                  required
                >
                  <option value="">Select Staff Role</option>
                  <option value="TEACHER">TEACHER</option>
                  <option value="PRINCIPAL">PRINCIPAL</option>
                  <option value="ACCOUNTANT">ACCOUNTANT</option>
                  <option value="MANAGEMENT STAFF">MANAGEMENT STAFF</option>
                  <option value="STORE MANAGER">STORE MANAGER</option>
                  <option value="OTHER">OTHER</option>
                </Select>
              </FormGroup>
            </Row>

            <h3>Other Information</h3>

            <Row>
              <FormGroup style={{ flex: 1 }}>
                <FormLabel>Father/Husband Name</FormLabel>
                <FormControl
                  type="text"
                  name="fatherHusbandName"
                  value={teacher.fatherHusbandName}
                  onChange={handleChange}
                  placeholder="Enter Father/Husband Name"
                  required
                />
              </FormGroup>

              <FormGroup style={{ flex: 1 }}>
                <FormLabel>Gender</FormLabel>
                <Select
                  name="gender"
                  value={teacher.gender}
                  onChange={handleChange}
                  required
                >
                  <option value="">Select Gender</option>
                  <option value="MALE">MALE</option>
                  <option value="FEMALE">FEMALE</option>
                </Select>
              </FormGroup>

              <FormGroup style={{ flex: 1 }}>
                <FormLabel>Experience (Years)</FormLabel>
                <FormControl
                  type="number"
                  name="experience"
                  value={teacher.experience}
                  onChange={handleChange}
                  placeholder="Enter Years of Experience"
                  required
                  min="0"
                />
              </FormGroup>
            </Row>

            <Row>
              <FormGroup style={{ flex: 1 }}>
                <FormLabel>Aadhaar ID</FormLabel>
                <FormControl
                  type="text"
                  name="aadhaarId"
                  value={teacher.aadhaarId}
                  onChange={handleChange}
                  placeholder="Enter Aadhaar ID"
                  required
                />
              </FormGroup>

              <FormGroup style={{ flex: 1 }}>
                <FormLabel>Religion</FormLabel>
                <Select
                  name="religion"
                  value={teacher.religion}
                  onChange={handleChange}
                  required
                >
                  
                  <option value="">Select Religion</option>
                  <option value="HINDU">HINDU</option>
                  <option value="MUSLIM">MUSLIM</option>
                  <option value="CHRISTIAN">CHRISTIAN</option>
                  <option value="SIKH">SIKH</option>
                  <option value="BUDDHIST">BUDDHIST</option>
                  <option value="JAIN">JAIN</option>
                </Select>
              </FormGroup>

              <FormGroup style={{ flex: 1 }}>
                <FormLabel>Email</FormLabel>
                <FormControl
                  type="email"
                  name="email"
                  value={teacher.email}
                  onChange={handleChange}
                  placeholder="Enter Email"
                  required
                />
              </FormGroup>
            </Row>

            <Row>
              <FormGroup style={{ flex: 1 }}>
                <FormLabel>Education</FormLabel>
                <FormControl
                  type="text"
                  name="education"
                  value={teacher.education}
                  onChange={handleChange}
                  placeholder="Enter Education"
                  required
                />
              </FormGroup>

              <FormGroup style={{ flex: 1 }}>
                <FormLabel>Blood Group</FormLabel>
                <Select
                  name="bloodGroup"
                  value={teacher.bloodGroup}
                  onChange={handleChange}
                  required
                >
                  <option value="">Select Blood Group</option>
                  <option value="A+">A+</option>
                  <option value="A-">A-</option>
                  <option value="B+">B+</option>
                  <option value="B-">B-</option>
                  <option value="O+">O+</option>
                  <option value="O-">O-</option>
                  <option value="AB+">AB+</option>
                  <option value="AB-">AB-</option>
                </Select>
              </FormGroup>

              <FormGroup style={{ flex: 1 }}>
                <FormLabel>Date of Birth</FormLabel>
                <FormControl
                  type="date"
                  name="dateOfBirth"
                  value={teacher.dateOfBirth}
                  onChange={handleChange}
                  required
                />
              </FormGroup>
            </Row>

            <Row>
              <FormGroup style={{ flex: 1 }}>
                <FormLabel> Address</FormLabel>
                <FormControl
                  type="text"
                  name="Address"
                  value={teacher.homeAddress}
                  onChange={handleChange}
                  placeholder="Enter Home Address"
                  required
                />
              </FormGroup>

              <FormGroup style={{ flex: 1 }}>
                <FormLabel>City</FormLabel>
                <FormControl
                  type="text"
                  name="city"
                  value={teacher.city}
                  onChange={handleChange}
                  placeholder="Enter City"
                  required
                />
              </FormGroup>

              <FormGroup style={{ flex: 1 }}>
                <FormLabel>State</FormLabel>
                <FormControl
                  type="text"
                  name="state"
                  value={teacher.state}
                  onChange={handleChange}
                  placeholder="Enter State"
                  required
                />
              </FormGroup>
            </Row>

            <Row>
              <FormGroup style={{ flex: 1 }}>
                <FormLabel>Postal Code</FormLabel>
                <FormControl
                  type="text"
                  name="postalCode"
                  value={teacher.postalCode}
                  onChange={handleChange}
                  placeholder="Enter Postal Code"
                  required
                />
              </FormGroup>

              <FormGroup style={{ flex: 1 }}>
                <FormLabel>Marital Status</FormLabel>
                <Select
                  name="maritalStatus"
                  value={teacher.maritalStatus}
                  onChange={handleChange}
                  required
                >
                <option value="">Select Marital Status</option>
                <option value="MARRIED">MARRIED</option>
                <option value="UNMARRIED">UNMARRIED</option>
                </Select>
              </FormGroup>
            </Row>

            <h3 style={{ marginTop: '2rem' }}>Optional Information</h3>
           
            <Row>
              <FormGroup style={{ flex: 1 }}>
                <FormLabel>Class</FormLabel>
                <Select
                  name="class"
                  value={teacher.class}
                  onChange={handleChange}
                >
                           
                   <option value="">Select Class</option>
                      <option value="LKG">LKG</option>
                     <option value="UKG">UKG</option>
                  {Array.from({ length: 12 }, (_, i) => (
                <option key={i + 1} value={i + 1}>{`Class ${i + 1}`}</option>
                  ))}
                </Select>
              </FormGroup>

              <FormGroup style={{ flex: 1 }}>
                <FormLabel>Section</FormLabel>
                <Select
                  name="section"
                  value={teacher.section}
                  onChange={handleChange}
                >
                  <option value="">Select Section</option>
                  <option value="A">A</option>
                  <option value="B">B</option>
                  <option value="C">C</option>
                </Select>
              </FormGroup>

              <FormGroup style={{ flex: 1 }}>
                <FormLabel>Subject</FormLabel>
                <FormControl
                  type="text"
                  name="subject"
                  value={teacher.subject}
                  onChange={handleChange}
                  placeholder="Enter Subject"
                />
              </FormGroup>
            </Row>

            <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: '20px' }}>
              <Button type="reset" onClick={handleReset}>Reset</Button>
              <Button type="submit">Submit</Button>
            </div>
          </form>
        </CardBody>
      </Card>
    </Container>
  );
};

export default Hiring;