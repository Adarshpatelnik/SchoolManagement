
import React, { useState, useEffect } from 'react';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import axios from 'axios';
import StudentNavbar from './Student_Navbar.jsx';

const StudentAssignment = () => {
  const [assignments, setAssignments] = useState([]);
  const [selectedAssignments, setSelectedAssignments] = useState([]);
  const [error, setError] = useState(null);
  const [successMessage, setSuccessMessage] = useState('');

  useEffect(() => {
    const fetchAssignments = async () => {
      try {
        console.log('Fetching assignments from API...');
        const response = await fetch(`http://13.127.57.224:2081/api/assignments`);
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}, message: ${response.statusText}`);
        }
        const data = await response.json();
        console.log('Assignments fetched successfully:', data);
        setAssignments(data);
      } catch (error) {
        console.error('Error fetching assignments:', error);
        setError(`Failed to fetch assignments: ${error.message}`);
      }
    };

    fetchAssignments();
  }, []);

  const handleSubmit = async () => {
    if (selectedAssignments.length === 0) {
      setError('Please select at least one assignment.');
      return;
    }

    setSuccessMessage('Submitted successfully');
    setTimeout(() => {
      setSuccessMessage('');
    }, 3000);

    try {
      const assignmentsToSubmit = selectedAssignments.map(assignment => ({
        assignmentId: assignment.ASSIGNMENT_ID,
        studentId: assignment.STUDENT_ID,
      }));

      console.log('Submitting selected assignments:', assignmentsToSubmit);

      const response = await axios.post('http://13.127.57.224:2081/api/submit-assignment', assignmentsToSubmit);
      console.log('Response from server:', response.data);
    } catch (error) {
      console.error('Error submitting assignments:', error);
      setError('Error submitting assignments');
    }
  };

  const columnDefs = [
    { headerCheckboxSelection: true, checkboxSelection: true, headerName: 'Select', width: 80 },
    { field: 'STUDENT_ID', headerName: 'Student ID', sortable: true, filter: true },
    { field: 'ASSIGNMENT_ID', headerName: 'Assignment ID', sortable: true, filter: true },
    { field: 'SUBJECT_NAME', headerName: 'Subject Name', sortable: true, filter: true },
    { field: 'ASSIGNMENT_DESC', headerName: 'Assignment Description', sortable: true, filter: true },
    {
      field: 'SUBMISSION_START_DATE',
      headerName: 'Submission Start Date',
      sortable: true,
      filter: true,
      valueFormatter: ({ value }) => new Date(value).toLocaleDateString(),
    },
    {
      field: 'SUBMISSION_END_DATE',
      headerName: 'Submission End Date',
      sortable: true,
      filter: true,
      valueFormatter: ({ value }) => new Date(value).toLocaleDateString(),
    },
  ];

  const onSelectionChanged = (event) => {
    const selectedRows = event.api.getSelectedRows();
    console.log('Selected assignments:', selectedRows);
    setSelectedAssignments(selectedRows);
  };

  return (
    <>
      <StudentNavbar />
      <div style={styles.assignmentDashboard}>
        {error && <p style={{ color: 'red' }}>{error}</p>}
        {successMessage && <p style={{ color: 'green', marginTop: '20px' }}>{successMessage}</p>}

        <div className="ag-theme-alpine" style={styles.gridContainer}>
          <AgGridReact
            rowData={assignments}
            columnDefs={columnDefs}
            rowSelection="multiple"
            onSelectionChanged={onSelectionChanged}
            defaultColDef={{ resizable: true, sortable: true, filter: true }}
          />
        </div>
        <button onClick={handleSubmit} style={styles.submitButton}>
          Submit
        </button>
      </div>
    </>
  );
};

const styles = {
  assignmentDashboard: {
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'center',
    height: '100vh', // Full viewport height
    padding: '10px',
  },
  gridContainer: {
    height: '400px',
    width: '100%',
    marginBottom: '20px',
  },
  submitButton: {
    padding: '10px 20px',
    backgroundColor: '#4CAF50',
    color: 'white',
    border: 'none',
    cursor: 'pointer',
    borderRadius: '5px',
  },
};

export default StudentAssignment;
