

import React from 'react';
import styled from 'styled-components';
import StudentPerformance from './Student_performance_Chart.jsx';
import StudentEventCalendar from './Student_eventcalendar.jsx';
import StudentAttendanceDashbord from './Student_Attendance_Dashbord.jsx';
import StudentTimeTableschedule from './Student_TimeTable_schedule.jsx';
import StudentNoticeBoard from './Student_Notice_Board.jsx';

import StudentNavbar from './Student_Navbar.jsx';
import { FaChartLine, FaCalendarAlt, FaClipboardList } from 'react-icons/fa'; // Import icons for the cards

// Styled components
const Container = styled.div`
  padding-top: 20px;
  min-height: 100vh;
  padding: 0 20px;
  max-width: 100%;
  margin: 0 auto;
  background-color: #F0F6FA;

  @media (max-width: 1200px) {
    max-width: 1000px;
  }
  @media (max-width: 992px) {
    max-width: 800px;
  }
  @media (max-width: 768px) {
    padding: 0 10px;
  }
  @media (max-width: 576px) {
    padding: 0 5px;
  }
`;

const Card = styled.div`
  background-color: #ffffff;
  padding: 0px;
  margin-bottom: 15%;
  min-height: 0;
  display: flex;
  flex-direction: column;
  justify-content: space-between;


  @media (max-width: 768px) {
    padding: 15px;
    min-height: 250px;
  }
`;





const Heading = styled.h3`
  font-size: 1.2rem;
  font-weight: 600;
  font-family: 'Lato', sans-serif;
  color: #333;
  margin-bottom: 20px;
  padding: 10px;
  letter-spacing: 1px;
  display: inline-block;
  background: linear-gradient(135deg, #f0f0f0, #e0e0e0);
  border-bottom: 2px solid #b0b0b0;
  transition: transform 0.3s ease, box-shadow 0.3s ease, background 0.3s ease;

  @media (max-width: 400px) {
    font-size: 1.1rem;
    padding: 8px 16px;
  }
`;

const StudentDashboard = () => {
  return (
    <>
      <StudentNavbar />
      <Container className="container-fluid" style={{ marginTop: '12vh', width: '97%', padding: 0 }}>
        <div className="row">
          <div className="col-lg-4" style={{ padding: '0 2px' }}>
            <Card style={{ height: '45vh' }}>
              <Heading>My Attendance</Heading>
              <StudentAttendanceDashbord />
            </Card>
          </div>
          <div className="col-lg-4" style={{ padding: '0 2px' }}>
            <Card style={{ height: '47vh' }}>
              <Heading>Event Calendar</Heading>
              <StudentEventCalendar />
            </Card>
          </div>
          <div className="col-lg-4" style={{ padding: '0 2px' }}>
            <Card style={{ height: '47vh' }}>
              <Heading>Performance Chart</Heading>
              <StudentPerformance />
            </Card>
          </div>
        </div>

        <div className="row" style={{ marginTop: '-7vh' }}>
          <div className="col-lg-8">
            <Card style={{ height: '58vh' }}>
            <Heading>Time Table Schedule</Heading>

              <StudentTimeTableschedule />
            </Card>
          </div>

          <div className="col-lg-4">
            <Card style={{ height: '58vh' }}>
            <Heading>Notice Board</Heading>

              <StudentNoticeBoard />
            </Card>
          </div>
        </div>
      </Container>
    </>
  );
};

export default StudentDashboard;
