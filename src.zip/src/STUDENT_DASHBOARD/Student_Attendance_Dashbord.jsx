

import React, { useState, useEffect } from "react";
import axios from "axios";
import { PieChart, Pie, Cell, Tooltip, Legend, ResponsiveContainer } from "recharts";
import styled from "styled-components";

const COLORS = ["#3498DB", "#F4D03F", "#58D68D", "#E74C3C"];
const SKYBLUE = "#87CEEB";
const WHITE = "#FFFFFF";
const DARKBLUE = "#1E2A78";

const Container = styled.div`
  padding: 6px;
  background-color: ${WHITE};
  border-radius: 10px;
  box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
`;

const FilterContainer = styled.div`
  display: flex;
  gap: 20px;
  margin-top: -4vh;
  margin-bottom: 0px;
`;

const Filter = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  flex: 1;
`;

const Label = styled.label`
  margin-bottom: 5px;
  font-weight: bold;
  color: ${DARKBLUE};
`;

const Select = styled.select`
  border: 1px solid ${SKYBLUE};
  border-radius: 5px;
  padding: 6px;
  font-size: 14px;
  width: 100%;
  background-color: ${WHITE};
`;

const DateInput = styled.input`
  border: 1px solid ${SKYBLUE};
  border-radius: 5px;
  padding: 6px;
  font-size: 14px;
  width: 100%;
  background-color: ${WHITE};
`;

const CenterText = styled.div`
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  font-size: 24px;
  font-weight: bold;
  color: ${DARKBLUE};
`;

const PieChartContainer = styled.div`
  position: relative;
  display: inline-block;
`;

const StudentAttendanceDashboard = () => {
  const [attendanceData, setAttendanceData] = useState([]);
  const [filteredData, setFilteredData] = useState([]);
  const [classes, setClasses] = useState([]);
  const [selectedClass, setSelectedClass] = useState("");
  const [selectedDateOption, setSelectedDateOption] = useState("");
  const [customDate, setCustomDate] = useState("");

  useEffect(() => {
    const fetchAttendanceData = async () => {
      try {
        const response = await axios.get(
          "http://13.127.57.224:2081/api/dashboradstudentattendance"
        );
        const data = response.data.map((record) => ({
          ...record,
          DATE: new Date(record.DATE).toLocaleDateString("en-GB"), // Format date to dd-mm-yyyy
          attendance_percentage: record.attendance_percentage || 0,
        }));
        setAttendanceData(data);

        const uniqueClasses = [...new Set(data.map((record) => record.CLASS))];
        setClasses(uniqueClasses);
      } catch (error) {
        console.error("Error fetching student attendance data:", error);
      }
    };

    fetchAttendanceData();
  }, []);

  useEffect(() => {
    let filtered = attendanceData;

    if (selectedClass) {
      filtered = filtered.filter((record) => record.CLASS === selectedClass);
    }

    // Filter based on selected date option
    if (selectedDateOption === "Today") {
      const today = new Date().toLocaleDateString("en-GB");
      filtered = filtered.filter((record) => record.DATE === today);
    } else if (selectedDateOption === "Yesterday") {
      const yesterday = new Date();
      yesterday.setDate(yesterday.getDate() - 1);
      const formattedYesterday = yesterday.toLocaleDateString("en-GB");
      filtered = filtered.filter((record) => record.DATE === formattedYesterday);
    } else if (selectedDateOption === "Custom Date" && customDate) {
      filtered = filtered.filter((record) => record.DATE === customDate);
    }

    setFilteredData(filtered);
  }, [selectedClass, selectedDateOption, customDate, attendanceData]);

  const processData = (data) => {
    const statusCount = data.reduce((acc, record) => {
      if (record.STATUS) { // Exclude null or invalid STATUS
        acc[record.STATUS] = (acc[record.STATUS] || 0) + 1;
      }
      return acc;
    }, {});

    return Object.entries(statusCount).map(([key, value]) => ({
      name: key,
      value,
    }));
  };

  const calculateAttendancePercentage = () => {
    if (filteredData.length === 0) return 0;

    const total = filteredData.length;
    const present = filteredData.filter(
      (record) => record.STATUS === "PRESENT"
    ).length;
    return Math.round((present / total) * 100);
  };

  const attendancePercentage = calculateAttendancePercentage();

  return (
    <Container>
      <FilterContainer>
        <Filter>
          <Label htmlFor="classFilter"></Label>
          <Select
            id="classFilter"
            value={selectedClass}
            onChange={(e) => setSelectedClass(e.target.value)}
          >
            <option value="">Select Class</option>
            {classes.map((cls, index) => (
              <option key={index} value={cls}>
                {cls}
              </option>
            ))}
          </Select>
        </Filter>
        <Filter>
          <Label htmlFor="dateFilter"></Label>
          <Select
            id="dateFilter"
            value={selectedDateOption}
            onChange={(e) => setSelectedDateOption(e.target.value)}
          >
            <option value="">Select Date</option>
            <option value="Today">Today</option>
            <option value="Yesterday">Yesterday</option>
            <option value="Custom Date">Custom Date</option>
          </Select>
          {selectedDateOption === "Custom Date" && (
            <DateInput
              type="date"
              value={customDate}
              onChange={(e) => setCustomDate(new Date(e.target.value).toLocaleDateString("en-GB"))}
            />
          )}
        </Filter>
      </FilterContainer>
      <PieChartContainer>
        <ResponsiveContainer width={400} height={230}>
          <PieChart>
            <Pie
              data={processData(filteredData)}
              dataKey="value"
              outerRadius={90}
              innerRadius={60}
              paddingAngle={5}
            >
              {processData(filteredData).map((entry, index) => (
                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
              ))}
            </Pie>
            <Tooltip />
            <Legend />
          </PieChart>
        </ResponsiveContainer>
        <CenterText>{attendancePercentage}%</CenterText>
      </PieChartContainer>
    </Container>
  );
};

export default StudentAttendanceDashboard;
