
import React, { useState, useContext } from 'react';
import { Navbar, Nav, Modal, Button } from 'react-bootstrap';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { FaPowerOff } from 'react-icons/fa';
import { FiClipboard } from 'react-icons/fi';
import { AuthContext } from '../SECURITY_OTHERS/AuthContext';

const StudentNavbar = () => {
    const [showLogoutModal, setShowLogoutModal] = useState(false);
    const navigate = useNavigate(); // For navigation after logout
    const location = useLocation(); // Get the current route
    const { logout } = useContext(AuthContext);
    const handleLogoutClick = () => {
        setShowLogoutModal(true); // Show the logout confirmation modal
    };

    const handleConfirmLogout = () => {
        setShowLogoutModal(false); // Close the modal
        navigate('/Login'); // Navigate to the Login page after logout
    };
    const confirmLogout = () => {
        logout(); // Call logout function from AuthContext
        setShowModal(false); // Close the modal
        navigate('/Login'); // Navigate to login page
      };
    const handleCancelLogout = () => {
        setShowLogoutModal(false); // Close the modal without logging out
    };

    const navbarStyle = {
        backgroundImage: "url('/background.avif')", // Replace with your image path
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        padding: '10px 20px',
        position: 'fixed',
        top: 0,
        left: 0,
        width: '100%',
        zIndex: 1000,
        boxShadow: '0 8px 9px rgba(0, 0, 0, 0.1)',

    };

    const navLinkStyle = (isActive) => ({
        margin: '0 15px',
        color: isActive ? '#012353' : 'black',
        fontWeight: isActive ? '600' : '500',
        textDecoration: 'none',
        transition: 'color 0.3s',
        borderBottom: isActive ? '2px solid #012353' : 'none',
        paddingBottom: isActive ? '3px' : '0',
    });

    const logoutStyle = {
        color: '#dc3545',
        fontWeight: 'bold',
        textDecoration: 'none',
        display: 'flex',
        alignItems: 'center',
        cursor: 'pointer',
    };

    return (
        <>
            <Navbar style={navbarStyle} expand="lg">
                <img 
                    src="02 1.jpg" 
                    alt="B2B360 Logo" 
                    style={{ 
                        width: '2rem', 
                        height: '2rem', 
                        marginRight: '0.5rem' 
                    }} 
                />
                <span
                    style={{
                        fontFamily: 'Playfair Display, serif',
                        fontSize: '1.5em',
                        fontWeight: 'bold',
                        backgroundImage: 'linear-gradient(to right, white, white)',
                        WebkitBackgroundClip: 'text',
                        WebkitTextFillColor: 'transparent',
                    }}
                >
                    EDU<span style={{ color: 'white' }}>3</span>6<span style={{ color: 'white' }}>0</span>
                </span>
                <Navbar.Toggle aria-controls="basic-navbar-nav" />
                <Navbar.Collapse id="basic-navbar-nav" className="justify-content-end">
                    <Nav className="d-flex justify-content-end">
                        <Nav.Link
                            as={Link}
                            to="/Student_Dashboard"
                            style={navLinkStyle(location.pathname === '/Student_Dashboard')}
                        >
                            Home
                        </Nav.Link>
                        <Nav.Link
                            as={Link}
                            to="/Student_Assignment"
                            style={navLinkStyle(location.pathname === '/Student_Assignment')}
                        >
                            Assignments
                        </Nav.Link>
                        <Nav.Link
                            as={Link}
                            to="/Edit_Form"
                            style={navLinkStyle(location.pathname === '/Edit_Form')}
                        >
                            <FiClipboard style={{ marginRight: '5px' }} />
                            Issue Board
                        </Nav.Link>
                        <Nav.Link onClick={handleLogoutClick} style={logoutStyle}>
                            <FaPowerOff style={{ marginRight: '5px' }} />
                            Logout
                        </Nav.Link>
                    </Nav>
                </Navbar.Collapse>
            </Navbar>

            {/* Logout Confirmation Modal */}
            <Modal show={showLogoutModal} onHide={handleCancelLogout} centered>
                <Modal.Header closeButton>
                    <Modal.Title>Confirm Logout</Modal.Title>
                </Modal.Header>
                <Modal.Body>Are you sure you want to log out?</Modal.Body>
                <Modal.Footer>
                    <Button variant="secondary" onClick={handleCancelLogout}>
                        No
                    </Button>
                    <Button variant="danger" onClick={confirmLogout}>
                        Yes
                    </Button>
                </Modal.Footer>
            </Modal>
        </>
    );
};

export default StudentNavbar;
