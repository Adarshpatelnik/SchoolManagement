
import React, { useEffect, useState, useCallback, useMemo } from "react";
import axios from "axios";
import './Student_Dashboard.css';

const StudentNoticeBoard = () => {
  const [notices, setNotices] = useState([]);
  const [downloadingStates, setDownloadingStates] = useState({});

  useEffect(() => {
    const fetchNotices = async () => {
      try {
        const response = await axios.get("http://13.127.57.224:2081/api/noticeboard");
        const sortedNotices = response.data.sort((a, b) => new Date(b.START_DATE) - new Date(a.START_DATE));
        setNotices(sortedNotices);
      } catch (error) {
        console.error("Error fetching notices:", error);
      }
    };

    fetchNotices();
  }, []);

  const colors = useMemo(() => ["#ff69b4", "#20c997", "#f9c74f"], []);

  const timeAgo = useCallback((date) => {
    const currentTime = new Date();
    const noticeTime = new Date(date);
    const diffInMs = currentTime - noticeTime;
    const diffInMinutes = Math.floor(diffInMs / 60000);

    if (diffInMinutes < 1) return "Just now";
    if (diffInMinutes < 60) return `${diffInMinutes} minutes ago`;
    if (diffInMinutes < 1440) return `${Math.floor(diffInMinutes / 60)} hours ago`;
    return `${Math.floor(diffInMinutes / 1440)} days ago`;
  }, []);

  const updateDownloadingState = (index, state) => {
    setDownloadingStates((prev) => ({ ...prev, [index]: state }));
  };

  const handleDownload = async (event, fileUrl, index) => {
    event.preventDefault();
    updateDownloadingState(index, 'downloading');

    try {
      const filename = fileUrl.split('/').pop();
      const response = await axios.get(`http://13.127.57.224:2081/api/downloadnotice/${filename}`, { responseType: 'blob' });

      if (response.status !== 200) throw new Error(`HTTP error! status: ${response.status}`);
      
      const blob = new Blob([response.data], { type: response.headers['content-type'] });
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', filename);
      document.body.appendChild(link);
      link.click();
      link.parentNode.removeChild(link);
      window.URL.revokeObjectURL(url);

      updateDownloadingState(index, 'completed');
    } catch (error) {
      console.error("Error downloading file:", error);
      updateDownloadingState(index, 'error');
      alert(`Download failed: ${error.message}`);
    } finally {
      setTimeout(() => {
        setDownloadingStates((prev) => {
          const newState = { ...prev };
          delete newState[index];
          return newState;
        });
      }, 2000);
    }
  };

  const capitalizeDescription = (description) => {
    return description
      .toLowerCase()
      .replace(/^[a-z]/, (letter) => letter.toUpperCase())
      .replace(/\bdow\s+[a-z]/g, (match) => {
        return match.slice(0, -1) + match.slice(-1).toUpperCase();
      });
  };

  return (
    <div className="notice-container">
      <div className="notices">
        {notices.map((notice, index) => {
          const { START_DATE, DESCRIPTION, file_url } = notice;
          return (
            <div key={index} className="notice" style={{ borderBottom: index !== notices.length - 1 ? "1px solid #ddd" : "none" }}>
              <div className="notice-date" style={{ backgroundColor: colors[index % colors.length] }}>
                {new Date(START_DATE).toLocaleDateString("en-GB", { day: "2-digit", month: "long", year: "numeric" })}
              </div>
              <p className="notice-description">{capitalizeDescription(DESCRIPTION)}</p>
              <p className="notice-time">{timeAgo(START_DATE)}</p>
              {file_url && (
                <div className="notice-file-actions">
                  <a href={file_url} className="notice-fileurl" target="_blank" rel="noopener noreferrer" onClick={(e) => { e.preventDefault(); window.open(file_url, '_blank'); }}>
                    View
                  </a>
                  {' / '}
                  <a href="#" className={`notice-download ${downloadingStates[index] ? 'downloading' : ''}`} onClick={(e) => handleDownload(e, file_url, index)}>
                    {downloadingStates[index] === 'downloading' ? 'Downloading...' : downloadingStates[index] === 'completed' ? 'Downloaded!' : downloadingStates[index] === 'error' ? 'Error' : 'Download'}
                  </a>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default StudentNoticeBoard;
