// // import React, { useState, useContext, useEffect } from 'react';
// // import { Link, useNavigate } from 'react-router-dom';
// // import axios from 'axios';
// // import styled, { keyframes } from 'styled-components';
// // import { FiMail, FiLock, FiUser } from 'react-icons/fi';
// // import Validation from './LoginValidation';
// // import { AuthContext } from './AuthContext';

// // const fadeIn = keyframes`
// //   from {
// //     opacity: 0;
// //   }
// //   to {
// //     opacity: 1;
// //   }
// // `;

// // const LoginContainer = styled.div`
// //   display: flex;
// //   justify-content: center;
// //   align-items: center;
// //   height: 100vh;
// //   background: url('laibray.png') no-repeat center center fixed; 
// //   background-size: cover;
// //   animation: ${fadeIn} 1s ease-in;
// // `;

// // const FormWrapper = styled.div`
// //   background-color: rgba(255, 255, 255, 0.9);
// //   padding: 40px;
// //   border-radius: 15px;
// //   box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
// //   max-width: 400px;
// //   width: 100%;
// //   text-align: center;
// //   transition: transform 0.3s ease, box-shadow 0.3s ease;

// //   &:hover {
// //     transform: translateY(-5px);
// //     box-shadow: 0 15px 35px rgba(0, 0, 0, 0.2);
// //   }
// // `;

// // const LogoContainer = styled.div`
// //   display: flex;
// //   justify-content: center;
// //   align-items: center;
// //   margin-bottom: 30px;
// // `;

// // const LogoImage = styled.img`
// //   width: 40px; /* Increased size for better visibility */
// //   margin-right: 7px;
// // `;

// // const LogoText = styled.span`
// //   font-size: 26px; /* Slightly increased font size */
// //   font-weight: bold;
// //   background: linear-gradient(to right, #012353, #27ae60);
// //   -webkit-background-clip: text;
// //   -webkit-text-fill-color: transparent;
// //   font-family: 'Playfair Display', serif;
// // `;

// // const Form = styled.form`
// //   width: 100%;
// // `;

// // const InputWrapper = styled.div`
// //   position: relative;
// //   margin-bottom: 25px;
// // `;

// // const IconWrapper = styled.span`
// //   position: absolute;
// //   top: 50%;
// //   left: 15px;
// //   transform: translateY(-50%);
// //   color: #999;
// // `;

// // const IconWrapperSelect = styled(IconWrapper)`
// //   left: 15px;
// // `;

// // const Input = styled.input`
// //   width: 100%;
// //   padding: 12px 45px;
// //   border: 2px solid #ccc;
// //   border-radius: 25px;
// //   font-size: 16px;
// //   box-sizing: border-box;
// //   transition: border-color 0.3s ease;

// //   &:focus {
// //     border-color: #2980b9;
// //     outline: none;
// //   }
// // `;

// // const Select = styled.select`
// //   width: 100%;
// //   padding: 12px 45px;
// //   border: 2px solid #ccc;
// //   border-radius: 25px;
// //   font-size: 16px;
// //   transition: border-color 0.3s ease;

// //   &:focus {
// //     border-color: #2980b9;
// //     outline: none;
// //   }
// // `;

// // const Button = styled.button`
// //   width: 100%;
// //   padding: 15px;
// //   background: linear-gradient(to right, #012353, #27ae60);
// //   color: white;
// //   border: none;
// //   border-radius: 25px;
// //   cursor: pointer;
// //   font-size: 18px;
// //   transition: background 0.3s ease, transform 0.3s ease;

// //   &:hover {
// //     background: linear-gradient(to right, #012353, #27ae60);
// //     transform: translateY(-2px);
// //   }
// // `;

// // const Message = styled.p`
// //   color: red;
// //   font-size: 14px;
// //   text-align: left;
// //   margin-top: -10px;
// //   margin-bottom: 10px;
// // `;

// // const LinkStyled = styled(Link)`
// //   display: block;
// //   text-align: center;
// //   margin-top: 20px;
// //   color: Black;
// //   text-decoration: none;
// //   font-size: 16px;

// //   span {
// //     text-decoration: none;
// //     color: blue; /* Make sure the color is inherited */
// //   }

// //   &:hover span {
// //     text-decoration: underline;
// //   }
// // `;

// // const SubHeading = styled.h3`
// //   font-size: 18px;
// //   color: #555;
// //   margin-bottom: 30px;
// // `;

// // function Login() {
// //   const { isAuthenticated, login, logout } = useContext(AuthContext);
// //   const [values, setValues] = useState({
// //     UserName: '',
// //     Password: '',
// //     Role: 'administrator'
// //   });
// //   const [errors, setErrors] = useState({});
// //   const [serverError, setServerError] = useState('');
// //   const navigate = useNavigate();

// //   useEffect(() => {
// //     if (isAuthenticated) {
// //       logout(); // Log out if already authenticated when navigating to login page
// //     }
// //    // throw new Error("Testing ErrorBoundary in Login component");
// //   }, [isAuthenticated, logout]);

// //   const handleInput = (event) => {
// //     const { name, value } = event.target;
// //     setValues((prevValues) => ({
// //       ...prevValues,
// //       [name]: value
// //     }));
// //   };

// //   const handleSubmit = async (event) => {
// //     event.preventDefault();
// //     const validationErrors = Validation(values);
// //     setErrors(validationErrors);
// //     setServerError(''); // Reset server error message

// //     if (Object.keys(validationErrors).length === 0) {
// //       try {
// //         const response = await axios.post('http://13.127.57.224:2081/login', values);
// //         console.log(response);
// //         if (response.status === 200) {
// //           login(); // Call login function from AuthContext to set isAuthenticated to true
// //           switch (values.Role) {
// //             case 'administrator':
// //               navigate('/DashBoard');
// //               break;
// //             case 'admin':
// //               navigate('/DashBoard');
// //               break;
// //             case 'staff':
// //               navigate('/Staff_Dashbord');
// //               break;
// //             case 'student':
// //               navigate('/Student_Dashboard');
// //               break;
// //             // default:
// //             //   navigate('/');
// //             //   break;
// //           }
// //         } else {
// //           setServerError('Authentication failed: ' + response.data.message);
// //         }
// //       }  catch (error) {
// //         if (error.response) {
// //           if (error.response.status === 401) {
// //             setServerError('Password does not match');
// //           } else if (error.response.status === 404) {
// //             setServerError('UserID or Role does not match');
// //           }  
// //         } else {
// //           setServerError('Error: ' + error.message);
// //         }
// //       }
// //     }
// //   };

// //   return (
// //     <LoginContainer>
// //       <FormWrapper>
// //         <Link to="/" style={{ textDecoration: "none" }}>
// //           <LogoContainer>
// //             <LogoImage src="02 1.jpg" alt="Logo" />
// //             <LogoText>EDU360</LogoText>
// //           </LogoContainer>
// //         </Link>

// //         <SubHeading>Login To Your Account</SubHeading>
// //         <Form onSubmit={handleSubmit}>
// //         {serverError && <Message>{serverError}</Message>}
// //           <InputWrapper>
// //             <IconWrapper><FiMail /></IconWrapper>
// //             {errors.UserName && <Message>{errors.UserName}</Message>}
// //             <Input
// //               type='text'
// //               placeholder='Enter UserName'
// //               name='UserName'
// //               onChange={handleInput}
// //               value={values.UserName}
// //             />
             
// //           </InputWrapper>
// //           <InputWrapper>
// //             <IconWrapper><FiLock /></IconWrapper>
// //             {errors.Password && <Message>{errors.Password}</Message>}
// //             <Input
// //               type='password'
// //               placeholder='Enter Password'
// //               name='Password'
// //               onChange={handleInput}
// //               value={values.Password}
// //             />
            
// //           </InputWrapper>
// //           <InputWrapper>
// //             <IconWrapperSelect><FiUser /></IconWrapperSelect>
// //             <Select
// //               name='Role'
// //               onChange={handleInput}
// //               value={values.Role}
// //             >
// //               <option value='administrator'>ADMINISTRATOR</option>
// //               <option value='admin'>ADMIN</option>
// //               <option value='staff'>STAFF</option>
// //               <option value='student'>STUDENT</option>
// //             </Select>
// //           </InputWrapper>
// //           <Button type="submit">Login</Button>
           
// //           <LinkStyled to='/signup'>Don't have an account ? <span>Signup</span></LinkStyled>
// //         </Form>
// //       </FormWrapper>
// //     </LoginContainer>
// //   );
// // }

// // export default Login;









// // import React, { useState, useContext, useEffect } from 'react';
// // import { Link, useNavigate } from 'react-router-dom';
// // import axios from 'axios';
// // import { FiMail, FiLock, FiUser, FiEye, FiEyeOff} from 'react-icons/fi';
// // import Validation from './LoginValidation';
// // import { AuthContext } from './AuthContext';
// // import './Security.css'
 
// // function Login() {
// //   const { isAuthenticated, login, logout } = useContext(AuthContext);
// //   const [values, setValues] = useState({
// //     UserName: '',
// //     Password: '',
// //     Role: 'administrator'
// //   });
 
// //   // For Eye icon in password
// //   const [showPassword, setShowPassword] = useState(false);
 
// //   const togglePasswordVisibility = () => {
// //     setShowPassword(prevState => !prevState);
// //   };
 
// //   const [errors, setErrors] = useState({});
// //   const [serverError, setServerError] = useState('');
// //   const navigate = useNavigate();
 
// //   useEffect(() => {
// //     if (isAuthenticated) {
// //       logout(); // Log out if already authenticated when navigating to login page
// //     }
// //   }, [isAuthenticated, logout]);
 
// //   const handleInput = (event) => {
// //     const { name, value } = event.target;
// //     setValues((prevValues) => ({
// //       ...prevValues,
// //       [name]: value
// //     }));
// //   };
 
 
// //   const handleSubmit = async (event) => {
// //     event.preventDefault();
// //     const validationErrors = Validation(values);
// //     setErrors(validationErrors);
// //     setServerError(''); // Reset server error message
 
// //     if (Object.keys(validationErrors).length === 0) {
// //       try {
// //         const response = await axios.post('http://13.127.57.224:2081/login', values);
// //         console.log(response);
// //         if (response.status === 200) {
// //           login(); // Call login function from AuthContext to set isAuthenticated to true
// //           switch (values.Role) {
// //             case 'administrator':
// //             case 'admin':
// //               navigate('/DashBoard');
// //               break;
// //             case 'staff':
// //               navigate('/Staff_Dashbord');
// //               break;
// //             case 'student':
// //               navigate('/Student_Dashboard');
// //               break;
// //             default:
// //               navigate('/');
// //               break;
// //           }
// //         } else {
// //           setServerError('Authentication failed: ' + response.data.message);
// //         }
// //       } catch (error) {
// //         if (error.response) {
// //           if (error.response.status === 401) {
// //             setServerError('Password does not match');
// //           } else if (error.response.status === 404) {
// //             setServerError('UserID or Role does not match');
// //           }
// //         } else {
// //           setServerError('Error: ' + error.message);
// //         }
// //       }
// //     }
// //   };
 
 
// //   return (
// //     <div className="LoginContainer">
// //       <div className="FormWrapper">
// //         <Link to="/" style={{ textDecoration: "none" }}>
// //           <div className="LogoContainer">
// //             <img src="02 1.jpg" alt="Logo" className="LogoImage" />
// //             <span className="LogoText">EDU360</span>
// //           </div>
// //         </Link>
 
// //         <h4 className="SubHeading">Login To Your Account</h4>
// //         <form onSubmit={handleSubmit} className="Form">
// //           {serverError && <p className="Message">{serverError}</p>}
// //           <div className="InputWrapper">
// //             <span className="IconWrapper"><FiMail /></span>
// //             {errors.UserName && <p className="Message">{errors.UserName}</p>}
// //             <input
// //               type='text'
// //               placeholder='Enter UserName'
// //               name='UserName'
// //               onChange={handleInput}
// //               value={values.UserName}
// //               className="Input"
// //             />
// //           </div>
// //           <div className="InputWrapper">
// //       <span className="IconWrapper"><FiLock /></span>
// //       {errors.Password && <p className="Message">{errors.Password}</p>}
// //       <input
// //         type={showPassword ? 'text' : 'password'}
// //         placeholder='Enter Password'
// //         name='Password'
// //         onChange={handleInput}
// //         value={values.Password}
// //         className="Input"
// //       />
// //       <span className="IconWrapperEye" onClick={togglePasswordVisibility}>
// //         {showPassword ? <FiEyeOff /> : <FiEye />}
// //       </span>
// //     </div>
// //           <div className="InputWrapper">
// //             <span className="IconWrapperSelect"><FiUser /></span>
// //             <select
// //               name='Role'
// //               onChange={handleInput}
// //               value={values.Role}
// //               className="Login_Select"
// //             >
// //               <option value='administrator'>ADMINISTRATOR</option>
// //               <option value='admin'>ADMIN</option>
// //               <option value='staff'>STAFF</option>
// //               <option value='student'>STUDENT</option>
// //             </select>
// //           </div>
// //           <button type="submit" className="Login_Button">Login</button>
// //           <Link to='/signup' className="LinkStyled">Don't have an account? <span>Signup</span></Link>
// //         </form>
// //       </div>
// //     </div>
// //   );
// // }
 
// // export default Login;
 







// import React, { useState, useContext, useEffect } from 'react';
// import { Link, useNavigate } from 'react-router-dom';
// import axios from 'axios';
// import { FiMail, FiLock, FiUser, FiEye, FiEyeOff} from 'react-icons/fi';
// import Validation from './LoginValidation';
// import { AuthContext } from './AuthContext';
// import './Security.css'
 
// function Login() {
//   const { isAuthenticated, login, logout } = useContext(AuthContext);
//   const [values, setValues] = useState({
//     UserName: '',
//     Password: '',
//     Role: 'administrator'
//   });
 
//   // For Eye icon in password
//   const [showPassword, setShowPassword] = useState(false);
 
//   const togglePasswordVisibility = () => {
//     setShowPassword(prevState => !prevState);
//   };
 
//   const [errors, setErrors] = useState({});
//   const [serverError, setServerError] = useState('');
//   const navigate = useNavigate();
 
//   useEffect(() => {
//     if (isAuthenticated) {
//       logout(); // Log out if already authenticated when navigating to login page
//     }
//   }, [isAuthenticated, logout]);
 
//   const handleInput = (event) => {
//     const { name, value } = event.target;
//     setValues((prevValues) => ({
//       ...prevValues,
//       [name]: value
//     }));
//   };
 
 
//   const handleSubmit = async (event) => {
//     event.preventDefault();
//     const validationErrors = Validation(values);
//     setErrors(validationErrors);
//     setServerError(''); // Reset server error message
 
//     if (Object.keys(validationErrors).length === 0) {
//       try {
//         let apiUrl = 'http://13.127.57.224:2081/login'; // Default API for other roles
  
//         // Check for developer role and use the dev login API if applicable
//         if (values.Role === 'developer') {
//           apiUrl = 'http://13.127.57.224:2081/logindev';
//         }
  
//         const response = await axios.post(apiUrl, values);
//         console.log(response);
  
//         if (response.status === 200) {
//           login(); // Call login function from AuthContext to set isAuthenticated to true
//           switch (values.Role) {
//             case 'administrator':
//               navigate('/DashBoard');
//               break;
//             case 'admin':
//               navigate('/DashBoard');
//               break;
//             case 'staff':
//               navigate('/Staff_Dashbord');
//               break;
//             case 'student':
//               navigate('/Student_Dashboard');
//               break;
//             case 'developer':
//               navigate('/DeveloperDashboard'); 
//             default:
//               navigate('/');
//               break;
//           }
//         } else {
//           setServerError('Authentication failed: ' + response.data.message);
//         }
//       } catch (error) {
//         if (error.response) {
//           if (error.response.status === 401) {
//             setServerError('Password does not match');
//           } else if (error.response.status === 404) {
//             setServerError('UserID or Role does not match');
//           }
//         } else {
//           setServerError('Error: ' + error.message);
//         }
//       }
//     }
//   };
 
 
//   return (
//     <div className="LoginContainer">
//       <div className="FormWrapper">
//         <Link to="/" style={{ textDecoration: "none" }}>
//           <div className="LogoContainer">
//             <img src="02 1.jpg" alt="Logo" className="LogoImage" />
//             <span className="LogoText">EDU360</span>
//           </div>
//         </Link>
 
//         <h4 className="SubHeading">Login To Your Account</h4>
//         <form onSubmit={handleSubmit} className="Form">
//           {serverError && <p className="Message">{serverError}</p>}
//           <div className="InputWrapper">
//             <span className="IconWrapper"><FiMail /></span>
//             {errors.UserName && <p className="Message">{errors.UserName}</p>}
//             <input
//               type='text'
//               placeholder='Enter UserName'
//               name='UserName'
//               onChange={handleInput}
//               value={values.UserName}
//               className="Input"
//             />
//           </div>
//           <div className="InputWrapper">
//       <span className="IconWrapper"><FiLock /></span>
//       {errors.Password && <p className="Message">{errors.Password}</p>}
//       <input
//         type={showPassword ? 'text' : 'password'}
//         placeholder='Enter Password'
//         name='Password'
//         onChange={handleInput}
//         value={values.Password}
//         className="Input"
//       />
//       <span className="IconWrapperEye" onClick={togglePasswordVisibility}>
//         {showPassword ? <FiEyeOff /> : <FiEye />}
//       </span>
//     </div>
//           <div className="InputWrapper">
//             <span className="IconWrapperSelect"><FiUser /></span>
//             <select
//               name='Role'
//               onChange={handleInput}
//               value={values.Role}
//               className="Login_Select"
//             >
//               <option value='administrator'>ADMINISTRATOR</option>
//               <option value='admin'>ADMIN</option>
//               <option value='staff'>STAFF</option>
//               <option value='student'>STUDENT</option>
//               <option value='developer'>DEVELOPER</option>
//             </select>
//           </div>
//           <button type="submit" className="Login_Button">Login</button>
//           <Link to='/signup' className="LinkStyled">Don't have an account? <span>Signup</span></Link>
//         </form>
//       </div>
//     </div>
//   );
// }
 
// export default Login;
 

import React, { useState, useContext, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { FiMail, FiLock, FiUser, FiEye, FiEyeOff } from 'react-icons/fi';
import Validation from './LoginValidation';
import { AuthContext } from './AuthContext';
import './Security.css';

function Login() {
  const { isAuthenticated, login, logout } = useContext(AuthContext);
  const [values, setValues] = useState({
    UserName: '',
    Password: '',
    Role: 'administrator'
  });

  // For Eye icon in password
  const [showPassword, setShowPassword] = useState(false);

  const togglePasswordVisibility = () => {
    setShowPassword(prevState => !prevState);
  };

  const [errors, setErrors] = useState({});
  const [serverError, setServerError] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    if (isAuthenticated) {
      logout(); // Log out if already authenticated when navigating to login page
    }
  }, [isAuthenticated, logout]);

  const handleInput = (event) => {
    const { name, value } = event.target;
    setValues((prevValues) => ({
      ...prevValues,
      [name]: value
    }));
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    const validationErrors = Validation(values);
    setErrors(validationErrors);
    setServerError(''); // Reset server error message

    if (Object.keys(validationErrors).length === 0) {
      try {
        let apiUrl = 'http://13.127.57.224:2081/login'; // Default API for other roles

        // Check for developer role and use the dev login API if applicable
        if (values.Role === 'developer') {
          apiUrl = 'http://13.127.57.224:2081/logindev';
        }

        const response = await axios.post(apiUrl, values);
        console.log("API Response:", response); // Debugging the response

        if (response.status === 200) {
          login(); // Call login function from AuthContext to set isAuthenticated to true

          // Check if the developer role is selected and navigate to DeveloperDashboard
          if (values.Role === 'developer') {
            console.log("Developer role detected, navigating to DeveloperDashboard");
            navigate('/DeveloperDashboard');
            return;
          }

          // Handle other roles
          switch (values.Role) {
            case 'administrator':
            case 'admin':
              navigate('/DashBoard');
              break;
            case 'staff':
              navigate('/Staff_Dashbord');
              break;
            case 'student':
              navigate('/Student_Dashboard');
              break;
            default:
              navigate('/');
              break;
          }
        } else {
          setServerError('Authentication failed: ' + response.data.message);
        }
      } catch (error) {
        if (error.response) {
          if (error.response.status === 401) {
            setServerError('Password does not match');
          } else if (error.response.status === 404) {
            setServerError('UserID or Role does not match');
          }
        } else {
          setServerError('Error: ' + error.message);
        }
      }
    }
  };

  return (
    <div className="LoginContainer">
      <div className="FormWrapper">
        <Link to="/" style={{ textDecoration: "none" }}>
          <div className="LogoContainer">
            <img src="02 1.jpg" alt="Logo" className="LogoImage" />
            <span className="LogoText">EDU360</span>
          </div>
        </Link>

        <h4 className="SubHeading">Login To Your Account</h4>
        <form onSubmit={handleSubmit} className="Form">
          {serverError && <p className="Message">{serverError}</p>}
          <div className="InputWrapper">
            <span className="IconWrapper"><FiMail /></span>
            {errors.UserName && <p className="Message">{errors.UserName}</p>}
            <input
              type='text'
              placeholder='Enter UserName'
              name='UserName'
              onChange={handleInput}
              value={values.UserName}
              className="Input"
            />
          </div>
          <div className="InputWrapper">
            <span className="IconWrapper"><FiLock /></span>
            {errors.Password && <p className="Message">{errors.Password}</p>}
            <input
              type={showPassword ? 'text' : 'password'}
              placeholder='Enter Password'
              name='Password'
              onChange={handleInput}
              value={values.Password}
              className="Input"
            />
            <span className="IconWrapperEye" onClick={togglePasswordVisibility}>
              {showPassword ? <FiEyeOff /> : <FiEye />}
            </span>
          </div>
          <div className="InputWrapper">
            <span className="IconWrapperSelect"><FiUser /></span>
            <select
              name='Role'
              onChange={handleInput}
              value={values.Role}
              className="Login_Select"
            >
              <option value='administrator'>ADMINISTRATOR</option>
              <option value='admin'>ADMIN</option>
              <option value='staff'>STAFF</option>
              <option value='student'>STUDENT</option>
              <option value='developer'>DEVELOPER</option>
            </select>
          </div>
          <button type="submit" className="Login_Button">Login</button>
          <Link to='/signup' className="LinkStyled">Don't have an account? <span>Signup</span></Link>
        </form>
      </div>
    </div>
  );
}

export default Login;
