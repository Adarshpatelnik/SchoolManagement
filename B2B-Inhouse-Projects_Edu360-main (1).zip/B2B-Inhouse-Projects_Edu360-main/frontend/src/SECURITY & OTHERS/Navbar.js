// import React, { useState, useEffect, useRef } from 'react';
// import 'bootstrap/dist/css/bootstrap.min.css';
// import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
// import { faHome, faEnvelope, faUser, faBriefcase ,faUserPlus} from '@fortawesome/free-solid-svg-icons';
// import { Link } from 'react-router-dom';
// import { Link as ScrollLink } from 'react-scroll';

// const Navbar = () => {
//   const [activeDropdown, setActiveDropdown] = useState(null);
//   const [isSmallScreen, setIsSmallScreen] = useState(window.innerWidth < 768); // Assuming Bootstrap breakpoint for small screens
//   const HomeRef = useRef(null);

//   const handleDropdownToggle = (dropdownId) => {
//     setActiveDropdown(activeDropdown === dropdownId ? null : dropdownId);
//   };

//   const linkStyle = {
//     fontFamily: 'Arial',
//     color: 'black',
//     fontWeight: 'normal',
//     textDecoration: 'none',
//     transition: 'font-weight 0.3s',
//   };

//   const activeLinkStyle = {
//     fontWeight: 'bold',
//     textDecoration: 'none',
//   };

//   const handleMouseOver = (event) => {
//     event.target.style.fontWeight = 'bold';
//     event.target.style.textDecoration = 'none';
//   };

//   const handleMouseOut = (event) => {
//     event.target.style.fontWeight = 'normal';
//     event.target.style.textDecoration = 'none';
//   };

//   useEffect(() => {
//     const handleClickOutside = (event) => {
//       if (HomeRef.current && !HomeRef.current.contains(event.target)) {
//         setActiveDropdown(null);
//       }
//     };

//     document.addEventListener('mousedown', handleClickOutside);

//     return () => {
//       document.removeEventListener('mousedown', handleClickOutside);
//     };
//   }, []);

//   useEffect(() => {
//     const handleResize = () => {
//       setIsSmallScreen(window.innerWidth < 768); // Assuming Bootstrap breakpoint for small screens
//     };

//     window.addEventListener('resize', handleResize);

//     return () => {
//       window.removeEventListener('resize', handleResize);
//     };
//   }, []);

 

//   const refreshPage = () => {
//     window.scrollTo({
//       top: 0,
//       behavior: 'smooth'
//     });
//   };
  
  
  
  

//   const baseFontSize = 16;

//   const navbarPaddingY = 10 / baseFontSize;
//   const navbarPaddingX = 20 / baseFontSize;
//   const navbarBorderRadius = 2 / baseFontSize;
//   const brandLogoWidth = 40 / baseFontSize;
//   const brandLogoHeight = 30 / baseFontSize;
//   const brandLogoMarginRight = 7 / baseFontSize;
//   const brandLogoMarginBottom = 8 / baseFontSize;
//   const brandFontSize = 1.3;

//   return (
//     <div>
//       <div className="navbar-container">
//         <nav className={`navbar navbar-expand-lg navbar-light mb-1 ${isSmallScreen && activeDropdown ? 'bg-transparent' : 'bg-white'}`}
//           style={{ padding: `${navbarPaddingY}rem ${navbarPaddingX}rem`, position: "fixed", top: 0, left: 0, right: 0, zIndex: 1000 }}>
//           <Link className="navbar-brand student-management-link" to="/" onClick={refreshPage}>
//             <img src="02 1.jpg" alt="B2B360 Logo" style={{ width: `${brandLogoWidth}rem`, height: `${brandLogoHeight}rem`, marginRight: `${brandLogoMarginRight}rem`, marginBottom: `${brandLogoMarginBottom}rem` }} />
//             <span style={{ fontFamily: 'Playfair Display, serif', fontSize: `${brandFontSize}em`, fontWeight: 'bold', backgroundImage: 'linear-gradient(to right, #012353, #27AE60)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>EDU<span style={{ color: '#dc3545' }}>3</span>6<span style={{ color: '#28a745' }}>0</span></span>
//           </Link>

//           <button
//             className="navbar-toggler"
//             type="button"
//             data-bs-toggle="collapse"
//             data-bs-target="#navbarNav"
//             aria-controls="navbarNav"
//             aria-expanded={activeDropdown !== null}
//             aria-label="Toggle navigation"
//             onClick={() => handleDropdownToggle('navbarNav')}
//           >
//             <span className="navbar-toggler-icon"></span>
//           </button>

//           <div className={`collapse navbar-collapse justify-content-end ${activeDropdown ? 'show' : ''}`} id="navbarNav" ref={HomeRef}>
//             <ul className="navbar-nav" style={{ fontSize: '1.1em', fontFamily: 'Playfair Display, serif' }}>
//               <li className="nav-item">
//               <ScrollLink
//   to="top"
//   spy={true}
//   smooth={true}
//   offset={-70}
//   duration={600}
//   className="nav-link student-management-link"
//   style={activeDropdown === 'Home' ? { ...linkStyle, ...activeLinkStyle } : linkStyle}
//   onMouseOver={handleMouseOver}
//   onMouseOut={handleMouseOut}
//   onClick={() => { handleDropdownToggle('Home'); refreshPage(); }}
// >
//   <FontAwesomeIcon icon={faHome} className="icon" />
//   <span style={{ fontFamily: 'Playfair Display, serif' }}> Home</span>
// </ScrollLink>


//               </li>
//               <li className="nav-item">
//                 <ScrollLink
//                   to="Contact"
//                   spy={true}
//                   smooth={true}
//                   offset={-60}
//                   duration={100}
//                   className="nav-link student-management-link"
//                   style={activeDropdown === 'Contact' ? { ...linkStyle, ...activeLinkStyle } : linkStyle}
//                   onMouseOver={handleMouseOver}
//                   onMouseOut={handleMouseOut}
//                   onClick={() => handleDropdownToggle('Contact')}
//                 >
//                   <FontAwesomeIcon icon={faEnvelope} className="icon" />
//                   <span style={{ fontFamily: 'Playfair Display, serif' }}> Contact Us</span>
//                 </ScrollLink>
//               </li>
//               <li className="nav-item">
//                 <ScrollLink
//                   to="Services"
//                   spy={true}
//                   smooth={true}
//                   offset={-60}
//                   duration={100}
//                   className="nav-link student-management-link"
//                   style={activeDropdown === 'Services' ? { ...linkStyle, ...activeLinkStyle } : linkStyle}
//                   onMouseOver={handleMouseOver}
//                   onMouseOut={handleMouseOut}
//                   onClick={() => handleDropdownToggle('Services')}
//                 >
//                   <FontAwesomeIcon icon={faBriefcase} className="icon" />
//                   <span style={{ fontFamily: 'Playfair Display, serif' }}> Services</span>
//                 </ScrollLink>
//               </li>
//               <li className="nav-item">
//   <Link
//     to="/Login"
//     className="btn nav-link"
//     style={{
//       padding: '8px 16px', // Adjust padding to ensure equal button size
//       marginLeft: '10px',
//       fontWeight: 'bold',
//       borderRadius: '6px',
//       color: 'black',
//       border: '1px solid #ccc',
//       display: 'flex',
//       alignItems: 'center',
//       fontFamily: 'Playfair Display, serif',
//       textDecoration: 'none',
//       transition: 'background-color 0.3s ease, color 0.3s ease',
//       cursor: 'pointer'
//     }}
//     onMouseEnter={(e) => {
//       e.target.style.color = "white";
//       e.target.style.background = "linear-gradient(to right, #012353, #27AE60)";
//     }}
//     onMouseLeave={(e) => {
//       e.target.style.color = "black";
//       e.target.style.background = "white";
//     }}
//   >
//     <FontAwesomeIcon icon={faUser} className="icon" /> {/* Add icon here */}
//     Login
//   </Link>
// </li>
// <li className="nav-item">
//   <Link
//     to="/Signup"
//     className="btn nav-link"
//     style={{
//       padding: '8px 16px',
//       marginLeft: '10px',
//       fontWeight: 'bold',
//       borderRadius: '6px',
//       color: 'white', // Initial text color
//       background: 'linear-gradient(to right, #012353, #27AE60)', // Initial background
//       border: '1px solid #ccc',
//       display: 'flex',
//       alignItems: 'center',
//       fontFamily: 'Playfair Display, serif',
//       textDecoration: 'none',
//       transition: 'background-color 0.3s ease, color 0.3s ease',
//       cursor: 'pointer'
//     }}
//     onMouseEnter={(e) => {
//       e.target.style.color = "black"; // Text color on hover
//       e.target.style.background = "white"; // Background color on hover
//     }}
//     onMouseLeave={(e) => {
//       e.target.style.color = "white"; // Revert text color
//       e.target.style.background = "linear-gradient(to right, #012353, #27AE60)"; // Revert background
//     }}
//   >
//     <FontAwesomeIcon icon={faUserPlus} className="icon" style={{ marginRight: '5px' }} />
//     Signup
//   </Link>
// </li>

//             </ul>
//           </div>
//         </nav>
//       </div>
//     </div>
//   );
// };

// export default Navbar;








import React, { useState, useEffect, useRef } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faHome, faEnvelope, faUser, faBriefcase , faUserPlus} from '@fortawesome/free-solid-svg-icons';
import { Link } from 'react-router-dom';
import { Link as ScrollLink } from 'react-scroll';
import './Security.css'; // Import the external CSS file
 
const Navbar = () => {
  const [activeDropdown, setActiveDropdown] = useState(null);
  const [isSmallScreen, setIsSmallScreen] = useState(window.innerWidth < 768); // Assuming Bootstrap breakpoint for small screens
  const HomeRef = useRef(null);
 
  const handleDropdownToggle = (dropdownId) => {
    setActiveDropdown(activeDropdown === dropdownId ? null : dropdownId);
  };
 
  const handleMouseOver = (event) => {
    event.target.style.fontWeight = 'bold';
    event.target.style.textDecoration = 'none';
  };
 
  const handleMouseOut = (event) => {
    event.target.style.fontWeight = 'normal';
    event.target.style.textDecoration = 'none';
  };
 
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (HomeRef.current && !HomeRef.current.contains(event.target)) {
        setActiveDropdown(null);
      }
    };
 
    document.addEventListener('mousedown', handleClickOutside);
 
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);
 
  useEffect(() => {
    const handleResize = () => {
      setIsSmallScreen(window.innerWidth < 768); // Assuming Bootstrap breakpoint for small screens
    };
 
    window.addEventListener('resize', handleResize);
 
    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);
 
  const refreshPage = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  };
 
  return (
    <div>
      <div className="navbar-container">
        <nav className={`navbar navbar-expand-lg navbar-light mb-1 ${isSmallScreen && activeDropdown ? 'bg-transparent' : 'bg-white'}`}
          style={{ padding: '10px 20px' }}>
          <Link className="navbar-brand student-management-link" to="/" onClick={refreshPage}>
            <img src="02 1.jpg" alt="B2B360 Logo" />
            <span>EDU360</span>
          </Link>
 
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarNav"
            aria-controls="navbarNav"
            aria-expanded={activeDropdown !== null}
            aria-label="Toggle navigation"
            onClick={() => handleDropdownToggle('navbarNav')}
          >
            <span className="navbar-toggler-icon"></span>
          </button>
 
          <div className={`collapse navbar-collapse justify-content-end ${activeDropdown ? 'show' : ''}`} id="navbarNav" ref={HomeRef}>
            <ul className="navbar-nav">
              <li className="nav-item">
                <ScrollLink
                  to="top"
                  spy={true}
                  smooth={true}
                  offset={-70}
                  duration={600}
                  className="nav-link student-management-link"
                  style={activeDropdown === 'Home' ? { fontWeight: 'bold' } : {}}
                  onMouseOver={handleMouseOver}
                  onMouseOut={handleMouseOut}
                  onClick={() => { handleDropdownToggle('Home'); refreshPage(); }}
                >
                  <FontAwesomeIcon icon={faHome} className="Navbar_icon" />
                  Home
                </ScrollLink>
              </li>
              <li className="nav-item">
                <ScrollLink
                  to="Services"
                  spy={true}
                  smooth={true}
                  offset={-68}
                  duration={100}
                  className="nav-link student-management-link"
                  style={activeDropdown === 'Services' ? { fontWeight: 'bold' } : {}}
                  onMouseOver={handleMouseOver}
                  onMouseOut={handleMouseOut}
                  onClick={() => handleDropdownToggle('Services')}
                >
                  <FontAwesomeIcon icon={faBriefcase} className="Navbar_icon" />
                  Services
                </ScrollLink>
              </li>
              <li className="nav-item">
                <ScrollLink
                  to="Contact"
                  spy={true}
                  smooth={true}
                  offset={-60}
                  duration={100}
                  className="nav-link student-management-link"
                  style={activeDropdown === 'Contact' ? { fontWeight: 'bold' } : {}}
                  onMouseOver={handleMouseOver}
                  onMouseOut={handleMouseOut}
                  onClick={() => handleDropdownToggle('Contact')}
                >
                  <FontAwesomeIcon icon={faEnvelope} className="Navbar_icon" />
                  Contact Us
                </ScrollLink>
              </li>
              <li className="nav-item">
                <Link to="/Login" className="btn btn-login nav-link">
                  <FontAwesomeIcon icon={faUser} className="Navbar_icon" />
                  Login
                </Link>
              </li>
              <li className="nav-item">
                <Link to="/Signup" className="btn btn-signup nav-link">
                  <FontAwesomeIcon icon={faUserPlus} className="Navbar_icon" />
                  Signup
                </Link>
              </li>
            </ul>
          </div>
        </nav>
      </div>
    </div>
  );
};
 
export default Navbar;
 
