// LoginValidation.js

function LoginValidation(values) {
  let errors = {};
 // const passwordPattern = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}$/;

  // Validate UserName
  if (!values.UserName) {
    errors.UserName = "Username is required";
  }

  // Validate Password
  if (!values.Password) {
    errors.Password = "Password is required";
  } //else if (!passwordPattern.test(values.Password)) {
   // errors.Password = "Password must contain at least 8 characters, including one uppercase letter, one lowercase letter, and one number";
 // }

  // Validate Role (Optional)
  // You might add validation specific to the 'Role' field if needed.

  return errors;
}

export default LoginValidation;
