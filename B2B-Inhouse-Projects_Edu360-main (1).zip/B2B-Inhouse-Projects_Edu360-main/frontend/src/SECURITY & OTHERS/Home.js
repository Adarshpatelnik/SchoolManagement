

// import React from 'react';
// import { Link as Element } from 'react-scroll';
// import Navbar from './Navbar.js';
// import MissionVision from './MissionVision.js';
// import Contact from './Contact.js';
// import Aboutus from './About_us.js';
// import Services from './Services.js';
// import Footer from './Footer.js';
// import styled from 'styled-components';

// const mediaContent = {
//   type: "video",
//   src: "vdo_type.mp4",
//   text: "Education is the passport to the future."
// };

// const MediaContainer = styled.div`
//   position: relative;
//   width: 100%;
//   height: 80vh;
//   overflow: hidden;

//   video {
//     width: 100%;
//     height: 100%;
//     object-fit: cover;
//   }

//   .overlay-text {
//     position: absolute;
//     bottom: 1%;
//     left: 50%;
//     transform: translateX(-50%);
//     color: #ffffff;
//     padding: 15px 20px;
//     border-radius: 10px;
//     font-size: 1.9em;
//     font-family: 'Fantasy';
//     text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
//     text-align: center;
//   }
// `;

// const Home = () => {
//   return (
//     <div>
//       <Navbar />
//       <div className="container-fluid" style={{ marginTop: '10vh', width: '100%', padding: 0 }}>
//         <MediaContainer>
//           <video src={mediaContent.src} autoPlay loop muted />
//           <div className="overlay-text">{mediaContent.text}</div>
//         </MediaContainer>
//         <MissionVision />
//         <Aboutus />
//         <Element name="Services">
//           <Services />
//         </Element>
//         <Element name="Contact">
//           <Contact />
//         </Element>
//         <div className="container-fluid" style={{ marginTop: '4vh', width: '100%', padding: 0 }}>
//           <div style={{ borderTop: '5px solid rgb(40, 137, 57)', paddingTop: '10px' }}>
//             <div className="container-fluid" style={{ marginTop: '4vh', width: '100%', padding: 0 }}></div>
//             <Footer />
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default Home;




import React from 'react';
import { Link as Element } from 'react-scroll';
import Navbar from './Navbar.js';
import MissionVision from './MissionVision.js';
import Contact from './Contact.js';
import Aboutus from './About_us.js';
import Services from './Services.js';
import Footer from './Footer.js';
import './Security.css'; // Import the Security.css file
 
const mediaContent = {
  type: "video",
  src: "vdo_type.mp4",
  text: "Education is the passport to the future."
};
 
const Home = () => {
  return (
    <div>
      <Navbar />
      <div className="container-fluid" style={{ marginTop: '10vh', width: '100%', padding: 0 }}>
        <div className="media-container">
          <video src={mediaContent.src} autoPlay loop muted />
          <div className="overlay-text">{mediaContent.text}</div>
        </div>
        <MissionVision />
        <Aboutus />
        <Element name="Services">
          <Services />
        </Element>
        <Element name="Contact">
          <Contact />
        </Element>
        <div className="container-fluid">
          <div className="Home_footer-border">
            <div className="container-fluid"></div>
            <Footer />
          </div>
        </div>
      </div>
    </div>
  );
};
 
export default Home;
 
