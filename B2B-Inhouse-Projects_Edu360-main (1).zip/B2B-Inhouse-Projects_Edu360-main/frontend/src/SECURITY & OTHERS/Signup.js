// import React, { useState } from 'react';
// import { Link, useNavigate } from 'react-router-dom';
// import axios from 'axios';
// import styled, { keyframes } from 'styled-components';
// import { FiMail, FiLock, FiUser, FiMap, FiBook, FiMapPin, FiPhone } from 'react-icons/fi';
// import Validation from './SignupValidation';

// const fadeIn = keyframes`
//   from {
//     opacity: 0;
//   }
//   to {
//     opacity: 1;
//   }
// `;

// const LoginContainer = styled.div`
//   display: flex;
//   justify-content: center;
//   align-items: center;
//   height: 100vh;
//   background: url('laibray.png') no-repeat center center fixed; 
//   background-size: cover;
//   animation: ${fadeIn} 1s ease-in;
// `;

// const FormWrapper = styled.div`
//   background-color: rgba(255, 255, 255, 0.9);
//   padding: 10px;
//   border-radius: 10px;
//   box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
//   max-width: 700px;
//   width: 100%;
//   text-align: center;
//   transition: transform 0.3s ease, box-shadow 0.3s ease;

//   &:hover {
//     transform: translateY(-5px);
//     box-shadow: 0 15px 35px rgba(0, 0, 0, 0.2);
//   }
// `;

// const LogoContainer = styled.div`
//   display: flex;
//   justify-content: center;
//   align-items: center;
//   margin-bottom: 5px;
// `;

// const LogoImage = styled.img`
//   width: 40px;
//   margin-right: 7px;
// `;

// const LogoText = styled.span`
//   font-size: 26px;
//   font-weight: bold;
//   background: linear-gradient(to right, #012353, #27ae60);
//   -webkit-background-clip: text;
//   -webkit-text-fill-color: transparent;
//   font-family: 'Playfair Display', serif;
// `;

// const Form = styled.form`
//   width: 100%;
//   display: flex;
//   flex-wrap: wrap;
//   justify-content: space-between;
// `;

// const Section = styled.div`
//   width: 48%;

//   @media (max-width: 768px) {
//     width: 100%;
//   }
// `;

// const InputWrapper = styled.div`
//   position: relative;
//   margin-bottom: 8px;
// `;

// const IconWrapper = styled.span`
//   position: absolute;
//   top: 50%;
//   left: 15px;
//   transform: translateY(-50%);
//   color: #999;
// `;

// const Input = styled.input`
//   width: 100%;
//   padding: 12px 45px;
//   border: 2px solid #ccc;
//   border-radius: 25px;
//   font-size: 16px;
//   box-sizing: border-box;
//   transition: border-color 0.3s ease;

//   &:focus {
//     border-color: #2980b9;
//     outline: none;
//   }
// `;

// const Button = styled.button`
//   width: 20%;
//   padding: 10px;
//   background: linear-gradient(to right, #012353, #27ae60);
//   color: white;
//   border: none;
//   border-radius: 10px;
//   cursor: pointer;
//   font-size: 18px;
//   transition: background 0.3s ease, transform 0.3s ease;
// margin-left:300px;

// margin-top:4px;
//   &:hover {
//     background: linear-gradient(to right, #012353, #27ae60);
//     transform: translateY(-2px);
//   }
// `;

// const Message = styled.p`
//   color: red;
//   font-size: 14px;
//   text-align: left;
//   margin-top: -10px;
//   margin-bottom: 10px;
// `;

// const LinkStyled = styled(Link)`
//   display: block;
//   text-align: center;
//   margin-top: 10px;
//   color: #333;
//   text-decoration: none;
//   font-size: 16px;

//   &:hover {
//     text-decoration: underline;
//   }
// `;

// const SubHeading = styled.h3`
//   font-size: 18px;
//   color: #555;
//   margin-bottom: 30px;
// `;

// const SuccessMessage = styled.p`
//   color: green;
//   font-size: 16px;
//   margin-top: 20px;
// `;

// function Signup() {
//   const [values, setValues] = useState({
//     FullName: '',
//     SchoolName: '',
//     SchoolBranch: '',
//     SchoolCode: '',
//     City: '',
//     State: '',
//     PostalCode: '',
//     Email: '',
//     MobileNumber: '',
//     UserName: '',
//     Password: '',
//     Role: 'administrator' // Default role
//   });

//   const [errors, setErrors] = useState({});
//   const [isSuccess, setIsSuccess] = useState(false);
//   const [serverError, setServerError] = useState('');
//   const navigate = useNavigate();

//   const handleInput = (event) => {
//     const { name, value } = event.target;
//     setValues((prevValues) => ({
//       ...prevValues,
//       [name]: value
//     }));
//   };

//   const handleSubmit = async (event) => {
//     event.preventDefault();
//     const validationErrors = Validation(values);
//     setErrors(validationErrors);
//     setServerError('');

//     if (Object.keys(validationErrors).length === 0) {
//       try {
//         const response = await axios.post('http://13.127.57.224:2081/signup', values);
//         console.log(response.data);
//         setIsSuccess(true);

//         setTimeout(() => {
//           navigate('/login');
//         }, 3000); // Adjust the delay as needed
//       } catch (error) {
//         if (error.response && error.response.status === 409) {
//           setServerError(error.response.data.error);
//         } else {
//           setServerError('An error occurred. Please try again later.');
//         }
//       }
//     }
//   };

//   return (
//     <LoginContainer>
//       <FormWrapper>
//         <Link to="/" style={{ textDecoration: "none" }}>
//           <LogoContainer>
//             <LogoImage src="02 1.jpg" alt="Logo" />
//             <LogoText>EDU360</LogoText>
//           </LogoContainer>
//         </Link>
//         <SubHeading>Signup To Your Account</SubHeading>
//         {serverError && <Message>{serverError}</Message>}
//         <Form onSubmit={handleSubmit}>
//           <Section>
//             <InputWrapper>
//               <IconWrapper><FiUser /></IconWrapper>
//               <Input
//                 type='text'
//                 placeholder='Enter Full Name'
//                 name='FullName'
//                 onChange={handleInput}
//                 value={values.FullName}
//               />
//               {errors.FullName && <Message>{errors.FullName}</Message>}
//             </InputWrapper>
//             <InputWrapper>
//               <IconWrapper><FiMapPin /></IconWrapper>
//               <Input
//                 type='text'
//                 placeholder='Enter School Branch'
//                 name='SchoolBranch'
//                 onChange={handleInput}
//                 value={values.SchoolBranch}
//               />
//               {errors.SchoolBranch && <Message>{errors.SchoolBranch}</Message>}
//             </InputWrapper>
//             <InputWrapper>
//               <IconWrapper><FiMapPin /></IconWrapper>
//               <Input
//                 type='text'
//                 placeholder='Enter School Code'
//                 name='SchoolCode'
//                 onChange={handleInput}
//                 value={values.SchoolCode}
//               />
//               {errors.SchoolCode && <Message>{errors.SchoolCode}</Message>}
//             </InputWrapper>
//             <InputWrapper>
//               <IconWrapper><FiMap /></IconWrapper>
//               <Input
//                 type='text'
//                 placeholder='Enter State'
//                 name='State'
//                 onChange={handleInput}
//                 value={values.State}
//               />
//               {errors.State && <Message>{errors.State}</Message>}
//             </InputWrapper>
//             <InputWrapper>
//               <IconWrapper><FiMail /></IconWrapper>
//               <Input
//                 type='email'
//                 placeholder='Enter Email'
//                 name='Email'
//                 onChange={handleInput}
//                 value={values.Email}
//               />
//               {errors.Email && <Message>{errors.Email}</Message>}
//             </InputWrapper>
//             <InputWrapper>
//               <IconWrapper><FiUser /></IconWrapper>
//               <Input
//                 type='text'
//                 placeholder='Enter UserName'
//                 name='UserName'
//                 onChange={handleInput}
//                 value={values.UserName}
//               />
//               {errors.UserName && <Message>{errors.UserName}</Message>}
//             </InputWrapper>
//           </Section>
//           <Section>
//             <InputWrapper>
//               <IconWrapper><FiBook /></IconWrapper>
//               <Input
//                 type='text'
//                 placeholder='Enter School Name'
//                 name='SchoolName'
//                 onChange={handleInput}
//                 value={values.SchoolName}
//               />
//               {errors.SchoolName && <Message>{errors.SchoolName}</Message>}
//             </InputWrapper>
//             <InputWrapper>
//               <IconWrapper><FiMapPin /></IconWrapper>
//               <Input
//                 type='text'
//                 placeholder='Enter City'
//                 name='City'
//                 onChange={handleInput}
//                 value={values.City}
//               />
//               {errors.City && <Message>{errors.City}</Message>}
//             </InputWrapper>
//             <InputWrapper>
//               <IconWrapper><FiMap /></IconWrapper>
//               <Input
//                 type='text'
//                 placeholder='Enter Postal Code'
//                 name='PostalCode'
//                 onChange={handleInput}
//                 value={values.PostalCode}
//               />
//               {errors.PostalCode && <Message>{errors.PostalCode}</Message>}
//             </InputWrapper>
//             <InputWrapper>
//               <IconWrapper><FiPhone /></IconWrapper>
//               <Input
//                 type='text'
//                 placeholder='Enter Mobile Number'
//                 name='MobileNumber'
//                 onChange={handleInput}
//                 value={values.MobileNumber}
//               />
//               {errors.MobileNumber && <Message>{errors.MobileNumber}</Message>}
//             </InputWrapper>
//             <InputWrapper>
//               <IconWrapper><FiLock /></IconWrapper>
//               <Input
//                 type='password'
//                 placeholder='Enter Password'
//                 name='Password'
//                 onChange={handleInput}
//                 value={values.Password}
//               />
//               {errors.Password && <Message>{errors.Password}</Message>}
//             </InputWrapper>
//           </Section>
//           <Button type="submit">Sign Up</Button>
//         </Form>
//         {isSuccess && <SuccessMessage>You have successfully registered!</SuccessMessage>}
         
//         <LinkStyled to='/login'>Login</LinkStyled>
//       </FormWrapper>
//     </LoginContainer>
//   );
// }

// export default Signup;









import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { FiMail, FiLock, FiUser, FiMap, FiBook, FiMapPin, FiPhone, FiEye, FiEyeOff } from 'react-icons/fi';
import './Security.css'
 
function Signup() {
  const [values, setValues] = useState({
    FullName: '',
    SchoolName: '',
    SchoolBranch: '',
    SchoolCode: '',
    City: '',
    State: '',
    PostalCode: '',
    Email: '',
    MobileNumber: '',
    UserName: '',
    Password: '',
    Role: 'administrator' // Default role
  });
 
  const [showPassword, setShowPassword] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [serverError, setServerError] = useState('');
  const navigate = useNavigate();
 
  const handleInput = (event) => {
    const { name, value } = event.target;
    setValues((prevValues) => ({
      ...prevValues,
      [name]: value
    }));
  };
 
 
  const togglePasswordVisibility = () => {
    setShowPassword(prevState => !prevState);
  };
  const handleSubmit = async (event) => {
    event.preventDefault();
    setServerError('');
    try {
      const response = await axios.post('http://13.127.57.224:2081/signup', values);
      console.log(response.data);
      setIsSuccess(true);
 
      setTimeout(() => {
        navigate('/login');
      }, 3000); // Adjust the delay as needed
    } catch (error) {
      if (error.response && error.response.status === 409) {
        setServerError(error.response.data.error);
      } else {
        setServerError('An error occurred. Please try again later.');
      }
    }
  };
 
  return (
    <div className="Signup_container">
      <div className="Signup_formWrapper">
        <Link to="/" style={{ textDecoration: "none" }}>
          <div className="Signup_logoContainer">
            <img src="02 1.jpg" alt="Logo" className="Signup_logoImage" />
            <span className="Signup_logoText">EDU360</span>
          </div>
        </Link>
        <h3 className="Signup_subHeading">Signup To Your Account</h3>
        {serverError && <p className="Signup_message">{serverError}</p>}
        <form onSubmit={handleSubmit} className="Signup_form">
          <div className="Signup_section">
            <div className="Signup_inputWrapper">
              <span className="Signup_iconWrapper"><FiUser /></span>
              <input
                type='text'
                placeholder='Enter Full Name'
                name='FullName'
                onChange={handleInput}
                value={values.FullName}
                className="Signup_input"
                required
              />
            </div>
            <div className="Signup_inputWrapper">
              <span className="Signup_iconWrapper"><FiMapPin /></span>
              <input
                type='text'
                placeholder='Enter School Branch'
                name='SchoolBranch'
                onChange={handleInput}
                value={values.SchoolBranch}
                className="Signup_input"
                required
              />
            </div>
            <div className="Signup_inputWrapper">
              <span className="Signup_iconWrapper"><FiMapPin /></span>
              <input
                type='text'
                placeholder='Enter School Code'
                name='SchoolCode'
                onChange={handleInput}
                value={values.SchoolCode}
                className="Signup_input"
                required
              />
            </div>
            <div className="Signup_inputWrapper">
              <span className="Signup_iconWrapper"><FiMap /></span>
              <input
                type='text'
                placeholder='Enter State'
                name='State'
                onChange={handleInput}
                value={values.State}
                className="Signup_input"
                required
              />
            </div>
            <div className="Signup_inputWrapper">
              <span className="Signup_iconWrapper"><FiMail /></span>
              <input
                type='email'
                placeholder='Enter Email'
                name='Email'
                onChange={handleInput}
                value={values.Email}
                className="Signup_input"
                required
              />
            </div>
            <div className="Signup_inputWrapper">
              <span className="Signup_iconWrapper"><FiUser /></span>
              <input
                type='text'
                placeholder='Enter UserName'
                name='UserName'
                onChange={handleInput}
                value={values.UserName}
                className="Signup_input"
                required
              />
            </div>
          </div>
 
          <div className="Signup_section">
            <div className="Signup_inputWrapper">
              <span className="Signup_iconWrapper"><FiBook /></span>
              <input
                type='text'
                placeholder='Enter School Name'
                name='SchoolName'
                onChange={handleInput}
                value={values.SchoolName}
                className="Signup_input"
                required
              />
            </div>
            <div className="Signup_inputWrapper">
              <span className="Signup_iconWrapper"><FiMapPin /></span>
              <input
                type='text'
                placeholder='Enter City'
                name='City'
                onChange={handleInput}
                value={values.City}
                className="Signup_input"
                required
              />
            </div>
            <div className="Signup_inputWrapper">
              <span className="Signup_iconWrapper"><FiMap /></span>
              <input
                type='number'
                placeholder='Enter Postal Code'
                name='PostalCode'
                onChange={handleInput}
                value={values.PostalCode}
                className="Signup_input"
                required
              />
            </div>
            <div className="Signup_inputWrapper">
              <span className="Signup_iconWrapper"><FiPhone /></span>
              <input
                type='number'
                placeholder='Enter Mobile Number'
                name='MobileNumber'
                onChange={handleInput}
                value={values.MobileNumber}
                className="Signup_input"
                required
              />
            </div>
            <div className="Signup_inputWrapper">
              <span className="Signup_iconWrapper"><FiLock /></span>
              <input
                type={showPassword ? 'text' : 'password'}
                placeholder='Enter Password'
                name='Password'
                onChange={handleInput}
                value={values.Password}
                className="Signup_input"
                required
              />
 
              <span className="Signup_iconWrapper_password" onClick={togglePasswordVisibility}>
        {showPassword ? <FiEyeOff /> : <FiEye />}
      </span>
            </div>
          </div>
          <div className='Signup_Submit_Button_div'>
            <button type="submit" className="Signup_button">Sign Up</button>
          </div>
        </form>
        {isSuccess && <p className="Signup_successMessage">You have successfully registered!</p>}
        <Link to='/login' className="Signup_linkStyled">
          Already have an account? <span>Login</span>
        </Link>
      </div>
    </div>
  );
}
 
export default Signup;