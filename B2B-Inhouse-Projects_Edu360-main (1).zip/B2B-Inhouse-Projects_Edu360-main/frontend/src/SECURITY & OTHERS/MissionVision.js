
// import React, { useState, useEffect } from 'react';
// import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
// import { faBullseye, faEye } from '@fortawesome/free-solid-svg-icons';

// const MissionVision = () => {
//   const [pointerPosition, setPointerPosition] = useState(0);

//   useEffect(() => {
//     const interval = setInterval(() => {
//       const newPointerPosition = (pointerPosition + 1) % 101;
//       setPointerPosition(newPointerPosition);
//     }, 50);

//     return () => clearInterval(interval);
//   }, [pointerPosition]);

//   return (
//     <div style={{ textAlign: 'center', marginBottom: '15px', marginTop: '28px', width: '100%' }}>
//   <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', marginBottom: '20px' }}>
//   <h2 style={{ fontFamily: 'Playfair Display, serif', fontSize: '30px', fontWeight: 'bold', color: '#333', marginRight: '-6px' }}>Empowering Tomorrow</h2>
//   <img src="pencil.png" alt="Empowering Tomorrow" style={{ height: '60px', verticalAlign: 'top' }} />
// </div>





//       <div className="bar" style={{ height: '5px', width: '7%', background: '#cdf1d8', margin: '20px auto', position: 'relative', borderRadius: '30px', overflow: 'hidden' }}>
//         <div className="pointer" style={{ width: '10px', height: '100%', background: 'green', position: 'absolute', top: '0', left: `${pointerPosition}%`, transition: 'left 0.05s ease-in-out' }}></div>
//       </div>

//       <div className="row justify-content-center" style={{ marginTop: '3px', marginBottom: '20px' }}>
//         <div className="col-md-4" style={{ textAlign: 'center' }}>
//           <div className="mission-card">
//             <div className="card-content">
//               <FontAwesomeIcon icon={faBullseye} size="3x" style={{ marginBottom: '10px', color: '#27AE60' }} />
//               <h2 className="card-title">Our Mission</h2>
//               <p className="card-text">
//                 To empower educational institutions with innovative technology solutions that enhance learning outcomes and operational efficiency.
//               </p>
//             </div>
//             <div className="gradient-overlay"></div>
//           </div>
//         </div>

//         <div className="col-md-4" style={{ textAlign: 'center' }}>
//           <div className="vision-card">
//             <div className="card-content">
//               <FontAwesomeIcon icon={faEye} size="3x" style={{ marginBottom: '10px', color: '#27AE60' }} />
//               <h2 className="card-title">Our Vision</h2>
//               <p className="card-text">
//                 To be the leading provider of comprehensive school management solutions globally, driving educational excellence through technology.
//               </p>
//             </div>
//             <div className="gradient-overlay"></div>
//           </div>
//         </div>
//       </div>

//       <style jsx>{`
//         .mission-card,
//         .vision-card {
//           position: relative;
//           overflow: hidden;
//           border: 2px solid #27AE60; /* Green border */
//           border-radius: 10px;
//           box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
//           transition: transform 0.3s ease;
//           height: 100%; /* Ensure both cards are equal height */
//           margin-bottom: 20px; /* Adjust spacing between cards */
//         }

//         .card-content {
//           padding: 10px;
//           position: relative;
//           z-index: 2; /* Ensure text is above overlay */
//           color: #012353; /* Initial text color */
//         }

//         .card-title {
//           font-family: 'Playfair Display, serif';
//           font-size: 28px;
//           font-weight: bold;
//           text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
//           margin-bottom: 10px;
//           transition: color 0.3s ease; /* Smooth color transition */
//         }

//         .card-text {
//           font-family: 'Arial, sans-serif';
//           font-size: 18px;
//           line-height: 1.6;
//           color: black; /* Initial text color */
//           transition: color 0.3s ease; /* Smooth color transition */
//         }

//         .gradient-overlay {
//           position: absolute;
//           top: -100%; /* Initially cover the entire card */
//           left: 0;
//           width: 100%;
//           height: 100%;
//           background: linear-gradient(to right, #012353, #27AE60); /* Initial gradient */
//           transition: top 0.3s ease; /* Smooth transition for overlay */
//           border-radius: 10px;
//           z-index: 1; /* Ensure overlay is behind text */
//         }

//         .mission-card:hover .gradient-overlay,
//         .vision-card:hover .gradient-overlay {
//           top: 0; /* Slide the overlay from top to bottom on hover */
//         }

//         .mission-card:hover .card-title,
//         .vision-card:hover .card-title,
//         .mission-card:hover .card-text,
//         .vision-card:hover .card-text {
//           color: white; /* Change text color to white on hover */
//         }
//       `}</style>
//     </div>
//   );
// };

// export default MissionVision;



import React, { useState, useEffect } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faBullseye, faEye } from '@fortawesome/free-solid-svg-icons';
import './Security.css';  // Import the Security.css file
 
const MissionVision = () => {
  const [pointerPosition, setPointerPosition] = useState(0);
 
  useEffect(() => {
    const interval = setInterval(() => {
      const newPointerPosition = (pointerPosition + 1) % 101;
      setPointerPosition(newPointerPosition);
    }, 50);
 
    return () => clearInterval(interval);
  }, [pointerPosition]);
 
  return (
    <div className="mission-vision-container">
      <div className="mission-vision-header">
        <h2>Empowering Tomorrow</h2>
        <img src="pencil.png" alt="Empowering Tomorrow" />
      </div>
 
      <div className="mission-vision-bar">
        <div className="mission-vision-pointer" style={{ left: `${pointerPosition}%` }}></div>
      </div>
 
      <div className="mission_vision_row">
        <div className="col-md-4" style={{ textAlign: 'center' }}>
          <div className="mission-card">
            <div className="mission-card-content">
              <FontAwesomeIcon icon={faBullseye} size="3x" style={{ marginBottom: '10px', color: '#27AE60' }} />
              <h2 className="mission-card-title">Our Mission</h2>
              <p className="mission-card-text">
                To empower educational institutions with innovative technology solutions that enhance learning outcomes and operational efficiency.
              </p>
            </div>
            <div className="gradient-overlay"></div>
          </div>
        </div>
 
        <div className="col-md-4" style={{ textAlign: 'center' }}>
          <div className="vision-card">
            <div className="mission-card-content">
              <FontAwesomeIcon icon={faEye} size="3x" style={{ marginBottom: '10px', color: '#27AE60' }} />
              <h2 className="mission-card-title">Our Vision</h2>
              <p className="mission-card-text">
                To be the leading provider of comprehensive school management solutions globally, driving educational excellence through technology.
              </p>
            </div>
            <div className="gradient-overlay"></div>
          </div>
        </div>
      </div>
    </div>
  );
};
 
export default MissionVision;
 