// import React from 'react';
// import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
// import { faUserGraduate, faChalkboardTeacher, faClipboard,faBookOpen } from '@fortawesome/free-solid-svg-icons';

// const Services = () => {
//   return (
//     <div className="container">
//       <div className="row">
//       <div style={{ textAlign: 'center', marginTop: '10px', width: '100%', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
//           <h2 style={{ fontFamily: 'Playfair Display, serif', fontSize: '28px', fontWeight: 'bold', color: '#333', textShadow: '2px 2px 4px rgba(0, 0, 0, 0.3)', marginRight: '10px' }}>Our Services</h2>
//           <img src="girl_services copy.png" alt="Services" style={{ height: '100px', verticalAlign: 'middle' }} />
//         </div>
//       </div>

//       <div className="row justify-content-center" style={{ marginTop: '3px' }}>
//         <div className="col-md-4">
//           <div className="info-card" style={{
//             padding: '7px',
//             margin: '10px',
//             textAlign: 'center',
//             border: '2px solid #27AE60',
//             borderRadius: '10px',
//             height: '90%',
//             boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
//             transition: 'transform 0.3s ease-in-out, border-color 0.3s ease-in-out',
//             overflow: 'hidden',
//           }}
//             onMouseOver={(e) => { e.currentTarget.style.transform = 'scale(1.05)'; e.currentTarget.style.borderColor = '#27AE60'; }}
//             onMouseOut={(e) => { e.currentTarget.style.transform = 'scale(1)'; e.currentTarget.style.borderColor = '#27AE60'; }}
//           >
//             <FontAwesomeIcon icon={faUserGraduate} size="2x" style={{ marginBottom: '10px', color: '#27AE60' }} />

//             <h2 style={{ fontFamily: 'Playfair Display, serif', color: 'Black', fontSize: '25px', fontWeight: 'bold', margin: '10px 0', lineHeight: '1.2' }}>Student Management</h2>
//             <p style={{ fontFamily: 'Arial, sans-serif', color: 'Black', fontSize: '15px', lineHeight: '1.4' }}>
//               Managing student enrollment, attendance, grades, behavior, and communication
//             </p>
//           </div>
//         </div>

//         <div className="col-md-4">
//           <div className="info-card" style={{
//             padding: '10px',
//             margin: '10px',
//             textAlign: 'center',
//             border: '2px solid #27AE60',
//             borderRadius: '10px',
//             height: '90%',
//             boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
//             transition: 'transform 0.3s ease-in-out, border-color 0.3s ease-in-out',
//             overflow: 'hidden',
//           }}
//             onMouseOver={(e) => { e.currentTarget.style.transform = 'scale(1.05)'; e.currentTarget.style.borderColor = '#27AE60'; }}
//             onMouseOut={(e) => { e.currentTarget.style.transform = 'scale(1)'; e.currentTarget.style.borderColor = '#27AE60'; }}
//           >
//             <FontAwesomeIcon icon={faChalkboardTeacher} size="2x" style={{ marginBottom: '10px', color: '#27AE60' }} />

//             <h2 style={{ fontFamily: 'Playfair Display, serif', color: '#333', fontSize: '25px', fontWeight: 'bold', margin: '7px 0', lineHeight: '1.2' }}>Teacher Management</h2>
//             <p style={{ fontFamily: 'Arial, sans-serif', color: 'black', fontSize: '15px', lineHeight: '1.4' }}>
//               Streamlining teacher schedules, performance evaluations, and professional development
//             </p>
//           </div>
//         </div>

//         <div className="col-md-4">
//           <div className="info-card" style={{
//             padding: '10px',
//             margin: '10px',
//             textAlign: 'center',
//             border: '2px solid #27AE60',
//             borderRadius: '10px',
//             height: '90%',
//             boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
//             transition: 'transform 0.3s ease-in-out, border-color 0.3s ease-in-out',
//             overflow: 'hidden',
//           }}
//             onMouseOver={(e) => { e.currentTarget.style.transform = 'scale(1.05)'; e.currentTarget.style.borderColor = '#27AE60'; }}
//             onMouseOut={(e) => { e.currentTarget.style.transform = 'scale(1)'; e.currentTarget.style.borderColor = '#27AE60'; }}
//           >
//             <FontAwesomeIcon icon={faClipboard} size="2x" style={{ marginBottom: '10px', color: '#27AE60' }} />

//             <h2 style={{ fontFamily: 'Playfair Display, serif', color: '#333', fontSize: '25px', fontWeight: 'bold', margin: '10px 0', lineHeight: '1.2' }}>Attendance Management</h2>
//             <p style={{ fontFamily: 'Arial, sans-serif', color: 'black', fontSize: '15px', lineHeight: '1.4' }}>
//               Effortlessly monitor student and staff attendance with precision.
//             </p>
//           </div>
//         </div>
//       </div>

//       <div className="row justify-content-center" style={{ marginTop: '10px' }}>
//         <div className="col-md-4">
//           <div className="info-card" style={{
//             padding: '10px',
//             margin: '10px',
//             textAlign: 'center',
//             border: '2px solid #27AE60',
//             borderRadius: '10px',
//             height: '90%',
//             boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
//             transition: 'transform 0.3s ease-in-out, border-color 0.3s ease-in-out',
//             overflow: 'hidden',
//           }}
//             onMouseOver={(e) => { e.currentTarget.style.transform = 'scale(1.05)'; e.currentTarget.style.borderColor = '#27AE60'; }}
//             onMouseOut={(e) => { e.currentTarget.style.transform = 'scale(1)'; e.currentTarget.style.borderColor = '#27AE60'; }}
//           >
//             <FontAwesomeIcon icon={faBookOpen} size="2x" style={{ marginBottom: '10px', color: '#27AE60' }} />

//             <h2 style={{ fontFamily: 'Playfair Display, serif', color: '#333', fontSize: '25px', fontWeight: 'bold', margin: '7px 0', lineHeight: '1.2' }}>Academic Management</h2>
//             <p style={{ fontFamily: 'Arial, sans-serif', color: 'black', fontSize: '15px', lineHeight: '1.4' }}>
//               Academic management encompasses curriculum development, teaching methodologies, assessments, teacher training, and monitoring student progress.
//             </p>
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default Services;
    

import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faUserGraduate, faChalkboardTeacher, faClipboard, faBookOpen } from '@fortawesome/free-solid-svg-icons';
import './Security.css'; // Import the external CSS file
 
const Services = () => {
  return (
    <div className="services_container">
      <div className="services_row">
        <div className="services_header">
          <h2 className="section-title">Our Services</h2>
          <img src="girl_services copy.png" alt="Services" className="section-image" />
        </div>
      </div>
 
      <div className="row justify-content-center service-cards">
        <div className="col-md-4">
          <div className="info-card">
            <FontAwesomeIcon icon={faUserGraduate} size="2x" className="Services_icon" />
            <h2 className="info-card-title">Student Management</h2>
            <p className="info-card-description">
              Managing student enrollment, attendance, grades, behavior, and communication
            </p>
          </div>
        </div>
 
        <div className="col-md-4">
          <div className="info-card">
            <FontAwesomeIcon icon={faChalkboardTeacher} size="2x" className="Services_icon" />
            <h2 className="info-card-title">Teacher Management</h2>
            <p className="info-card-description">
              Streamlining teacher schedules, performance evaluations, and professional development
            </p>
          </div>
        </div>
 
        <div className="col-md-4">
          <div className="info-card">
            <FontAwesomeIcon icon={faClipboard} size="2x" className="Services_icon" />
            <h2 className="info-card-title">Attendance Management</h2>
            <p className="info-card-description">
              Effortlessly monitor student and staff attendance with precision.
            </p>
          </div>
        </div>
      </div>
 
      <div className="row justify-content-center service-cards">
        <div className="col-md-4">
          <div className="info-card">
            <FontAwesomeIcon icon={faBookOpen} size="2x" className="Services_icon" />
            <h2 className="info-card-title">Academic Management</h2>
            <p className="info-card-description">
              Academic management encompasses curriculum development, teaching methodologies, assessments, teacher training, and monitoring student progress.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
 
export default Services;
 

