// import React from 'react';
// import styled from 'styled-components';

// const StyledContainer = styled.div`
//   position: relative;
//   z-index: 1;
//   background: linear-gradient(135deg, #012353, #43e794);
//   padding: 20px;
// `;

// const StyledRow = styled.div`
//   display: flex;
//   flex-wrap: wrap;
//   margin-left: -10px; /* Adjusted negative margin */
//   margin-right: -10px; /* Adjusted negative margin */
// `;

// const StyledImageColumn = styled.div`
//   flex: 0 0 100%;
//   padding: 0 10px 20px; /* Adjusted padding */
  
//   @media (min-width: 768px) {
//     flex: 0 0 40%; /* Reduced column width */
//     max-width: 40%; /* Reduced max-width */
//     padding: 0 30px; /* Adjusted padding */
//   }
// `;

// const StyledContentColumn = styled.div`
//   flex: 0 0 100%;
//   padding: 0 10px; /* Adjusted padding */
  
//   @media (min-width: 768px) {
//     flex: 0 0 60%; /* Increased column width */
//     max-width: 60%; /* Increased max-width */
//     padding: 0 15px; /* Adjusted padding */
//   }
// `;

// const StyledImage = styled.img`
//   width: 70%; /* Reduced width for smaller screens */
//   max-width: 100%; /* Adjusted max-width */
//   height: auto;
//   display: block;
//   border-radius: 8px;

//   @media (min-width: 768px) {
//     width: 100%; /* Adjusted width for larger screens */
//     max-width: 100%; /* Adjusted max-width for larger screens */
//   }
// `;

// const StyledTitle = styled.h1`
//   color: #ffffff;
//   font-size: 28px;
//   margin-top: 20px;
//   margin-bottom: 27px;
// `;

// const StyledText = styled.p`
//   color: #ffffff;
//   font-size: 18px; /* Increase text size for larger screens */
//   line-height: 1.6;
// `;

// const Aboutus = () => {
//   return (
//     <StyledContainer>
//       <StyledRow>
//         <StyledImageColumn className="col-12 col-lg-6">
//           <div className="discover-image">
//             <StyledImage
//               alt="girl.png"
//               loading="lazy"
//               src="blackboard-1299841_1280.png"
//             />
//           </div>
//         </StyledImageColumn>
//         <StyledContentColumn className="col-12 col-lg-6">
//           <div className="discover-content">
//             <StyledTitle>About Us</StyledTitle>
//             <StyledText>
//               BitTwoBye is a technology and professional services company specializing in analytics, operations, and product engineering. Through B2B EDU360, we facilitate the seamless transition of your school's management platform online, ensuring 24/7 accessibility. Our comprehensive solution efficiently manages vital administrative tasks, including grading, student attendance, exams and results, employee records and payroll, fee management, accounting, certificate issuance, front office operations, and transportation logistics, empowering educational institutions to enhance efficiency and deliver exceptional academic experiences.
//             </StyledText>
//           </div>
//         </StyledContentColumn>
//       </StyledRow>
//     </StyledContainer>
//   );
// };

// export default Aboutus;



import React from 'react';
import './Security.css'; // Import the CSS file
 
const Aboutus = () => {
  return (
    <div className="about_container">
      <div className="about_row">
        <div className="image-column">
          <div className="discover-image">
            <img
              alt="girl.png"
              loading="lazy"
              className="image"
              src="blackboard-1299841_1280.png"
            />
          </div>
        </div>
        <div className="content-column">
          <div className="discover-content">
            <h1 className="title">About Us</h1>
            <p className="text">
              BitTwoBye is a technology and professional services company specializing in analytics, operations, and product engineering. Through B2B EDU360, we facilitate the seamless transition of your school's management platform online, ensuring 24/7 accessibility. Our comprehensive solution efficiently manages vital administrative tasks, including grading, student attendance, exams and results, employee records and payroll, fee management, accounting, certificate issuance, front office operations, and transportation logistics, empowering educational institutions to enhance efficiency and deliver exceptional academic experiences.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
 
export default Aboutus;
 