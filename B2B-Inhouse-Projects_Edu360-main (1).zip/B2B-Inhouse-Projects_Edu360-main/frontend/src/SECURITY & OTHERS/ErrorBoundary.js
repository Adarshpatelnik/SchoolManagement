

import React from 'react';

class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { 
      hasError: false, 
      error: null, 
      info: null 
    };
  }

  static getDerivedStateFromError(error) {
    // Update state to indicate that an error occurred
    return { hasError: true, error };
  }

  componentDidCatch(error, info) {
    // Log the error and info to the console for debugging
    console.log('Error caught:', error);
    console.log('Error info:', info);

    // Save additional error info in the state
    this.setState({ info });

    // Send error details to the backend for email notification
    fetch('http://13.127.57.224:2081/api/send-error', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        error: error.toString(),  // Convert error to string
        errorInfo: info,          // Additional error info
        timestamp: new Date().toISOString(),  // Time the error occurred
      }),
    })
    .then(response => {
      if (!response.ok) {
        console.error('Failed to send error data to backend');
      } else {
        console.log('Error data sent to backend successfully');
      }
    })
    .catch(err => {
      console.error('Error sending error data:', err);
    });
  }

  render() {
    if (this.state.hasError) {
      // Display a user-friendly popup message when an error occurs
      return (
        <div className="error-popup">
          <p>Something went wrong. Please wait, we are updating!</p>
        </div>
      );
    }

    // If no error, render the children normally
    return this.props.children;
  }
}

export default ErrorBoundary;
