

// import React, { createContext, useState, useEffect, useContext } from 'react';

// export const AuthContext = createContext();

// export const AuthProvider = ({ children }) => {
//   const [isAuthenticated, setIsAuthenticated] = useState(
//     sessionStorage.getItem('isAuthenticated') === 'true'
//   );

//   useEffect(() => {
//     const storedAuth = sessionStorage.getItem('isAuthenticated') === 'true';
//     setIsAuthenticated(storedAuth);
//   }, []);

//   const login = () => {
//     setIsAuthenticated(true);
//     sessionStorage.setItem('isAuthenticated', 'true');
//   };

//   const logout = () => {
//     setIsAuthenticated(false);
//     sessionStorage.removeItem('isAuthenticated');
//   };

//   return (
//     <AuthContext.Provider value={{ isAuthenticated, login, logout }}>
//       {children}
//     </AuthContext.Provider>
//   );
// };

// // Custom hook to use the auth context
// export const useAuth = () => {
//   return useContext(AuthContext);
// };



import React, { createContext, useState, useEffect, useContext } from 'react';
 
export const AuthContext = createContext();
 
export const AuthProvider = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(
    sessionStorage.getItem('isAuthenticated') === 'true'
  );
 
  useEffect(() => {
    const storedAuth = sessionStorage.getItem('isAuthenticated') === 'true';
    setIsAuthenticated(storedAuth);
  }, []);
 
  const login = () => {
    setIsAuthenticated(true);
    sessionStorage.setItem('isAuthenticated', 'true');
  };
 
  const logout = () => {
    setIsAuthenticated(false);
    sessionStorage.removeItem('isAuthenticated');
  };
 
  return (
    <AuthContext.Provider value={{ isAuthenticated, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};
 
// Custom hook to use the auth context
export const useAuth = () => {
  return useContext(AuthContext);
};
 