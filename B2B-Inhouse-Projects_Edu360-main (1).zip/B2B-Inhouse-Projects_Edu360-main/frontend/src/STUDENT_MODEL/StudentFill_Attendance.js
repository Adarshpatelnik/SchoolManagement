// import React, { useState, useEffect } from 'react';
// import axios from 'axios';
// import DatePicker from 'react-datepicker';
// import 'react-datepicker/dist/react-datepicker.css';
// // import Landing  from '/home/ec2-user/Edu360/SchoolManagement/frontend/src/ADMIN_MODEL/Landing.js';

// const StudentFillAttendance = () => {
//   const [studentDetails, setStudentDetails] = useState([]);
//   const [selectedDate, setSelectedDate] = useState(new Date());
//   const [attendance, setAttendance] = useState([]);
//   const [searchText, setSearchText] = useState('');
//   const [searchStudentName, setSearchStudentName] = useState('');
//   const [searchStudentId, setSearchStudentId] = useState('');
//   const [selectAll, setSelectAll] = useState(false); // State for Select All checkbox

//   useEffect(() => {
//     fetchStudentDetails(selectedDate);
//     addGlobalStyles();
//   }, [selectedDate]);

//   useEffect(() => {
//     // When studentDetails change, initialize attendance state
//     const initialAttendance = studentDetails.map(student => ({
//       studentId: student.studentId,
//       date: student.date,
//       status: 'absent' // Default to absent
//     }));
//     setAttendance(initialAttendance);
//   }, [studentDetails]);

//   const fetchStudentDetails = (selectedDate) => {
//     const formattedDate = formatDate(selectedDate);
//     axios.get(`http://13.127.57.224:2081/api/studentAttendance?date=${formattedDate}`)
//       .then(response => {
//         const initialAttendance = response.data.map(student => ({
//           studentId: student.STUDENT_ID,
//           studentName: student.STUDENT_NAME,
//           class: student.CLASS,
//           session: student.SESSION,
//           date: formattedDate,
//           status: student.STATUS
//         }));
//         setStudentDetails(initialAttendance);
//       })
//       .catch(error => {
//         console.error('Error fetching student details:', error);
//       });
//   };

//   const handleDateChange = (date) => {
//     setSelectedDate(date);
//   };

//   const handleStatusChange = (index, newStatus) => {
//     if (index >= 0 && index < attendance.length) {
//       const updatedAttendance = [...attendance];
//       updatedAttendance[index] = {
//         ...updatedAttendance[index],
//         status: newStatus
//       };
//       setAttendance(updatedAttendance);
//     } else {
//       console.error(`Invalid index ${index} for attendance array`);
//     }
//   };

//   const handleDropdownChange = (index, newStatus) => {
//     if (index >= 0 && index < attendance.length) {
//       const updatedAttendance = [...attendance];
//       updatedAttendance[index] = {
//         ...updatedAttendance[index],
//         status: newStatus
//       };
//       setAttendance(updatedAttendance);
//     } else {
//       console.error(`Invalid index ${index} for attendance array`);
//     }
//   };

//   const handleSearchChange = (e) => {
//     setSearchText(e.target.value);
//   };

//   const handleStudentNameSearchChange = (e) => {
//     setSearchStudentName(e.target.value);
//   };

//   const handleStudentIdSearchChange = (e) => {
//     setSearchStudentId(e.target.value);
//   };

//   const submitAttendance = () => {
//     const updatedAttendance = attendance.filter(att => att.status !== 'absent');
//     axios.post('http://13.127.57.224:2081/api/studentAttendances', updatedAttendance)
//       .then(response => {
//         console.log('Attendance submitted successfully:', response.data);
//         alert('Attendance submitted successfully.');
//       })
//       .catch(error => {
//         console.error('Error submitting attendance:', error);
//         alert('Failed to submit attendance. Please try again later.');
//       });
//   };

//   const formatDate = (date) => {
//     return `${date.getFullYear()}-${('0' + (date.getMonth() + 1)).slice(-2)}-${('0' + date.getDate()).slice(-2)}`;
//   };

//   const addGlobalStyles = () => {
//     const style = document.createElement('style');
//     style.textContent = `
//       body, h1, h2, h3, h4, h5, h6, p, a, input, button, th, td, label, select {
//         font-family: 'Arial', sans-serif;
//       }

//       .header-input {
//         background-color: #009CE0;
//         color: white;
//         border: 2px solid #ccc;
//         padding: 5px;
//         border-radius: 3px;
//         box-shadow: inset 0 1px 2px rgba(234, 218, 218, 0.1);
//         text-align: center;
//         margin-right: 10px;
//       }

//       .header-input::placeholder {
//         color: white;
//       }

//        .table-container {
//         display: flex;
//         justify-content: left;
//       }

//       .table {
//         margin: 0 auto;
//         width: 90%; /* Adjust the width as needed */
//       }


//       .table th {
//          border: 1px solid  black;  
//         padding: 2px;
//         text-align: center; 
//         white-space: nowrap;
//         overflow: hidden;
//         text-overflow: ellipsis;
//         background-color: #D5DBDB ;
//         color: black; 
//         font-weight: bold; 
//         height: 40px; 
//         box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); 
//         transition: background-color 0.3s ease; 
//       }

//       .table td {
//          border: 1px solid black;  
//         padding: 7px;
//         white-space: nowrap; 
//         text-align: left; 
//         overflow: hidden; 
//         text-overflow: ellipsis;
//       }

//       .sticky-header th {
//         position: sticky;
//          padding: 3px;
//         top: 0;
//         z-index: 999;
//         background-color: #D5DBDB;
//         border: 1px solid black;
//       }

//       .table-container {
//         max-height: 60vh;
//         overflow-y: auto;
//       }

//       .date-picker {
//         padding: 8px;
//         font-size: 14px;
//         border: 1px solid #ccc;
//         border-radius: 5px;
//         width: 150px;
//       }

//       .date-picker-wrapper {
//         display: inline-block;
//       }

//       .attendance-status {
//         margin: 0;
//         display: flex;
//         justify-content: center;
//         align-items: center; /* Align items vertically */
//       }

//       .attendance-status label {
//         margin-right: 10px;
//       }

//       .submit-button {
//         padding: 12px 24px;
//         font-size: 16px;
//         background: linear-gradient(to right, #012353, #27ae60);
//         color: white;
//         border: none;
//         cursor: pointer;
//         border-radius: 5px;
//         box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
//         margin-top: 0px;
//       }

//       .dropdown {
//         width: 100px;
//         margin-left: 10px;
//       }
//     `;
//     document.head.appendChild(style);
//   };

//   const filterStudentsBySearch = (student) => {
//     const searchLower = searchText.toLowerCase();
//     const searchNameLower = searchStudentName.toLowerCase();
//     const searchIdLower = searchStudentId.toLowerCase();
//     const formattedDate = formatDate(selectedDate);

//     return (
//       student.class.toLowerCase().includes(searchLower) &&
//       student.date === formattedDate &&
//       student.studentName.toLowerCase().includes(searchNameLower) &&
//       student.studentId.toLowerCase().includes(searchIdLower)
//     );
//   };

//   const handleReset = () => {
//     setSearchStudentName('');
//     setSearchStudentId('');
//     setSearchText('');
//     fetchStudentDetails(selectedDate); // Reload student details after reset
//   };

//   const handleSelectAll = () => {
//     const updatedAttendance = attendance.map(student => ({
//       ...student,
//       status: selectAll ? 'absent' : 'present' // Toggle the status based on selectAll state
//     }));
//     setAttendance(updatedAttendance);
//     setSelectAll(!selectAll); // Toggle selectAll state
//   };

//   return (
//     <div>
//     {/* <Landing /> */}
  
//     <div className="container-fluid" style={{ marginLeft: '12vh', marginTop: '12vh',  width: '94%', padding: 0 }}>
//     <div style={{ fontFamily: 'Arial, sans-serif', maxWidth: '99%', margin: 'auto' }}>

//       <div style={{ marginBottom: '20px', display: 'flex', justifyContent: 'flex-start', alignItems: 'center' }}>
//         <div style={{ marginRight: '20px', textAlign: 'center' }}>
//           <label style={{ marginRight: '10px', fontSize: '16px', fontWeight: 'bold' }}>Select Date</label>
//           <DatePicker
//             selected={selectedDate}
//             onChange={date => handleDateChange(date)}
//             dateFormat="yyyy-MM-dd"
//             className="date-picker"
//             wrapperClassName="date-picker-wrapper"
//           />
//         </div>

//         <div style={{ textAlign: 'center', marginRight: '20px' }}>
//           <label style={{ marginRight: '10px', fontSize: '16px', fontWeight: 'bold' }}>Class </label>
//           <input
//             type="text"
//             value={searchText}
//             onChange={handleSearchChange}
//             style={{ padding: '8px', fontSize: '14px', borderRadius: '5px', border: '1px solid #ccc', width: '200px' }}
//           />
//         </div>

//         <div style={{ textAlign: 'center', marginRight: '20px' }}>
//           <label style={{ marginRight: '10px', fontSize: '16px', fontWeight: 'bold' }}>Student Name </label>
//           <input
//             type="text"
//             value={searchStudentName}
//             onChange={handleStudentNameSearchChange}
//             placeholder=" "
//             style={{ padding: '8px', fontSize: '14px', borderRadius: '5px', border: '1px solid #ccc', width: '200px' }}
//           />
//         </div>
		
// 		<div style={{ textAlign: 'center', marginRight: '20px' }}>
//           <label style={{ marginRight: '10px', fontSize: '16px', fontWeight: 'bold' }}>Student ID </label>
//           <input
//             type="text"
//             value={searchStudentId}
//             onChange={handleStudentIdSearchChange}
//             placeholder=" "
//             style={{ padding: '8px', fontSize: '14px', borderRadius: '5px', border: '1px solid #ccc', width: '200px' }}
//           />
//         </div>

//         <div style={{ textAlign: 'center', marginTop: '5px' }}>
//           <label style={{ marginRight: '10px' }}>
//             <input
//               type="checkbox"
//               checked={selectAll}
//               onChange={handleSelectAll}
//             /> Select All
//           </label>
//         </div>

//         <div className="ml-3">
//           <button
//             type="button"
//             className="btn btn-primary"
//             onClick={handleReset}
//             style={{ background: '#0d2b84', border: 'none' }}
//           >
//             Reset
//           </button>
//         </div>
//       </div>

//       <div className="table-container">
//         <table className="table">
//           <thead className="sticky-header">
//             <tr>
//               <th>Student ID</th>
//               <th>Student Name</th>
//               <th>Class</th>
//               <th>Session</th>
//               <th>Date</th>
//               <th>Attendance Status</th>
//             </tr>
//           </thead>
//           <tbody>
//             {studentDetails.filter(filterStudentsBySearch).map((student, index) => (
//               <tr key={student.studentId}>
//                 <td>{student.studentId}</td>
//                 <td>{student.studentName}</td>
//                 <td>{student.class}</td>
//                 <td>{student.session}</td>
//                 <td>{student.date}</td>
//                 <td className="attendance-status">
//                   <select
//                     className="dropdown"
//                     value={attendance[index]?.status}
//                     onChange={(e) => handleDropdownChange(index, e.target.value)}
//                   >
//                     <option value="present">Present</option>
//                     <option value="absent">Absent</option>
//                   </select>
//                 </td>
//               </tr>
//             ))}
//           </tbody>
//         </table>
//       </div>

//       <div style={{ textAlign: 'center', marginTop: '20px' }}>
//         <button
//           type="button"
//           className="submit-button"
//           onClick={submitAttendance}
//         >
//           Submit Attendance
//         </button>
//       </div>
//     </div>
//     </div>
//     </div>
//   );
// };

// export default StudentFillAttendance;








// import React, { useState, useEffect } from 'react';
// import axios from 'axios';
// import DatePicker from 'react-datepicker';
// import 'react-datepicker/dist/react-datepicker.css';
// import { AgGridReact } from 'ag-grid-react'; // Import AG Grid
// import 'ag-grid-community/styles/ag-grid.css'; // AG Grid styles
// import 'ag-grid-community/styles/ag-theme-alpine.css'; // AG Grid theme

// const StudentFillAttendance = () => {
//   const [studentDetails, setStudentDetails] = useState([]);
//   const [selectedDate, setSelectedDate] = useState(new Date());
//   const [attendance, setAttendance] = useState([]);
//   const [searchText, setSearchText] = useState('');
//   const [searchStudentName, setSearchStudentName] = useState('');
//   const [searchStudentId, setSearchStudentId] = useState('');
//   const [selectAll, setSelectAll] = useState(false); // State for Select All checkbox

//   useEffect(() => {
//     fetchStudentDetails(selectedDate);
//     addGlobalStyles();
//   }, [selectedDate]);

//   useEffect(() => {
//     // When studentDetails change, initialize attendance state
//     const initialAttendance = studentDetails.map(student => ({
//       studentId: student.studentId,
//       date: student.date,
//       status: 'absent' // Default to absent
//     }));
//     setAttendance(initialAttendance);
//   }, [studentDetails]);

//   const fetchStudentDetails = (selectedDate) => {
//     const formattedDate = formatDate(selectedDate);
//     axios.get(`http://13.127.57.224:2081/api/studentAttendance?date=${formattedDate}`)
//       .then(response => {
//         const initialAttendance = response.data.map(student => ({
//           studentId: student.STUDENT_ID,
//           studentName: student.STUDENT_NAME,
//           class: student.CLASS,
//           session: student.SESSION,
//           date: formattedDate,
//           status: student.STATUS
//         }));
//         setStudentDetails(initialAttendance);
//       })
//       .catch(error => {
//         console.error('Error fetching student details:', error);
//       });
//   };

//   const handleDateChange = (date) => {
//     setSelectedDate(date);
//   };

//   const handleDropdownChange = (params) => {
//     const { data, value } = params;
//     const updatedAttendance = attendance.map(att => {
//       if (att.studentId === data.studentId) {
//         return { ...att, status: value };
//       }
//       return att;
//     });
//     setAttendance(updatedAttendance);
//   };

//   const handleSearchChange = (e) => {
//     setSearchText(e.target.value);
//   };

//   const handleStudentNameSearchChange = (e) => {
//     setSearchStudentName(e.target.value);
//   };

//   const handleStudentIdSearchChange = (e) => {
//     setSearchStudentId(e.target.value);
//   };

//   const submitAttendance = () => {
//     const updatedAttendance = attendance.filter(att => att.status !== 'absent');
//     axios.post('http://13.127.57.224:2081/api/studentAttendances', updatedAttendance)
//       .then(response => {
//         console.log('Attendance submitted successfully:', response.data);
//         alert('Attendance submitted successfully.');
//       })
//       .catch(error => {
//         console.error('Error submitting attendance:', error);
//         alert('Failed to submit attendance. Please try again later.');
//       });
//   };

//   const formatDate = (date) => {
//     return `${date.getFullYear()}-${('0' + (date.getMonth() + 1)).slice(-2)}-${('0' + date.getDate()).slice(-2)}`;
//   };

//   const addGlobalStyles = () => {
//     const style = document.createElement('style');
//     style.textContent = `
//       body, h1, h2, h3, h4, h5, h6, p, a, input, button, th, td, label, select {
//         font-family: 'Arial', sans-serif;
//       }
  
//       .header-input {
//         background-color: #009CE0;
//         color: white;
//         border: 2px solid #ccc;
//         padding: 5px;
//         border-radius: 3px;
//         box-shadow: inset 0 1px 2px rgba(234, 218, 218, 0.1);
//         text-align: center;
//         margin-right: 10px;
//       }
  
//       .header-input::placeholder {
//         color: white;
//       }
  
//       .submit-button {
//         padding: 8px 12px; /* Reduced padding for height */
//         font-size: 14px; /* Slightly smaller font size */
//         background: linear-gradient(to right, #012353, #27ae60);
//         color: white;
//         border: none;
//         cursor: pointer;
//         border-radius: 5px;
//         box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
//         margin-top: 1%;
//       }
//     `;
//     document.head.appendChild(style);
//   };
  

//   const filterStudentsBySearch = (student) => {
//     const searchLower = searchText.toLowerCase();
//     const searchNameLower = searchStudentName.toLowerCase();
//     const searchIdLower = searchStudentId.toLowerCase();
//     const formattedDate = formatDate(selectedDate);

//     return (
//       student.class.toLowerCase().includes(searchLower) &&
//       student.date === formattedDate &&
//       student.studentName.toLowerCase().includes(searchNameLower) &&
//       student.studentId.toLowerCase().includes(searchIdLower)
//     );
//   };

//   const handleReset = () => {
//     setSearchStudentName('');
//     setSearchStudentId('');
//     setSearchText('');
//     fetchStudentDetails(selectedDate); // Reload student details after reset
//   };

//   const handleSelectAll = () => {
//     const updatedAttendance = attendance.map(student => ({
//       ...student,
//       status: selectAll ? 'absent' : 'present' // Toggle the status based on selectAll state
//     }));
//     setAttendance(updatedAttendance);
//     setSelectAll(!selectAll); // Toggle selectAll state
//   };

//   const columnDefs = [
//     { headerName: "Student ID", field: "studentId", sortable: true, filter: true },
//     { headerName: "Student Name", field: "studentName", sortable: true, filter: true },
//     { headerName: "Class", field: "class", sortable: true, filter: true },
//     { headerName: "Session", field: "session", sortable: true, filter: true },
//     { headerName: "Date", field: "date", sortable: true, filter: true },
//     {
//       headerName: "Attendance Status",
//       field: "status",
//       cellEditor: 'agSelectCellEditor',
//       cellEditorParams: {
//         values: ['present', 'absent'], // Dropdown options for attendance
//       },
//       editable: true,
//       valueSetter: (params) => {
//         params.data.status = params.newValue; // Update status on change
//         return true; // Return true to trigger a redraw of the grid
//       },
//     },
//   ];
  
//   return (
//     <div>
//       <div className="container-fluid" style={{ marginTop: '5vh', width: '100%', padding: 0 }}>
//         <div style={{ fontFamily: 'Arial, sans-serif', maxWidth: '99%', margin: 'auto' }}>
//           <div style={{ marginBottom: '10px', display: 'flex', justifyContent: 'flex-start', alignItems: 'center' }}>
//             <div style={{ marginRight: '20px', textAlign: 'center' }}>
//               <label style={{ marginRight: '10px',marginTop: '5%', fontSize: '16px', fontWeight: 'bold' }}> Date</label>
//               <DatePicker
//                 selected={selectedDate}
//                 onChange={date => handleDateChange(date)}
//                 dateFormat="yyyy-MM-dd"
//                 className="date-picker"
//               />
//             </div>

         

         
		
            

//             <button className="submit-button" onClick={handleReset}>Reset</button>
//           </div>

//           <div className="ag-theme-alpine" style={{ height: '500px', width: '100%' }}>
//             <AgGridReact
//               rowData={studentDetails.filter(filterStudentsBySearch)}
//               columnDefs={columnDefs}
//               onCellValueChanged={handleDropdownChange}
//               domLayout='autoHeight'
//               rowHeight={40}
//               paginationPageSize={10}
//               pagination={true}
//               defaultColDef={{
//                 flex: 1,
//                 minWidth: 150,
//               }}
//             />
//           </div>

//           <button className="submit-button" onClick={submitAttendance}>Submit Attendance</button>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default StudentFillAttendance;








import React, { useState, useEffect } from 'react';
import axios from 'axios';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import { AgGridReact } from 'ag-grid-react'; // Import AG Grid
import 'ag-grid-community/styles/ag-grid.css'; // AG Grid styles
import 'ag-grid-community/styles/ag-theme-alpine.css'; // AG Grid theme

const StudentFillAttendance = () => {
  const [studentDetails, setStudentDetails] = useState([]);
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [attendance, setAttendance] = useState([]);
  const [searchText, setSearchText] = useState('');
  const [searchStudentName, setSearchStudentName] = useState('');
  const [searchStudentId, setSearchStudentId] = useState('');
  const [selectAll, setSelectAll] = useState(false); // State for Select All checkbox

  useEffect(() => {
    fetchStudentDetails(selectedDate);
    addGlobalStyles();
  }, [selectedDate]);

  useEffect(() => {
    // When studentDetails change, initialize attendance state
    const initialAttendance = studentDetails.map(student => ({
      studentId: student.studentId,
      date: student.date,
      status: 'absent' // Default to absent
    }));
    setAttendance(initialAttendance);
  }, [studentDetails]);

  const fetchStudentDetails = (selectedDate) => {
    const formattedDate = formatDate(selectedDate);
    axios.get(`http://13.127.57.224:2081/api/studentAttendance?date=${formattedDate}`)
      .then(response => {
        const initialAttendance = response.data.map(student => ({
          studentId: student.STUDENT_ID,
          studentName: student.STUDENT_NAME,
          class: student.CLASS,
          session: student.SESSION,
          date: formattedDate,
          status: student.STATUS
        }));
        setStudentDetails(initialAttendance);
      })
      .catch(error => {
        console.error('Error fetching student details:', error);
      });
  };

  const handleDateChange = (date) => {
    setSelectedDate(date);
  };

  const handleDropdownChange = (params) => {
    const { data, value } = params;
    const updatedAttendance = attendance.map(att => {
      if (att.studentId === data.studentId) {
        return { ...att, status: value };
      }
      return att;
    });
    setAttendance(updatedAttendance);
  };

  const handleSearchChange = (e) => {
    setSearchText(e.target.value);
  };

  const handleStudentNameSearchChange = (e) => {
    setSearchStudentName(e.target.value);
  };

  const handleStudentIdSearchChange = (e) => {
    setSearchStudentId(e.target.value);
  };

  const submitAttendance = () => {
    const updatedAttendance = attendance.filter(att => att.status !== 'absent');
    axios.post('http://13.127.57.224:2081/api/studentAttendances', updatedAttendance)
      .then(response => {
        console.log('Attendance submitted successfully:', response.data);
        alert('Attendance submitted successfully.');
      })
      .catch(error => {
        console.error('Error submitting attendance:', error);
        alert('Failed to submit attendance. Please try again later.');
      });
  };

  const formatDate = (date) => {
    return `${date.getFullYear()}-${('0' + (date.getMonth() + 1)).slice(-2)}-${('0' + date.getDate()).slice(-2)}`;
  };

  const addGlobalStyles = () => {
    const style = document.createElement('style');
    style.textContent = `
      body, h1, h2, h3, h4, h5, h6, p, a, input, button, th, td, label, select {
        font-family: 'Arial', sans-serif;
      }
  
      .header-input {
        background-color: #009CE0;
        color: white;
        border: 2px solid #ccc;
        padding: 5px;
        border-radius: 3px;
        box-shadow: inset 0 1px 2px rgba(234, 218, 218, 0.1);
        text-align: center;
        margin-right: 10px;
      }
  
      .header-input::placeholder {
        color: white;
      }
  
      .submit-button {
        padding: 8px 12px; /* Reduced padding for height */
        font-size: 14px; /* Slightly smaller font size */
        background: linear-gradient(to right, #012353, #27ae60);
        color: white;
        border: none;
        cursor: pointer;
        border-radius: 5px;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
        margin-top: 1%;
      }
    `;
    document.head.appendChild(style);
  };

  const filterStudentsBySearch = (student) => {
    const searchLower = searchText.toLowerCase();
    const searchNameLower = searchStudentName.toLowerCase();
    const searchIdLower = searchStudentId.toLowerCase();
    const formattedDate = formatDate(selectedDate);

    return (
      student.class.toLowerCase().includes(searchLower) &&
      student.date === formattedDate &&
      student.studentName.toLowerCase().includes(searchNameLower) &&
      student.studentId.toLowerCase().includes(searchIdLower)
    );
  };

  const handleReset = () => {
    setSearchStudentName('');
    setSearchStudentId('');
    setSearchText('');
    fetchStudentDetails(selectedDate); // Reload student details after reset
  };

  const handleSelectAll = () => {
    const updatedAttendance = attendance.map(student => ({
      ...student,
      status: selectAll ? 'absent' : 'present' // Toggle the status based on selectAll state
    }));
    setAttendance(updatedAttendance);
    setSelectAll(!selectAll); // Toggle selectAll state
  };

  const columnDefs = [
    { headerName: "Student ID", field: "studentId", sortable: true, filter: true },
    { headerName: "Student Name", field: "studentName", sortable: true, filter: true },
    { headerName: "Class", field: "class", sortable: true, filter: true },
    { headerName: "Session", field: "session", sortable: true, filter: true },
    { headerName: "Date", field: "date", sortable: true, filter: true },
    {
      headerName: "Attendance Status",
      field: "status",
      cellEditor: 'agSelectCellEditor',
      cellEditorParams: {
        values: ['present', 'absent'], // Dropdown options for attendance
      },
      editable: true,
      valueSetter: (params) => {
        params.data.status = params.newValue; // Update status on change
        return true; // Return true to trigger a redraw of the grid
      },
    },
  ];

  return (
    <div>
      <div className="container-fluid" style={{ marginTop: '5vh', width: '100%', padding: 0 }}>
        <div style={{ fontFamily: 'Arial, sans-serif', maxWidth: '99%', margin: 'auto' }}>
          <div style={{ marginBottom: '10px', display: 'flex', justifyContent: 'flex-start', alignItems: 'center' }}>
            <div style={{ marginRight: '20px', textAlign: 'center' }}>
              <label style={{ marginRight: '10px', marginTop: '5%', fontSize: '16px', fontWeight: 'bold' }}> Date</label>
              <DatePicker
                selected={selectedDate}
                onChange={date => handleDateChange(date)}
                dateFormat="yyyy-MM-dd"
                className="date-picker"
              />
            </div>

            <button className="submit-button" onClick={handleReset}>Reset</button>
          </div>

          <div className="ag-theme-alpine" style={{ height: '70vh', width: '100%', overflowY: 'auto' }}>
            <AgGridReact
              rowData={studentDetails.filter(filterStudentsBySearch)}
              columnDefs={columnDefs}
              onCellValueChanged={handleDropdownChange}
              rowHeight={30} // Reduced row height
              pagination={false} // Disable pagination
              defaultColDef={{
                flex: 1,
                minWidth: 150,
              }}
            />
          </div>

          <button className="submit-button" onClick={submitAttendance}>Submit Attendance</button>
        </div>
      </div>
    </div>
  );
};

export default StudentFillAttendance;
