import React, { useState, useEffect } from 'react';
import axios from 'axios';
import styled from 'styled-components';
import { useParams, useNavigate } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faAngleDoubleLeft, faEdit, faSave } from '@fortawesome/free-solid-svg-icons';

const FormWrapper = styled.div`
    max-width: 100%;
    margin: 30px auto;
    padding: 10px;
    background-color: #f2f5f8;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
`;

const Title = styled.h1`
    font-size: 1.5rem;
    padding: 1.3rem;
    background-color: #34495E;
    color: #FFFFFF;
    border-radius: 10px;
    display: flex;
    align-items: center;
`;

const StyledForm = styled.form`
    display: flex;
    flex-direction: column;
    gap: 20px;
`;

const Section = styled.div`
    margin-top: 20px;
`;

const SectionTitle = styled.h3`
    color: black;
    padding-bottom: 10px;
    margin-bottom: 10px;
    position: relative;
    display: inline-block;

    &::after {
        content: '';
        position: absolute;
        left: 0;
        bottom: 0;
        width: 100%;
        height: 3px;
        background: linear-gradient(to right, #012353, #27ae60);
    }
`;

const Label = styled.label`
    color: #333;
`;

const Input = styled.input`
    width: calc(100% - 20px);
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 4px;
    font-size: 14px;
    transition: border-color 0.3s ease;

    &:focus {
        outline: none;
        border-color: #007bff;
        box-shadow: 0 0 5px rgba(0, 123, 255, 0.5);
    }
`;

const Button = styled.button`
    padding: 10px 40px;
    background: linear-gradient(to right, #012353, #27ae60);
    color: #fff;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    transition: background-color 0.3s ease;

    &:hover {
        background: linear-gradient(to right, #011d42, #1e8e50);
    }
`;

const ParentForm = () => {
    const { parentId } = useParams();
    const [formData, setFormData] = useState({
        PARENT_ID: '',
        FATHER_NAME: '',
        FATHER_OCCUPATION: '',
        FATHER_EDUCATION: '',
        FATHER_ADHAR_ID: '',
        FATHER_MOBILE_NUMBER: '',
        FATHER_INCOME: '',
        MOTHER_NAME: '',
        MOTHER_OCCUPATION: '',
        MOTHER_EDUCATION: '',
        MOTHER_ADHAR_ID: '',
        MOTHER_MOBILE_NUMBER: '',
        MOTHER_INCOME: '',
        PRIMARY_CONTACT_NUMBER: ''
    });
    const navigate = useNavigate();
    const [editMode, setEditMode] = useState(false);

    useEffect(() => {
        const fetchData = async () => {
            try {
                const response = await axios.get(`http://13.127.57.224:2081/api/parent_Detail_Update/${parentId}`);
                const data = response.data;
                setFormData(data);
            } catch (error) {
                console.error('Error fetching data:', error);
            }
        };

        if (parentId) {
            fetchData();
        }
    }, [parentId]);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData(prevState => ({
            ...prevState,
            [name]: value
        }));
    };

    const handleBackClick = () => {
        navigate(-1);
    };

    const handleEditClick = () => {
        setEditMode(true);
    };

    const handleSaveClick = async (e) => {
        e.preventDefault();

        try {
            if (editMode) {
                await axios.put(`http://13.127.57.224:2081/api/parent_Detail_Update/${parentId}`, formData);
                alert('Data updated successfully!');
                setEditMode(false);
                navigate(-1); // Navigate back after successful save
            }
        } catch (error) {
            console.error('Error updating data:', error);
            alert('Error updating data. Please check console for details.');
        }
    };

    return (
        <div>
            <FormWrapper>
                <Title>
                    <FontAwesomeIcon icon={faAngleDoubleLeft} style={{ marginRight: '10px', cursor: 'pointer' }} onClick={handleBackClick} />
                    Parent Details
                </Title>
                <StyledForm onSubmit={handleSaveClick}>
                    <Section>
                        <SectionTitle>Parent Information</SectionTitle>
                        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px' }}>
                            <div>
                                <Label htmlFor="PARENT_ID">Parent ID</Label>
                                <Input
                                    type="text"
                                    id="PARENT_ID"
                                    name="PARENT_ID"
                                    value={formData.PARENT_ID}
                                    onChange={handleChange}
                                    required
                                    readOnly={!editMode}
                                />
                            </div>
                            <div>
                                <Label htmlFor="FATHER_NAME">Father Name</Label>
                                <Input
                                    type="text"
                                    id="FATHER_NAME"
                                    name="FATHER_NAME"
                                    value={formData.FATHER_NAME}
                                    onChange={handleChange}
                                    readOnly={!editMode}
                                />
                            </div>
                            <div>
                                <Label htmlFor="FATHER_OCCUPATION">Father Occupation</Label>
                                <Input
                                    type="text"
                                    id="FATHER_OCCUPATION"
                                    name="FATHER_OCCUPATION"
                                    value={formData.FATHER_OCCUPATION}
                                    onChange={handleChange}
                                    readOnly={!editMode}
                                />
                            </div>
                            <div>
                                <Label htmlFor="FATHER_EDUCATION">Father Education</Label>
                                <Input
                                    type="text"
                                    id="FATHER_EDUCATION"
                                    name="FATHER_EDUCATION"
                                    value={formData.FATHER_EDUCATION}
                                    onChange={handleChange}
                                    readOnly={!editMode}
                                />
                            </div>
                            <div>
                                <Label htmlFor="FATHER_ADHAR_ID">Father Aadhaar ID</Label>
                                <Input
                                    type="text"
                                    id="FATHER_ADHAR_ID"
                                    name="FATHER_ADHAR_ID"
                                    value={formData.FATHER_ADHAR_ID}
                                    onChange={handleChange}
                                    readOnly={!editMode}
                                />
                            </div>
                            <div>
                                <Label htmlFor="FATHER_MOBILE_NUMBER">Father Mobile Number</Label>
                                <Input
                                    type="text"
                                    id="FATHER_MOBILE_NUMBER"
                                    name="FATHER_MOBILE_NUMBER"
                                    value={formData.FATHER_MOBILE_NUMBER}
                                    onChange={handleChange}
                                    readOnly={!editMode}
                                />
                            </div>
                            <div>
                                <Label htmlFor="FATHER_INCOME">Father Income</Label>
                                <Input
                                    type="text"
                                    id="FATHER_INCOME"
                                    name="FATHER_INCOME"
                                    value={formData.FATHER_INCOME}
                                    onChange={handleChange}
                                    readOnly={!editMode}
                                />
                            </div>
                            <div>
                                <Label htmlFor="MOTHER_NAME">Mother Name</Label>
                                <Input
                                    type="text"
                                    id="MOTHER_NAME"
                                    name="MOTHER_NAME"
                                    value={formData.MOTHER_NAME}
                                    onChange={handleChange}
                                    readOnly={!editMode}
                                />
                            </div>
                            <div>
                                <Label htmlFor="MOTHER_OCCUPATION">Mother Occupation</Label>
                                <Input
                                    type="text"
                                    id="MOTHER_OCCUPATION"
                                    name="MOTHER_OCCUPATION"
                                    value={formData.MOTHER_OCCUPATION}
                                    onChange={handleChange}
                                    readOnly={!editMode}
                                />
                            </div>
                            <div>
                                <Label htmlFor="MOTHER_EDUCATION">Mother Education</Label>
                                <Input
                                    type="text"
                                    id="MOTHER_EDUCATION"
                                    name="MOTHER_EDUCATION"
                                    value={formData.MOTHER_EDUCATION}
                                    onChange={handleChange}
                                    readOnly={!editMode}
                                />
                            </div>
                            <div>
                                <Label htmlFor="MOTHER_ADHAR_ID">Mother Aadhaar ID</Label>
                                <Input
                                    type="text"
                                    id="MOTHER_ADHAR_ID"
                                    name="MOTHER_ADHAR_ID"
                                    value={formData.MOTHER_ADHAR_ID}
                                    onChange={handleChange}
                                    readOnly={!editMode}
                                />
                            </div>
                            <div>
                                <Label htmlFor="MOTHER_MOBILE_NUMBER">Mother Mobile Number</Label>
                                <Input
                                    type="text"
                                    id="MOTHER_MOBILE_NUMBER"
                                    name="MOTHER_MOBILE_NUMBER"
                                    value={formData.MOTHER_MOBILE_NUMBER}
                                    onChange={handleChange}
                                    readOnly={!editMode}
                                />
                            </div>
                            <div>
                                <Label htmlFor="MOTHER_INCOME">Mother Income</Label>
                                <Input
                                    type="text"
                                    id="MOTHER_INCOME"
                                    name="MOTHER_INCOME"
                                    value={formData.MOTHER_INCOME}
                                    onChange={handleChange}
                                    readOnly={!editMode}
                                />
                            </div>
                            <div>
                                <Label htmlFor="PRIMARY_CONTACT_NUMBER">Primary Contact Number</Label>
                                <Input
                                    type="text"
                                    id="PRIMARY_CONTACT_NUMBER"
                                    name="PRIMARY_CONTACT_NUMBER"
                                    value={formData.PRIMARY_CONTACT_NUMBER}
                                    onChange={handleChange}
                                    readOnly={!editMode}
                                />
                            </div>
                        </div>
                    </Section>
                    <div style={{ display: 'flex', justifyContent: 'center', gap: '10px', marginTop: '20px' }}>
                        {!editMode && (
                            <Button type="button" onClick={handleEditClick}>
                                <FontAwesomeIcon icon={faEdit} style={{ marginRight: '5px' }} /> Edit
                            </Button>
                        )}
                        {editMode && (
                            <Button type="submit">
                                <FontAwesomeIcon icon={faSave} style={{ marginRight: '5px' }} /> Save
                            </Button>
                        )}
                    </div>
                </StyledForm>
            </FormWrapper>
        </div>
    );
};

export default ParentForm;
