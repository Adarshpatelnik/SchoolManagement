import React, { useState, useEffect } from 'react';
import axios from 'axios';
import styled from 'styled-components';
import { useParams, useNavigate } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faAngleDoubleLeft, faEdit, faSave } from '@fortawesome/free-solid-svg-icons';

const FormWrapper = styled.div`
    max-width: 100%;
    margin: 30px auto;
        padding: 10px;
    background-color: #f2f5f8;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
`;

const Title = styled.h1`
    font-size: 1.5rem;
    padding: 1.1rem;
    background-color: #34495E;
    color: #FFFFFF;
    border-radius: 10px;
    display: flex;
    align-items: center; /* Center items vertically */
`;

const StyledForm = styled.form`
    display: flex;
    flex-direction: column;
    gap: 20px;
`;

const Section = styled.div`
    margin-top: 20px;
`;

const SectionTitle = styled.h3`
    color: black;
    padding-bottom: 10px;
    margin-bottom: 10px;
    position: relative;
    display: inline-block;

    &::after {
        content: '';
        position: absolute;
        left: 0;
        bottom: 0;
        width: 100%;
        height: 3px;
        background: linear-gradient(to right, #012353, #27ae60);
    }
`;

const Label = styled.label`
    color: #333;
`;

const Input = styled.input`
    width: calc(100% - 20px);
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 4px;
    font-size: 14px;
    transition: border-color 0.3s ease;

    &:focus {
        outline: none;
        border-color: #007bff;
        box-shadow: 0 0 5px rgba(0, 123, 255, 0.5);
    }
`;

const Select = styled.select`
    width: calc(100% - 20px);
    padding: 7px;
    border: 1px solid #ccc;
    border-radius: 10px;
    font-size: 14px;
`;

const Textarea = styled.textarea`
    width: calc(100% - 20px);
    padding: 7px;
    border: 1px solid #ccc;
    border-radius: 10px;
    font-size: 14px;
    transition: border-color 0.3s ease;

    &:focus {
        outline: none;
        border-color: #007bff;
        box-shadow: 0 0 5px rgba(0, 123, 255, 0.5);
    }
`;

const Button = styled.button`
    padding: 10px 40px;
    background: linear-gradient(to right, #012353, #27ae60);
    color: #fff;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    transition: background-color 0.3s ease;
`;

const StudentForm = () => {
    const { studentId } = useParams();
    const [formData, setFormData] = useState({
        STUDENT_ID: '',
        FIRST_NAME: '',
        MIDDLE_NAME: '',
        LAST_NAME: '',
        GENDER: '',
        CLASS_ID: '',
        CONTACT_NUMBER: '',
        HOUSE_NUMBER: '',
        HOUSE_BUILDING_NAME: '',
        STREET_NAME: '',
        LANDMARK: '',
        CITY: '',
        STATE: '',
        POSTAL_CODE: '',
       
        DATE_OF_BIRTH: '',
        EMAIL: '',
        ENROLLMENT_DATE: '',
        NATIONALITY: '',
        ORPHAN_STUDENT: '',
        BIRTH_CERTIFICATE_NUMBER: '',
        CAST: '',
        RELIGION: '',
        BLOOD_GROUP: '',
        DISEASE_IF_ANY: '',
        ADDITIONAL_NOTE: '',
        IDENTIFICATION_MARK: '',
        PREVIOUS_SCHOOL: '',
        EMERGENCY_CONTACT_NAME: '',
        EMERGENCY_CONTACT_NUMBER: '',
        AADHAAR_NUMBER: ''
    });

    const navigate = useNavigate();
    const [editMode, setEditMode] = useState(false);

    useEffect(() => {
        const fetchData = async () => {
            try {
                const response = await axios.get(`http://13.127.57.224:2081/api/studentupdate/${studentId}`);
                const data = response.data;
                data.DATE_OF_BIRTH = data.DATE_OF_BIRTH ? data.DATE_OF_BIRTH.split('T')[0] : '';
                data.ENROLLMENT_DATE = data.ENROLLMENT_DATE ? data.ENROLLMENT_DATE.split('T')[0] : '';
                setFormData(data);
                setEditMode(false);
            } catch (error) {
                console.error('Error fetching data:', error);
            }
        };

        if (studentId) {
            fetchData();
        }
    }, [studentId]);

    const handleChange = (e) => {
        const { name, value } = e.target;

        if (name === 'DATE_OF_BIRTH' || name === 'ENROLLMENT_DATE') {
            const formattedDate = value ? new Date(value).toISOString().split('T')[0] : '';
            setFormData(prevState => ({
                ...prevState,
                [name]: formattedDate
            }));
        } else {
            setFormData(prevState => ({
                ...prevState,
                [name]: value
            }));
        }
    };

    const handleBackClick = () => {
        navigate(-1);
    };

    const handleEditClick = () => {
        setEditMode(true);
    };

    const handleSaveClick = async (e) => {
        e.preventDefault();
        try {
            if (editMode) {
                await axios.put(`http://13.127.57.224:2081/api/studentupdate/${studentId}`, formData);
                alert('Data updated successfully!');
                navigate(-1); // Navigate back to the previous page
            }
            setEditMode(false);
        } catch (error) {
            console.error('Error updating data:', error);
            alert('Error updating data. Please check console for details.');
        }
    };

    return (
        <div>
            <FormWrapper>
                <Title>
                    <FontAwesomeIcon icon={faAngleDoubleLeft} style={{ marginRight: '10px' }} onClick={handleBackClick} />
                    Student Details
                </Title>
                <StyledForm onSubmit={handleSaveClick}>
                    <Section>
                        <SectionTitle>Student Information</SectionTitle>
                        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '20px' }}>
                            <div>
                                <Label htmlFor="STUDENT_ID">Student ID</Label>
                                <Input
                                    type="text"
                                    id="STUDENT_ID"
                                    name="STUDENT_ID"
                                    value={formData.STUDENT_ID}
                                    onChange={handleChange}
                                    required
                                    readOnly={!editMode}
                                />
                            </div>
                            <div>
                                <Label htmlFor="FIRST_NAME">First Name</Label>
                                <Input
                                    type="text"
                                    id="FIRST_NAME"
                                    name="FIRST_NAME"
                                    value={formData.FIRST_NAME}
                                    onChange={handleChange}
                                    readOnly={!editMode}
                                />
                            </div>
                            <div>
                                <Label htmlFor="MIDDLE_NAME">Middle Name</Label>
                                <Input
                                    type="text"
                                    id="MIDDLE_NAME"
                                    name="MIDDLE_NAME"
                                    value={formData.MIDDLE_NAME}
                                    onChange={handleChange}
                                    readOnly={!editMode}
                                />
                            </div>
                            <div>
                                <Label htmlFor="LAST_NAME">Last Name</Label>
                                <Input
                                    type="text"
                                    id="LAST_NAME"
                                    name="LAST_NAME"
                                    value={formData.LAST_NAME}
                                    onChange={handleChange}
                                    readOnly={!editMode}
                                />
                            </div>
                           
                            <div>
                                <Label htmlFor="GENDER">Gender</Label>
                                <Select
                                    id="GENDER"
                                    name="GENDER"
                                    value={formData.GENDER}
                                    onChange={handleChange}
                                    disabled={!editMode}
                                >
                                    <option value="">Select Gender</option>
                                    <option value="Male">Male</option>
                                    <option value="Female">Female</option>
                                    <option value="Other">Other</option>
                                </Select>
                            </div>
                            <div>
                                <Label htmlFor="CLASS_ID"> Class</Label>
                                <Input
                                    type="text"
                                    id="CLASS_ID"
                                    name="CLASS_ID"
                                    value={formData.CLASS_ID}
                                    onChange={handleChange}
                                    readOnly={!editMode}
                                />
                            </div>
                            <div>
                                <Label htmlFor="CONTACT_NUMBER">Contact Number</Label>
                                <Input
                                    type="text"
                                    id="CONTACT_NUMBER"
                                    name="CONTACT_NUMBER"
                                    value={formData.CONTACT_NUMBER}
                                    onChange={handleChange}
                                    readOnly={!editMode}
                                />
                            </div>
                            <div>
                                <Label htmlFor="HOUSE_NUMBER">House Number</Label>
                                <Input
                                    type="text"
                                    id="HOUSE_NUMBER"
                                    name="HOUSE_NUMBER"
                                    value={formData.HOUSE_NUMBER}
                                    onChange={handleChange}
                                    readOnly={!editMode}
                                />
                            </div>
                            <div>
                                <Label htmlFor="HOUSE_BUILDING_NAME">House Building Name</Label>
                                <Input
                                    type="text"
                                    id="HOUSE_BUILDING_NAME"
                                    name="HOUSE_BUILDING_NAME"
                                    value={formData.HOUSE_BUILDING_NAME}
                                    onChange={handleChange}
                                    readOnly={!editMode}
                                />
                            </div>
                            <div>
                                <Label htmlFor="STREET_NAME">Street Name</Label>
                                <Input
                                    type="text"
                                    id="STREET_NAME"
                                    name="STREET_NAME"
                                    value={formData.STREET_NAME}
                                    onChange={handleChange}
                                    readOnly={!editMode}
                                />
                            </div>
                            <div>
                                <Label htmlFor="LANDMARK">Landmark</Label>
                                <Input
                                    type="text"
                                    id="LANDMARK"
                                    name="LANDMARK"
                                    value={formData.LANDMARK}
                                    onChange={handleChange}
                                    readOnly={!editMode}
                                />
                            </div>
                            <div>
                                <Label htmlFor="CITY">City</Label>
                                <Input
                                    type="text"
                                    id="CITY"
                                    name="CITY"
                                    value={formData.CITY}
                                    onChange={handleChange}
                                    readOnly={!editMode}
                                />
                            </div>
                            <div>
                                <Label htmlFor="STATE">State</Label>
                                <Input
                                    type="text"
                                    id="STATE"
                                    name="STATE"
                                    value={formData.STATE}
                                    onChange={handleChange}
                                    readOnly={!editMode}
                                />
                            </div>
                            <div>
                                <Label htmlFor="POSTAL_CODE">Postal Code</Label>
                                <Input
                                    type="text"
                                    id="POSTAL_CODE"
                                    name="POSTAL_CODE"
                                    value={formData.POSTAL_CODE}
                                    onChange={handleChange}
                                    readOnly={!editMode}
                                />
                            </div>
                          
                            <div>
                                <Label htmlFor="DATE_OF_BIRTH">Date of Birth</Label>
                                <Input
                                    type="date"
                                    id="DATE_OF_BIRTH"
                                    name="DATE_OF_BIRTH"
                                    value={formData.DATE_OF_BIRTH}
                                    onChange={handleChange}
                                    readOnly={!editMode}
                                />
                            </div>
                            <div>
                                <Label htmlFor="EMAIL">Email</Label>
                                <Input
                                    type="email"
                                    id="EMAIL"
                                    name="EMAIL"
                                    value={formData.EMAIL}
                                    onChange={handleChange}
                                    readOnly={!editMode}
                                />
                            </div>
                            <div>
                                <Label htmlFor="ENROLLMENT_DATE">Enrollment Date</Label>
                                <Input
                                    type="date"
                                    id="ENROLLMENT_DATE"
                                    name="ENROLLMENT_DATE"
                                    value={formData.ENROLLMENT_DATE}
                                    onChange={handleChange}
                                    readOnly={!editMode}
                                />
                            </div>
                            <div>
                                <Label htmlFor="NATIONALITY">Nationality</Label>
                                <Input
                                    type="text"
                                    id="NATIONALITY"
                                    name="NATIONALITY"
                                    value={formData.NATIONALITY}
                                    onChange={handleChange}
                                    readOnly={!editMode}
                                />
                            </div>
                            <div>
                                <Label htmlFor="ORPHAN_STUDENT">Orphan Student</Label>
                                <Select
                                    id="ORPHAN_STUDENT"
                                    name="ORPHAN_STUDENT"
                                    value={formData.ORPHAN_STUDENT}
                                    onChange={handleChange}
                                    disabled={!editMode}
                                >
                                    <option value="">Select Option</option>
                                    <option value="Yes">Yes</option>
                                    <option value="No">No</option>
                                </Select>
                            </div>
                            <div>
                                <Label htmlFor="BIRTH_CERTIFICATE_NUMBER">Birth Certificate Number</Label>
                                <Input
                                    type="text"
                                    id="BIRTH_CERTIFICATE_NUMBER"
                                    name="BIRTH_CERTIFICATE_NUMBER"
                                    value={formData.BIRTH_CERTIFICATE_NUMBER}
                                    onChange={handleChange}
                                    readOnly={!editMode}
                                />
                            </div>
                            <div>
                                <Label htmlFor="CAST">Cast</Label>
                                <Input
                                    type="text"
                                    id="CAST"
                                    name="CAST"
                                    value={formData.CAST}
                                    onChange={handleChange}
                                    readOnly={!editMode}
                                />
                            </div>
                            <div>
                                <Label htmlFor="RELIGION">Religion</Label>
                                <Input
                                    type="text"
                                    id="RELIGION"
                                    name="RELIGION"
                                    value={formData.RELIGION}
                                    onChange={handleChange}
                                    readOnly={!editMode}
                                />
                            </div>
                            <div>
                                <Label htmlFor="BLOOD_GROUP">Blood Group</Label>
                                <Input
                                    type="text"
                                    id="BLOOD_GROUP"
                                    name="BLOOD_GROUP"
                                    value={formData.BLOOD_GROUP}
                                    onChange={handleChange}
                                    readOnly={!editMode}
                                />
                            </div>
                            <div>
                                <Label htmlFor="DISEASE_IF_ANY">Disease (If Any)</Label>
                                <Input
                                    type="text"
                                    id="DISEASE_IF_ANY"
                                    name="DISEASE_IF_ANY"
                                    value={formData.DISEASE_IF_ANY}
                                    onChange={handleChange}
                                    readOnly={!editMode}
                                />
                            </div>
                            <div>
                                <Label htmlFor="ADDITIONAL_NOTE">Additional Note</Label>
                                <Textarea
                                    id="ADDITIONAL_NOTE"
                                    name="ADDITIONAL_NOTE"
                                    rows="3"
                                    value={formData.ADDITIONAL_NOTE}
                                    onChange={handleChange}
                                    readOnly={!editMode}
                                />
                            </div>
                            <div>
                                <Label htmlFor="IDENTIFICATION_MARK">Identification Mark</Label>
                                <Input
                                    type="text"
                                    id="IDENTIFICATION_MARK"
                                    name="IDENTIFICATION_MARK"
                                    value={formData.IDENTIFICATION_MARK}
                                    onChange={handleChange}
                                    readOnly={!editMode}
                                />
                            </div>
                            <div>
                                <Label htmlFor="PREVIOUS_SCHOOL">Previous School</Label>
                                <Input
                                    type="text"
                                    id="PREVIOUS_SCHOOL"
                                    name="PREVIOUS_SCHOOL"
                                    value={formData.PREVIOUS_SCHOOL}
                                    onChange={handleChange}
                                    readOnly={!editMode}
                                />
                            </div>
                            <div>
                                <Label htmlFor="EMERGENCY_CONTACT_NAME">Emergency Contact Name</Label>
                                <Input
                                    type="text"
                                    id="EMERGENCY_CONTACT_NAME"
                                    name="EMERGENCY_CONTACT_NAME"
                                    value={formData.EMERGENCY_CONTACT_NAME}
                                    onChange={handleChange}
                                    readOnly={!editMode}
                                />
                            </div>
                            <div>
                                <Label htmlFor="EMERGENCY_CONTACT_NUMBER">Emergency Contact Number</Label>
                                <Input
                                    type="text"
                                    id="EMERGENCY_CONTACT_NUMBER"
                                    name="EMERGENCY_CONTACT_NUMBER"
                                    value={formData.EMERGENCY_CONTACT_NUMBER}
                                    onChange={handleChange}
                                    readOnly={!editMode}
                                />
                            </div>
                            <div>
                                <Label htmlFor="AADHAAR_NUMBER">Aadhaar Number</Label>
                                <Input
                                    type="text"
                                    id="AADHAAR_NUMBER"
                                    name="AADHAAR_NUMBER"
                                    value={formData.AADHAAR_NUMBER}
                                    onChange={handleChange}
                                    readOnly={!editMode}
                                />
                            </div>
                        </div>
                    </Section>
                    <div style={{ display: 'flex', justifyContent: 'center', gap: '10px' }}>
                        {!editMode && (
                            <Button type="button" onClick={handleEditClick}>
                                <FontAwesomeIcon icon={faEdit} style={{ marginRight: '5px' }} />
                                Edit
                            </Button>
                        )}
                        {editMode && (
                            <Button type="submit">
                                <FontAwesomeIcon icon={faSave} style={{ marginRight: '5px' }} />
                                Save
                            </Button>
                        )}
                    </div>
                </StyledForm>
            </FormWrapper>
        </div>
    );
};

export default StudentForm;
