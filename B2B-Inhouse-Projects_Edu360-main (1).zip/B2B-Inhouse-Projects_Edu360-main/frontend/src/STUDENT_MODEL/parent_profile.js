
import React, { useState, useEffect } from 'react';
import { AgGridReact } from 'ag-grid-react';
import { Link } from 'react-router-dom';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import 'bootstrap/dist/css/bootstrap.min.css';
// import Landing from '../ADMIN_MODEL/Landing.js';

const ParentProfile = () => {
  const [studentAcademic, setStudentAcademic] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchStudentAcademic();
  }, []);

  const fetchStudentAcademic = async () => {
    try {
      const response = await fetch('http://13.127.57.224:2081/api/ParentProfile');
      if (!response.ok) {
        throw new Error('Failed to fetch');
      }
      const data = await response.json();
      setStudentAcademic(data);
    } catch (error) {
      console.error('Error fetching students:', error);
      setError(error.message);
    } finally {
      setIsLoading(false);
    }
  };

  const columnDefs = [
    { headerName: 'Parent Id', field: 'PARENT_ID', 
      cellRenderer: (params) => (
        <Link to={`/Parent_Detail/${params.value}`} style={{ textDecoration: 'none', color: '#0000FF' }}>
          {params.value}
        </Link>
      ),
    },
    { headerName: 'Student Name', field: 'STUDENT_NAME', filter: true },
    { headerName: 'Father Name', field: 'FATHER_NAME' },
    { headerName: 'Father Adhar ID', field: 'FATHER_ADHAR_ID' },
    { headerName: 'Father Occupation', field: 'FATHER_OCCUPATION' },
    { headerName: 'Father Education', field: 'FATHER_EDUCATION' },
    { headerName: 'Father Mobile Number', field: 'FATHER_MOBILE_NUMBER' },
    { headerName: 'Father Income', field: 'FATHER_INCOME' },
    { headerName: 'Mother Name', field: 'MOTHER_NAME' },
    { headerName: 'Mother Adhar ID', field: 'MOTHER_ADHAR_ID' },
    { headerName: 'Mother Occupation', field: 'MOTHER_OCCUPATION' },
    { headerName: 'Mother Education', field: 'MOTHER_EDUCATION' },
    { headerName: 'Mother Mobile Number', field: 'MOTHER_MOBILE_NUMBER' },
    { headerName: 'Mother Income', field: 'MOTHER_INCOME' },
    { headerName: 'Primary Contact Number', field: 'PRIMARY_CONTACT_NUMBER' },
  ];

  const defaultColDef = {
    floatingFilter: true,
    sortable: true,
    minWidth: 150,
    maxWidth: 180,
    resizable: true,
  };

  if (isLoading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>Error: {error}</div>;
  }

  return (
    <div className="header-container">
      {/* <Landing /> */}
      <div className="container-fluid" style={{ marginTop: '7vh', width: '100%', padding: 0 }}>
        <div className="container-fluid d-flex flex-column" style={{ minHeight: '80vh' }}>
          {/* Fixed height for the table container */}
          <div className="ag-theme-alpine" style={{ height: '88vh', width: '100%', overflow: 'auto' }}>
            <AgGridReact
              rowData={studentAcademic}
              columnDefs={columnDefs}
              defaultColDef={defaultColDef}
              suppressPaginationPanel={true} // Disable pagination panel
              pagination={false} // Disable pagination
              suppressHorizontalScroll={false} // Allow horizontal scroll if needed
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default ParentProfile;
