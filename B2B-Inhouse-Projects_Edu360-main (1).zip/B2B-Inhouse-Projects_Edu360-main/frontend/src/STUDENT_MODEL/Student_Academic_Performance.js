

import React, { useState, useEffect } from 'react';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import 'bootstrap/dist/css/bootstrap.min.css';
// import Landing from '../ADMIN_MODEL/Landing.js';

const Studentperformancetable = () => {
  const [studentAcademic, setStudentAcademic] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchStudentAcademic();
  }, []);

  const fetchStudentAcademic = async () => {
    try {
      const response = await fetch('http://13.127.57.224:2081/api/Studentperformancetable');
      if (!response.ok) {
        throw new Error('Failed to fetch');
      }
      const data = await response.json();
      setStudentAcademic(data);
      setIsLoading(false);
    } catch (error) {
      console.error('Error fetching students:', error);
      setError(error.message);
      setIsLoading(false);
    }
  };

  const columnDefs = [
    {
      headerName: 'Student ID',
      field: 'STUDENT_ID',    filter: true,

      
    },
    { headerName: 'Student Name', field: 'STUDENT_NAME',    filter: true,    },
    { headerName: 'Academic Year', field: 'ACADEMIC_YEAR',    filter: true,    },
    { headerName: 'Class', field: 'CLASS',    filter: true,    },
    { headerName: 'Subject', field: 'SUBJECT',    filter: true,    }
    ,
    { headerName: 'Term 1 PT', field: 'TERM_1_PT' },
    { headerName: 'Term 1 NB', field: 'TERM_1_NB' },
    { headerName: 'Term 1 SE', field: 'TERM_1_SE' },
    { headerName: 'Half yearly', field: 'HALF_YEARLY',    filter: true,    },
    { headerName: 'Term 1 Total', field: 'TERM_1_TOTAL' },
    { headerName: 'Work Education 1 ', field: 'WORK_EDUCATION_1' },
    { headerName: 'Art Education 1', field: 'ART_EDUCATION_1' },
    { headerName: 'Health And Hygiene 1', field: 'HEALTH_AND_HYGIENE_1' },
    
    
    
    { headerName: 'Regularity And Punctuallity 1', field: 'REGULARITY_AND_PUNCTUALLITY_1' },
    { headerName: 'Term 2 PT', field: 'TERM_2_PT' },
    { headerName: 'Term 2 NB', field: 'TERM_2_NB' },
    { headerName: 'Term 2 SE', field: 'TERM_2_SE' },
    { headerName: 'Annual', field: 'ANNUAL' },
    { headerName: 'Term 2 Total', field: 'TERM_2_TOTAL' },
    { headerName: 'Work Education 2', field: 'WORK_EDUCATION_2' },
    { headerName: 'Art Education 2', field: 'ART_EDUCATION_2' },
    { headerName: 'Health And Hygiene 2', field: 'HEALTH_AND_HYGIENE_2',    filter: true,    },
    { headerName: 'Regularity And Punctuallity 2', field:'REGULARITY_AND_PUNCTUALLITY_2' },
    { headerName: 'Grand Total', field: 'GRAND_TOTAL' },
    { headerName: 'Percent', field: 'PERCENT',    filter: true,    },
  ];

  const defaultColDef = {
    floatingFilter: true,
    sortable: true,
    minWidth: 150,
    maxWidth: 180,
    resizable: true,
  };


  if (isLoading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>Error: {error}</div>;
  }

  return (
    <div className="header-container">

      <div className="container-fluid" style={{  marginTop: '7vh', width: '95%', padding: 0 }}>
        <div className="container-fluid d-flex flex-column fixed-middle" style={{ minHeight: '80vh' }}>
         
        <div className="ag-theme-alpine" style={{ height: '74vh', width: '100%', overflow: 'auto' }}>
            <AgGridReact
              rowData={studentAcademic}
              columnDefs={columnDefs}
              defaultColDef={defaultColDef}
              suppressPaginationPanel={true} // Disable pagination panel
              pagination={false} // Disable pagination
              suppressHorizontalScroll={false} // Allow horizontal scroll if needed
            />
          </div>
        </div>
      </div>
    </div>
  );
};

const MarksIndicatorTable = () => {
  useEffect(() => {
    const style = document.createElement('style');
    style.textContent = `
      .marks-indicator-container {
        margin-bottom: 1px;
      }
 
      .marks-indicator-table-container {
        display: flex;
        justify-content: flex-start; /* Align content to the left */
      }
 
      .marks-indicator-table {
        margin: 0 auto;
        width: 100%;
      }
 
      .marks-indicator-table th,
      .marks-indicator-table td {
        border: 3px solid #dee2e6;
        padding: 4px;
        text-align: center;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }
 
      .marks-indicator-sticky-header th {
        position: sticky;
        top: 0;
        z-index: 999;
        background-color: #ffffff;
      }
 
      .marks-indicator-table-container {
        max-height: 80vh;
        overflow-y: auto;
      }
    `;
    document.head.appendChild(style);
 
    return () => {
      document.head.removeChild(style);
    };
  }, []);
 
  return (
    <div className="marks-indicator-container">
             <div className="container-fluid" style={{ marginLeft: 'vh',  width: '95%', padding: 0 }}>

      <div className="container-fluid d-flex flex-column">
      <div className="p-2 mb-2 d-flex justify-content-between align-items-center" style={{ background: 'linear-gradient(to right, #012353, #27AE60)', color: '#FFFFFF', borderRadius: '10px' ,marginTop:'-2rem'}}>
      <h1 style={{ fontSize: '1.5rem' }}>Marks Indicator</h1>
          </div>         
        <div className="marks-indicator-table-container">
          <div className="table-responsive">
            <table className="table marks-indicator-table">
              <thead className="marks-indicator-sticky-header thead-dark">
                <tr>
                  <th>T.1 PT</th>
                  <th>T.1 NB</th>
                  <th>T.1 SE</th>
                  <th>H.Y</th>
                  <th>T1T</th>
                  <th>W.E1</th>
                  <th>A.E1</th>
                  <th>H.A.H1</th>
                  <th>R.A.P1</th>
                  <th>T.2 PT</th>
                  <th>T.2 NB</th>
                  <th>T.2 SE</th>
                  <th>T2T</th>
                  <th>W.E2 </th>
                  <th>A.E2</th>
                  <th>H.A.H2</th>
                  <th>R.A.P2</th>
                  <th>G.T</th>
                </tr>
                <tr>
                <th>Periodic Test1</th>
                  <th>Note Book1</th>
                  <th>Subject Enrichment1</th>
                  <th>Half Yearly</th>
                  <th>Term1 Total</th>
                  <th>Work Education1</th>
                  <th>Art Education1</th>
                  <th>Health & Hygiene1</th>
                  <th>Regularity & Punctuallity1</th>
                  <th>Periodic Test1</th>
                  <th>Note Book2</th>
                  <th>Subject Enrichment2</th>
                  <th>Term2 Total</th>
                  <th>Work Education2</th>
                  <th>Art Education2</th>
                  <th>Health & Hygiene2</th>
                  <th>Regularity & Punctuallity2</th>
                  <th>Grand Total</th>
                </tr>
              </thead>
            </table>
          </div>
        </div>
      </div>
    </div>
    </div>
     
  );
};
 
function App() {
  return (
    <div className="App">
      <Studentperformancetable />
      <MarksIndicatorTable />
    </div>
   
  );
}
 
export default App;





