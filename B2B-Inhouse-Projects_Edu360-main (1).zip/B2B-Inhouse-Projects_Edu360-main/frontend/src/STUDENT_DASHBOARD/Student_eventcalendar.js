


// import React, { useState, useEffect } from 'react';
// import { FaChevronLeft, FaChevronRight } from 'react-icons/fa';
// import axios from 'axios';

// const EventCalendar = () => {
//   const [selectedDate, setSelectedDate] = useState(null);
//   const [year, setYear] = useState(new Date().getFullYear());
//   const [month, setMonth] = useState(new Date().getMonth());
//   const [events, setEvents] = useState([]);

//   useEffect(() => {
//     fetchEvents();
//   }, [year, month]);

//   const fetchEvents = async () => {
//     try {
//       const response = await axios.get('http://13.127.57.224:2081/api/holidays', {
//         params: {
//           year,
//           month: month + 1,
//         },
//       });
//       const mappedEvents = response.data.map(event => ({
//         holidayName: event.HOLIDAY_NAME,
//         holidayMonth: event.HOLIDAY_MONTH,
//         holidayYear: event.HOLIDAY_YEAR,
//         startDate: new Date(event.START_DATE).toLocaleDateString('en-US'),
//         endDate: new Date(event.END_DATE).toLocaleDateString('en-US'),
//       }));
//       setEvents(mappedEvents);
//     } catch (error) {
//       console.error('Error fetching events:', error);
//     }
//   };

//   const daysInMonth = new Date(year, month + 1, 0).getDate();
//   const firstDayOfMonth = new Date(year, month, 1).getDay();

//   const handleDateClick = (date) => {
//     setSelectedDate(date);
//   };

//   const handlePrevMonth = () => {
//     if (month === 0) {
//       setMonth(11);
//       setYear(year - 1);
//     } else {
//       setMonth(month - 1);
//     }
//   };

//   const handleNextMonth = () => {
//     if (month === 11) {
//       setMonth(0);
//       setYear(year + 1);
//     } else {
//       setMonth(month + 1);
//     }
//   };

//   const monthName = new Date(year, month).toLocaleDateString('default', { month: 'long' });

//   const generateCalendar = () => {
//     const calendarDays = [];
//     for (let i = 0; i < firstDayOfMonth; i++) {
//       calendarDays.push(<div style={styles.emptyDay} key={`empty-${i}`}></div>);
//     }

//     for (let day = 1; day <= daysInMonth; day++) {
//       const date = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
//       const isToday = new Date().toLocaleDateString('en-CA') === date;
//       const eventsForDate = events.filter(event =>
//         new Date(event.startDate) <= new Date(date) && new Date(event.endDate) >= new Date(date)
//       );

//       calendarDays.push(
//         <div
//           style={{ ...styles.calendarDay, ...(isToday && styles.todayHighlight) }}
//           key={date}
//           onClick={() => handleDateClick(date)}
//         >
//           <span>{day}</span>
//           {eventsForDate.map(event => (
//             <div key={event.startDate} style={styles.eventItem}>
//               <span>{event.holidayName}</span>
//             </div>
//           ))}
//         </div>
//       );
//     }

//     return calendarDays;
//   };

//   return (
//     <div className="events-calendar" style={styles.eventsCalendar}>
//       <div style={styles.eventsHeader}>
//         <h3 style={styles.monthName}>{monthName} {year}</h3>
//         <div style={styles.navigation}>
//           <button style={styles.navigationButton} onClick={handlePrevMonth}>
//             <FaChevronLeft />
//           </button>
//           <button style={styles.navigationButton} onClick={handleNextMonth}>
//             <FaChevronRight />
//           </button>
//         </div>
//       </div>
//       <div style={styles.calendarGrid}>
//         {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
//           <div style={styles.calendarHeader} key={day}>
//             {day}
//           </div>
//         ))}
//         {generateCalendar()}
//       </div>
//     </div>
//   );
// };

// const styles = {
//   eventsCalendar: {
//     maxWidth: '400px', // Set a maximum width for the calendar
//     margin: '0px auto',
//     fontFamily: 'Arial, sans-serif',
//     background: 'linear-gradient(135deg, #e0f7fa, #fff)',
//     padding: '10px',
//     borderRadius: '8px',
//     marginTop: '-2vh',
//     boxShadow: '0 4px 10px rgba(0, 0, 0, 0.1)',
//   },
//   eventsHeader: {
//     display: 'flex',
//     justifyContent: 'space-between',
//     alignItems: 'center',
//     marginTop: '10px',
//   },
//   navigation: {
//     display: 'flex',
//   },
//   navigationButton: {
//     border: 'none',
//     cursor: 'pointer',
//     outline: 'none',
//     fontSize: '12px', // Reduced font size
//     padding: '4px 6px', // Adjusted padding
//     color: '#2c3e50',
//     transition: 'transform 0.2s ease',
//     margin: '0 2px',
//   },
//   monthName: {
//     margin: 0,
//     fontSize: '14px', // Reduced font size
//     fontWeight: 'bold',
//     color: '#27ae60',
//   },
//   calendarDay: {
//     backgroundColor: '#ffffff',
//     padding: '4px', // Reduced padding
//     textAlign: 'center',
//     cursor: 'pointer',
//     border: '1px solid #ddd',
//     transition: 'background-color 0.3s',
//     borderRadius: '4px',
//     fontSize: '10px', // Reduced font size for day numbers
//   },
//   todayHighlight: {
//     backgroundColor: '#2ecc71',
//     color: '#fff',
//     fontWeight: 'bold',
//     boxShadow: '0 2px 5px rgba(0, 0, 0, 0.2)',
//   },
//   calendarGrid: {
//     display: 'grid',
//     gridTemplateColumns: 'repeat(7, 1fr)',
//     gap: '1px', // Reduced gap
//     marginTop: '5px',
//   },
//   calendarHeader: {
//     textAlign: 'center',
//     fontWeight: 'bold',
//     color: '#34495e',
//     fontSize: '10px', // Reduced font size for headers
//   },
//   eventItem: {
//     marginTop: '2px', // Reduced margin
//     fontSize: '10px', // Reduced font size for event items
//     backgroundColor: '#e74c3c',
//     color: '#fff',
//     borderRadius: '3px',
//     padding: '2px 3px',
//   },
//   emptyDay: {
//     backgroundColor: '#f7f9fc',
//     border: '1px solid #ddd',
//     height: '20px',
//   },

//   // Media queries for responsiveness
//   '@media (max-width: 768px)': {
//     eventsCalendar: {
//       maxWidth: '90%', // Responsive adjustment
//       padding: '8px',
//     },
//     calendarDay: {
//       padding: '2px', // Reduced padding
//     },
//     calendarHeader: {
//       fontSize: '10px', // Reduced font size
//     },
//     navigationButton: {
//       fontSize: '10px', // Reduced font size
//       padding: '2px 4px', // Adjusted padding
//     },
//   },
//   '@media (max-width: 480px)': {
//     calendarGrid: {
//       gap: '1px', // Reduced gap for smaller screens
//     },
//     calendarDay: {
//       padding: '2px', // Further reduced padding
//       fontSize: '9px', // Smaller font size
//     },
//     navigationButton: {
//       fontSize: '8px', // Smaller font size for buttons
//       padding: '2px 3px', // Adjusted padding
//     },
//   },
// };

// export default EventCalendar;



import React, { useState, useEffect, useRef } from 'react';
import { FaChevronLeft, FaChevronRight, FaEllipsisV } from 'react-icons/fa';
import axios from 'axios';
 
const EventCalendar = () => {
  const [selectedDate, setSelectedDate] = useState(null);
  const [selectedEvent, setSelectedEvent] = useState(null);
  const [year, setYear] = useState(new Date().getFullYear());
  const [month, setMonth] = useState(new Date().getMonth());
  const [events, setEvents] = useState([]);
  const [showUpcomingEvents, setShowUpcomingEvents] = useState(false);
  const [filterType, setFilterType] = useState('');
  const dropdownRef = useRef(null);
 
  useEffect(() => {
    fetchEvents();
  }, [year, month]);
 
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setShowUpcomingEvents(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);
 
  const fetchEvents = async () => {
    try {
      const response = await axios.get('http://13.127.57.224:2081/api/holidays', {
        params: {
          year,
          month: month + 1,
        },
      });
      const mappedEvents = response.data.map(event => ({
        holidayName: event.HOLIDAY_NAME,
        holidayMonth: event.HOLIDAY_MONTH,
        holidayYear: event.HOLIDAY_YEAR,
        startDate: new Date(event.START_DATE),
        endDate: new Date(event.END_DATE),
        type: event.TYPE,
      }));
      setEvents(mappedEvents);
    } catch (error) {
      console.error('Error fetching events:', error);
    }
  };
 
  const handleDateClick = (date) => {
    setSelectedDate(date);
    const event = getEventForDate(date);
    setSelectedEvent(event);
  };
 
  const getEventForDate = (date) => {
    return events.find(event =>
      event.startDate.toISOString().split('T')[0] === date
    );
  };
 
  const handlePrevMonth = () => {
    if (month === 0) {
      setMonth(11);
      setYear(year - 1);
    } else {
      setMonth(month - 1);
    }
  };
 
  const handleNextMonth = () => {
    if (month === 11) {
      setMonth(0);
      setYear(year + 1);
    } else {
      setMonth(month + 1);
    }
  };
 
  const monthName = new Date(year, month).toLocaleDateString('default', { month: 'long' });
 
  const getFilteredEvents = () => {
    const today = new Date();
    const weekFromNow = new Date(today);
    weekFromNow.setDate(today.getDate() + 7);
 
    const thisWeekEvents = events.filter(event => event.startDate >= today && event.startDate <= weekFromNow);
    const thisMonthEvents = events.filter(event =>
      event.startDate.getMonth() === today.getMonth() &&
      event.startDate.getFullYear() === today.getFullYear() &&
      !thisWeekEvents.includes(event) &&
      event.startDate > today
    );
    const thisYearEvents = events.filter(event =>
      event.startDate.getFullYear() === today.getFullYear() &&
      event.startDate > today
    );
 
    if (filterType === 'week') return thisWeekEvents;
    if (filterType === 'month') return thisMonthEvents;
    if (filterType === 'year') return thisYearEvents;
  };
 
  const filteredEvents = getFilteredEvents();
 
  const generateCalendar = () => {
    const calendar = [];
    const firstDayOfMonth = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
 
    for (let i = 0; i < firstDayOfMonth; i++) {
      calendar.push(<div key={`empty-${i}`} style={styles.emptyDay}></div>);
    }
 
    for (let day = 1; day <= daysInMonth; day++) {
      const date = new Date(year, month, day);
      const isEventDate = events.some(event =>
        event.startDate.toISOString().split('T')[0] === date.toISOString().split('T')[0]
      );
 
      calendar.push(
        <div
          key={day}
          style={{
            ...styles.calendarDay,
            ...(selectedDate === date.toISOString().split('T')[0] ? styles.calendarDaySelected : {}),
            ...(isEventDate ? styles.eventDateHighlight : {}),
          }}
          onClick={() => handleDateClick(date.toISOString().split('T')[0])}
        >
          {day}
        </div>
      );
    }
 
    return calendar;
  };
 
  return (
    <div className="events-calendar" style={styles.eventsCalendar}>
      <div style={styles.eventSummary}>
        <div style={styles.eventToggle}>
          <FaEllipsisV
            style={styles.toggleIcon}
            onClick={() => setShowUpcomingEvents(!showUpcomingEvents)}
          />
          {showUpcomingEvents && (
            <div ref={dropdownRef} style={styles.dropdownMenu}>
              <p onClick={() => { setFilterType('week'); setShowUpcomingEvents(false); }}>This Week</p>
              <p onClick={() => { setFilterType('month'); setShowUpcomingEvents(false); }}>This Month</p>
              <p onClick={() => { setFilterType('year'); setShowUpcomingEvents(false); }}>This Year</p>
            </div>
          )}
        </div>
        <h4 style={styles.eventsHeading}>Events</h4>
        {selectedEvent ? (
          <div style={styles.selectedEventInfo}>
            <p><strong>{selectedEvent.holidayName}</strong></p>
            <p><strong></strong> {selectedEvent.startDate.toLocaleDateString()}</p>
          </div>
        ) : (
          <p>Click on an event date to see details.</p>
        )}
      </div>
 
      <div style={styles.calendarWrapper}>
        <div style={styles.calendarContainer}>
          <div style={styles.eventsHeader}>
            <div style={styles.navigation}>
              <button style={styles.navigationButton} onClick={handlePrevMonth}>
                <FaChevronLeft />
              </button>
              <h3 style={styles.monthYearText}>{monthName} {year}</h3>
              <button style={styles.navigationButton} onClick={handleNextMonth}>
                <FaChevronRight />
              </button>
            </div>
          </div>
          <div style={styles.calendarGrid}>
            {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
              <div style={styles.calendarHeader} key={day}>
                {day}
              </div>
            ))}
            {generateCalendar()}
          </div>
        </div>
      </div>
 
      {filterType && (
        <div style={styles.upcomingEventsList}>
          <h5>Upcoming Events - {filterType === 'week' ? 'This Week' : filterType === 'month' ? 'This Month' : 'This Year'}</h5>
          {filteredEvents && filteredEvents.length > 0 ? (
            filteredEvents.map((event, index) => (
              <div key={index} style={styles.eventItem}>
                <p><strong>{event.holidayName}</strong> | From: {event.startDate.toLocaleDateString()} To: {event.endDate.toLocaleDateString()}</p>
              </div>
            ))
          ) : (
            <p>No events for this period.</p>
          )}
        </div>
      )}
    </div>
  );
};
 
const styles = {
  eventsCalendar: {
    maxWidth: '500%', // Set max-width to a percentage
    margin: 'auto',
    fontFamily: 'Arial, sans-serif',
    borderRadius: '10px',
    backgroundColor: '#ffffff',
    padding: '-1rem',
    display: 'flex',
    flexDirection: 'column',
    position: 'relative',
    boxShadow: '0 4px 15px rgba(0, 0, 0, 0.1)',
    overflow: 'hidden',
},
 
  eventSummary: {
    backgroundColor: '#f9f9f9',
    padding: '-3rem',
    borderRadius: '5px',
    marginBottom: '10px',
    boxShadow: '0 2px 5px rgba(0, 0, 0, 0.1)',
  },
  eventToggle: {
    cursor: 'pointer',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'flex-end',
  },
  toggleIcon: {
    fontSize: '18px',
    marginLeft: '10px',
    cursor: 'pointer',
  },
  eventsHeading: {
    color: '#a0a0a0',
    fontSize: '18px',
    marginBottom: '0px',
  },
  selectedEventInfo: {
    marginTop: '0px',
    fontSize: '14px',
  },
  calendarWrapper: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
  },
  calendarContainer: {
    borderRadius: '10px',
    padding: '1px',
    backgroundColor: '#ffffff',
    display: 'flex',
    flexDirection: 'column',
    width: '100%', // Set to full width
  },
  eventsHeader: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: '0px',
  },
  navigation: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center', // Center the month/year display
    width: '100%', // Ensure the navigation takes full width
  },
  monthYearText: {
    fontWeight: 'bold',
    fontSize: '18px',
    margin: '0 10px',
    textAlign: 'center', // Center the text within the h3 element
  },
  navigationButton: {
    backgroundColor: 'transparent',
    border: 'none',
    cursor: 'pointer',
  },
  calendarGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(7, 1fr)',
    gap: 'px',
    textAlign: 'center',
  },
  calendarHeader: {
    fontSize: '14px',
    fontWeight: 'bold',
    color: '#333',
  },
  calendarDay: {
    fontSize: '14px',
    padding: '1px',
    cursor: 'pointer',
    borderRadius: '50%',
  },
  calendarDaySelected: {
    backgroundColor: '#007bff',
    color: '#fff',
  },
  eventDateHighlight: {
    fontWeight: 'bold',
    color: '#333',
    backgroundColor: '#d4edda', // light green background for event dates
    borderRadius: '50%',
  },
  emptyDay: {
    height: '30px',
  },
  upcomingEventsList: {
    backgroundColor: '#f9f9f9',
    padding: '1px',
    borderRadius: '5px',
    marginTop: '1px',
  },
  eventItem: {
    fontSize: '14px',
    color: '#666',
    marginBottom: 'px',
  },
};
 
export default EventCalendar;
 
 
 
