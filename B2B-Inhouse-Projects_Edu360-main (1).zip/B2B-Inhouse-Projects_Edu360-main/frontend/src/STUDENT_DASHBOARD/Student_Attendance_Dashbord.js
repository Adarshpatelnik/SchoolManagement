// import React, { useEffect, useState } from 'react';
// import axios from 'axios';
// import { AgCharts } from 'ag-charts-react';
// import styled from 'styled-components';
 
// const Container = styled.div`
//   width: 70%;
//   max-width: 500px;
//   margin: auto;
//   padding: 1px;
//   background-color: white;
//   border-radius: 10px;
// `;
 
// const FilterContainer = styled.div`
//   display: flex;
//   gap: 10px;
//   margin-bottom: 10px;
//   margin-top: -1vh;
// `;
 
// const Filter = styled.div`
//   display: flex;
//   flex-direction: column;
//   align-items: flex-start;
//   flex: 1;
// `;
 
// const Select = styled.select`
//   border: 1px solid #87CEEB;
//   border-radius: 5px;
//   padding: 6px;
//   font-size: 14px;
//   width: 100%;
// `;
 
// const LegendContainer = styled.div`
//   display: flex;
//   justify-content: space-evenly;
//   margin-top: 10px;
// `;
 
// const LegendItem = styled.div`
//   display: flex;
//   align-items: center;
//   margin-right: 15px;
// `;
 
// const LegendColorBox = styled.div`
//   width: 15px;
//   height: 15px;
//   margin-right: 5px;
//   background-color: ${props => props.color};
//   border: 1px solid #ccc;
// `;
 
// const TotalText = styled.div`
//   position: absolute;
//   top: 50%;
//   left: 50%;
//   transform: translate(-50%, -50%);
//   font-size: 24px;
//   font-weight: bold;
// `;
 
// const StudentAttendanceDashbord = () => {
//   const [attendanceData, setAttendanceData] = useState([]);
//   const [filteredData, setFilteredData] = useState([]);
//   const [selectedClass, setSelectedClass] = useState('');
 
//   useEffect(() => {
//     const fetchAttendanceData = async () => {
//       try {
//         // Fetch data from backend
//         const response = await axios.get('http://13.127.57.224:2081/api/studentcount');
//         const data = response.data.map(record => ({
//           GENDER: record.GENDER === 'MALE' ? 'Male' : 'Female',
//           count: record.count
//         }));
 
//         setAttendanceData(data);
//       } catch (error) {
//         console.error('Error fetching student attendance data:', error);
//       }
//     };
 
//     fetchAttendanceData();
//   }, []);
 
//   const getGenderCounts = () => {
//     let boys = 0;
//     let girls = 0;
 
//     attendanceData.forEach(record => {
//       if (record.GENDER === 'Male') boys += record.count;
//       if (record.GENDER === 'Female') girls += record.count;
//     });
 
//     return { boys, girls };
//   };
 
//   const { boys, girls } = getGenderCounts();
//   const totalStudents = boys + girls;
 
//   const chartData = [
//     { label: 'Boys', value: boys },
//     { label: 'Girls', value: girls },
//   ];
 
//   const options = {
//     data: chartData,
//     series: [{
//       type: 'pie',
//       angleKey: 'value',
//       labelKey: 'label',
//       innerRadiusRatio: 0.8, // Doughnut effect
//       fills: ['#A8E6CF', '#CE93D8'],
//       strokes: ['#FFFFFF'],
//     }],
//     tooltip: {
//       enabled: false,
//     },
//   };
 
//   return (
//     <Container>
//       <FilterContainer>
//         <Filter>
//           <Select value={selectedClass} onChange={e => setSelectedClass(e.target.value)}>
//             <option value="">All Classes</option>
//             {/* Add classes filter if necessary */}
//           </Select>
//         </Filter>
//       </FilterContainer>
 
//       <div style={{ height: '30vh', width: '100%', position: 'relative' }}>
//         <AgCharts options={options} />
//         <TotalText>{totalStudents}</TotalText>
//       </div>
 
//       <LegendContainer>
//         <LegendItem>
//           <LegendColorBox color="#A8E6CF" />
//           Boys: {boys}
//         </LegendItem>
//         <LegendItem>
//           <LegendColorBox color="#CE93D8" />
//           Girls: {girls}
//         </LegendItem>
//       </LegendContainer>
//     </Container>
//   );
// };
 
// export default StudentAttendanceDashbord;










// import React, { useEffect, useState } from 'react';
// import axios from 'axios';
// import { AgCharts } from 'ag-charts-react';
// import styled from 'styled-components';

// const Container = styled.div`
//   width: 100%;  /* Reduced width */
//   max-width: 400px;  /* Reduced max-width */
//   margin: auto;
//   padding: 15px;  /* Reduced padding */
//   background-color: #ffffff;
//   border-radius: 10px;
//   box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
// `;

// const Title = styled.h2`
//   text-align: center;
//   color: #2c3e50;
//   margin-bottom: 15px;  /* Reduced margin */
//   font-size: 20px;  /* Reduced font size */
//   font-weight: bold;
// `;

// const FilterContainer = styled.div`
//   display: flex;
//   gap: 10px;
//   margin-bottom: 15px;  /* Reduced margin */
// `;

// const Filter = styled.div`
//   display: flex;
//   flex-direction: column;
//   align-items: flex-start;
//   flex: 1;
// `;

// const Select = styled.select`
//   border: 1px solid #87CEEB;
//   border-radius: 5px;
//   padding: 6px;  /* Reduced padding */
//   font-size: 14px;  /* Reduced font size */
//   width: 100%;
//   transition: border 0.3s;

//   &:hover {
//     border: 1px solid #3498db;
//   }
// `;

// const LegendContainer = styled.div`
//   display: flex;
//   justify-content: space-evenly;
//   margin-top: 15px;  /* Reduced margin */
//   padding: 10px 0;
//   border-top: 1px solid #e0e0e0;
// `;

// const LegendItem = styled.div`
//   display: flex;
//   align-items: center;
//   margin-right: 10px;  /* Reduced margin */
//   font-size: 14px;  /* Reduced font size */
//   color: #34495e;
//   transition: transform 0.2s;

//   &:hover {
//     transform: scale(1.05);
//   }
// `;

// const LegendColorBox = styled.div`
//   width: 12px;  /* Reduced width */
//   height: 12px;  /* Reduced height */
//   margin-right: 5px;
//   background-color: ${props => props.color};
//   border: 1px solid #ccc;
// `;

// const TotalText = styled.div`
//   position: absolute;
//   top: 50%;
//   left: 50%;
//   transform: translate(-50%, -50%);
//   font-size: 24px;  /* Reduced font size */
//   font-weight: bold;
//   color: #34495e;
// `;

// const StudentAttendanceDashbord = () => {
//   const [attendanceData, setAttendanceData] = useState([]);
//   const [selectedClass, setSelectedClass] = useState('');

//   useEffect(() => {
//     const fetchAttendanceData = async () => {
//       try {
//         const response = await axios.get('http://13.127.57.224:2081/api/studentcount');
//         const data = response.data.map(record => ({
//           GENDER: record.GENDER === 'MALE' ? 'Male' : 'Female',
//           count: record.count
//         }));

//         setAttendanceData(data);
//       } catch (error) {
//         console.error('Error fetching student attendance data:', error);
//       }
//     };

//     fetchAttendanceData();
//   }, []);

//   const getGenderCounts = () => {
//     let boys = 0;
//     let girls = 0;

//     attendanceData.forEach(record => {
//       if (record.GENDER === 'Male') boys += record.count;
//       if (record.GENDER === 'Female') girls += record.count;
//     });

//     return { boys, girls };
//   };

//   const { boys, girls } = getGenderCounts();
//   const totalStudents = boys + girls;

//   const chartData = [
//     { label: 'Boys', value: boys },
//     { label: 'Girls', value: girls },
//   ];

//   const options = {
//     data: chartData,
//     series: [{
//       type: 'pie',
//       angleKey: 'value',
//       labelKey: 'label',
//       innerRadiusRatio: 0.8, // Doughnut effect
//       fills: ['#A8E6CF', '#CE93D8'],
//       strokes: ['#FFFFFF'],
//     }],
//     tooltip: {
//       enabled: false,
//     },
//   };

//   return (
//     <Container>
//       <FilterContainer>
//         <Filter>
//           <Select value={selectedClass} onChange={e => setSelectedClass(e.target.value)}>
//             <option value="">All Classes</option>
//             {/* Add classes filter if necessary */}
//           </Select>
//         </Filter>
//       </FilterContainer>

//       <div style={{ height: '20vh', width: '100%', position: 'relative' }}> {/* Reduced height */}
//         <AgCharts options={options} />
//         <TotalText>{totalStudents}</TotalText>
//       </div>

//       <LegendContainer>
//         <LegendItem>
//           <LegendColorBox color="#A8E6CF" />
//           Boys: {boys}
//         </LegendItem>
//         <LegendItem>
//           <LegendColorBox color="#CE93D8" />
//           Girls: {girls}
//         </LegendItem>
//       </LegendContainer>
//     </Container>
//   );
// };

// export default StudentAttendanceDashbord;




// import React, { useState, useEffect } from 'react';
// import axios from 'axios';
// import { PieChart, Pie, Cell, Tooltip, Legend } from 'recharts';
// import styled from 'styled-components';
// import { ThreeDotsVertical } from 'react-bootstrap-icons';

// const COLORS = ['#3498DB', '#F4D03F', '#58D68D', '#E74C3C'];
// const SKYBLUE = '#87CEEB';
// const WHITE = '#FFFFFF';
// const DARKBLUE = '#1E2A78';

// const Container = styled.div`
//   padding: 0px;
//   background-color: ${WHITE};
//   border-radius: 10px;

//   box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
// `;

// const OptionsIcon = styled.div`
//   position: absolute;
//   top: 20px;
//   right: 20px;
//   cursor: pointer;
// `;

// const FilterDropdown = styled.div`
//   position: absolute;
//   top: 50px;
//   right: 0;
//   background: ${WHITE};
//   box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
//   border-radius: 5px;
//   z-index: 10;
//   padding: 10px;
//   display: ${props => (props.show ? 'block' : 'none')};
// `;

// const FilterContainer = styled.div`
//   display: flex;
//   gap: 10px;
//   flex-direction: column;
// `;

// const Filter = styled.div`
//   display: flex;
//   flex-direction: column;
//   align-items: flex-start;
//   flex: 1;
// `;

// const Label = styled.label`
//   margin-bottom: 5px;
//   font-weight: bold;
//   color: black;
// `;

// const Select = styled.select`
//   border: 1px solid ${SKYBLUE};
//   border-radius: 5px;
//   padding: 6px;
//   font-size: 14px;
//   width: 100%;
//   max-width: 150px;
//   background-color: ${WHITE};
// `;

// const AttendanceInfo = styled.div`
//   padding: 20px;
//   background-color: ${WHITE};
//   border-radius: 10px;
//   box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
//   text-align: center;
// `;

// const AttendanceLabel = styled.div`
//   font-size: 16px;
//   color: ${DARKBLUE};
//   margin-bottom: 0px;
// `;

// const AttendancePercentage = styled.div`
//   font-size: 24px;
//   font-weight: bold;
//   color: #E74C3C; // Color for the Attendance Percentage
// `;

// const StudentAttendanceDashbord = () => {
//   const [attendanceData, setAttendanceData] = useState([]);
//   const [filteredData, setFilteredData] = useState([]);
//   const [classes, setClasses] = useState([]);
//   const [dates, setDates] = useState([]);
//   const [sessions, setSessions] = useState([]);
//   const [selectedClass, setSelectedClass] = useState('');
//   const [selectedDate, setSelectedDate] = useState('');
//   const [selectedSession, setSelectedSession] = useState('');
//   const [showFilters, setShowFilters] = useState(false);

//   useEffect(() => {
//     const fetchAttendanceData = async () => {
//       try {
//         const response = await axios.get('http://13.127.57.224:2081/api/dashboradstudentattendance');
//         const data = response.data.map(record => ({
//           ...record,
//           attendance_percentage: record.attendance_percentage || 0
//         }));
//         setAttendanceData(data);

//         const uniqueClasses = [...new Set(data.map(record => record.CLASS))];
//         const uniqueDates = [...new Set(data.map(record => record.DATE))];
//         const uniqueSessions = [...new Set(data.map(record => record.SESSION))];

//         setClasses(uniqueClasses);
//         setDates(uniqueDates);
//         setSessions(uniqueSessions);
//       } catch (error) {
//         console.error('Error fetching student attendance data:', error);
//       }
//     };

//     fetchAttendanceData();
//   }, []);

//   const handleClassChange = (e) => setSelectedClass(e.target.value);
//   const handleDateChange = (e) => setSelectedDate(e.target.value);
//   const handleSessionChange = (e) => setSelectedSession(e.target.value);

//   useEffect(() => {
//     let filtered = attendanceData;

//     if (selectedClass) {
//       filtered = filtered.filter(record => record.CLASS === selectedClass);
//     }
//     if (selectedDate) {
//       filtered = filtered.filter(record => record.DATE === selectedDate);
//     }
//     if (selectedSession) {
//       filtered = filtered.filter(record => record.SESSION === selectedSession);
//     }

//     setFilteredData(filtered);
//   }, [selectedClass, selectedDate, selectedSession, attendanceData]);

//   const processData = (data) => {
//     const statusCount = data.reduce((acc, record) => {
//       acc[record.STATUS] = (acc[record.STATUS] || 0) + 1;
//       return acc;
//     }, {});

//     return Object.entries(statusCount).map(([key, value]) => ({
//       name: key,
//       value,
//     }));
//   };

//   const calculateAttendancePercentage = () => {
//     if (filteredData.length === 0) return 0;

//     const total = filteredData.length;
//     const present = filteredData.filter(record => record.STATUS === 'PRESENT').length;
//     return Math.round((present / total) * 100); // Remove decimals
//   };

//   return (
//     <Container>
//       <OptionsIcon onClick={() => setShowFilters(!showFilters)}>
//         <ThreeDotsVertical />
//       </OptionsIcon>
//       <FilterDropdown show={showFilters}>
//         <FilterContainer>
//           <Filter>
//             <Label htmlFor="classFilter">Class</Label>
//             <Select id="classFilter" value={selectedClass} onChange={handleClassChange}>
//               <option value="">Class</option>
//               {classes.map((cls, index) => (
//                 <option key={index} value={cls}>{cls}</option>
//               ))}
//             </Select>
//           </Filter>
//           <Filter>
//             <Label htmlFor="dateFilter">Date</Label>
//             <Select id="dateFilter" value={selectedDate} onChange={handleDateChange}>
//               <option value="">Date</option>
//               {dates.map((date, index) => (
//                 <option key={index} value={date}>{date}</option>
//               ))}
//             </Select>
//           </Filter>
//           <Filter>
//             <Label htmlFor="sessionFilter">Session</Label>
//             <Select id="sessionFilter" value={selectedSession} onChange={handleSessionChange}>
//               <option value="">Session</option>
//               {sessions.map((session, index) => (
//                 <option key={index} value={session}>{session}</option>
//               ))}
//             </Select>
//           </Filter>
//         </FilterContainer>
//       </FilterDropdown>
//       <PieChart width={400} height={300}>
//         <Pie
//           data={processData(filteredData)}
//           dataKey="value"
//           outerRadius={90}
//           innerRadius={60} // Adjust this value to create the donut effect
//           fill="#8884d8"
//           paddingAngle={5}
//         >
//           {processData(filteredData).map((entry, index) => (
//             <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
//           ))}
//         </Pie>
//         <Tooltip />
//         <Legend />
//       </PieChart>
//       <AttendanceInfo>
//         <AttendanceLabel>Attendance Percentage</AttendanceLabel>
//         <AttendancePercentage>{calculateAttendancePercentage()}%</AttendancePercentage>
//       </AttendanceInfo>
//     </Container>
//   );
// };

// export default StudentAttendanceDashbord;




// import React, { useState, useEffect } from 'react';
// import axios from 'axios';
// import { AgCharts } from 'ag-charts-react';
// import styled from 'styled-components';
// import { ThreeDotsVertical } from 'react-bootstrap-icons';

// const COLORS = ['#3498DB', '#F4D03F', '#58D68D', '#E74C3C'];
// const SKYBLUE = '#87CEEB';
// const WHITE = '#FFFFFF';
// const DARKBLUE = '#1E2A78';

// const Container = styled.div`
//   padding: 0px;
//   background-color: ${WHITE};
//   border-radius: 10px;
//   // box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
//   position: relative;
// `;

// const ChartContainer = styled.div`
//   position: relative;
//   display: flex;
//     top: -1rem;

//   justify-content: center;
//   align-items: center;
// `;

// const OptionsIcon = styled.div`
//   position: absolute;
//   top: -3rem;
//   right: 10px;
//   cursor: pointer;
//   z-index: 5;
// `;

// const FilterDropdown = styled.div`
//   position: absolute;
//   top: 3px;
//   right: 10px;
//   background: ${WHITE};
//   box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
//   border-radius: 5px;
//   z-index: 10;
//   padding: 4px;
//   display: ${props => (props.show ? 'block' : 'none')};
// `;

// const FilterContainer = styled.div`
//   display: flex;
//   gap: 1px;
//   flex-direction: column;
// `;

// const Filter = styled.div`
//   display: flex;
//   flex-direction: column;
//   align-items: flex-start;
//   flex: 1;
// `;

// const Label = styled.label`
//   margin-bottom: px;
//   font-weight: bold;
//   color: black;
// `;

// const Select = styled.select`
//   border: 1px solid ${SKYBLUE};
//   border-radius: 5px;
//   padding: 6px;
//   font-size: 14px;
//   width: 100%;
//   max-width: 150px;
//   background-color: ${WHITE};
// `;

// const AttendanceInfo = styled.div`
//   position: absolute;
//   top: 50%;
//   left: 35%;
//   transform: translate(-50%, -50%);  // This centers the content
//   padding: 10px;
//   background-color: ${WHITE};
//   border-radius: 10px;
//   // box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
//   text-align: center;
//   z-index: 10;
// `;

// const AttendanceLabel = styled.div`
//   font-size: 12px;
//   color: ${DARKBLUE};
//   margin-bottom: 0px;
// `;

// const AttendancePercentage = styled.div`
//   font-size: 18px;
//   font-weight: bold;
//   color: #E74C3C;
// `;

// const DataDisplay = styled.div`
//   margin-top: 20px;
//   padding: 10px;
//   background-color: ${WHITE};
//   border-radius: 10px;
//   // box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
// `;

// const DataRow = styled.div`
//   display: flex;
//   justify-content: space-between;
//   padding: 5px 0;
// `;

// const DataLabel = styled.div`
//   font-weight: bold;
// `;

// const DataValue = styled.div`
//   color: #2E4053;
// `;

// const StudentAttendanceDashboard = () => {
//   const [attendanceData, setAttendanceData] = useState([]);
//   const [filteredData, setFilteredData] = useState([]);
//   const [classes, setClasses] = useState([]);
//   const [dates, setDates] = useState([]);
//   const [sessions, setSessions] = useState([]);
//   const [selectedClass, setSelectedClass] = useState('');
//   const [selectedDate, setSelectedDate] = useState('');
//   const [selectedSession, setSelectedSession] = useState('');
//   const [showFilters, setShowFilters] = useState(false);

//   useEffect(() => {
//     const fetchAttendanceData = async () => {
//       try {
//         const response = await axios.get('http://13.127.57.224:2081/api/dashboradstudentattendance');
//         const data = response.data.map(record => ({
//           ...record,
//           attendance_percentage: record.attendance_percentage || 0
//         }));
//         setAttendanceData(data);

//         const uniqueClasses = [...new Set(data.map(record => record.CLASS))];
//         const uniqueDates = [...new Set(data.map(record => record.DATE))];
//         const uniqueSessions = [...new Set(data.map(record => record.SESSION))];

//         setClasses(uniqueClasses);
//         setDates(uniqueDates);
//         setSessions(uniqueSessions);
//       } catch (error) {
//         console.error('Error fetching student attendance data:', error);
//       }
//     };

//     fetchAttendanceData();
//   }, []); 

//   const handleClassChange = (e) => setSelectedClass(e.target.value);
//   const handleDateChange = (e) => setSelectedDate(e.target.value);
//   const handleSessionChange = (e) => setSelectedSession(e.target.value);

//   useEffect(() => {
//     let filtered = attendanceData;

//     if (selectedClass) {
//       filtered = filtered.filter(record => record.CLASS === selectedClass);
//     }
//     if (selectedDate) {
//       filtered = filtered.filter(record => record.DATE === selectedDate);
//     }
//     if (selectedSession) {
//       filtered = filtered.filter(record => record.SESSION === selectedSession);
//     }

//     setFilteredData(filtered);
//   }, [selectedClass, selectedDate, selectedSession, attendanceData]);

//   const processData = (data) => {
//     const statusCount = data.reduce((acc, record) => {
//       acc[record.STATUS] = (acc[record.STATUS] || 0) + 1;
//       return acc;
//     }, {});

//     return Object.entries(statusCount).map(([key, value]) => ({
//       asset: key,
//       amount: value,
//     }));
//   };

//   const calculateAttendancePercentage = () => {
//     if (filteredData.length === 0) return 0;

//     const total = filteredData.length;
//     const present = filteredData.filter(record => record.STATUS === 'PRESENT').length;
//     return Math.round((present / total) * 100);
//   };

//   const options = {
//     data: processData(filteredData),
//     series: [
//       {
//         type: 'donut',
//         calloutLabelKey: 'asset',
//         angleKey: 'amount',
//         innerRadiusRatio: 0.7,  // Maintain donut shape with a radius ratio
//         fills: COLORS,
//         calloutLabel: {
//           enabled: true,
//           formatter: (params) => `${params.datum.asset}: ${params.datum.amount}`,
//         },
//       },
//     ],
//     legend: {
//       enabled: true,
//       position: 'right',
//     },
//     tooltip: {
//       enabled: true,
//     },
//   };

//   return (
//     <Container>
//       <OptionsIcon onClick={() => setShowFilters(!showFilters)}>
//         <ThreeDotsVertical />
//       </OptionsIcon>
//       <FilterDropdown show={showFilters}>
//         <FilterContainer>
//           <Filter>
//             <Label>Class</Label>
//             <Select value={selectedClass} onChange={handleClassChange}>
//               <option value="">All</option>
//               {classes.map(cls => (
//                 <option key={cls} value={cls}>{cls}</option>
//               ))}
//             </Select>
//           </Filter>
//           <Filter>
//             <Label>Date</Label>
//             <Select value={selectedDate} onChange={handleDateChange}>
//               <option value="">All</option>
//               {dates.map(date => (
//                 <option key={date} value={date}>{date}</option>
//               ))}
//             </Select>
//           </Filter>
//           <Filter>
//             <Label>Session</Label>
//             <Select value={selectedSession} onChange={handleSessionChange}>
//               <option value="">All</option>
//               {sessions.map(session => (
//                 <option key={session} value={session}>{session}</option>
//               ))}
//             </Select>
//           </Filter>
//         </FilterContainer>
//       </FilterDropdown>
//       <ChartContainer>
//         <AgCharts options={options} style={{ width: '100%', height: '29vh', marginTop: '-1vh' }}  />
//         <AttendanceInfo>
//           <AttendanceLabel></AttendanceLabel>
//           <AttendancePercentage>{calculateAttendancePercentage()}%</AttendancePercentage>
//         </AttendanceInfo>
//       </ChartContainer>
//       {/* <DataDisplay>
//         <DataRow>
//           <DataLabel>Total Students</DataLabel>
//           <DataValue>{filteredData.length}</DataValue>
//         </DataRow>
//         <DataRow>
//           <DataLabel>Present</DataLabel>
//           <DataValue>{filteredData.filter(record => record.STATUS === 'PRESENT').length}</DataValue>
//         </DataRow>
//         <DataRow>
//           <DataLabel>Absent</DataLabel>
//           <DataValue>{filteredData.filter(record => record.STATUS === 'ABSENT').length}</DataValue>
//         </DataRow>
//       </DataDisplay> */}
//     </Container>
//   );
// };

// export default StudentAttendanceDashboard;






import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { PieChart, Pie, Cell, Tooltip, Legend } from 'recharts';
import styled from 'styled-components';
import { ThreeDotsVertical } from 'react-bootstrap-icons';
 
const COLORS = ['#3498DB', '#F4D03F', '#58D68D', '#E74C3C'];
const SKYBLUE = '#87CEEB';
const WHITE = '#FFFFFF';
const DARKBLUE = '#1E2A78';
 
const Container = styled.div`
  padding: 20px;
  background-color: ${WHITE};
  border-radius: 10px;
  box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
`;
 
const Heading = styled.h2`
  font-size: 20px;
  color: ${DARKBLUE};
  text-align: left;
  margin-bottom: 20px;
`;
 
const OptionsIcon = styled.div`
  position: absolute;
  top: 20px;
  right: 20px;
  cursor: pointer;
`;
 
const FilterDropdown = styled.div`
  position: absolute;
  top: 50px;
  right: 0;
  background: ${WHITE};
  box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
  border-radius: 5px;
  z-index: 10;
  padding: 10px;
  display: ${props => (props.show ? 'block' : 'none')};
`;
 
const FilterContainer = styled.div`
  display: flex;
  gap: 10px;
  flex-direction: column;
`;
 
const Filter = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  flex: 1;
`;
 
const Label = styled.label`
  margin-bottom: 5px;
  font-weight: bold;
  color: black;
`;
 
const Select = styled.select`
  border: 1px solid ${SKYBLUE};
  border-radius: 5px;
  padding: 6px;
  font-size: 14px;
  width: 100%;
  max-width: 150px;
  background-color: ${WHITE};
`;
 
const AttendanceInfo = styled.div`
  padding: 20px;
  background-color: ${WHITE};
  border-radius: 10px;
  box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
  text-align: center;
`;
 
const AttendanceLabel = styled.div`
  font-size: 16px;
  color: ${DARKBLUE};
  margin-bottom: 10px;
`;
 
const AttendancePercentage = styled.div`
  font-size: 24px;
  font-weight: bold;
  color: #E74C3C; // Color for the Attendance Percentage
`;
 
const StudentAttendanceDashboard = () => {
  const [attendanceData, setAttendanceData] = useState([]);
  const [filteredData, setFilteredData] = useState([]);
  const [classes, setClasses] = useState([]);
  const [dates, setDates] = useState([]);
  const [sessions, setSessions] = useState([]);
  const [selectedClass, setSelectedClass] = useState('');
  const [selectedDate, setSelectedDate] = useState('');
  const [selectedSession, setSelectedSession] = useState('');
  const [showFilters, setShowFilters] = useState(false);
 
  useEffect(() => {
    const fetchAttendanceData = async () => {
      try {
        const response = await axios.get('http://13.127.57.224:2081/api/dashboradstudentattendance');
        const data = response.data.map(record => ({
          ...record,
          attendance_percentage: record.attendance_percentage || 0
        }));
        setAttendanceData(data);
 
        const uniqueClasses = [...new Set(data.map(record => record.CLASS))];
        const uniqueDates = [...new Set(data.map(record => record.DATE))];
        const uniqueSessions = [...new Set(data.map(record => record.SESSION))];
 
        setClasses(uniqueClasses);
        setDates(uniqueDates);
        setSessions(uniqueSessions);
      } catch (error) {
        console.error('Error fetching student attendance data:', error);
      }
    };
 
    fetchAttendanceData();
  }, []);
 
  const handleClassChange = (e) => setSelectedClass(e.target.value);
  const handleDateChange = (e) => setSelectedDate(e.target.value);
  const handleSessionChange = (e) => setSelectedSession(e.target.value);
 
  useEffect(() => {
    let filtered = attendanceData;
 
    if (selectedClass) {
      filtered = filtered.filter(record => record.CLASS === selectedClass);
    }
    if (selectedDate) {
      filtered = filtered.filter(record => record.DATE === selectedDate);
    }
    if (selectedSession) {
      filtered = filtered.filter(record => record.SESSION === selectedSession);
    }
 
    setFilteredData(filtered);
  }, [selectedClass, selectedDate, selectedSession, attendanceData]);
 
  const processData = (data) => {
    const statusCount = data.reduce((acc, record) => {
      acc[record.STATUS] = (acc[record.STATUS] || 0) + 1;
      return acc;
    }, {});
 
    return Object.entries(statusCount).map(([key, value]) => ({
      name: key,
      value,
    }));
  };
 
  const calculateAttendancePercentage = () => {
    if (filteredData.length === 0) return 0;
 
    const total = filteredData.length;
    const present = filteredData.filter(record => record.STATUS === 'PRESENT').length;
    return Math.round((present / total) * 100); // Remove decimals
  };
 
  return (
    <Container>
      <Heading>Student Attendance</Heading>
      <OptionsIcon onClick={() => setShowFilters(!showFilters)}>
        <ThreeDotsVertical />
      </OptionsIcon>
      <FilterDropdown show={showFilters}>
        <FilterContainer>
          <Filter>
            <Label htmlFor="classFilter">Class</Label>
            <Select id="classFilter" value={selectedClass} onChange={handleClassChange}>
              <option value="">Class</option>
              {classes.map((cls, index) => (
                <option key={index} value={cls}>{cls}</option>
              ))}
            </Select>
          </Filter>
          <Filter>
            <Label htmlFor="dateFilter">Date</Label>
            <Select id="dateFilter" value={selectedDate} onChange={handleDateChange}>
              <option value="">Date</option>
              {dates.map((date, index) => (
                <option key={index} value={date}>{date}</option>
              ))}
            </Select>
          </Filter>
          <Filter>
            <Label htmlFor="sessionFilter">Session</Label>
            <Select id="sessionFilter" value={selectedSession} onChange={handleSessionChange}>
              <option value="">Session</option>
              {sessions.map((session, index) => (
                <option key={index} value={session}>{session}</option>
              ))}
            </Select>
          </Filter>
        </FilterContainer>
      </FilterDropdown>
      <PieChart width={400} height={300}>
        <Pie
          data={processData(filteredData)}
          dataKey="value"
          outerRadius={90}
          innerRadius={60} // Adjust this value to create the donut effect
          fill="#8884d8"
          paddingAngle={5}
        >
          {processData(filteredData).map((entry, index) => (
            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
          ))}
        </Pie>
        <Tooltip />
        <Legend />
      </PieChart>
      <AttendanceInfo>
        <AttendanceLabel>Attendance Percentage</AttendanceLabel>
        <AttendancePercentage>{calculateAttendancePercentage()}%</AttendancePercentage>
      </AttendanceInfo>
    </Container>
  );
};
 
export default StudentAttendanceDashboard;
 