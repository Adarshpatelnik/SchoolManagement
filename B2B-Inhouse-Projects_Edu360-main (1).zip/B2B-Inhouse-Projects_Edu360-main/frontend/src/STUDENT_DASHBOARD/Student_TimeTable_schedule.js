
// import React, { useEffect, useState } from 'react';
// import { AgGridReact } from 'ag-grid-react';
// import axios from 'axios';
// import 'ag-grid-community/styles/ag-grid.css';
// import 'ag-grid-community/styles/ag-theme-alpine.css';
// import 'bootstrap/dist/css/bootstrap.min.css'; // Bootstrap CSS

// const StudentTimeTableschedule = () => {
//   const [classData, setClassData] = useState([]); // Class list
//   const [gridData, setGridData] = useState([]); // Data for selected class
//   const [selectedClass, setSelectedClass] = useState('LKG A'); // Default selected class as 'LKG A'
//   const [loading, setLoading] = useState(true); // Loading state
//   const [error, setError] = useState(''); // Error message

//   // Fetch all class IDs from the backend
//   useEffect(() => {
//     const fetchClassData = async () => {
//       setLoading(true); // Start loading
//       try {
//         const response = await axios.get('http://13.127.57.224:2081/api/Studenttimetable');
//         setClassData(response.data); // Set fetched class IDs
//         console.log('Fetched class data:', response.data);
//         setError(''); // Clear previous error (if any)
//       } catch (error) {
//         console.error('Error fetching class data:', error);
//         setError('Error fetching class data. Please try again later.');
//       } finally {
//         setLoading(false); // Stop loading
//       }
//     };

//     fetchClassData();
//   }, []);

//   // Fetch data for the selected class when component mounts and when selectedClass changes
//   useEffect(() => {
//     const fetchGridData = async () => {
//       if (!selectedClass) return; // Skip if no class is selected

//       setLoading(true); // Start loading
//       try {
//         const response = await axios.get(`http://13.127.57.224:2081/api/class_data?class=${selectedClass}`);
//         setGridData(response.data); // Set data for selected class
//         console.log('Fetched grid data for selected class:', response.data);
//         setError(''); // Clear any previous errors
//       } catch (error) {
//         console.error('Error fetching data for selected class:', error);
//         setError('Error fetching data for the selected class. Please try again.');
//       } finally {
//         setLoading(false); // Stop loading
//       }
//     };

//     fetchGridData();
//   }, [selectedClass]); // Trigger when selectedClass changes

//   // Handle class selection from dropdown
//   const onClassSelect = (event) => {
//     const selectedClassValue = event.target.value;
//     setSelectedClass(selectedClassValue); // Update the selected class
//   };

//   // AG Grid column definitions
//   const columnDefs = [
//     { headerName: 'PERIOD', field: 'PERIOD', sortable: true, filter: true },
//     { headerName: 'TIME SLOT', field: 'TIME_SLOT', sortable: true, filter: true },
//     { headerName: 'MONDAY', field: 'Monday', sortable: true, filter: true },
//     { headerName: 'TUESDAY', field: 'Tuesday', sortable: true, filter: true },
//     { headerName: 'WEDNESDAY', field: 'Wednesday', sortable: true, filter: true },
//     { headerName: 'THURSDAY', field: 'Thursday', sortable: true, filter: true },
//     { headerName: 'FRIDAY', field: 'Friday', sortable: true, filter: true },
//     { headerName: 'SATURDAY', field: 'Saturday', sortable: true, filter: true },
//   ];

//   return (
//     <div className="container mt-" style={{ backgroundColor: '#f9f9f9', borderRadius: '10px',marginTop: '-3rem' }}>
//       {/* Class Selection Dropdown */}
       

//       {/* Display loading or error messages */}
//       {loading && <p className="text-center text-info">Loading data...</p>}
//       {error && <p className="text-center text-danger fw-bold">{error}</p>}

//       {/* AG Grid Table */}
//       <div
//         className="ag-theme-alpine"
//         style={{ height: '30vh', width: '100%', }}
//       >
//         {gridData.length > 0 ? (
//           <AgGridReact       

//             columnDefs={columnDefs}
//             rowData={gridData}
//             pagination={true}
//             paginationPageSize={10}
//             suppressPaginationPanel={true} // Hides the pagination controls
//             // domLayout='autoHeight' // Makes the grid responsive to the content height
//           />
//         ) : (
//           !loading && <p className="text-center text-muted">No data available for the selected class.</p>
//         )}
//       </div>
//     </div>
//   );
// };

// export default StudentTimeTableschedule;




// import React, { useEffect, useState } from 'react';
// import { AgGridReact } from 'ag-grid-react';
// import axios from 'axios';
// import 'ag-grid-community/styles/ag-grid.css';
// import 'ag-grid-community/styles/ag-theme-alpine.css';
// import 'bootstrap/dist/css/bootstrap.min.css'; // Bootstrap CSS

// const StudentTimeTableschedule = () => {
//   const [classData, setClassData] = useState([]); // Class list
//   const [gridData, setGridData] = useState([]); // Data for selected class
//   const [selectedClass, setSelectedClass] = useState('LKG A'); // Default selected class as 'LKG A'
//   const [loading, setLoading] = useState(true); // Loading state
//   const [error, setError] = useState(''); // Error message

//   // Fetch all class IDs from the backend
//   useEffect(() => {
//     const fetchClassData = async () => {
//       setLoading(true); // Start loading
//       try {
//         const response = await axios.get('http://13.127.57.224:2081/api/Studenttimetable');
//         setClassData(response.data); // Set fetched class IDs
//         console.log('Fetched class data:', response.data);
//         setError(''); // Clear previous error (if any)
//       } catch (error) {
//         console.error('Error fetching class data:', error);
//         setError('Error fetching class data. Please try again later.');
//       } finally {
//         setLoading(false); // Stop loading
//       }
//     };

//     fetchClassData();
//   }, []);

//   // Fetch data for the selected class when component mounts and when selectedClass changes
//   useEffect(() => {
//     const fetchGridData = async () => {
//       if (!selectedClass) return; // Skip if no class is selected

//       setLoading(true); // Start loading
//       try {
//         const response = await axios.get(`http://13.127.57.224:2081/api/class_data?class=${selectedClass}`);
//         setGridData(response.data); // Set data for selected class
//         console.log('Fetched grid data for selected class:', response.data);
//         setError(''); // Clear any previous errors
//       } catch (error) {
//         console.error('Error fetching data for selected class:', error);
//         setError('Error fetching data for the selected class. Please try again.');
//       } finally {
//         setLoading(false); // Stop loading
//       }
//     };

//     fetchGridData();
//   }, [selectedClass]); // Trigger when selectedClass changes

//   // Handle class selection from dropdown
//   const onClassSelect = (event) => {
//     const selectedClassValue = event.target.value;
//     setSelectedClass(selectedClassValue); // Update the selected class
//   };

//   // AG Grid column definitions
//   const columnDefs = [
//     { headerName: 'PERIOD', field: 'PERIOD', sortable: true, filter: true },
//     { headerName: 'TIME SLOT', field: 'TIME_SLOT', sortable: true, filter: true },
//     { headerName: 'MONDAY', field: 'Monday', sortable: true, filter: true },
//     { headerName: 'TUESDAY', field: 'Tuesday', sortable: true, filter: true },
//     { headerName: 'WEDNESDAY', field: 'Wednesday', sortable: true, filter: true },
//     { headerName: 'THURSDAY', field: 'Thursday', sortable: true, filter: true },
//     { headerName: 'FRIDAY', field: 'Friday', sortable: true, filter: true },
//     { headerName: 'SATURDAY', field: 'Saturday', sortable: true, filter: true },
//   ];

//   return (
//     <div className="container mt-" style={{ backgroundColor: '#f9f9f9', borderRadius: '10px', marginTop: '-1rem' }}>
//       {/* Class Selection Dropdown */}

//       {/* Display loading or error messages */}
//       {loading && <p className="text-center text-info">Loading data...</p>}
//       {error && <p className="text-center text-danger fw-bold">{error}</p>}

//       {/* AG Grid Table */}
//       <div
//         className="ag-theme-alpine"
//         style={{ height: '70vh', width: '100%' }}
//       >
//         {gridData.length > 0 ? (
//           <AgGridReact
//             columnDefs={columnDefs}
//             rowData={gridData}
//             domLayout="autoHeight" // Automatically adjust grid height
//             pagination={false} // Disable pagination
//           />
//         ) : (
//           !loading && <p className="text-center text-muted">No data available for the selected class.</p>
//         )}
//       </div>
//     </div>
//   );
// };

// export default StudentTimeTableschedule;







// import React, { useEffect, useState } from 'react';
// import { AgGridReact } from 'ag-grid-react';
// import axios from 'axios';
// import 'ag-grid-community/styles/ag-grid.css';
// import 'ag-grid-community/styles/ag-theme-alpine.css';
// import 'bootstrap/dist/css/bootstrap.min.css';
// import styled from 'styled-components';



// const Heading = styled.h3`
//   font-size: 1.1rem;
//   font-weight: 600; 
//   font-family: 'Lato', sans-serif;
//   color: #333;  
//   margin-bottom: 30px;
//   padding: 5px 10px;
//   letter-spacing: px;
//   border-radius:12px;
//   display: inline-block;
  
//   background: linear-gradient(135deg, #f0f0f0, #e0e0e0);
//   border-bottom: 1px solid #b0b0b0; 
  
//   transition: transform 0.3s ease, box-shadow 0.3s ease, background 0.3s ease;

 

//   @media (max-width: 400px) {
//     font-size: 1.2rem;
//     padding: 8px 16px;
//     margin-bottom: 20px;
//   }
// `;

// const StudentTimeTableschedule = () => {
//   const [classData, setClassData] = useState([]);
//   const [gridData, setGridData] = useState([]);
//   const [selectedClass, setSelectedClass] = useState('LKG A');
//   const [loading, setLoading] = useState(true);
//   const [error, setError] = useState('');

//   useEffect(() => {
//     const fetchClassData = async () => {
//       setLoading(true);
//       try {
//         const response = await axios.get('http://13.127.57.224:2081/api/Studenttimetable');
//         setClassData(response.data);
//         setError('');
//       } catch (error) {
//         setError('Error fetching class data. Please try again later.');
//       } finally {
//         setLoading(false);
//       }
//     };

//     fetchClassData();
//   }, []);

//   useEffect(() => {
//     const fetchGridData = async () => {
//       if (!selectedClass) return;

//       setLoading(true);
//       try {
//         const response = await axios.get(`http://13.127.57.224:2081/api/class_data?class=${selectedClass}`);
//         setGridData(response.data);
//         setError('');
//       } catch (error) {
//         setError('Error fetching data for the selected class. Please try again.');
//       } finally {
//         setLoading(false);
//       }
//     };

//     fetchGridData();
//   }, [selectedClass]);

//   const onClassSelect = (event) => {
//     setSelectedClass(event.target.value);
//   };

//   // Determine the current day
//   const currentDay = new Date().toLocaleString('en-us', { weekday: 'long' });

//   // Column definitions with conditional cell styling based on the current day
//   const columnDefs = [
//     { headerName: 'PERIOD', field: 'PERIOD', sortable: true, filter: true, width: 100, cellStyle: { padding: '5px' } },
//     { headerName: 'TIME SLOT', field: 'TIME_SLOT', sortable: true, filter: true, width: 150, cellStyle: { padding: '5px' } },
//     {
//       headerName: 'MONDAY',
//       field: 'Monday',
//       sortable: true,
//       filter: true,
//       width: 150,
//       cellStyle: params => ({
//         padding: '5px',
//         backgroundColor: currentDay === 'Monday' ? '#088F8F' : undefined, // Highlight current day
//         color: currentDay === 'Monday' ? '#fff' : '#000'
//       })
//     },
  //   {
  //     headerName: 'TUESDAY',
  //     field: 'Tuesday',
  //     sortable: true,
  //     filter: true,
  //     width: 150,
  //     cellStyle: params => ({
  //       padding: '5px',
  //       backgroundColor: currentDay === 'Tuesday' ? '#6495ED	' : undefined,
  //       color: currentDay === 'Tuesday' ? '#fff' : '#000'
  //     })
  //   },
  //   {
  //     headerName: 'WEDNESDAY',
  //     field: 'Wednesday',
  //     sortable: true,
  //     filter: true,
  //     width: 150,
  //     cellStyle: params => ({
  //       padding: '5px',
  //       backgroundColor: currentDay === 'Wednesday' ? '#4682B4	' : undefined,
  //       color: currentDay === 'Wednesday' ? '#fff' : '#000'
  //     })
  //   },
  //   {
  //     headerName: 'THURSDAY',
  //     field: 'Thursday',
  //     sortable: true,
  //     filter: true,
  //     width: 150,
  //     cellStyle: params => ({
  //       padding: '5px',
  //       backgroundColor: currentDay === 'Thursday' ? '#6F8FAF	' : undefined,
  //       color: currentDay === 'Thursday' ? '#fff' : '#000'
  //     })
  //   },
  //   {
  //     headerName: 'FRIDAY',
  //     field: 'Friday',
  //     sortable: true,
  //     filter: true,
  //     width: 150,
  //     cellStyle: params => ({
  //       padding: '5px',
  //       backgroundColor: currentDay === 'Friday' ? '#5F9EA0	' : undefined,
  //       color: currentDay === 'Friday' ? '#fff' : '#000'
  //     })
  //   },
  //   {
  //     headerName: 'SATURDAY',
  //     field: 'Saturday',
  //     sortable: true,
  //     filter: true,
  //     width: 150,
  //     cellStyle: params => ({
  //       padding: '5px',
  //       backgroundColor: currentDay === 'Saturday' ? '#566573 ' : undefined,
  //       color: currentDay === 'Saturday' ? '#fff' : '#000'
  //     })
  //   },
  // ];

//   return (
//     <div className="container" style={{ backgroundColor: '#f9f9f9', borderRadius: '10px', marginTop: '-1rem' }}>
//       <div className="mb-3 d-flex justify-content-center align-items-center">
//       <Heading>Time Table schedule

//         <label htmlFor="class-select" className="me-2 fw-semibold text-secondary">Class</label>
        // <select
        //   id="class-select"
        //   onChange={onClassSelect}
        //   value={selectedClass}
        //   className="form-select w-auto shadow-sm"
        //   style={{ borderRadius: '8px' }}
        // >
        //   <option value="">-- Select Class --</option>
        //   {classData.map((classItem) => (
        //     <option key={classItem.CLASS_ID} value={classItem.CLASS_ID}>
        //       {classItem.CLASS_ID}
        //     </option>
        //   ))}
        // </select>
//         </Heading>
//       </div>

//       {loading && <p className="text-center text-info">Loading data...</p>}
//       {error && <p className="text-center text-danger fw-bold">{error}</p>}

//       <div className="ag-theme-alpine" style={{ height: '55vh', width: '100%' }}>
//         {gridData.length > 0 ? (
//           <AgGridReact
//             columnDefs={columnDefs}
//             rowData={gridData}
//             pagination={true}
//             paginationPageSize={10}
//             suppressPaginationPanel={true}
//           />
//         ) : (
//           !loading && <p className="text-center text-muted">No data available for the selected class.</p>
//         )}
//       </div>
//     </div>
//   );
// };

// export default StudentTimeTableschedule;



import React, { useEffect, useState } from 'react';
import { AgGridReact } from 'ag-grid-react';
import axios from 'axios';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import styled from 'styled-components';

const Heading = styled.h3`
  font-size: 1.1rem;
  font-weight: 600; 
  font-family: 'Lato', sans-serif;
  color: #333;  
  margin-bottom: px;
  padding: 5px 10px;
  letter-spacing: 1px;
  border-radius: 12px;
  display: block; /* Set display to block to take full width */
  width: 100%; /* Full width */
  text-align: left; /* Optional: Align text to the left */
  
  background: linear-gradient(135deg, #f0f0f0, #e0e0e0);
  border-bottom: 1px solid #b0b0b0; 
  
  transition: transform 0.3s ease, box-shadow 0.3s ease, background 0.3s ease;

  @media (max-width: 400px) {
    font-size: 1.2rem;
    padding: 8px 16px;
    margin-bottom: 20px;
  }
`;


const StudentTimeTableschedule = () => {
  const [classData, setClassData] = useState([]);
  const [gridData, setGridData] = useState([]);
  const [selectedClass, setSelectedClass] = useState('LKG A');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchClassData = async () => {
      setLoading(true);
      try {
        const response = await axios.get('http://13.127.57.224:2081/api/Studenttimetable');
        setClassData(response.data);
        setError('');
      } catch (error) {
        setError('Error fetching class data. Please try again later.');
      } finally {
        setLoading(false);
      }
    };

    fetchClassData();
  }, []);

  useEffect(() => {
    const fetchGridData = async () => {
      if (!selectedClass) return;

      setLoading(true);
      try {
        const response = await axios.get(`http://13.127.57.224:2081/api/class_data?class=${selectedClass}`);
        setGridData(response.data);
        setError('');
      } catch (error) {
        setError('Error fetching data for the selected class. Please try again.');
      } finally {
        setLoading(false);
      }
    };

    fetchGridData();
  }, [selectedClass]);

  const onClassSelect = (event) => {
    setSelectedClass(event.target.value);
  };

  const currentDay = new Date().toLocaleString('en-us', { weekday: 'long' });

  const columnDefs = [
    { headerName: 'PERIOD', field: 'PERIOD', sortable: true, filter: true, width: 100 },
    { headerName: 'TIME SLOT', field: 'TIME_SLOT', sortable: true, filter: true, width: 150 },
    {
      headerName: 'MONDAY',
      field: 'Monday',
      sortable: true,
      filter: true,
      width: 150,
      cellStyle: params => ({
        backgroundColor: currentDay === 'Monday' ? '#088F8F' : undefined,
        color: currentDay === 'Monday' ? '#fff' : '#000'
      })
    },
    {
      headerName: 'TUESDAY',
      field: 'Tuesday',
      sortable: true,
      filter: true,
      width: 150,
      cellStyle: params => ({
        padding: '5px',
        backgroundColor: currentDay === 'Tuesday' ? '#6495ED	' : undefined,
        color: currentDay === 'Tuesday' ? '#fff' : '#000'
      })
    },
    {
      headerName: 'WEDNESDAY',
      field: 'Wednesday',
      sortable: true,
      filter: true,
      width: 150,
      cellStyle: params => ({
        padding: '5px',
        backgroundColor: currentDay === 'Wednesday' ? '#4682B4	' : undefined,
        color: currentDay === 'Wednesday' ? '#fff' : '#000'
      })
    },
    {
      headerName: 'THURSDAY',
      field: 'Thursday',
      sortable: true,
      filter: true,
      width: 150,
      cellStyle: params => ({
        padding: '5px',
        backgroundColor: currentDay === 'Thursday' ? '#6F8FAF	' : undefined,
        color: currentDay === 'Thursday' ? '#fff' : '#000'
      })
    },
    {
      headerName: 'FRIDAY',
      field: 'Friday',
      sortable: true,
      filter: true,
      width: 150,
      cellStyle: params => ({
        padding: '5px',
        backgroundColor: currentDay === 'Friday' ? '#5F9EA0	' : undefined,
        color: currentDay === 'Friday' ? '#fff' : '#000'
      })
    },
    {
      headerName: 'SATURDAY',
      field: 'Saturday',
      sortable: true,
      filter: true,
      width: 150,
      cellStyle: params => ({
        padding: '5px',
        backgroundColor: currentDay === 'Saturday' ? '#566573 ' : undefined,
        color: currentDay === 'Saturday' ? '#fff' : '#000'
      })
    },
  ];

  return (
    <div className="container" style={{ backgroundColor: '#f9f9f9', borderRadius: '10px', marginTop: '0.2rem' }}>
 <Heading>
  <div className="d-flex justify-content-between align-items-center">
    <span>Time Table Schedule</span>
    <div className="d-flex align-items-center">
      <label htmlFor="class-select" className="me-2 fw-semibold text-secondary">Class</label>
      <select
        id="class-select"
        onChange={onClassSelect}
        value={selectedClass}
        className="form-select w-auto shadow-sm"
        style={{ borderRadius: '8px' }}
      >
        <option value="">Class</option>
        {classData.map((classItem) => (
          <option key={classItem.CLASS_ID} value={classItem.CLASS_ID}>
            {classItem.CLASS_ID}
          </option>
        ))}
      </select>
    </div>
  </div>
</Heading>

      

      {loading && <p className="text-center text-info">Loading data...</p>}
      {error && <p className="text-center text-danger fw-bold">{error}</p>}

      <div className="ag-theme-alpine" style={{ height: '55vh', width: '100%' }}>
        {gridData.length > 0 ? (
          <AgGridReact
            columnDefs={columnDefs}
            rowData={gridData}
            pagination={true}
            paginationPageSize={10}
            suppressPaginationPanel={true}
          />
        ) : (
          !loading && <p className="text-center text-muted">No data available for the selected class.</p>
        )}
      </div>
    </div>
  );
};

export default StudentTimeTableschedule;
