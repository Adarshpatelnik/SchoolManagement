import React, { useState, useContext, useEffect } from 'react';
import styled from 'styled-components';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {
  faTachometerAlt, faAddressCard, faUserAlt, faChevronRight,faEnvelope,
  faUserTie, faClipboardList, faBars, faPowerOff, faFileAlt, faChevronDown
} from '@fortawesome/free-solid-svg-icons';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { AuthContext } from '../SECURITY & OTHERS/AuthContext';

// Styled component for the circle icon
const CircleIcon = styled.div`
  width: 16px;
  height: 16px;
  border-radius: 50%;
  background: ${props => (props.isActive ? 'transparent' : 'transparent')};
  border: 2px solid gray;
  margin-right: 8px;
  margin-left: 23px;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: background 0.3s ease;
`;

// Update Sidebar to conditionally render text in LogoContainer
const Sidebar = styled.div`
  height: 100%;
  width: ${props => (props.isVisible ? '250px' : '74px')};
  position: fixed;
  top: 0;
  left: 0;
  background: linear-gradient(145deg, #454545, #34495e);
  color: #ecf0f1;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  overflow-x: hidden;
  transition: width 0.4s ease, background 0.4s ease;
  padding-top: ${props => (props.isVisible ? '8.6rem' : '8.6rem')}; /* Adjust padding for collapsed state */
  z-index: 1000;
  display: flex;
  flex-direction: column;
  justify-content: flex-start; /* Adjust to fit logo correctly */

  &:hover {
    width: ${props => (props.isHovered || props.isVisible ? '250px' : '74px')}; /* Expand only if hovered or visible */
  }
`;



const Logo = styled.img`
  width: 40px; /* Set a fixed width for consistency */
  height: 40px; /* Ensure the height matches the width for a perfect circle */
  border-radius: 50%; /* Make the image circular */
  background: white; /* Circle background color */
  border: 1px solid #fff; /* Border around the circle */
  object-fit: contain; /* Adjust image size while maintaining aspect ratio */
  position: fixed;
  top: 10px; /* Position from the top of the screen */
  left: 17px; /* Position from the left of the screen */
  transition: transform 0.3s ease, box-shadow 0.3s ease;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
  
  &:hover {
    transform: scale(1.05);
    box-shadow: 0 8px 16px rgba(0, 0, 0, 0.3);
  }
  
  @media (max-width: 768px) {
    width: 40px;
    height: 40px; /* Ensure the height matches the width for smaller screens */
    top: 10px;
    left: 10px;
  }
`;

// Styled component for the text with a gradient effect
const Text = styled.span`
  font-size: 1.5rem;
  padding: 11px 50px; 
  font-weight: bold; 
  text-transform: uppercase; 
  position: absolute;
  top: 0px; 
  left: 14px; 
  background: linear-gradient(145deg, #012353, #27AE60);
  -webkit-background-clip: text; 
  -webkit-text-fill-color: white; 
  color: white; 
`;

const Navbar = styled.div`
  position: fixed;
  top: 0;
  left: ${props => (props.sidebarVisible ? '225px' : '60px')};
  height: 60px;
  width: calc(100% - ${props => (props.sidebarVisible ? '225px' : '60px')});
  background: #e5e8e8;
  color: #2c3e50;
  display: flex;
  align-items: center;
  padding: 0 2rem;
  border-bottom: 1px solid #e1e6eb;
  border-radius: 0 0 10px 10px;
  transition: left 0.3s ease, width 0.3s ease;
  z-index: 999;

  @media only screen and (max-width: 768px) {
    left: ${props => (props.sidebarVisible ? '250px' : '60px')};
    width: calc(100% - ${props => (props.sidebarVisible ? '250px' : '60px')});
  }
`;

const NavItem = styled(Link)`
  color: ${props => (props.isActive ? 'black' : 'gray')};
  text-decoration: none;
  margin-left: 2.5rem;
  font-size: 1rem;

  &:hover {
    color: black;
  }
`;

const ToggleButton = styled.div`
  font-size: 1.2rem;
  color: #2c3e50;
  cursor: pointer;
  position: absolute;
  top: 1.1rem;
  left: 2rem;
  z-index: 1001;

  @media only screen and (max-width: 768px) {
    left: 1.1rem;
    top: 1rem;
  }
`;

const LogoutButton = styled.button`
  border: none;
  color: black;
  cursor: pointer;
  display: flex;
  align-items: center;
  font-size: 1.2rem;
  padding: 0.4rem 0.4rem;
  margin-left: auto;
  background: #e5e8e8;

  &:active {
    color: black;
  }

  @media only screen and (max-width: 768px) {
    margin-right: 1rem;
  }
`;

const Icon = styled.div`
  margin-right: 6px;
  display: flex;
  
  font-size: 1.5rem;
  align-items: center;
   svg {
    margin-left: 8px;
  }

`;

const SidebarItem = styled.div`
  padding: 9px 11px;
  display: flex;
  border-radius: 4px;
  align-items: center;
  cursor: pointer;
  font-size: 1rem;
  color: ${props => (props.isActive ? '#fff' : 'white')};
  background: ${props => (props.isActive ? '#2980b9' : 'transparent')};
  transition: background 0.2s ease, width 0.3s ease, padding 0.3s ease, margin 0.3s ease;
  white-space: nowrap;
  overflow: hidden;
  margin: 5px 0; /* Add margin to create gap */

  &:hover {
    background: #2980b9;
  }

  ${props => props.isExpanded && `
    padding: 1rem 1rem; /* Adjusted left and right padding for expanded state */
  `}
`;



const SidebarLink = styled(Link)`
  color: inherit;
  text-decoration: none;
  display: flex;
  align-items: center;
  width: 100%;
  height: 100%;
`;

const SidebarDropdownMenu = styled.div`
  display: ${props => (props.isVisible ? '#fff' : 'none')};
  padding: -1px 13px;
`;

const SidebarDropdownItem = styled.div`
  padding: 7px 3px; /* Adjust as necessary for dropdown item specific styles */
  display: flex;
  align-items: center;
  border-radius: 4px;
  cursor: pointer;
  font-size: 1rem;
  color: ${props => (props.isActive ? 'black' : '#e5e8e8')};
  background: ${props => (props.isActive ? '#fff' : 'transparent')}; /* White background for active, transparent for non-active */
  transition: background 0.3s ease, margin 0.3s ease;
  margin: 5px 0; /* Add margin to create gap */

  &:hover {
    background: #5d6d7e;
    color: white;
  }

  &.active {
    background: #fff;
  }
`;




const StudentLanding = () => {
  const [sidebarVisible, setSidebarVisible] = useState(true);
  const [sidebarHovered, setSidebarHovered] = useState(false);

  const [visibleDropdown, setVisibleDropdown] = useState(null);
  const { logout } = useContext(AuthContext);
  const navigate = useNavigate();
  const location = useLocation();

  const toggleSidebar = () => {
    setSidebarVisible(prev => {
      const newState = !prev;
      if (!newState) {
        setVisibleDropdown(null); // Close dropdowns when sidebar is collapsed
      }
      return newState;
    });
  };

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  const showDropdown = (dropdown) => {
    setVisibleDropdown(visibleDropdown === dropdown ? null : dropdown);
  };

  const handleSidebarLinkClick = (path) => {
    if (location.pathname === path) {
      setVisibleDropdown(null); // Close dropdown if same link is clicked
    }
  };
  const determineDropdownVisibility = () => {
    if (sidebarVisible) { // Only set dropdown visibility if sidebar is visible
      if (location.pathname.startsWith('/Edit_Form') || location.pathname.startsWith('/')) {
        return 'Admission';
      } else if (location.pathname.startsWith('/Student_Profile') || location.pathname.startsWith('/parent_profile') || location.pathname.startsWith('/Student_Attendance') || location.pathname.startsWith('/Student_Academic_Performance') || location.pathname.startsWith('/Student_health') || location.pathname.startsWith('/Student_Grad_Book') || location.pathname.startsWith('/Student_performance')) {
        return 'student';
      } else if (location.pathname.startsWith('/Assignment_Form') || location.pathname.startsWith('/Application_form') ||location.pathname.startsWith('/StudentFill_Attendance') || location.pathname.startsWith('/Student_Grade_Book_Entry') || location.pathname.startsWith('/Student_promoted_form') ) {
        return 'Form';
      } else if (location.pathname.startsWith('/Assignment')) {
        return 'academic';
      } else if (location.pathname.startsWith('/Staff_Profile') || location.pathname.startsWith('/Staff_Attendance')) {
        return 'Staff';
      }
    }
    return null;
  };

  useEffect(() => {
    const dropdownToShow = determineDropdownVisibility();
    setVisibleDropdown(dropdownToShow);
  }, [location.pathname, sidebarVisible]);

  return (
    <>
    
      <Sidebar
      
        isVisible={sidebarVisible}
        isHovered={sidebarHovered}
        onMouseEnter={() => setSidebarHovered(true)}
        onMouseLeave={() => setSidebarHovered(false)}
      >

        
        <div>
          
        <div >
  <Logo isVisible={sidebarVisible} src="02 1 copy.jpg" alt="Logo" />
  
  {sidebarVisible || sidebarHovered ? <Text>Edu360</Text> : null}

  
  <hr style={{ width: '100%', height: '1px', backgroundColor: 'grey', margin: '0', padding: '0', border: 'none' ,}} />
</div>



  {/* dashboard */}
          
          <SidebarItem isActive={location.pathname === '/Student_Dashboard'} onClick={() => handleSidebarLinkClick('/Student_Dashboard')}>
            <SidebarLink to="/Student_Dashboard">
            <Icon style={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-start', marginLeft: '4px' }}>
            <FontAwesomeIcon icon={faTachometerAlt} />
              </Icon>
              {sidebarVisible || sidebarHovered ? 'DashBoard' : null}
            </SidebarLink>
          </SidebarItem>
     

       {/* form */}

    
       <SidebarItem isActive={location.pathname === '/Edit_Form'} onClick={() => handleSidebarLinkClick('/Edit_Form')}>
            <SidebarLink to="/Edit_Form">
            <Icon style={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-start', marginLeft: '4px' }}>
            <FontAwesomeIcon icon={faTachometerAlt} />
              </Icon>
              {sidebarVisible || sidebarHovered ? 'Student Profile' : null}
            </SidebarLink>
          </SidebarItem>
     


  {/* message */}
  
      


         </div>
         <div>
        </div>
      </Sidebar>

  {/* navbar */}

      <Navbar sidebarVisible={sidebarVisible}>
        <ToggleButton onClick={toggleSidebar}>
          <FontAwesomeIcon icon={faBars} />
        </ToggleButton>
        <NavItem to="/Student_Dashboard" isActive={location.pathname === '/Student_Dashboard'}>Home</NavItem>
        <LogoutButton onClick={handleLogout}>
          <Icon><FontAwesomeIcon icon={faPowerOff} /></Icon>
         </LogoutButton>
      </Navbar>
    </>
  );
};

export default StudentLanding;




