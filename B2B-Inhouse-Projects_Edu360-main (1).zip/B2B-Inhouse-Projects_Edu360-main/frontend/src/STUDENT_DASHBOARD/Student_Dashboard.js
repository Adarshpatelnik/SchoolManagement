
// // Student_Dashboard.js
// import React, { useState, useEffect } from 'react';
// import styled from 'styled-components'; // Import styled from styled-components
// import StudentPerformance from './Student_performance_Chart';
// import StudentEventCalendar from './Student_eventcalendar';
// // import StudentLanding from './Student_landing';
// import StudentAttendanceDashbord from './Student_Attendance_Dashbord'; // Ensure this file exists
// import StudentAssignment  from './Student_Assignment';
// import StudentNavbar from './Student_Navbar.js';

// // Styled Heading component
// const Heading = styled.h2`
//   font-size: 24px;
//   color: #333;
//   margin-bottom: 20px;
// `;

// const StudentDashboard = () => {
//   return (
// <>
// <StudentNavbar />
//       <div className="container-fluid" style={{ marginLeft: '12vh', marginTop: '11vh', width: '94%', padding: 0 }}>
//             <Heading>Student Performance</Heading>
//             <StudentPerformance />
//           <StudentAttendanceDashbord /> {/* Include Attendance Dashboard */}
//           <StudentEventCalendar />
//           <StudentAssignment />
          
//       </div>
//       </>
//   );
// };

// export default StudentDashboard;









import React from 'react';
import styled from 'styled-components';
import StudentPerformance from './Student_performance_Chart';
import StudentEventCalendar from './Student_eventcalendar';
import StudentAttendanceDashbord from './Student_Attendance_Dashbord';
import StudentTimeTableschedule from './Student_TimeTable_schedule';
import StudentNavbar from './Student_Navbar.js';
import { FaChartLine, FaCalendarAlt, FaClipboardList } from 'react-icons/fa'; // Import icons for the cards

// Styled components
const Container = styled.div`
  padding-top: 10px;
  min-height: 100vh;
  padding: 0 20px;
  max-width: 100%;
  margin: 0 auto;
  background-color: #F0F6FA	;

  @media (max-width: 1200px) {
    max-width: 1000px;
  }
  @media (max-width: 992px) {
    max-width: 800px;
  }
  @media (max-width: 768px) {
    padding: 0 10px;
  }
  @media (max-width: 576px) {
    padding: 0 5px;
  }
`;


const Card = styled.div`
  background-color: #ffffff;
  border: 2px solid #ccc; /* Add this line for a 1px border */
  border-radius: 4px; /* Adjust the radius value as needed */
  padding: 0px;
  margin-bottom: 15%;
  min-height: 0;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  transition: transform 0.3s ease, box-shadow 0.3s ease;
  // box-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);

  @media (max-width: 768px) {
    padding: 15px;
    min-height: 250px;
  }
`;

const InfoCard = styled.div`
  display: flex;
  border-radius: 12px;
  align-items: center;
  justify-content: center;
  padding: 1px;
  margin: 8px 0;
  flex: 1;
  background: ${(props) => props.gradient};
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.2);
  transition: transform 0.3s ease, box-shadow 0.3s ease;

  &:hover {
    transform: scale(1.05);
    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.3);
  }
`;

const InfoText = styled.div`
  display: flex;
  flex-direction: column;
  margin-left: 10px;
  color: #333;

  strong {
    font-size: 1.1rem; 
    margin-bottom: 5px;
    font-weight: 600; 
  }

  div {
    font-size: 1.8rem; 
    font-weight: bold;
  }
`;

const IconContainer = styled.div`
  font-size: 2rem; 
  margin-right: 20px;
  color: white; 
  border-radius: 50%;
  padding: 7px;
  background: rgba(0, 0, 0, 0.15);
  transition: transform 0.3s ease, box-shadow 0.3s ease;

  &:hover {
    transform: scale(1.2); 
    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
  }
`;

const Heading = styled.h3`
  font-size: 1.1rem;
  font-weight: 600; 
  font-family: 'Lato', sans-serif;
  color: #333;  
  margin-bottom: 30px;
  padding: 5px 10px;
  letter-spacing: px;
  border-radius:12px;
  display: inline-block;
  
  background: linear-gradient(135deg, #f0f0f0, #e0e0e0);
  border-bottom: 1px solid #b0b0b0; 
  
  transition: transform 0.3s ease, box-shadow 0.3s ease, background 0.3s ease;

 

  @media (max-width: 400px) {
    font-size: 1.2rem;
    padding: 8px 16px;
    margin-bottom: 20px;
  }
`;


const StudentDashboard = () => {
  return (
    <>
      <StudentNavbar />
      <Container className="container-fluid" style={{ marginTop: '10vh', width: '97%', padding: 0 }}>
        
         
        <div className="row">
          <div className="col-lg-4 " style={{ padding: '0 2px' }}>
            <Card style={{ height: '43vh', borderRadius: '16px' }}>
              <Heading>My Attendance</Heading>
              <StudentAttendanceDashbord />
            </Card>
          </div>
          <div className="col-lg-4 "style={{ padding: '0 2px' }}>
            <Card style={{ height: '43vh', borderRadius: '16px' }}>
              <Heading>Event Calendar</Heading>
              <StudentEventCalendar />
            </Card>
          </div>
       
          <div className="col-lg-4"style={{ padding: '0 2px' }}>
<Card style={{ height: '43vh', borderRadius: '16px' }}>
  <Heading> Performance Chart</Heading>
  <StudentPerformance />
</Card>
</div>
          
        </div>



        <div className="row"style={{ marginTop: '-9vh'  }}>
         <div className="col-lg-10">
            <Card style={{ height: '44vh', borderRadius: '16px' }}>
              {/* <Heading>TimeTable schedule</Heading> */}
              <StudentTimeTableschedule />
            </Card>
          
</div>
        
        </div>
      </Container>
    </>
  );
};

export default StudentDashboard;


