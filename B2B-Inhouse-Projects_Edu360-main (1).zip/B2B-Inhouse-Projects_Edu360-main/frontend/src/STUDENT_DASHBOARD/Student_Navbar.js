// import React from 'react';
// import { Navbar, Nav } from 'react-bootstrap';
// import { Link } from 'react-router-dom';
// import { FaPowerOff } from 'react-icons/fa'; // Import the logout icon
// import { FiClipboard } from 'react-icons/fi'; // Import the icon

// const StudentNavbar = () => {
//     const navbarStyle = {
//         backgroundColor: '#f8f9fa', // Light background
//         padding: '10px 20px', // Padding for the navbar
//         position: 'fixed', // Fix the navbar to the top
//         top: 0, // Align it to the top
//         left: 0, // Align it to the left
//         width: '100%', // Full width of the viewport
//         zIndex: 1000 // Ensure it's above other elements
//     };

//     const navLinkStyle = {
//         margin: '0 20px', // Margin between links
//         color: 'black', // Link color
//         textDecoration: 'none', // Remove underline
//         fontWeight: '500', // Set a font weight for better readability
//         transition: 'color 0.3s', // Add transition for hover effect
//     };

//     const logoutStyle = {
//         color: 'black', // Logout button color
//         fontWeight: 'bold', // Bold text for Logout
//         textDecoration: 'none', // Remove underline from Logout
//         transition: 'color 0.3s', // Add transition for hover effect
//         display: 'flex', // Use flex to align icon and text
//         alignItems: 'center', // Center align the items
//     };

//     const brandFontSize = 1.5; // Font size for the brand

//     // Define the logo dimensions and margins
//     const brandLogoWidth = 2; // Reduced width of the logo in rem
//     const brandLogoHeight = 2; // Reduced height of the logo in rem
//     const brandLogoMarginRight = 0.2; // Right margin for the logo in rem
//     const brandLogoMarginBottom = 0.2; // Bottom margin for the logo in rem

//     return (
//         <Navbar style={navbarStyle} expand="lg">
//             <img 
//                 src="02 1.jpg" 
//                 alt="B2B360 Logo" 
//                 style={{ 
//                     width: `${brandLogoWidth}rem`, 
//                     height: `${brandLogoHeight}rem`, 
//                     marginRight: `${brandLogoMarginRight}rem`, 
//                     marginBottom: `${brandLogoMarginBottom}rem` 
//                 }} 
//             />
//             <span
//                 style={{
//                     fontFamily: 'Playfair Display, serif',
//                     fontSize: `${brandFontSize}em`, // Use the defined font size
//                     fontWeight: 'bold',
//                     backgroundImage: 'linear-gradient(to right, #012353, #27AE60)',
//                     WebkitBackgroundClip: 'text',
//                     WebkitTextFillColor: 'transparent',
//                 }}
//             >
//                 EDU<span style={{ color: '#dc3545' }}>3</span>6<span style={{ color: '#28a745' }}>0</span>
//             </span>
//             <Navbar.Toggle aria-controls="basic-navbar-nav" />
//             <Navbar.Collapse id="basic-navbar-nav" className="justify-content-end"> {/* Align Nav to the end */}
//                 <Nav className="d-flex justify-content-end"> {/* Align items to the right */}
//                     <Nav.Link as={Link} to="/Student_Dashboard" style={navLinkStyle}>Home</Nav.Link>
//                     <Nav.Link as={Link} to="/Edit_Form" style={navLinkStyle}>
//   <FiClipboard style={{ marginRight: '5px' }} /> {/* Add the icon with some spacing */}
//   Issue Bord
// </Nav.Link>                    <Nav.Link as={Link} to="/Student_Assignment" style={navLinkStyle}>Assignments</Nav.Link>

//                     {/* <NavDropdown title="Services" id="basic-nav-dropdown" style={navLinkStyle}>
//                         <NavDropdown.Item as={Link} to="/service1">Service 1</NavDropdown.Item>
//                         <NavDropdown.Item as={Link} to="/service2">Service 2</NavDropdown.Item>
//                         <NavDropdown.Item as={Link} to="/service3">Service 3</NavDropdown.Item>
//                     </NavDropdown> */}
//                     <Nav.Link href="/Login" style={logoutStyle}>
//                         <FaPowerOff style={{ marginRight: '5px' }} /> {/* Use FaPowerOff for the logout icon */}
                   
//                     </Nav.Link>
//                 </Nav>
//             </Navbar.Collapse>
//         </Navbar>
//     );
// };

// export default StudentNavbar;




import React, { useState } from 'react';
import { Navbar, Nav, Modal, Button } from 'react-bootstrap';
import { Link, useNavigate } from 'react-router-dom';
import { FaPowerOff } from 'react-icons/fa';
import { FiClipboard } from 'react-icons/fi';

const StudentNavbar = () => {
    const [showLogoutModal, setShowLogoutModal] = useState(false);
    const navigate = useNavigate(); // For navigation after logout

    const handleLogoutClick = () => {
        setShowLogoutModal(true);
    };

    const handleConfirmLogout = () => {
        setShowLogoutModal(false);
        navigate('/Login'); // Navigate to the Login page after logout
    };

    const handleCancelLogout = () => {
        setShowLogoutModal(false);
    };

    const navbarStyle = {
        backgroundColor: '#f8f9fa',
        padding: '10px 20px',
        position: 'fixed',
        top: 0,
        left: 0,
        width: '100%',
        zIndex: 1000,
    };

    const navLinkStyle = {
        margin: '0 20px',
        color: 'black',
        textDecoration: 'none',
        fontWeight: '500',
        transition: 'color 0.3s',
    };

    const logoutStyle = {
        color: 'black',
        fontWeight: 'bold',
        textDecoration: 'none',
        transition: 'color 0.3s',
        display: 'flex',
        alignItems: 'center',
    };

    const brandFontSize = 1.5;
    const brandLogoWidth = 2;
    const brandLogoHeight = 2;
    const brandLogoMarginRight = 0.2;
    const brandLogoMarginBottom = 0.2;

    return (
        <>
            <Navbar style={navbarStyle} expand="lg">
                <img 
                    src="02 1.jpg" 
                    alt="B2B360 Logo" 
                    style={{ 
                        width: `${brandLogoWidth}rem`, 
                        height: `${brandLogoHeight}rem`, 
                        marginRight: `${brandLogoMarginRight}rem`, 
                        marginBottom: `${brandLogoMarginBottom}rem` 
                    }} 
                />
                <span
                    style={{
                        fontFamily: 'Playfair Display, serif',
                        fontSize: `${brandFontSize}em`,
                        fontWeight: 'bold',
                        backgroundImage: 'linear-gradient(to right, #012353, #27AE60)',
                        WebkitBackgroundClip: 'text',
                        WebkitTextFillColor: 'transparent',
                    }}
                >
                    EDU<span style={{ color: '#dc3545' }}>3</span>6<span style={{ color: '#28a745' }}>0</span>
                </span>
                <Navbar.Toggle aria-controls="basic-navbar-nav" />
                <Navbar.Collapse id="basic-navbar-nav" className="justify-content-end">
                    <Nav className="d-flex justify-content-end">
                        <Nav.Link as={Link} to="/Student_Dashboard" style={navLinkStyle}>Home</Nav.Link>
                       
                        <Nav.Link as={Link} to="/Student_Assignment" style={navLinkStyle}>Assignments</Nav.Link>
                        <Nav.Link as={Link} to="/Edit_Form" style={navLinkStyle}>
                            <FiClipboard style={{ marginRight: '5px' }} />
                            Issue Bord
                        </Nav.Link>
                        <Nav.Link onClick={handleLogoutClick} style={logoutStyle}>
                            <FaPowerOff style={{ marginRight: '5px' }} />
                       
                        </Nav.Link>
                    </Nav>
                </Navbar.Collapse>
            </Navbar>

            {/* Logout Confirmation Modal */}
            <Modal show={showLogoutModal} onHide={handleCancelLogout} centered>
                <Modal.Header closeButton>
                    <Modal.Title>Confirm Logout</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    Are you sure you want to log out?
                </Modal.Body>
                <Modal.Footer>
                    <Button variant="secondary" onClick={handleCancelLogout}>
                        No
                    </Button>
                    <Button variant="danger" onClick={handleConfirmLogout}>
                        Yes, Log Out
                    </Button>
                </Modal.Footer>
            </Modal>
        </>
    );
};

export default StudentNavbar;
