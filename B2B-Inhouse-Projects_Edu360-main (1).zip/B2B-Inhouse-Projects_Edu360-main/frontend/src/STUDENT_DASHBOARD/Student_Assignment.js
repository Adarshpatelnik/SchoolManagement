

// import React, { useState, useEffect } from 'react';
// import { AgGridReact } from 'ag-grid-react'; // Import AG Grid React component
// import 'ag-grid-community/styles/ag-grid.css'; // AG Grid CSS
// import 'ag-grid-community/styles/ag-theme-alpine.css'; // AG Grid theme
// import axios from 'axios'; // Import axios for making HTTP requests
 
// const StudentAssignment = () => {
//   const [assignments, setAssignments] = useState([]);
//   const [selectedAssignments, setSelectedAssignments] = useState([]);
//   const [error, setError] = useState(null);
//   const [successMessage, setSuccessMessage] = useState('');
 
//   // Fetch assignments on component load
//   useEffect(() => {
//     const fetchAssignments = async () => {
//       try {
//         console.log('Fetching assignments...');
//         const response = await fetch(`http://13.127.57.224:2081/api/assignments`);
//         if (!response.ok) {
//           console.error(`HTTP error! status: ${response.status}`);
//           throw new Error(`HTTP error! status: ${response.status}`);
//         }
//         const data = await response.json();
//         console.log('Assignments fetched successfully:', data);
//         setAssignments(data);
//       } catch (error) {
//         console.error('Error fetching assignments:', error);
//         setError(error.message);
//       }
//     };
 
//     fetchAssignments();
//   }, []);
 
//   // Handle form submission for selected assignments
//  // Handle form submission for selected assignments
// const handleSubmit = async () => {
//   if (selectedAssignments.length === 0) {
//     setError('Please select at least one assignment.');
//     return;
//   }
 
//   // Show success message instantly
//   setSuccessMessage('Submitted successfully');
 
//   // Automatically hide the success message after 3 seconds
//   setTimeout(() => {
//     setSuccessMessage('');
//   }, 3000);
 
//   try {
//     // Prepare the data to submit
//     const assignmentsToSubmit = selectedAssignments.map(assignment => ({
//       assignmentId: assignment.ASSIGNMENT_ID, // Assuming ASSIGNMENT_ID is your field
//       studentId: assignment.STUDENT_ID, // Assuming STUDENT_ID is your field
//     }));
 
//     // Log the assignments being submitted
//     console.log('Submitting selected assignments:', assignmentsToSubmit);
 
//     // Make the POST request to the backend
//     const response = await axios.post('http://13.127.57.224:2081/api/submit-assignment', assignmentsToSubmit);
 
//     // Handle the response from the server
//     console.log('Response from server:', response.data);
 
//   } catch (error) {
//     console.error('Error submitting assignments:', error);
//     // Handle the error (e.g., show a message to the user)
//     setError('Error submitting assignments');
//   }
// };
 
 
//   // AG Grid column definitions with updated sequence
//   const columnDefs = [
//     { headerCheckboxSelection: true, checkboxSelection: true, headerName: 'Select', width: 80 },
//     { field: 'STUDENT_ID', headerName: 'Student ID', sortable: true, filter: true },
//     { field: 'ASSIGNMENT_ID', headerName: 'Assignment ID', sortable: true, filter: true },
//     { field: 'SUBJECT_NAME', headerName: 'Subject Name', sortable: true, filter: true },
//     { field: 'ASSIGNMENT_DESC', headerName: 'Assignment Description', sortable: true, filter: true },
//     { field: 'SUBMISSION_START_DATE', headerName: 'Submission Start Date', sortable: true, filter: true, valueFormatter: ({ value }) => new Date(value).toLocaleDateString() },
//     { field: 'SUBMISSION_END_DATE', headerName: 'Submission End Date', sortable: true, filter: true, valueFormatter: ({ value }) => new Date(value).toLocaleDateString() },
//   ];
 
//   // Capture selected assignments using AG Grid's selection API
//   const onSelectionChanged = (event) => {
//     const selectedRows = event.api.getSelectedRows();
//     console.log('Selected assignments:', selectedRows);
//     setSelectedAssignments(selectedRows);
//   };
 
//   return (
//     <div style={styles.assignmentDashboard}>
//       <h3>My Assignments</h3>
//       {error && <p style={{ color: 'red' }}>{error}</p>}
//       {successMessage && <p style={{ color: 'green' }}>{successMessage}</p>}
     
//       {/* Submit button at the top */}
//       <button onClick={handleSubmit} style={styles.submitButton}>Submit</button>
 
//       <div
//         className="ag-theme-alpine"
//         style={{ height: 400, width: '100%', marginTop: '20px' }}
//       >
//         <AgGridReact
//           rowData={assignments}
//           columnDefs={columnDefs}
//           rowSelection="multiple"
//           onSelectionChanged={onSelectionChanged}
//           defaultColDef={{ resizable: true, sortable: true, filter: true }}
//         />
//       </div>
//     </div>
//   );
// };
 
// const styles = {
//   assignmentDashboard: {
//     padding: '20px',
//   },
//   submitButton: {
//     padding: '10px 20px',
//     backgroundColor: '#4CAF50',
//     color: 'white',
//     border: 'none',
//     cursor: 'pointer',
//     marginBottom: '10px', // Added margin to keep space between button and grid
//   },
// };
 
// export default StudentAssignment;









// import React, { useState, useEffect } from 'react';
// import { AgGridReact } from 'ag-grid-react'; // Import AG Grid React component
// import 'ag-grid-community/styles/ag-grid.css'; // AG Grid CSS
// import 'ag-grid-community/styles/ag-theme-alpine.css'; // AG Grid theme
// import axios from 'axios'; // Import axios for making HTTP requests
 
// const StudentAssignment = () => {
//   const [assignments, setAssignments] = useState([]);
//   const [selectedAssignments, setSelectedAssignments] = useState([]);
//   const [error, setError] = useState(null);
//   const [successMessage, setSuccessMessage] = useState('');
 
//   // Fetch assignments on component load
//   useEffect(() => {
//     const fetchAssignments = async () => {
//       try {
//         console.log('Fetching assignments...');
//         const response = await fetch(`http://13.127.57.224:2081/api/assignments`);
//         if (!response.ok) {
//           console.error(`HTTP error! status: ${response.status}`);
//           throw new Error(`HTTP error! status: ${response.status}`);
//         }
//         const data = await response.json();
//         console.log('Assignments fetched successfully:', data);
//         setAssignments(data);
//       } catch (error) {
//         console.error('Error fetching assignments:', error);
//         setError(error.message);
//       }
//     };
 
//     fetchAssignments();
//   }, []);
 
//   // Handle form submission for selected assignments
//  // Handle form submission for selected assignments
// const handleSubmit = async () => {
//   if (selectedAssignments.length === 0) {
//     setError('Please select at least one assignment.');
//     return;
//   }
 
//   // Show success message instantly
//   setSuccessMessage('Submitted successfully');
 
//   // Automatically hide the success message after 3 seconds
//   setTimeout(() => {
//     setSuccessMessage('');
//   }, 3000);
 
//   try {
//     // Prepare the data to submit
//     const assignmentsToSubmit = selectedAssignments.map(assignment => ({
//       assignmentId: assignment.ASSIGNMENT_ID, // Assuming ASSIGNMENT_ID is your field
//       studentId: assignment.STUDENT_ID, // Assuming STUDENT_ID is your field
//     }));
 
//     // Log the assignments being submitted
//     console.log('Submitting selected assignments:', assignmentsToSubmit);
 
//     // Make the POST request to the backend
//     const response = await axios.post('http://13.127.57.224:2081/api/submit-assignment', assignmentsToSubmit);
 
//     // Handle the response from the server
//     console.log('Response from server:', response.data);
 
//   } catch (error) {
//     console.error('Error submitting assignments:', error);
//     // Handle the error (e.g., show a message to the user)
//     setError('Error submitting assignments');
//   }
// };
 
 
//   // AG Grid column definitions with updated sequence
//   const columnDefs = [
//     { headerCheckboxSelection: true, checkboxSelection: true, headerName: 'Select', width: 80 },
//     { field: 'STUDENT_ID', headerName: 'Student ID', sortable: true, filter: true },
//     { field: 'ASSIGNMENT_ID', headerName: 'Assignment ID', sortable: true, filter: true },
//     { field: 'SUBJECT_NAME', headerName: 'Subject Name', sortable: true, filter: true },
//     { field: 'ASSIGNMENT_DESC', headerName: 'Assignment Description', sortable: true, filter: true },
//     { field: 'SUBMISSION_START_DATE', headerName: 'Submission Start Date', sortable: true, filter: true, valueFormatter: ({ value }) => new Date(value).toLocaleDateString() },
//     { field: 'SUBMISSION_END_DATE', headerName: 'Submission End Date', sortable: true, filter: true, valueFormatter: ({ value }) => new Date(value).toLocaleDateString() },
//   ];
 
//   // Capture selected assignments using AG Grid's selection API
//   const onSelectionChanged = (event) => {
//     const selectedRows = event.api.getSelectedRows();
//     console.log('Selected assignments:', selectedRows);
//     setSelectedAssignments(selectedRows);
//   };
 
//   return (
//     <div style={styles.assignmentDashboard}>
//       <h3>My Assignments</h3>
//       {error && <p style={{ color: 'red' }}>{error}</p>}
//       {successMessage && <p style={{ color: 'green' }}>{successMessage}</p>}
     
//       {/* Submit button at the top */}
//       <button onClick={handleSubmit} style={styles.submitButton}>Submit</button>
 
//       <div
//         className="ag-theme-alpine"
//         style={{ height: 400, width: '100%', marginTop: '20px' }}
//       >
//         <AgGridReact
//           rowData={assignments}
//           columnDefs={columnDefs}
//           rowSelection="multiple"
//           onSelectionChanged={onSelectionChanged}
//           defaultColDef={{ resizable: true, sortable: true, filter: true }}
//         />
//       </div>
//     </div>
//   );
// };
 
// const styles = {
//   assignmentDashboard: {
//     padding: '20px',
//   },
//   submitButton: {
//     padding: '10px 20px',
//     backgroundColor: '#4CAF50',
//     color: 'white',
//     border: 'none',
//     cursor: 'pointer',
//     marginBottom: '10px', // Added margin to keep space between button and grid
//   },
// };
 
// export default StudentAssignment;
 

import React, { useState, useEffect } from 'react';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import axios from 'axios';

const StudentAssignment = () => {
  const [assignments, setAssignments] = useState([]);
  const [selectedAssignments, setSelectedAssignments] = useState([]);
  const [error, setError] = useState(null);
  const [successMessage, setSuccessMessage] = useState('');

  useEffect(() => {
    const fetchAssignments = async () => {
      try {
        console.log('Fetching assignments from API...');
        const response = await fetch(`http://13.127.57.224:2081/api/assignments`);
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}, message: ${response.statusText}`);
        }
        const data = await response.json();
        console.log('Assignments fetched successfully:', data);
        setAssignments(data);
      } catch (error) {
        console.error('Error fetching assignments:', error);
        setError(`Failed to fetch assignments: ${error.message}`);
      }
    };
  
    fetchAssignments();
  }, []);
  

  const handleSubmit = async () => {
    if (selectedAssignments.length === 0) {
      setError('Please select at least one assignment.');
      return;
    }

    setSuccessMessage('Submitted successfully');
    setTimeout(() => {
      setSuccessMessage('');
    }, 3000);

    try {
      const assignmentsToSubmit = selectedAssignments.map(assignment => ({
        assignmentId: assignment.ASSIGNMENT_ID,
        studentId: assignment.STUDENT_ID,
      }));

      console.log('Submitting selected assignments:', assignmentsToSubmit);

      const response = await axios.post('http://13.127.57.224:2081/api/submit-assignment', assignmentsToSubmit);
      console.log('Response from server:', response.data);

    } catch (error) {
      console.error('Error submitting assignments:', error);
      setError('Error submitting assignments');
    }
  };

  const columnDefs = [
    { headerCheckboxSelection: true, checkboxSelection: true, headerName: 'Select', width: 80 },
    { field: 'STUDENT_ID', headerName: 'Student ID', sortable: true, filter: true },
    { field: 'ASSIGNMENT_ID', headerName: 'Assignment ID', sortable: true, filter: true },
    { field: 'SUBJECT_NAME', headerName: 'Subject Name', sortable: true, filter: true },
    { field: 'ASSIGNMENT_DESC', headerName: 'Assignment Description', sortable: true, filter: true },
    { field: 'SUBMISSION_START_DATE', headerName: 'Submission Start Date', sortable: true, filter: true, valueFormatter: ({ value }) => new Date(value).toLocaleDateString() },
    { field: 'SUBMISSION_END_DATE', headerName: 'Submission End Date', sortable: true, filter: true, valueFormatter: ({ value }) => new Date(value).toLocaleDateString() },
  ];

  const onSelectionChanged = (event) => {
    const selectedRows = event.api.getSelectedRows();
    console.log('Selected assignments:', selectedRows);
    setSelectedAssignments(selectedRows);
  };

  return (
    <div style={styles.assignmentDashboard}>
      <h3>My Assignments</h3>
      {error && <p style={{ color: 'red' }}>{error}</p>}
      {successMessage && <p style={{ color: 'green' }}>{successMessage}</p>}
     
      <button onClick={handleSubmit} style={styles.submitButton}>Submit</button>

      <div className="ag-theme-alpine" style={{ height: 400, width: '100%', marginTop: '20px' }}>
        <AgGridReact
          rowData={assignments}
          columnDefs={columnDefs}
          rowSelection="multiple"
          onSelectionChanged={onSelectionChanged}
          defaultColDef={{ resizable: true, sortable: true, filter: true }}
        />
      </div>
    </div>
  );
};

const styles = {
  assignmentDashboard: {
    padding: '20px',
  },
  submitButton: {
    padding: '10px 20px',
    backgroundColor: '#4CAF50',
    color: 'white',
    border: 'none',
    cursor: 'pointer',
    marginBottom: '10px',
  },
};

export default StudentAssignment;

 
