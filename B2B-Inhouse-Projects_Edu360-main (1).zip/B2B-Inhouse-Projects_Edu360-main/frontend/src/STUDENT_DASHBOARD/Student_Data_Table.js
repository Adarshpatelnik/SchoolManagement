// import React, { useEffect, useState } from 'react';
// import { AgGridReact } from 'ag-grid-react';
// import 'ag-grid-community/styles/ag-grid.css';
// import 'ag-grid-community/styles/ag-theme-alpine.css';
// import axios from 'axios';

// const StudentDataTable = () => {
//   const [rowData, setRowData] = useState([]);
//   const [selectedRows, setSelectedRows] = useState([]);
//   const [error, setError] = useState(null);  // State to handle errors

//   const columnDefs = [
//     { headerCheckboxSelection: true, checkboxSelection: true, headerName: 'Select', width: 80 },
//     { headerName: 'REQUEST_ID', field: 'REQUEST_ID', sortable: true, filter: true, minWidth: 150 },
//     { headerName: 'REQUESTER_ID', field: 'REQUESTER_ID', sortable: true, filter: true, minWidth: 150 },
//     { headerName: 'REQUESTER_TYPE', field: 'REQUESTER_TYPE', sortable: true, filter: true, minWidth: 150 },
//     { headerName: 'FIRST_NAME', field: 'FIRST_NAME', sortable: true, filter: true, minWidth: 150 },
//     { headerName: 'TYPE', field: 'TYPE', sortable: true, filter: true, minWidth: 150 },
//     { headerName: 'OLDDATA', field: 'OLDDATA', sortable: true, filter: true, minWidth: 150 },
//     { headerName: 'NEWDATA', field: 'NEWDATA', sortable: true, filter: true, minWidth: 150 },
//     { headerName: 'STATUS', field: 'STATUS', sortable: true, filter: true, minWidth: 150 },
//     { headerName: 'ISSUE', field: 'ISSUE', sortable: true, filter: true, minWidth: 150 },
//   ];

//   useEffect(() => {
    

//     axios
//       .get(`http://13.127.57.224:2081/api/student-data`)
//       .then((response) => {
//         setRowData(response.data);
//       })
//       .catch((error) => {
//         console.error('Error fetching student data:', error);
//         setError('Error fetching student data. Please try again later.');
//       });
//   }, [REQUESTER_ID]);

//   const onSelectionChanged = (event) => {
//     const selectedNodes = event.api.getSelectedNodes();
//     const selectedData = selectedNodes.map(node => node.data);
//     setSelectedRows(selectedData);
//   };

//   const handleApprove = () => {
//     if (selectedRows.length === 0) {
//       alert('Please select at least one row to approve.');
//       return;
//     }

//     const statusUpdatePromises = selectedRows.map(row =>
//       axios.post('http://13.127.57.224:2081/api/update-status', {
//         REQUEST_ID: row.REQUEST_ID,
//         STATUS: 'Approved',
//       })
//     );

//     const studentProfileUpdatePromise = axios.post('http://13.127.57.224:2081/api/update-student-profile', {
//       REQUESTER_ID,
//     });

//     Promise.all([...statusUpdatePromises, studentProfileUpdatePromise])
//       .then(() => {
//         alert('Approved the selected requests and updated student profile.');
//       })
//       .catch((error) => {
//         console.error('Error updating status or profile:', error);
//         alert('Error occurred while updating requests.');
//       });
//   };

//   const handleReject = () => {
//     if (selectedRows.length === 0) {
//       alert('Please select at least one row to reject.');
//       return;
//     }

//     const statusUpdatePromises = selectedRows.map(row =>
//       axios.post('http://13.127.57.224:2081/api/update-status', {
//         REQUEST_ID: row.REQUEST_ID,
//         STATUS: 'Rejected', 
//       })
//     );

//     Promise.all(statusUpdatePromises)
//       .then(() => {
//         alert('Rejected the selected requests.');
//       })
//       .catch((error) => {
//         console.error('Error rejecting requests:', error);
//         alert('Error occurred while rejecting requests.');
//       });
//   };

//   return (
//     <div>
//       {error && <div style={{ color: 'red' }}>{error}</div>}
//       <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: '10px' }}>
//         <button
//           onClick={handleApprove}
//           style={{
//             backgroundColor: 'green',
//             color: 'white',
//             border: 'none',
//             padding: '6px 12px',
//             marginRight: '10px',
//             cursor: 'pointer',
//             fontSize: '0.875rem',
//           }}
//         >
//           Approve
//         </button>
//         <button
//           onClick={handleReject}
//           style={{
//             backgroundColor: 'red',
//             color: 'white',
//             border: 'none',
//             padding: '6px 12px',
//             cursor: 'pointer',
//             fontSize: '0.875rem',
//           }}
//         >
//           Reject
//         </button>
//       </div>
//       <div className="ag-theme-alpine" style={{ height: 400, width: '100%' }}>
//         <AgGridReact
//           rowData={rowData}
//           columnDefs={columnDefs}
//           rowSelection="multiple"
//           defaultColDef={{
//             flex: 1,
//             minWidth: 150,
//             resizable: true,
//           }}
//           onSelectionChanged={onSelectionChanged}
//           domLayout="autoHeight"
//         />
//       </div>
//     </div>
//   );
// };

// export default StudentDataTable;


import React, { useEffect, useState } from 'react';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import axios from 'axios';

const StudentDataTable = () => {
  const [rowData, setRowData] = useState([]);
  const [selectedRows, setSelectedRows] = useState([]);
  const [error, setError] = useState(null);  // State to handle errors

  const columnDefs = [
    { headerCheckboxSelection: true, checkboxSelection: true, headerName: 'Select', width: 80 },
    { headerName: 'REQUEST_ID', field: 'REQUEST_ID', sortable: true, filter: true, minWidth: 150 },
    { headerName: 'REQUESTER_ID', field: 'REQUESTER_ID', sortable: true, filter: true, minWidth: 150 },
    { headerName: 'REQUESTER_TYPE', field: 'REQUESTER_TYPE', sortable: true, filter: true, minWidth: 150 },
    { headerName: 'FIRST_NAME', field: 'FIRST_NAME', sortable: true, filter: true, minWidth: 150 },
    { headerName: 'TYPE', field: 'TYPE', sortable: true, filter: true, minWidth: 150 },
    { headerName: 'OLDDATA', field: 'OLDDATA', sortable: true, filter: true, minWidth: 150 },
    { headerName: 'NEWDATA', field: 'NEWDATA', sortable: true, filter: true, minWidth: 150 },
    { headerName: 'STATUS', field: 'STATUS', sortable: true, filter: true, minWidth: 150 },
    { headerName: 'ISSUE', field: 'ISSUE', sortable: true, filter: true, minWidth: 150 },
  ];

  useEffect(() => {
    axios
      .get(`http://13.127.57.224:2081/api/student-data`)
      .then((response) => {
        setRowData(response.data);
      })
      .catch((error) => {
        console.error('Error fetching student data:', error);
        setError('Error fetching student data. Please try again later.');
      });
  }, []); // Removed REQUESTER_ID from the dependency array

  const onSelectionChanged = (event) => {
    const selectedNodes = event.api.getSelectedNodes();
    const selectedData = selectedNodes.map(node => node.data);
    setSelectedRows(selectedData);
  };

  const handleApprove = () => {
    if (selectedRows.length === 0) {
      alert('Please select at least one row to approve.');
      return;
    }

    const statusUpdatePromises = selectedRows.map(row =>
      axios.post('http://13.127.57.224:2081/api/update-status', {
        REQUEST_ID: row.REQUEST_ID,
        STATUS: 'Approved',
      })
    );

    const studentProfileUpdatePromises = selectedRows.map(row =>
      axios.post('http://13.127.57.224:2081/api/update-student-profile', {
        REQUESTER_ID: row.REQUESTER_ID,  // Now passing REQUESTER_ID for each selected row
      })
    );

    Promise.all([...statusUpdatePromises, ...studentProfileUpdatePromises])
      .then(() => {
        alert('Approved the selected requests and updated student profile.');
      })
      .catch((error) => {
        console.error('Error updating status or profile:', error);
        alert('Error occurred while updating requests.');
      });
  };

  const handleReject = () => {
    if (selectedRows.length === 0) {
      alert('Please select at least one row to reject.');
      return;
    }

    const statusUpdatePromises = selectedRows.map(row =>
      axios.post('http://13.127.57.224:2081/api/update-status', {
        REQUEST_ID: row.REQUEST_ID,
        STATUS: 'Rejected', 
      })
    );

    Promise.all(statusUpdatePromises)
      .then(() => {
        alert('Rejected the selected requests.');
      })
      .catch((error) => {
        console.error('Error rejecting requests:', error);
        alert('Error occurred while rejecting requests.');
      });
  };

  return (
    <div>
            <div className="container-fluid" style={{ marginLeft: 'vh', marginTop: '11vh', width: '100%', padding: 0 }}>

      {error && <div style={{ color: 'red' }}>{error}</div>}
      <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: '10px' }}>
        <button
          onClick={handleApprove}
          style={{
            backgroundColor: 'green',
            color: 'white',
            border: 'none',
            padding: '6px 12px',
            marginRight: '10px',
            cursor: 'pointer',
            fontSize: '0.875rem',
          }}
        >
          Approve
        </button>
        <button
          onClick={handleReject}
          style={{
            backgroundColor: 'red',
            color: 'white',
            border: 'none',
            padding: '6px 12px',
            cursor: 'pointer',
            fontSize: '0.875rem',
          }}
        >
          Reject
        </button>
      </div>
      <div className="ag-theme-alpine" style={{ height: 400, width: '100%' }}>
        <AgGridReact
          rowData={rowData}
          columnDefs={columnDefs}
          rowSelection="multiple"
          defaultColDef={{
            flex: 1,
            minWidth: 150,
            resizable: true,
          }}
          onSelectionChanged={onSelectionChanged}
          domLayout="autoHeight"
        />
      </div>
      </div>
    </div>
  );
};

export default StudentDataTable;
