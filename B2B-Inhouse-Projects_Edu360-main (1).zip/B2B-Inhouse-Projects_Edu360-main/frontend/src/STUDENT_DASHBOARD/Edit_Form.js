// import React, { useState, useEffect } from 'react';
// import axios from 'axios';
// import StudentLanding from '/home/ec2-user/Edu360/SchoolManagement/frontend/src/STUDENT_DASHBOARD/Student_landing.js';

// const EditForm = ({ STUDENTID }) => {
//   const [formData, setFormData] = useState({
//     CONTACT_NUMBER: '',
//     CITY: '',
//     POSTAL_CODE: '',
//     EMAIL: '',
//     EMERGENCY_CONTACT_NUMBER: '',
//     STUDENT_ID: '',
//     STUDENT_NAME: ''
//   });

//   const [selectedField, setSelectedField] = useState('');
//   const [newValue, setNewValue] = useState('');
//   const [isEditing, setIsEditing] = useState(false);
//   const [issue, setIssue] = useState('');
//   const [loading, setLoading] = useState(false);
//   const [error, setError] = useState('');

//   useEffect(() => {
//     if (!STUDENTID) {
//       console.error('Student ID is not provided');
//       setError('Student ID is missing.');
//       return;
//     }

//     console.log('Fetching data for student ID:', STUDENTID);
//     setLoading(true);
    

//     axios
//       .get(`http://13.127.57.224:2081/api/Edit_Form?STUDENT_ID=${STUDENTID}`)
//       .then((response) => {
//         console.log('Response from API:', response);
//         setFormData({
//           CONTACT_NUMBER: response.data.CONTACT_NUMBER || '',
//           CITY: response.data.CITY || '',
//           POSTAL_CODE: response.data.POSTAL_CODE || '',
//           EMAIL: response.data.EMAIL || '',
//           EMERGENCY_CONTACT_NUMBER: response.data.EMERGENCY_CONTACT_NUMBER || '',
//           STUDENT_ID: response.data.STUDENT_ID || '',
//           STUDENT_NAME: response.data.FIRST_NAME || ''
//         });
//         setLoading(false);
//       })
//       .catch((error) => {
//         console.error('Error fetching data:', error);
//         setError('Error fetching data. Please try again.');
//         setLoading(false);
//       });
//   }, [STUDENTID]);

//   const handleSubmit = (e) => {
//     e.preventDefault();
//     if (!selectedField || !newValue || !issue) {
//       setError('Please fill in all fields.');
//       return;
//     }
  
//     setLoading(true);
//     const newRequestData = {
//       STUDENT_ID: formData.STUDENT_ID,  // This is the student's ID
//       FIRST_NAME: formData.STUDENT_NAME, // Ensure this is correctly populated
//       TYPE: selectedField,
//       OLDDATA: formData[selectedField],   // The old value of the field being edited
//       NEWDATA: newValue,                  // The new value for the field
//       STATUS: 'Pending',                  // You can set this as needed
//       ISSUE: issue                        // The issue description
//     };
  
//     axios
//       .post('http://localhost:2082/api/submit-edit-request', newRequestData)
//       .then(() => {
//         alert('Field and issue submitted successfully!');
//         setNewValue('');
//         setIsEditing(false);
//         setIssue('');
//         setSelectedField('');
//       })
//       .catch((error) => {
//         console.error('Error submitting data:', error);
//         setError('Error submitting data. Please try again later.');
//       });
//   };

//   return (
//     <>   
//        <StudentLanding/>
//     <div style={styles.container}>
//       {loading && <p>Loading...</p>}
//       {error && <p style={styles.error}>{error}</p>}

//       <div style={styles.infoSection}>
//         <p><strong>Student ID:</strong> {formData.STUDENT_ID}</p>
//         <p><strong>Student Name:</strong> {formData.STUDENT_NAME}</p>
//       </div>

//       <div style={styles.fieldContainer}>
//         <label htmlFor="fieldSelect">Select Field: </label>
//         <select
//           id="fieldSelect"
//           style={styles.select}
//           value={selectedField}
//           onChange={(e) => setSelectedField(e.target.value)}
//         >
//           <option value="">--Select a Field--</option>
//           <option value="CONTACT_NUMBER">Contact Number</option>
//           <option value="EMAIL">Email</option>
//           <option value="EMERGENCY_CONTACT_NUMBER">Emergency Contact Number</option>
//           <option value="POSTAL_CODE">Postal Code</option>
//           <option value="CITY">City</option>
//         </select>
//       </div>

//       {selectedField && (
//         <div style={styles.editSection}>
//           <div>
//             <label>{selectedField.replace('_', ' ')}: </label>
//             <input
//               type="text"
//               value={formData[selectedField]}
//               readOnly
//               style={styles.input}
//             />
//           </div>

//           {!isEditing ? (
//             <button style={styles.editButton} onClick={() => setIsEditing(true)}>
//               Edit
//             </button>
//           ) : (
//             <form onSubmit={handleSubmit} style={styles.form}>
//               <div>
//                 <label>New {selectedField.replace('_', ' ')}: </label>
//                 <input
//                   type="text"
//                   value={newValue}
//                   onChange={(e) => setNewValue(e.target.value)}
//                   style={styles.input}
//                   required
//                 />
//               </div>

//               <div>
//                 <label>Issue: </label>
//                 <textarea
//                   value={issue}
//                   onChange={(e) => setIssue(e.target.value)}
//                   placeholder="Describe the issue"
//                   style={styles.textarea}
//                   rows="4"
//                   required
//                 />
//               </div>

//               <button type="submit" style={styles.submitButton}>Submit</button>
//             </form>
//           )}
//         </div>
//       )}
//     </div>
//     </>
//   );
// };

// const styles = {
//   container: {
//     margin: '0 auto',
//     padding: '20px',
//     maxWidth: '600px',
//     border: '1px solid #ccc',
//     borderRadius: '8px',
//     backgroundColor: '#f9f9f9'
//   },
//   fieldContainer: {
//     marginBottom: '20px',
//   },
//   select: {
//     padding: '10px',
//     width: '100%',
//     fontSize: '16px',
//     borderRadius: '4px',
//     border: '1px solid #ccc',
//   },
//   infoSection: {
//     marginBottom: '20px',
//   },
//   editSection: {
//     marginTop: '20px',
//   },
//   input: {
//     padding: '10px',
//     width: '100%',
//     fontSize: '16px',
//     margin: '10px 0',
//     borderRadius: '4px',
//     border: '1px solid #ccc',
//   },
//   textarea: {
//     padding: '10px',
//     width: '100%',
//     fontSize: '16px',
//     margin: '10px 0',
//     borderRadius: '4px',
//     border: '1px solid #ccc',
//   },
//   editButton: {
//     padding: '10px 15px',
//     backgroundColor: '#007bff',
//     color: '#fff',
//     border: 'none',
//     borderRadius: '4px',
//     cursor: 'pointer',
//   },
//   form: {
//     marginTop: '20px',
//   },
//   submitButton: {
//     padding: '10px 15px',
//     backgroundColor: '#28a745',
//     color: '#fff',
//     border: 'none',
//     borderRadius: '4px',
//     cursor: 'pointer',
//   },
//   error: {
//     color: 'red',
//     margin: '10px 0',
//   }
// };

// export default EditForm;









import React, { useState, useEffect } from 'react';
import axios from 'axios';
import StudentNavbar from './Student_Navbar.js';

const EditForm = () => {
  const [formData, setFormData] = useState({
    CONTACT_NUMBER: '',
    CITY: '',
    POSTAL_CODE: '',
    EMAIL: '',
    EMERGENCY_CONTACT_NUMBER: '',
    STUDENT_ID: '',
    STUDENT_NAME: ''
  });

  const [selectedField, setSelectedField] = useState('');
  const [newValue, setNewValue] = useState('');
  const [isEditing, setIsEditing] = useState(false);
  const [issue, setIssue] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    console.log('Fetching data for the student');
    setLoading(true);

    axios
      .get('http://13.127.57.224:2081/api/Edit_Form')
      .then((response) => {
        console.log('Response from API:', response);
        setFormData({
          CONTACT_NUMBER: response.data.CONTACT_NUMBER || '',
          CITY: response.data.CITY || '',
          POSTAL_CODE: response.data.POSTAL_CODE || '',
          EMAIL: response.data.EMAIL || '',
          EMERGENCY_CONTACT_NUMBER: response.data.EMERGENCY_CONTACT_NUMBER || '',
          STUDENT_ID: response.data.STUDENT_ID || '',
          STUDENT_NAME: response.data.FIRST_NAME || ''
        });
        setLoading(false);
      })
      .catch((error) => {
        console.error('Error fetching data:', error);
        setError('Error fetching data. Please try again.');
        setLoading(false);
      });
  }, []);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!selectedField || !newValue || !issue) {
      setError('Please fill in all fields.');
      return;
    }
  
    setLoading(true);
    const newRequestData = {
      STUDENT_ID: formData.STUDENT_ID,  // This is the student's ID
      FIRST_NAME: formData.STUDENT_NAME, // Ensure this is correctly populated
      TYPE: selectedField,
      OLDDATA: formData[selectedField],   // The old value of the field being edited
      NEWDATA: newValue,                  // The new value for the field
      STATUS: 'Pending',                  // You can set this as needed
      ISSUE: issue                        // The issue description
    };
  
    axios
      .post('http://13.127.57.224:2081/api/submit-edit-request', newRequestData)
      .then(() => {
        alert('Field and issue submitted successfully!');
        setNewValue('');
        setIsEditing(false);
        setIssue('');
        setSelectedField('');
      })
      .catch((error) => {
        console.error('Error submitting data:', error);
        setError('Error submitting data. Please try again later.');
      });
  };

  return (
    <>   
      <StudentNavbar />
      <div className="container-fluid" style={{ marginTop: '12vh', width: '100%', padding: 0 }}>

      <div style={styles.container}>
        {loading && <p>Loading...</p>}
        {error && <p style={styles.error}>{error}</p>}

        <div style={styles.infoSection}>
          <p><strong>Student ID:</strong> {formData.STUDENT_ID}</p>
          <p><strong>Student Name:</strong> {formData.STUDENT_NAME}</p>
        </div>

        <div style={styles.fieldContainer}>
          <label htmlFor="fieldSelect">Select Field: </label>
          <select
            id="fieldSelect"
            style={styles.select}
            value={selectedField}
            onChange={(e) => setSelectedField(e.target.value)}
          >
            <option value="">--Select a Field--</option>
            <option value="CONTACT_NUMBER">Contact Number</option>
            <option value="EMAIL">Email</option>
            <option value="EMERGENCY_CONTACT_NUMBER">Emergency Contact Number</option>
            <option value="POSTAL_CODE">Postal Code</option>
            <option value="CITY">City</option>
          </select>
        </div>

        {selectedField && (
          <div style={styles.editSection}>
            <div>
              <label>{selectedField.replace('_', ' ')}: </label>
              <input
                type="text"
                value={formData[selectedField]}
                readOnly
                style={styles.input}
              />
            </div>

            {!isEditing ? (
              <button style={styles.editButton} onClick={() => setIsEditing(true)}>
                Edit
              </button>
            ) : (
              <form onSubmit={handleSubmit} style={styles.form}>
                <div>
                  <label>New {selectedField.replace('_', ' ')}: </label>
                  <input
                    type="text"
                    value={newValue}
                    onChange={(e) => setNewValue(e.target.value)}
                    style={styles.input}
                    required
                  />
                </div>

                <div>
                  <label>Issue: </label>
                  <textarea
                    value={issue}
                    onChange={(e) => setIssue(e.target.value)}
                    placeholder="Describe the issue"
                    style={styles.textarea}
                    rows="4"
                    required
                  />
                </div>

                <button type="submit" style={styles.submitButton}>Submit</button>
              </form>
            )}
          </div>
        )}
      </div>
      </div>
    </>
  );
};

const styles = {
  container: {
    margin: '0 auto',
    padding: '20px',
    maxWidth: '600px',
    border: '1px solid #ccc',
    borderRadius: '8px',
    backgroundColor: '#f9f9f9'
  },
  fieldContainer: {
    marginBottom: '20px',
  },
  select: {
    padding: '10px',
    width: '100%',
    fontSize: '16px',
    borderRadius: '4px',
    border: '1px solid #ccc',
  },
  infoSection: {
    marginBottom: '20px',
  },
  editSection: {
    marginTop: '20px',
  },
  input: {
    padding: '10px',
    width: '100%',
    fontSize: '16px',
    margin: '10px 0',
    borderRadius: '4px',
    border: '1px solid #ccc',
  },
  textarea: {
    padding: '10px',
    width: '100%',
    fontSize: '16px',
    margin: '10px 0',
    borderRadius: '4px',
    border: '1px solid #ccc',
  },
  editButton: {
    padding: '10px 15px',
    backgroundColor: '#007bff',
    color: '#fff',
    border: 'none',
    borderRadius: '4px',
    cursor: 'pointer',
  },
  form: {
    marginTop: '20px',
  },
  submitButton: {
    padding: '10px 15px',
    backgroundColor: '#28a745',
    color: '#fff',
    border: 'none',
    borderRadius: '4px',
    cursor: 'pointer',
  },
  error: {
    color: 'red',
    margin: '10px 0',
  }
};

export default EditForm;
