// import React, { useState, useEffect } from 'react';
// import { AgCharts } from 'ag-charts-react';
// import axios from 'axios';
// import '@fortawesome/fontawesome-free/css/all.min.css';

// const Studentperformance = () => {
//   const [selectedClass, setSelectedClass] = useState('');
//   const [selectedAcademicYear, setSelectedAcademicYear] = useState('');
//   const [classes, setClasses] = useState([]);
//   const [academicYears, setAcademicYears] = useState([]);
//   const [subjects, setSubjects] = useState([]);
//   const [chartData, setChartData] = useState([]);
//   const [annualPerformanceData, setAnnualPerformanceData] = useState([]);
//   const [loading, setLoading] = useState(false);
//   const [error, setError] = useState('');

//   const fetchData = async () => {
//     setLoading(true);
//     setError('');
//     try {
//       const response = await axios.get('http://13.127.57.224:2081/api/Studentsummary', {
//         params: {
//           CLASS: selectedClass,
//           ACADEMIC_YEAR: selectedAcademicYear,
//         },
//       });

//       const data = response.data;

//       const uniqueClasses = [...new Set(data.map(item => item.CLASS))];
//       const uniqueAcademicYears = [...new Set(data.map(item => item.ACADEMIC_YEAR))];
//       const uniqueSubjects = [...new Set(data.map(item => item.SUBJECT))];

//       // Prepare chart data for AG Charts
//       const chartData = uniqueSubjects.map(subject => {
//         const item = data.find(d => d.SUBJECT === subject);
//         return {
//           subject,
//           term1Total: item ? item.TERM_1_TOTAL : 0,
//           term2Total: item ? item.TERM_2_TOTAL : 0,
//           annualPerformance: item ? item.ANNUAL_PERFORMANCE : 0,
//         };
//       });

//       setClasses(uniqueClasses);
//       setAcademicYears(uniqueAcademicYears);
//       setSubjects(uniqueSubjects);
//       setAnnualPerformanceData(chartData.map(item => item.annualPerformance)); // Store annual performance data in state

//       setChartData(chartData); // Update chart data state
//     } catch (error) {
//       setError('Error fetching data. Please try again later.');
//       console.error('Error fetching data:', error);
//     } finally {
//       setLoading(false);
//     }
//   };

//   useEffect(() => {
//     fetchData();
//   }, [selectedClass, selectedAcademicYear]);

//   const handleClassChange = (event) => {
//     setSelectedClass(event.target.value);
//   };

//   const handleAcademicYearChange = (event) => {
//     setSelectedAcademicYear(event.target.value);
//   };

//   const options = {
//     data: chartData,
//     title: {
//       text: '',
//     },
//     series: [
//       {
//         type: 'bar',
//         xKey: 'subject',
//         yKey: 'term1Total',
//         name: 'Term 1 Total',
//         fill: '#4caf50',
//       },
//       {
//         type: 'bar',
//         xKey: 'subject',
//         yKey: 'term2Total',
//         name: 'Term 2 Total',
//         fill: '#ff9800',
//       },
//     ],
//     axes: [
//       {
//         type: 'category',
//         position: 'bottom',
//         title: 'Subject',
//       },
//       {
//         type: 'number',
//         position: 'left',
//         title: 'Grade',
//         min: 0,
//       },
//     ],
//   };

//   return (
//     <div className="card card-success" style={{ fontFamily: 'Arial, sans-serif', width: '100%', height: 'auto',marginTop: '-4vh' }}>
//       <div className="card-body">
//         {loading && <p>Loading...</p>}
//         {error && <p style={{ color: 'red' }}>{error}</p>}
//         <div style={{ marginBottom: '0px', display: 'flex', gap: '10px' }}>
//           <div>
//             <label htmlFor="classFilter" style={{ fontWeight: 'bold' }}></label>
//             <select id="classFilter" onChange={handleClassChange} value={selectedClass} style={{ marginLeft: '10px', borderColor: 'lightSkyBlue', padding: '5px', borderRadius: '5px' }}>
//               <option value="">Class</option>
//               {classes.map((classItem) => (
//                 <option key={classItem} value={classItem}>
//                   {classItem}
//                 </option>
//               ))}
//             </select>
//           </div>
//           <div>
//             <label htmlFor="academicYearFilter" style={{ fontWeight: 'bold' }}></label>
//             <select id="academicYearFilter" onChange={handleAcademicYearChange} value={selectedAcademicYear} style={{ marginLeft: '10px', borderColor: 'lightSkyBlue', padding: '5px', borderRadius: '5px' }}>
//               <option value="">Year</option>
//               {academicYears.map((year) => (
//                 <option key={year} value={year}>
//                   {year}
//                 </option>
//               ))}
//             </select>
//           </div>
//         </div>
//         <div style={{ width: '100%', height: 'auto' }}> {/* Adjust the height of the chart here */}
//           <AgCharts options={options}  style={{ width: '100%', height: '33vh', marginTop: '-2vh' }} />
//         </div>
//       </div>
//     </div>
//   );
// };

// export default Studentperformance;











// import React, { useState, useEffect } from 'react';
// import { AgCharts } from 'ag-charts-react';
// import axios from 'axios';
// import '@fortawesome/fontawesome-free/css/all.min.css';

// const Studentperformance = () => {
//   const [selectedClass, setSelectedClass] = useState('');
//   const [selectedAcademicYear, setSelectedAcademicYear] = useState('');
//   const [classes, setClasses] = useState([]);
//   const [academicYears, setAcademicYears] = useState([]);
//   const [subjects, setSubjects] = useState([]);
//   const [chartData, setChartData] = useState([]);
//   const [annualPerformanceData, setAnnualPerformanceData] = useState([]);
//   const [loading, setLoading] = useState(false);
//   const [error, setError] = useState('');

//   const fetchData = async () => {
//     setLoading(true);
//     setError('');
//     try {
//       const response = await axios.get('http://13.127.57.224:2081/api/Studentsummary', {
//         params: {
//           CLASS: selectedClass,
//           ACADEMIC_YEAR: selectedAcademicYear,
//         },
//       });

//       const data = response.data;

//       const uniqueClasses = [...new Set(data.map(item => item.CLASS))];
//       const uniqueAcademicYears = [...new Set(data.map(item => item.ACADEMIC_YEAR))];
//       const uniqueSubjects = [...new Set(data.map(item => item.SUBJECT))];

//       // Prepare chart data for AG Charts
//       const chartData = uniqueSubjects.map(subject => {
//         const item = data.find(d => d.SUBJECT === subject);
//         return {
//           subject,
//           term1Total: item ? item.TERM_1_TOTAL : 0,
//           term2Total: item ? item.TERM_2_TOTAL : 0,
//           annualPerformance: item ? item.ANNUAL_PERFORMANCE : 0,
//         };
//       });

//       setClasses(uniqueClasses);
//       setAcademicYears(uniqueAcademicYears);
//       setSubjects(uniqueSubjects);
//       setAnnualPerformanceData(chartData.map(item => item.annualPerformance)); // Store annual performance data in state

//       setChartData(chartData); // Update chart data state
//     } catch (error) {
//       setError('Error fetching data. Please try again later.');
//       console.error('Error fetching data:', error);
//     } finally {
//       setLoading(false);
//     }
//   };

//   useEffect(() => {
//     fetchData();
//   }, [selectedClass, selectedAcademicYear]);

//   const handleClassChange = (event) => {
//     setSelectedClass(event.target.value);
//   };

//   const handleAcademicYearChange = (event) => {
//     setSelectedAcademicYear(event.target.value);
//   };

//   const options = {
//     data: chartData,
//     title: {
//       text: '',
//     },
//     series: [
//       {
//         type: 'bar',
//         xKey: 'subject',
//         yKey: 'term1Total',
//         name: 'Term 1 Total',
//         fill: '#4caf50',
//       },
//       {
//         type: 'bar',
//         xKey: 'subject',
//         yKey: 'term2Total',
//         name: 'Term 2 Total',
//         fill: '#ff9800',
//       },
//     ],
//     axes: [
//       {
//         type: 'category',
//         position: 'bottom',
//         title: 'Subject',
//       },
//       {
//         type: 'number',
//         position: 'left',
//         title: 'Grade',
//         min: 0,
//       },
//     ],
//   };

//   return (
//     <div className="card card-success" style={{ fontFamily: 'Arial, sans-serif', width: '100%', height: 'auto', marginTop: '-4vh' }}>
//       <div className="card-body">
//         {loading && <p>Loading...</p>}
//         {error && <p style={{ color: 'red' }}>{error}</p>}
        
//         {/* Filters inside the chart container */}
//         <div style={{ display: 'flex', justifyContent: 'center', marginBottom: '10px' }}>
//           <div style={{ marginRight: '20px' }}>
//             <select 
//               id="classFilter" 
//               onChange={handleClassChange} 
//               value={selectedClass} 
//               style={{ padding: '5px', borderRadius: '5px', borderColor: 'lightSkyBlue' }}
//             >
//               <option value="">Class</option>
//               {classes.map((classItem) => (
//                 <option key={classItem} value={classItem}>
//                   {classItem}
//                 </option>
//               ))}
//             </select>
//           </div>
//           <div>
//             <select 
//               id="academicYearFilter" 
//               onChange={handleAcademicYearChange} 
//               value={selectedAcademicYear} 
//               style={{ padding: '5px', borderRadius: '5px', borderColor: 'lightSkyBlue' }}
//             >
//               <option value="">Year</option>
//               {academicYears.map((year) => (
//                 <option key={year} value={year}>
//                   {year}
//                 </option>
//               ))}
//             </select>
//           </div>
//         </div>
        
//         {/* Chart container */}
//         <div style={{ width: '100%', height: 'auto' }}>
//           <AgCharts options={options} style={{ width: '100%', height: '33vh', marginTop: '-2vh' }} />
//         </div>
//       </div>
//     </div>
//   );
// };

// export default Studentperformance;



import React, { useState, useEffect } from 'react';
import { AgCharts } from 'ag-charts-react';
import axios from 'axios';
import '@fortawesome/fontawesome-free/css/all.min.css';

const Studentperformance = () => {
  const [selectedClass, setSelectedClass] = useState('');
  const [selectedAcademicYear, setSelectedAcademicYear] = useState('');
  const [classes, setClasses] = useState([]);
  const [academicYears, setAcademicYears] = useState([]);
  const [subjects, setSubjects] = useState([]);
  const [chartData, setChartData] = useState([]);
  const [annualPerformanceData, setAnnualPerformanceData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const fetchData = async () => {
    setLoading(true);
    setError('');
    try {
      const response = await axios.get('http://13.127.57.224:2081/api/Studentsummary', {
        params: {
          CLASS: selectedClass,
          ACADEMIC_YEAR: selectedAcademicYear,
        },
      });

      const data = response.data;

      const uniqueClasses = [...new Set(data.map(item => item.CLASS))];
      const uniqueAcademicYears = [...new Set(data.map(item => item.ACADEMIC_YEAR))];
      const uniqueSubjects = [...new Set(data.map(item => item.SUBJECT))];

      // Prepare chart data for AG Charts
      const chartData = uniqueSubjects.map(subject => {
        const item = data.find(d => d.SUBJECT === subject);
        return {
          subject,
          term1Total: item ? item.TERM_1_TOTAL : 0,
          term2Total: item ? item.TERM_2_TOTAL : 0,
          annualPerformance: item ? item.ANNUAL_PERFORMANCE : 0,
        };
      });

      setClasses(uniqueClasses);
      setAcademicYears(uniqueAcademicYears);
      setSubjects(uniqueSubjects);
      setAnnualPerformanceData(chartData.map(item => item.annualPerformance)); // Store annual performance data in state

      setChartData(chartData); // Update chart data state
    } catch (error) {
      setError('Error fetching data. Please try again later.');
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [selectedClass, selectedAcademicYear]);

  const handleClassChange = (event) => {
    setSelectedClass(event.target.value);
  };

  const handleAcademicYearChange = (event) => {
    setSelectedAcademicYear(event.target.value);
  };

  const options = {
    data: chartData,
    title: {
      text: '',
    },
    series: [
      {
        type: 'bar',
        xKey: 'subject',
        yKey: 'term1Total',
        name: 'Term 1 Total',
        fill: '#4caf50',
      },
      {
        type: 'bar',
        xKey: 'subject',
        yKey: 'term2Total',
        name: 'Term 2 Total',
        fill: '#ff9800',
      },
    ],
    axes: [
      {
        type: 'category',
        position: 'bottom',
        title: 'Subject',
      },
     {
        type: 'number',
        position: 'left',
        title: 'Grade',
        min: 0,
      },
      
    ],
  };

  return (
    <div className="card card-success" style={{ fontFamily: 'Arial, sans-serif', width: '100%', height: 'auto', marginTop: '-7vh' }}>
      <div className="card-body">
        {loading && <p>Loading...</p>}
        {error && <p style={{ color: 'red' }}>{error}</p>}

        {/* Chart container with filters inside */}
        <div style={{ width: '100%', position: 'relative' }}>
          {/* Filters inside the chart container */}
          <div style={{ position: 'absolute', top: '-1vh', left: '10px', zIndex: 10, display: 'flex', gap: '0px' }}>
            <div>
              <select
                id="classFilter"
                onChange={handleClassChange}
                value={selectedClass}
                style={{ padding: '5px', borderRadius: '5px', borderColor: 'lightSkyBlue' }}
              >
                <option value="">Class</option>
                {classes.map((classItem) => (
                  <option key={classItem} value={classItem}>
                    {classItem}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <select
                id="academicYearFilter"
                onChange={handleAcademicYearChange}
                value={selectedAcademicYear}
                style={{ padding: '5px', borderRadius: '5px', borderColor: 'lightSkyBlue' }}
              >
                <option value="">Year</option>
                {academicYears.map((year) => (
                  <option key={year} value={year}>
                    {year}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Chart */}
          <AgCharts options={options} style={{ width: '100%', height: '33vh', marginTop: '-2rem' }} />
        </div>
      </div>
    </div>
  );
};

export default Studentperformance;
