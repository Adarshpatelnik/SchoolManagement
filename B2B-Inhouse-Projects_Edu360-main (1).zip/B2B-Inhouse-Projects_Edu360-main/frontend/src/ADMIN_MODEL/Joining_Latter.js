// import React, { useState, useEffect } from 'react';
// import styled from 'styled-components';
// import { jsPDF } from 'jspdf';
// import { AgGridReact } from 'ag-grid-react';
// import 'ag-grid-community/styles/ag-grid.css';
// import 'ag-grid-community/styles/ag-theme-alpine.css';

// const Container = styled.div`
//     width: 100%;
//     margin: 20px 0 0 0; /* Adds some top margin */
//     padding: 20px;
//     background: #fff;
//     box-sizing: border-box;
//     border-radius: 8px;
//     box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
// `;

// const TableContainer = styled.div`
//     margin-top: 10px;
//     padding: 10px;
//     background: #f8f9fa;
//     border-radius: 8px;
//     box-shadow: 0 0 10px rgba(0, 0, 0, 0.05);
//     width: 100%;
//     height: 500px; /* Set a fixed height for the table */
//     overflow: auto; /* Allow scrolling if content overflows */
// `;

// const Button = styled.button`
//     background: linear-gradient(to right, #012353, #27ae60);
//     color: white;
//     border: none;
//     padding: 12px 20px;
//     font-size: 16px;
//     border-radius: 5px;
//     cursor: pointer;
//     transition: all 0.3s ease;

//     &:hover {
//         background: linear-gradient(to right, #27ae60, #012353);
//     }
// `;

// const JoiningLatter = () => {
//     const [staffData, setStaffData] = useState([]);
//     const [loading, setLoading] = useState(true);
//     const [selectedRows, setSelectedRows] = useState([]);

//     useEffect(() => {
//         const fetchStaffData = async () => {
//             try {
//                 const response = await fetch('http://13.127.57.224:2081/api/JoiningLatter');
//                 const data = await response.json();
//                 setStaffData(data);
//                 setLoading(false);
//             } catch (error) {
//                 console.error("Error fetching staff data:", error);
//                 setLoading(false);
//             }
//         };

//         fetchStaffData();
//     }, []);

//     if (loading) {
//         return <div>Loading...</div>;
//     }

//     if (staffData.length === 0) {
//         return <div>No staff data found</div>;
//     }

//     const formatDate = (dateString) => {
//         const date = new Date(dateString);
//         return date.toLocaleDateString('en-US');
//     };

//     const generateLetterHTML = (staff) => {
//         const {
//             TEACHER_NAME,
//             STAFF_ROLE,
//             DATE_OF_JOINING,
//             MONTHLY_SALARY,
//             SCHOOL_NAME,
//             PRINCIPAL_NAME,
//             ADDRESS,
//             CITY,
//             POSTAL_CODE,
//             CONTACT_NUMBER,
//             EMAIL,
//             STAFF_INITIALS
//         } = staff;

//         const formattedDate = formatDate(DATE_OF_JOINING);
//         return `
//             <div style="font-family: Arial, sans-serif; padding: 20px;">
//                 <h2>Joining Letter for ${TEACHER_NAME}</h2>
//                 <p><strong>School Name:</strong> ${SCHOOL_NAME}</p>
//                 <p><strong>Address:</strong> ${ADDRESS}</p>
//                 <p><strong>City, Postal Code:</strong> ${CITY}, ${POSTAL_CODE}</p>
//                 <p><strong>Phone number:</strong> ${CONTACT_NUMBER}</p>
//                 <p><strong>Email:</strong> ${EMAIL}</p>
//                 <p><strong>Date:</strong> ${formattedDate}</p>
//                 <p>Dear ${TEACHER_NAME},</p>
//                 <p>Welcome to ${SCHOOL_NAME}! We are excited to have you join our teaching team. Your passion for education and commitment to students' growth are highly valued, and we are confident that you will thrive here.</p>
//                 <p>Starting on ${formattedDate}, you will be a ${STAFF_ROLE} teacher, responsible for [Briefly Mention Teaching responsibilities]. Your experience and dedication make you a perfect fit for our school's mission of fostering a love for learning.</p>
//                 <p>Please review the enclosed employment contract for details on your compensation package and benefits, including a salary of ${MONTHLY_SALARY}. If you have any questions before your start date, please contact ${PRINCIPAL_NAME} in our Human Resources department at ${EMAIL}.</p>
//                 <p>Once again, welcome to ${SCHOOL_NAME}. We look forward to your contributions to our students' success.</p>
//                 <p>Sincerely,</p>
//                 <p>${STAFF_INITIALS}<br>${PRINCIPAL_NAME}<br>${SCHOOL_NAME}</p>
//             </div>
//         `;
//     };

//     const generatePDF = () => {
//         selectedRows.forEach(staff => {
//             const letterHTML = generateLetterHTML(staff);
//             const doc = new jsPDF();
//             doc.setFontSize(18);
//             doc.text('Joining Letter for Teacher', 20, 20);
//             doc.setFontSize(12);
//             const splitText = doc.splitTextToSize(letterHTML.replace(/<[^>]+>/g, ''), 180); // Remove HTML tags for PDF
//             splitText.forEach((line, index) => {
//                 doc.text(line, 20, 40 + (index * 10));
//             });
//             doc.save(`JoiningLetter_${staff.TEACHER_NAME}.pdf`);
//         });
//     };

//     const handlePrint = () => {
//         const printContents = selectedRows.map(staff => generateLetterHTML(staff)).join('<div style="page-break-after: always;"></div>');
        
//         const printWindow = window.open('', '_blank');
//         printWindow.document.write('<html><head><title>Print Letters</title></head><body>');
//         printWindow.document.write(printContents);
//         printWindow.document.write('</body></html>');
//         printWindow.document.close();
//         printWindow.print();
//     };

//     const columnDefs = [
//         {
//             headerCheckboxSelection: true,
//             checkboxSelection: true,
//             width: 50
//         },
//         { headerName: "Staff ID", field: "STAFF_ID", width: 150, filter: true },
//         { headerName: "Staff Name", field: "TEACHER_NAME", width: 250, filter: true },
//         { headerName: "Contact Number", field: "CONTACT_NUMBER", width: 200, filter: true },
//         { headerName: "School Name", field: "SCHOOL_NAME", width: 250, filter: true },
//         { headerName: "Address", field: "ADDRESS", width: 200, filter: true },
//         { headerName: "City", field: "CITY", width: 250, filter: true },
//     ];

//     const onSelectionChanged = (event) => {
//         const selectedNodes = event.api.getSelectedNodes();
//         const selectedData = selectedNodes.map(node => node.data);
//         setSelectedRows(selectedData);
//     };

//     return (
//         <Container>
//             <Button onClick={generatePDF} disabled={selectedRows.length === 0}>
//                 Generate PDF for Selected
//             </Button>
//             <Button onClick={handlePrint} disabled={selectedRows.length === 0} style={{ marginLeft: '10px' }}>
//                 Print Selected Letters
//             </Button>

//             <TableContainer className="ag-theme-alpine">
//                 <AgGridReact
//                     rowData={staffData}
//                     columnDefs={columnDefs}
//                     domLayout='autoHeight'
//                     onSelectionChanged={onSelectionChanged}
//                     enableFilter={true} // Enable filtering for all columns
//                     headerHeight={35} // Fixed header height
//                     rowHeight={45}    // Adjusted row height
//                 />
//             </TableContainer>
//         </Container>
//     );
// };

// export default JoiningLatter;




import React, { useState, useEffect } from 'react';
import styled from 'styled-components';
import html2pdf from 'html2pdf.js';

const Container = styled.div`
    width: 100%;
    margin: 0;
    padding: 20px;
    background: #f4f7fb;
    box-sizing: border-box;
    border-radius: 12px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
`;

const TitleContainer = styled.div`
    text-align: center;
    margin-bottom: 20px;
    background: linear-gradient(to right, #3f87a6, #ebf8e1);
    padding: 15px;
    border-radius: 10px;
`;

const Title = styled.h2`
    margin: 0;
    color: white;
    font-family: 'Roboto', sans-serif;
    font-weight: bold;
`;

const SearchContainer = styled.div`
    margin-bottom: 20px;
    display: flex;
    flex-direction: column;
    align-items: center;
    position: relative;
`;

const Input = styled.input`
    padding: 12px;
    font-size: 16px;
    border: 1px solid #ccc;
    border-radius: 5px;
    margin-bottom: 10px;
    width: 300px;
`;

const Button = styled.button`
    background: linear-gradient(to right, #3f87a6, #ebf8e1);
    color: white;
    border: none;
    padding: 12px 20px;
    font-size: 16px;
    border-radius: 5px;
    cursor: pointer;
    transition: all 0.3s ease;
    margin-left: auto;
    margin-top: ${(props) => (props.topButton ? '30px' : '10px')};

    &:hover {
        background: linear-gradient(to right, #ebf8e1, #3f87a6);
    }
`;

const SuggestionsList = styled.ul`
    position: absolute;
    top: 60px;
    left: 0;
    width: 300px;
    max-height: 150px;
    overflow-y: auto;
    background: #fff;
    border: 1px solid #ccc;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    padding: 0;
    margin: 0;
    border-radius: 5px;
    z-index: 10;
`;

const SuggestionItem = styled.li`
    padding: 8px 12px;
    cursor: pointer;
    &:hover {
        background-color: #f0f0f0;
    }
`;

const StaffDetails = styled.div`
    margin-top: 20px;
    padding: 20px;
    background: #fff;
    border-radius: 12px;
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.05);
    font-family: 'Roboto', sans-serif;
    display: flex;
    justify-content: flex-start;
    align-items: flex-start;
`;

const LeftSide = styled.div`
    width: 30%;
    text-align: center;
    display: flex;
    flex-direction: column;
    justify-content: flex-start;
    align-items: center;
    margin-left: 100px;
    margin-right: 40px;
`;

const TextBelowImage = styled.div`
    margin-top: 10px;
    font-weight: bold;
    text-align: center;
`;

const RightSide = styled.div`
    width: 60%;
    display: flex;
    flex-direction: column;
    justify-content: flex-start;
    align-items: flex-start;
    margin-left: 20px;
`;

const DetailsGrid = styled.div`
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 10px;
    align-items: flex-start;
`;

const DetailItem = styled.div`
    font-size: 13px;
    line-height: 1.4;
    display: flex;
    align-items: center;
    justify-content: space-between;
`;

const generateJoiningLetterText = (staff) => {
    const {
        TEACHER_NAME,
        SCHOOL_NAME,
        DATE_OF_JOINING,
        STAFF_ROLE,
        PRINCIPAL_NAME,
        ADDRESS,
        CITY,
        POSTAL_CODE,
        CONTACT_NUMBER,
        EMAIL,
    } = staff;

    const formattedDate = new Date(DATE_OF_JOINING).toLocaleDateString('en-US');

    return `
        <div style="font-family: Arial, sans-serif; padding: 30px; max-width: 600px; margin: 0 auto; background: #fff; border-radius: 12px; box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);">
            <div style="text-align: center; font-size: 18px; font-weight: bold; background: linear-gradient(to right, #3f87a6, #ebf8e1); padding: 10px; color: white; border-radius: 12px;">
                <img src="pngtree-school-logo-png-image.png" alt="${SCHOOL_NAME}" style="width: 50px; height: 50px; vertical-align: middle; margin-right: 10px;" />
                ${SCHOOL_NAME}
            </div>
            <div style="text-align: left; margin-top: 20px; font-size: 14px;">
                <p style="margin: 0; line-height: 1.2;">${SCHOOL_NAME}</p>
                <p style="margin: 0; line-height: 1.2;">${ADDRESS}</p>
                <p style="margin: 0; line-height: 1.2;">${CITY}, ${POSTAL_CODE}</p>
                <p style="margin: 0; line-height: 1.2;"> ${CONTACT_NUMBER} </p>
                <p style="margin: 0; line-height: 1.2;">${EMAIL}</p>
            </div>
            <hr style="margin: 20px 0; border: 1px solid #ccc;">
            <p>Dear ${TEACHER_NAME},</p>
            <p>We are pleased to welcome you to ${SCHOOL_NAME}! It is our pleasure to have you join our dynamic teaching team. Your experience, passion for education, and commitment to student success are highly valued, and we are confident you will be an asset to our school community.</p>
            <p>Starting on ${formattedDate}, you will be a ${STAFF_ROLE}, responsible for [Briefly Mention Teaching responsibilities]. We look forward to working with you and supporting you in your role.</p>
            <p>Your monthly salary will be [Insert Salary], and we encourage you to review the contract for additional benefits. If you have any questions or need further assistance, please don't hesitate to contact ${PRINCIPAL_NAME} in Human Resources at ${EMAIL}.</p>
            <p>Once again, welcome to the ${SCHOOL_NAME} family. We are excited to see the contributions you will make in the years to come.</p>
            <br><br>
            <p style="margin: 0; line-height: 1.2;">Sincerely,</p>
            <p style="margin: 0; line-height: 1.2;">${PRINCIPAL_NAME}</p>
            <p style="margin: 0; line-height: 1.2;">${SCHOOL_NAME}</p>
        </div>
    `;
};



const generateExperienceLetterText = (staff) => {
    const {
        TEACHER_NAME,
        SCHOOL_NAME,
        DATE_OF_JOINING,
        EXIT_DATE,
        STAFF_ROLE,
        STAFF_INITIALS,
        PRINCIPAL_NAME,
        ADDRESS,
        CITY,
        POSTAL_CODE,
        CONTACT_NUMBER,
        EMAIL,
    } = staff;

    const formattedJoiningDate = new Date(DATE_OF_JOINING).toLocaleDateString('en-US');
    const formattedExitDate = EXIT_DATE ? new Date(EXIT_DATE).toLocaleDateString('en-US') : 'Present';

    return `
        <div style="font-family: Arial, sans-serif; padding: 30px; max-width: 600px; margin: 0 auto; background: #fff; border-radius: 12px; box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);">
            <div style="text-align: center; font-size: 18px; font-weight: bold; background: linear-gradient(to right, #3f87a6, #ebf8e1); padding: 10px; color: white; border-radius: 12px;">
                <img src="pngtree-school-logo-png-image.png" alt="${SCHOOL_NAME}" style="width: 50px; height: 50px; vertical-align: middle; margin-right: 10px;" />
                ${SCHOOL_NAME}
            </div>

            <div style="text-align: left; margin-top: 20px; font-size: 14px;">
                <p style="margin: 0; line-height: 1.2;">${SCHOOL_NAME}</p>
                <p style="margin: 0; line-height: 1.2;">${ADDRESS}</p>
                <p style="margin: 0; line-height: 1.2;">${CITY}, ${POSTAL_CODE}</p>
                <p style="margin: 0; line-height: 1.2;">Phone: ${CONTACT_NUMBER}</p>
                <p style="margin: 0; line-height: 1.2;">Email: ${EMAIL}</p>
            </div>

            <hr style="margin: 20px 0; border: 1px solid #ccc;">

            <p>Dear ${TEACHER_NAME},</p>

            <p>This is to certify that ${STAFF_INITIALS} served as a ${STAFF_ROLE} at ${SCHOOL_NAME} from ${formattedJoiningDate} to ${formattedExitDate}. ${STAFF_INITIALS} was responsible for teaching [specify subject], planning lessons, and assessing student progress. ${STAFF_INITIALS} dedication to management was evident throughout ${STAFF_INITIALS} tenure.</p>

            <p>${STAFF_INITIALS} consistently demonstrated professionalism, reliability, and a passion for teaching. ${STAFF_INITIALS} maintained positive relationships with students and colleagues, contributing to a supportive learning environment.</p>

            <p>We are confident in ${STAFF_INITIALS} abilities and wish ${STAFF_INITIALS} continued success in ${STAFF_INITIALS} future endeavors.</p>

            <br><br>
            <p style="margin: 0; line-height: 1.2;">Sincerely,</p>
            <p style="margin: 0; line-height: 1.2;">${PRINCIPAL_NAME}</p>
            <p style="margin: 0; line-height: 1.2;">${SCHOOL_NAME}</p>
        </div>
    `;
};

const handleGenerateJoiningLetterPDF = (staff) => {
    const pdfOptions = {
        margin: 10,
        filename: 'JoiningLetter.pdf',
        jsPDF: { unit: 'pt', format: 'letter', orientation: 'portrait' },
    };

    const contentHTML = generateJoiningLetterText(staff);

    const contentElement = document.createElement('div');
    contentElement.innerHTML = contentHTML;
    html2pdf().from(contentElement).set(pdfOptions).save();
};

const handleGenerateExperienceLetterPDF = (staff) => {
    const pdfOptions = {
        margin: 10,
        filename: 'ExperienceLetter.pdf',
        jsPDF: { unit: 'pt', format: 'letter', orientation: 'portrait' },
    };

    const contentHTML = generateExperienceLetterText(staff);

    const contentElement = document.createElement('div');
    contentElement.innerHTML = contentHTML;
    html2pdf().from(contentElement).set(pdfOptions).save();
};

const JoiningLatter = () => {
    const [staffData, setStaffData] = useState([]);
    const [loading, setLoading] = useState(true);
    const [searchTerm, setSearchTerm] = useState('');
    const [selectedStaff, setSelectedStaff] = useState(null);

    useEffect(() => {
        const fetchStaffData = async () => {
            try {
                const response = await fetch('http://13.127.57.224:2081/api/JoiningLatter');
                const data = await response.json();
                setStaffData(data);
                setLoading(false);
            } catch (error) {
                console.error("Error fetching staff data:", error);
                setLoading(false);
            }
        };

        fetchStaffData();
    }, []);

    // Filter staff data based on search term
    const filteredStaff = staffData.filter(staff =>
        staff.TEACHER_NAME && staff.TEACHER_NAME.toLowerCase().includes(searchTerm.toLowerCase())
    );

    // Handle selecting staff
    const handleSelectStaff = (staff) => {
        setSelectedStaff(staff);
        setSearchTerm(''); // Clear search term when a staff member is selected
    };

    const handleSearchChange = (e) => {
        setSearchTerm(e.target.value);
    };

    if (loading) {
        return <div>Loading...</div>;
    }

    return (
        <div className="container-fluid" style={{ marginTop: '5vh',  }}>

        <Container>
            <TitleContainer>
                <Title>Generate Joining Letter</Title>
            </TitleContainer>

            {/* Only show the search box and suggestions if no staff is selected */}
            {!selectedStaff && (
                <SearchContainer>
                    <Input
                        type="text"
                        value={searchTerm}
                        onChange={handleSearchChange}
                        placeholder="Search by Teacher Name"
                    />
                    {/* Show suggestions only when there is a search term */}
                    {searchTerm && filteredStaff.length > 0 && (
                        <SuggestionsList>
                            {filteredStaff.map(staff => (
                                <SuggestionItem key={staff.ID} onClick={() => handleSelectStaff(staff)}>
                                    {staff.TEACHER_NAME}
                                </SuggestionItem>
                            ))}
                        </SuggestionsList>
                    )}
                    {/* Show a message when no results are found */}
                    {searchTerm && filteredStaff.length === 0 && (
                        <div>No matching staff found</div>
                    )}
                </SearchContainer>
            )}

            {selectedStaff && (
                <StaffDetails>
                    <LeftSide>
                        <img
                            src="3d-cartoon-business-character_1048-16604.avif"
                            alt="Staff Image"
                            style={{ width: '25%', borderRadius: '10px' }}
                        />
                        <TextBelowImage>{selectedStaff.TEACHER_NAME}</TextBelowImage>
                    </LeftSide>

                    <RightSide>
                        <DetailsGrid>
                            <DetailItem>
                                <div><strong>Registration/ID:</strong> {selectedStaff.STAFF_ID}</div>
                            </DetailItem>
                            <DetailItem>
                                <div><strong>Role:</strong> {selectedStaff.STAFF_ROLE}</div>
                            </DetailItem>
                            <DetailItem>
                                <div><strong>Date of Joining:</strong> {new Date(selectedStaff.DATE_OF_JOINING).toLocaleDateString()}</div>
                            </DetailItem>
                            <DetailItem>
                                <div><strong>Contact Number:</strong> {selectedStaff.CONTACT_NUMBER}</div>
                            </DetailItem>
                            <DetailItem>
                                <div><strong>Address:</strong> {selectedStaff.ADDRESS}</div>
                            </DetailItem>
                            <DetailItem>
                                <div><strong>Username:</strong> {selectedStaff.STAFF_USER_ID}</div>
                            </DetailItem>
                        </DetailsGrid>
                        <Button onClick={() => handleGenerateJoiningLetterPDF(selectedStaff)}>
                            Generate Joining Letter PDF
                        </Button>
                        <Button onClick={() => handleGenerateExperienceLetterPDF(selectedStaff)}>
                            Generate Experience Letter PDF
                        </Button>
                    </RightSide>
                </StaffDetails>
            )}
        </Container>
        </div>
    );
};

export default JoiningLatter;
