
import React, { useState, useEffect, useCallback } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

const GradeBook = () => {
  const [selectedAcademicYear, setSelectedAcademicYear] = useState('All');
  const [searchStudentId, setSearchStudentId] = useState('');
  const [searchFirstName, setSearchFirstName] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedClass, setSelectedClass] = useState('All');
  const [studentAcademic, setStudentAcademic] = useState([]);
  const [filteredStudentAcademic, setFilteredStudentAcademic] = useState([]);
  const [classes, setClasses] = useState([]);
  const [schoolDetails, setSchoolDetails] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
 
  useEffect(() => {
    const fetchData = async () => {
      try {
        const [academicResponse, schoolDetailsResponse] = await Promise.all([
          fetch('http://13.127.57.224:2081/api/VWACADEMICMARKS', { mode: 'cors' }),
          fetch('http://13.127.57.224:2081/api/SCHOOLDETAILS', { mode: 'cors' })
        ]);
 
        if (!academicResponse.ok) throw new Error('Failed to fetch student academic data');
        if (!schoolDetailsResponse.ok) throw new Error('Failed to fetch school details data');
 
        const academicData = await academicResponse.json();
        const schoolDetailsData = await schoolDetailsResponse.json();
 
        setStudentAcademic(academicData);
        setFilteredStudentAcademic(academicData);
        setSchoolDetails(schoolDetailsData);
 
        const uniqueClasses = [...new Set(academicData.map(student => student.CLASS.trim()))];
        setClasses(uniqueClasses);
      } catch (error) {
        console.error('Error fetching data:', error);
        setError('Failed to fetch data. Please try again later.');
      } finally {
        setIsLoading(false);
      }
    };
 
    fetchData();
  }, []);
 
 
 
  // Filter data based on selected criteria
  const filterData = useCallback(() => {
    let filteredData = [...studentAcademic];
   
    console.log('Original Data:', filteredData);
 
    // Filter by Academic Year
    if (selectedAcademicYear !== 'All') {
      filteredData = filteredData.filter(student =>
        student.ACADEMIC_YEAR.toLowerCase() === selectedAcademicYear.toLowerCase()
      );
    }
    console.log('After Academic Year Filter:', filteredData);
 
    // Filter by Class
    if (selectedClass !== 'All') {
      filteredData = filteredData.filter(student =>
        student.CLASS.trim().toLowerCase() === selectedClass.trim().toLowerCase()
      );
    }
    console.log('After Class Filter:', filteredData);
 
    // Filter by Student ID
    if (searchStudentId.trim() !== '') {
      filteredData = filteredData.filter(student =>
        student.STUDENT_ID.toLowerCase().includes(searchStudentId.toLowerCase().trim())
      );
    }
    console.log('After Student ID Filter:', filteredData);
 
    // Filter by First Name
    if (searchFirstName.trim() !== '') {
      filteredData = filteredData.filter(student =>
        student.STUDENT_NAME.toLowerCase().includes(searchFirstName.toLowerCase().trim())
      );
    }
    console.log('After First Name Filter:', filteredData);
 
   
 
    // Aggregate data to ensure unique student IDs
    const uniqueStudentIds = new Set();
    const aggregatedData = filteredData.filter(student => {
      if (!uniqueStudentIds.has(student.STUDENT_ID)) {
        uniqueStudentIds.add(student.STUDENT_ID);
        return true;
      }
      return false;
    });
 
    console.log('Final Filtered Data:', aggregatedData);
 
    setFilteredStudentAcademic(aggregatedData);
  }, [selectedAcademicYear, selectedClass, searchStudentId, searchFirstName, searchTerm, studentAcademic]);
 
  useEffect(() => {
    filterData();
  }, [filterData]);
 
  // Reset filters
  const handleReset = () => {
    setSelectedAcademicYear('All');
    setSelectedClass('All');
    setSearchStudentId('');
    setSearchFirstName('');
    setSearchTerm('');
  };
 
  // Group data by student and aggregate subject information
  const groupStudentData = (studentId) => {
    const studentData = studentAcademic.filter(student => student.STUDENT_ID === studentId);
    if (!studentData.length) {
      alert('No student found with the provided ID.');
      return [];
    }
 
    const aggregatedData = studentData.reduce((acc, student) => {
      const existing = acc.find(item => item.STUDENT_ID === student.STUDENT_ID);
      if (existing) {
        existing.SUBJECTS.push(student.SUBJECT);
        existing.TERM_1_TOTAL += student.TERM_1_TOTAL;
        existing.TERM_2_TOTAL += student.TERM_2_TOTAL;
        existing.SUBJECT_COUNT += 1;
      } else {
        acc.push({
          ...student,
          SUBJECTS: [student.SUBJECT],
          TERM_1_TOTAL: student.TERM_1_TOTAL,
          TERM_2_TOTAL: student.TERM_2_TOTAL,
          SUBJECT_COUNT: 1
        });
      }
      return acc;
    }, []);
 
    return aggregatedData;
  };
 
  const printStudentReportCard = (studentId) => {
    const studentData = groupStudentData(studentId);
    if (!studentData.length) {
        alert('No student data available to generate the report.');
        return;
    }
 
    const calculateAttendance = () => ({
        term1: { percentage: '85%', details: 'No absenteeism' },
        term2: { percentage: '90%', details: 'No absenteeism' },
        overall: { percentage: '87.5%', details: 'Consistent attendance' }
    });
 
    const calculatePhysicalFitness = () => ({
    weightInKg: { score: studentData[0].WEIGHT_IN_KG, details: 'Average fitness' }, // Use actual weight
    heightInCm: { score: studentData[0].HEIGHT_IN_CM, details: 'Improved fitness' }, // Use actual height
        generalHealthCondition: { score: 'Good', details: 'Good overall fitness' }
    });
 
    const calculateStatus = () => 'Promoted to 11th class';
 
    // Extract subject data for chart
    let subjects = {};
    studentData.forEach(data => {
        data.SUBJECTS.forEach(subject => {
            if (!subjects[subject]) {
                subjects[subject] = { term1: 0, term2: 0 };
            }
            subjects[subject].term1 += data.PERIODIC_TEST_1 || 0; // Assuming PERIODIC_TEST_1 is the mark for Term 1
            subjects[subject].term2 += data.PERIODIC_TEST_2 || 0; // Assuming PERIODIC_TEST_2 is the mark for Term 2
        });
    });
 
    // Prepare data for chart
    const chartLabels = Object.keys(subjects);
    const term1Data = chartLabels.map(subject => subjects[subject].term1);
    const term2Data = chartLabels.map(subject => subjects[subject].term2);
 
    const chartData = {
        labels: chartLabels,
        datasets: [
            {
                label: 'Term 1',
                data: term1Data,
                backgroundColor: 'rgba(134, 159, 245, 0.5)', // Light blue
                borderColor: 'rgba(134, 159, 245, 1)', // Dark blue
                borderWidth: 1
            },
            {
                label: 'Term 2',
                data: term2Data,
                backgroundColor: 'rgba(209, 205, 126, 0.5)', // Light yellow
                borderColor: 'rgba(209, 205, 126, 1)', // Dark yellow
                borderWidth: 1
            }
        ]
    };
 
    const chartOptions = {
        scales: {
            y: {
                beginAtZero: true
            }
        }
    };
 
    const sectionStyle = 'border-collapse: collapse; width: 100%; margin-top: 20px;';
    const tableStyle = 'border: 1px solid #ddd; padding: 8px; text-align: center; width: 100%;';
    const thStyle = 'background-color: #a7ca8f; padding: 8px; border: 1px solid #ddd;';
    const thTdStyle = 'padding: 8px; border: 1px solid #ddd;';
 
    const printWindow = window.open('', '', 'height=800,width=1000');
    printWindow.document.write('<html><head><title>Student Report Card</title>');
    printWindow.document.write('<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">');
    printWindow.document.write('<style>body { font-family: Arial, sans-serif; margin: 20px; } header, footer { text-align: center; } table { border-collapse: collapse; width: 100%; margin-top: 20px; } th, td { border: 1px solid #ddd; padding: 8px; text-align: center; } th { background-color: #f4f4f4; } h1, h2 { color: #333; } .signature-container { margin-top: 40px; text-align: center; } .signature-container div { display: inline-block; width: 45%; text-align: center; margin: 0 20px; } .signature-container .left { text-align: left; } .signature-container .right { text-align: right; } .section-header { background-color: #f8f9fa; padding: 10px; font-weight: bold; } </style>');
    printWindow.document.write('</head><body>');
    printWindow.document.write('<div class="container">');
 
    // Header
    printWindow.document.write('<header><img src="schoollogo.jpg" alt="School Logo" style="width: 100px; height: auto;"><h1>EUROKIDS PRE SCHOOL </h1><p>NH7, NEHRU NAGAR, REWA 486001</p><h5>REPORT CARD</h5><p>Academic Session: 2023-2024</p></header>');
 
// Student Information
studentData.forEach(data => {
  printWindow.document.write('<section><div class="container">'); // Use container to center content
  printWindow.document.write('<div class="row">');
 
  // Left side information
  printWindow.document.write('<div class="col-md-6">');
  printWindow.document.write('<p><strong>Student ID:</strong> ' + data.STUDENT_ID + '</p>');
  printWindow.document.write('<p><strong>Name:</strong> ' + data.STUDENT_NAME + '</p>');
  printWindow.document.write('<p><strong>Father\'s Name:</strong> ' + data.FATHER_NAME + '</p>');
  printWindow.document.write('<p><strong>Mother\'s Name:</strong> ' + data.MOTHER_NAME + '</p>');
  printWindow.document.write('</div>');
 
  // Right side information
  printWindow.document.write('<div class="col-md-6 text-right">');
  printWindow.document.write('<p><strong>Class & Session:</strong> ' + data.CLASS + '</p>');
  printWindow.document.write('<p><strong>Date of Birth:</strong> ' + new Date(data.DATE_OF_BIRTH).toLocaleDateString('en-IN') + '</p>');
  printWindow.document.write('<p><strong>School No:</strong> ' + data.SCHOOL_NO + '</p>');
  printWindow.document.write('<p><strong>Contact No:</strong> ' + data.PRIMARY_CONTACT_NUMBER + '</p>');
  printWindow.document.write('</div>');
 
  printWindow.document.write('</div></div></section>');
});
 
    // Open the document for writing
printWindow.document.write('<section><h2 class="text-center">SCHOLASTIC AREA</h2>');
printWindow.document.write('<table class="table table-bordered" style="width: 100%;">');
printWindow.document.write('<thead>');
printWindow.document.write('<tr>');
// Add an empty cell to create space on the left side
printWindow.document.write('<th style="background-color: transparent; border: none;"></th>');
// Adjust colspan as needed
printWindow.document.write('<th colspan="6" style="background-color: #869ff5; color: #000; text-align: center;">Term 1</th>');
printWindow.document.write('<th colspan="6" style="background-color: #d1cd7e; color: #000; text-align: center;">Term 2</th>');
printWindow.document.write('</tr>');
printWindow.document.write('<tr>');
printWindow.document.write('<th>Subject</th>');
printWindow.document.write('<th>P.T(30/10)</th>');
printWindow.document.write('<th>N.B(5)</th>');
printWindow.document.write('<th>S.E(5)</th>');
printWindow.document.write('<th>H.Y(80/100)</th>');
printWindow.document.write('<th>T.T(100)</th>');
printWindow.document.write('<th>G.D</th>');
printWindow.document.write('<th>P.T(30/10)</th>');
printWindow.document.write('<th>N.B(5)</th>');
printWindow.document.write('<th>S.E(5)</th>');
printWindow.document.write('<th>H.Y(80/100)</th>');
printWindow.document.write('<th>T.T(100)</th>');
printWindow.document.write('<th>G.D</th>');
printWindow.document.write('</tr>');
printWindow.document.write('</thead>');
printWindow.document.write('<tbody>');
 
// Populate table rows with data
studentData.forEach(data => {
    data.SUBJECTS.forEach(subject => {
        printWindow.document.write('<tr>');
        printWindow.document.write('<td>' + subject + '</td>');
        printWindow.document.write('<td>' + (data.PERIODIC_TEST_1 || '') + '</td>');
        printWindow.document.write('<td>' + (data.NOTE_BOOK_1 || '') + '</td>');
        printWindow.document.write('<td>' + (data.SUBJECT_ENRICHMENT_1 || '') + '</td>');
        printWindow.document.write('<td>' + (data.HALF_YEARLY || '') + '</td>');
        printWindow.document.write('<td>' + (data.TERM_1_TOTAL || '') + '</td>');
        printWindow.document.write('<td>' + (data.GRADE || '') + '</td>');
        printWindow.document.write('<td>' + (data.PERIODIC_TEST_2 || '') + '</td>');
        printWindow.document.write('<td>' + (data.NOTE_BOOK_2 || '') + '</td>');
        printWindow.document.write('<td>' + (data.SUBJECT_ENRICHMENT_2 || '') + '</td>');
        printWindow.document.write('<td>' + (data.ANNUAL || '') + '</td>');
        printWindow.document.write('<td>' + (data.TERM_2_TOTAL || '') + '</td>');
        printWindow.document.write('<td>' + (data.GRADE || '') + '</td>');
        printWindow.document.write('</tr>');
    });
});
 
 
 
  // Add Total and Remarks rows
printWindow.document.write('<tr><td><strong>Total</strong></td><td colspan="5">' +
  studentData.reduce((sum, data) => sum + data.TERM_1_TOTAL, 0) + '/600' +
  '</td><td>-</td><td colspan="5">' +
  studentData.reduce((sum, data) => sum + data.TERM_2_TOTAL, 0) + '/600' +
  '</td><td>-</td></tr>');
 
printWindow.document.write('<tr><td><strong>Teacher\'s Remarks</strong></td><td colspan="12">Can do better!</td></tr>');
 
   
    // Combined Attendance, Physical Fitness & Status Section
    printWindow.document.write('<section style="' + sectionStyle + '"><table style="' + tableStyle + '"><thead><tr><th style="' + thStyle + '" colSpan="3">ATTENDANCE</th><th style="' + thStyle + '" colSpan="3">PHYSICAL & BODY FITNESS</th><th style="' + thStyle + '" colSpan="3">STATUS</th></tr></thead><tbody><tr><td style="' + thTdStyle + '">Term 1</td><td style="' + thTdStyle + '">' + calculateAttendance().term1.percentage + '</td><td style="' + thTdStyle + '">' + calculateAttendance().term1.details + '</td><td style="' + thTdStyle + '">Weight in kg</td><td style="' + thTdStyle + '">' + calculatePhysicalFitness().weightInKg.score + '</td><td style="' + thTdStyle + '">' + calculatePhysicalFitness().weightInKg.details + '</td><td style="' + thTdStyle + '" rowSpan="3">' + calculateStatus() + '</td></tr><tr><td style="' + thTdStyle + '">Term 2</td><td style="' + thTdStyle + '">' + calculateAttendance().term2.percentage + '</td><td style="' + thTdStyle + '">' + calculateAttendance().term2.details + '</td><td style="' + thTdStyle + '">Height in cm</td><td style="' + thTdStyle + '">' + calculatePhysicalFitness().heightInCm.score + '</td><td style="' + thTdStyle + '">' + calculatePhysicalFitness().heightInCm.details + '</td></tr><tr><td style="' + thTdStyle + '">Overall</td><td style="' + thTdStyle + '">' + calculateAttendance().overall.percentage + '</td><td style="' + thTdStyle + '">' + calculateAttendance().overall.details + '</td><td style="' + thTdStyle + '">General Health Condition</td><td style="' + thTdStyle + '">' + calculatePhysicalFitness().generalHealthCondition.score + '</td><td style="' + thTdStyle + '">' + calculatePhysicalFitness().generalHealthCondition.details + '</td></tr></tbody></table></section>');
 
 // Co-Scholastic and Discipline Section
  // Co-Scholastic and Discipline Section
  printWindow.document.write('<section style="' + sectionStyle + '"><table style="' + tableStyle + '"><thead><tr><th style="' + thStyle + '">CO-SCHOLASTIC</th><th style="' + thStyle + '">Term 1</th><th style="' + thStyle + '">Term 2</th><th style="' + thStyle + '">DISCIPLINE</th><th style="' + thStyle + '">Term 1</th><th style="' + thStyle + '">Term 2</th></tr></thead><tbody>');
 
  studentData.forEach(data => {
      const rows = [
          {
              activity: 'Work Education',
              term1: data.WORK_EDUCATION_1 || '',
              term2: data.WORK_EDUCATION_2 || '',
              discipline: 'Attitude Towards Society',
              disciplineTerm1: data.ATTITUDE_TOWARDS_SOCIETY_1 || '',
              disciplineTerm2: data.ATTITUDE_TOWARDS_SOCIETY_2 || ''
          },
          {
              activity: 'Art Education',
              term1: data.ART_EDUCATION_1 || '',
              term2: data.ART_EDUCATION_2 || '',
              discipline: 'Regularity & Punctuality',
              disciplineTerm1: data.REGULARITY_AND_PUNCTUALLITY_1 || '',
              disciplineTerm2: data.REGULARITY_AND_PUNCTUALLITY_2 || ''
          },
          {
              activity: 'Health & Hygiene',
              term1: data.HEALTH_AND_HYGIENE_1 || '',
              term2: data.HEALTH_AND_HYGIENE_2 || '',
              discipline: 'Respectfulness for Rules & Regulations',
              disciplineTerm1: data.RESPECTFULNESS_AND_REGULATIONS_1 || '',
              disciplineTerm2: data.RESPECTFULNESS_AND_REGULATIONS_2 || ''
          }
      ];
 
      rows.forEach(row => {
          printWindow.document.write('<tr><td style="' + thTdStyle + '">' + row.activity + '</td><td style="' + thTdStyle + '">' + row.term1 + '</td><td style="' + thTdStyle + '">' + row.term2 + '</td><td style="' + thTdStyle + '">' + row.discipline + '</td><td style="' + thTdStyle + '">' + row.disciplineTerm1 + '</td><td style="' + thTdStyle + '">' + row.disciplineTerm2 + '</td></tr>');
      });
  });
 
  printWindow.document.write('</tbody></table></section>');
 
    // Grading Scale Section
    printWindow.document.write('<section style="' + sectionStyle + '"><table style="' + tableStyle + '"><thead><tr><th style="' + thStyle + '" colSpan="9">8 Point Grading Scale</th></tr></thead><tbody><tr><td style="' + thTdStyle + '"><strong>MARKS</strong></td><td style="' + thTdStyle + '">91-100</td><td style="' + thTdStyle + '">81-90</td><td style="' + thTdStyle + '">71-80</td><td style="' + thTdStyle + '">61-70</td><td style="' + thTdStyle + '">51-60</td><td style="' + thTdStyle + '">41-50</td><td style="' + thTdStyle + '">33-40</td><td style="' + thTdStyle + '">32 & Below</td></tr><tr><td style="' + thTdStyle + '"><strong>GRADE</strong></td><td style="' + thTdStyle + '">A1</td><td style="' + thTdStyle + '">B1</td><td style="' + thTdStyle + '">B2</td><td style="' + thTdStyle + '">C1</td><td style="' + thTdStyle + '">C2</td><td style="' + thTdStyle + '">D</td><td style="' + thTdStyle + '">E</td><td style="' + thTdStyle + '">E</td></tr></tbody></table></section>');
 
    // Marks Indicators Section
    printWindow.document.write('<section style="' + sectionStyle + '"><table style="' + tableStyle + '"><thead><tr><th style="' + thStyle + '" colSpan="7">Marks Indicators</th></tr></thead><tbody><tr><td style="' + thTdStyle + '">P.T</td><td style="' + thTdStyle + '">N.B</td><td style="' + thTdStyle + '">S.E</td><td style="' + thTdStyle + '">H.Y</td><td style="' + thTdStyle + '">T.T</td><td style="' + thTdStyle + '">A.N</td><td style="' + thTdStyle + '">G.D</td></tr><tr><td style="' + thTdStyle + '">Periodic Test</td><td style="' + thTdStyle + '">Note Book</td><td style="' + thTdStyle + '">Subject Enrichment</td><td style="' + thTdStyle + '">Half Yearly</td><td style="' + thTdStyle + '">Total</td><td style="' + thTdStyle + '">Annual</td><td style="' + thTdStyle + '">Grade</td></tr></tbody></table></section>');
 
    // Chart Section
    printWindow.document.write('<section><canvas id="subjectChart" style="width:100%; max-width:600px; margin: 0 auto;"></canvas></section>');
    printWindow.document.write('<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>');
    printWindow.document.write('<script>');
    printWindow.document.write('const ctx = document.getElementById("subjectChart").getContext("2d");');
    printWindow.document.write('new Chart(ctx, { type: "bar", data: ' + JSON.stringify(chartData) + ', options: ' + JSON.stringify(chartOptions) + ' });');
    printWindow.document.write('</script>');
 
    // Signature Section
    printWindow.document.write('<footer><div class="signature-container"><div class="left"><br>Principal Signature:<br></div><div class="right"><br>Class Teacher Signature:<br</div></div></footer>');
 
    printWindow.document.write('</div></body></html>');
    printWindow.document.close();
    printWindow.focus();
    printWindow.print();
};
 
  return (
    <div className="container mt-5">
   
        {/* <div className="p-3 mb-2 d-flex justify-content-between align-items-center" style={{ background: '#34495E', color: '#FFFFFF', borderTopLeftRadius: '10px', borderTopRightRadius: '10px', borderBottomLeftRadius: '10px', borderBottomRightRadius: '10px' }}>
          <h1 style={{ fontSize: '1.5rem' }}> Grade Book </h1>
        </div> */}
     
      {isLoading && <div className="alert alert-info">Loading...</div>}
      {error && <div className="alert alert-danger">{error}</div>}
 
      <div className="row mb-4">
        <div className="col-md-3">
          <label htmlFor="academicYear">Academic Year</label>
          <select
            id="academicYear"
            className="form-control"
            value={selectedAcademicYear}
            onChange={(e) => setSelectedAcademicYear(e.target.value)}
          >
            <option value="All">All</option>
            <option value="2023-2024">2023-2024</option>
            <option value="2022-2023">2022-2023</option>
            {/* Add more academic years as needed */}
          </select>
        </div>
        <div className="col-md-3">
          <label htmlFor="class">Class</label>
          <select
            id="class"
            className="form-control"
            value={selectedClass}
            onChange={(e) => setSelectedClass(e.target.value)}
          >
            <option value="All">All</option>
            {classes.map((cls, index) => (
              <option key={index} value={cls}>{cls}</option>
            ))}
          </select>
        </div>
        <div className="col-md-3">
          <label htmlFor="studentId">Student ID</label>
          <input
            id="studentId"
            className="form-control"
            type="text"
            value={searchStudentId}
            onChange={(e) => setSearchStudentId(e.target.value)}
          />
        </div>
        <div className="col-md-3">
          <label htmlFor="firstName">First Name</label>
          <input
            id="firstName"
            className="form-control"
            type="text"
            value={searchFirstName}
            onChange={(e) => setSearchFirstName(e.target.value)}
          />
        </div>
      </div>
   
      <button className="btn btn-secondary mb-4" onClick={handleReset}>Reset</button>
 
      <table className="table table-bordered">
        <thead>
          <tr>
            <th>Student ID</th>
            <th>Name</th>
            <th>Class</th>
            <th>Academic Year</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {filteredStudentAcademic.map((student, index) => (
            <tr key={index}>
              <td>{student.STUDENT_ID}</td>
              <td>{student.STUDENT_NAME}</td>
              <td>{student.CLASS}</td>
              <td>{student.ACADEMIC_YEAR}</td>
              <td>
                <button
                  className="btn btn-info"
                  onClick={() => printStudentReportCard(student.STUDENT_ID)}
                >
                  Print Report Card
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};
 
export default GradeBook;
 
 