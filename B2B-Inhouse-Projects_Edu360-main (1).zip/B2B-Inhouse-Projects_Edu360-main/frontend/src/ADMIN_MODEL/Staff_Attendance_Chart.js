

// import React, { useEffect, useState } from 'react';
// import axios from 'axios';
// import { AgCharts } from 'ag-charts-react';
// import styled from 'styled-components';
// import 'bootstrap/dist/css/bootstrap.min.css';

// const COLORS = ['#4682B4', '#D35400', '#012353', '#27AE60'];
// const black = '#87CEEB';

// const FilterContainer = styled.div`
//   display: flex;
//   justify-content: center;
//   margin-top: -1.6rem;
//   padding: px 0;
//   background-color: #f8f9fa;
//   border-radius: 8px;
// `;

// const Select = styled.select`
//   width: 100%;
//   max-width: 200px;
//   padding: 5px;
//   border: px solid ${black};
//   border-radius: 12px;
//   font-size: 12px;
//   background-color: #f0f4f8;
//   box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.1);
//   transition: 0.3s ease;

//   &:focus {
//     border-color: #5fa8d3;
//     outline: none;
//   }
// `;

// const ChartContainer = styled.div`
//   display: flex;
//   justify-content: center;
//   align-items: flex-start;
//   width: 100%;
//   margin-top: 0;
//   height: 28vh;
// `;

// const AttendanceChart = () => {
//   const [attendanceData, setAttendanceData] = useState([]);
//   const [filteredData, setFilteredData] = useState([]);
//   const [dates, setDates] = useState([]);
//   const [statuses, setStatuses] = useState([]);
//   const [roles, setRoles] = useState([]);
//   const [sessions, setSessions] = useState([]);
//   const [selectedDate, setSelectedDate] = useState('');
//   const [selectedStatus, setSelectedStatus] = useState('');
//   const [selectedRole, setSelectedRole] = useState('');
//   const [selectedSession, setSelectedSession] = useState('');

//   const formatDate = (date) => {
//     const options = { year: 'numeric', month: '2-digit', day: '2-digit' };
//     return new Date(date).toLocaleDateString(undefined, options);
//   };

//   useEffect(() => {
//     const fetchAttendanceData = async () => {
//       try {
//         const response = await axios.get('http://13.127.57.224:2081/api/staffattendance');
//         const data = response.data.map(record => ({
//           ...record,
//           DATE: formatDate(record.DATE),
//         }));
//         setAttendanceData(data);

//         const uniqueDates = [...new Set(data.map(record => record.DATE))];
//         const uniqueStatuses = [...new Set(data.map(record => record.STATUS))];
//         const uniqueRoles = [...new Set(data.map(record => record.STAFF_ROLE))];
//         const uniqueSessions = [...new Set(data.map(record => record.SESSION))];

//         setDates(uniqueDates);
//         setStatuses(uniqueStatuses);
//         setRoles(uniqueRoles);
//         setSessions(uniqueSessions);
//       } catch (error) {
//         console.error('Error fetching staff attendance data:', error);
//       }
//     };

//     fetchAttendanceData();
//   }, []);

//   useEffect(() => {
//     let filtered = attendanceData;

//     if (selectedDate) {
//       filtered = filtered.filter(record => record.DATE === selectedDate);
//     }
//     if (selectedStatus) {
//       filtered = filtered.filter(record => record.STATUS === selectedStatus);
//     }
//     if (selectedRole) {
//       filtered = filtered.filter(record => record.STAFF_ROLE === selectedRole);
//     }
//     if (selectedSession) {
//       filtered = filtered.filter(record => record.SESSION === selectedSession);
//     }

//     setFilteredData(filtered);
//   }, [selectedDate, selectedStatus, selectedRole, selectedSession, attendanceData]);

//   const processData = (data) => {
//     const totalCount = data.length;
//     const statusCount = data.reduce((acc, record) => {
//       acc[record.STATUS] = (acc[record.STATUS] || 0) + 1;
//       return acc;
//     }, {});

//     return Object.entries(statusCount).map(([key, value]) => ({
//       name: key,
//       value,
//       percentage: Math.round((value / totalCount) * 100) + '%',
//     }));
//   };

//   const chartData = processData(filteredData);

//   const options = {
//     data: chartData,
//     series: [
//       {
//         type: 'pie',
//         legendItemKey: 'name',
//         angleKey: 'value',
//         innerRadiusRatio: 0.7,
//         fills: COLORS,
//         // legendItemKey: {
//         //   fontSize: 0,
//         // },
//         tooltip: {
//           renderer: ({ datum }) => `${datum.name}: ${datum.value} (${datum.percentage})`,
          
//         },
//       },
//     ],
//     legend: {
//       enabled: true,
//       position: 'right',
//       layout: 'horizontal',
//       item: {
//         label: {
//           fontSize: 10,
//           color: '#000', // Change color as needed
//         },
//       },
//     },
//   };

//   return (
//     <div>
//       <FilterContainer>
//         <Select value={selectedDate} onChange={(e) => setSelectedDate(e.target.value)}>
//           <option value="">Date</option>
//           {dates.map((date, index) => (
//             <option key={index} value={date}>{date}</option>
//           ))}
//         </Select>
//         <Select value={selectedStatus} onChange={(e) => setSelectedStatus(e.target.value)}>
//           <option value="">Status</option>
//           {statuses.map((status, index) => (
//             <option key={index} value={status}>{status}</option>
//           ))}
//         </Select>
//         <Select value={selectedRole} onChange={(e) => setSelectedRole(e.target.value)}>
//           <option value="">Role</option>
//           {roles.map((role, index) => (
//             <option key={index} value={role}>{role}</option>
//           ))}
//         </Select>
//         <Select value={selectedSession} onChange={(e) => setSelectedSession(e.target.value)}>
//           <option value="">Session</option>
//           {sessions.map((session, index) => (
//             <option key={index} value={session}>{session}</option>
//           ))}
//         </Select>
//       </FilterContainer>
//       <ChartContainer>
//         <AgCharts options={options} style={{ width: '100%', height: '23vh',marginTop: '1vh'  }} />
//       </ChartContainer>
//     </div>
//   );
// };

// export default AttendanceChart;




// import React, { useEffect, useState } from 'react';
// import axios from 'axios';
// import { AgCharts } from 'ag-charts-react';
// import styled from 'styled-components';
// import 'bootstrap/dist/css/bootstrap.min.css';

// // Styled Components
// const FilterContainer = styled.div`
//   display: flex;
//   justify-content: center;
//   margin-top: -1.6rem;
//   padding: 0;
//   background-color: #f8f9fa;
//   border-radius: 8px;
// `;

// const Select = styled.select`
//   width: 90%;
//   max-width: 200px;
//   padding: 5px;
//   border: 1px solid black;
//   border-radius: 5px;
//   font-size: 12px;
//   background-color: #f0f4f8;
//   box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.1);
//   transition: 0.3s ease;

//   &:focus {
//     border-color: #5fa8d3;
//     outline: none;
//   }
// `;

// const ChartContainer = styled.div`
//   display: flex;
//   justify-content: center;
//   align-items: flex-start;
//   width: 100%;
//   margin-top: 0;
//   height: 28vh;
// `;

// const AttendanceChart = () => {
//   const [attendanceData, setAttendanceData] = useState([]);
//   const [filteredData, setFilteredData] = useState([]);
//   const [dates, setDates] = useState([]);
//   const [statuses, setStatuses] = useState([]);
//   const [roles, setRoles] = useState([]);
//   const [sessions, setSessions] = useState([]);
//   const [selectedDate, setSelectedDate] = useState('');
//   const [selectedStatus, setSelectedStatus] = useState('');
//   const [selectedRole, setSelectedRole] = useState('');
//   const [selectedSession, setSelectedSession] = useState('');

//   // Helper function to count occurrences
//   const getCountByCategory = (data, category) => {
//     return data.reduce((acc, record) => {
//       acc[record[category]] = (acc[record[category]] || 0) + 1;
//       return acc;
//     }, {});
//   };

//   useEffect(() => {
//     const fetchAttendanceData = async () => {
//       try {
//         const response = await axios.get('http://13.127.57.224:2081/api/staffattendance');
//         const data = response.data.map(record => ({
//           ...record,
//           DATE: new Date(record.DATE).toLocaleDateString(),
//         }));
//         setAttendanceData(data);

//         const uniqueDates = getCountByCategory(data, 'DATE');
//         const uniqueStatuses = getCountByCategory(data, 'STATUS');
//         const uniqueRoles = getCountByCategory(data, 'STAFF_ROLE');
//         const uniqueSessions = getCountByCategory(data, 'SESSION');

//         setDates(uniqueDates);
//         setStatuses(uniqueStatuses);
//         setRoles(uniqueRoles);
//         setSessions(uniqueSessions);
//       } catch (error) {
//         console.error('Error fetching staff attendance data:', error);
//       }
//     };

//     fetchAttendanceData();
//   }, []);

//   useEffect(() => {
//     let filtered = attendanceData;

//     if (selectedDate) filtered = filtered.filter(record => record.DATE === selectedDate);
//     if (selectedStatus) filtered = filtered.filter(record => record.STATUS === selectedStatus);
//     if (selectedRole) filtered = filtered.filter(record => record.STAFF_ROLE === selectedRole);
//     if (selectedSession) filtered = filtered.filter(record => record.SESSION === selectedSession);

//     setFilteredData(filtered);
//   }, [selectedDate, selectedStatus, selectedRole, selectedSession, attendanceData]);

//   const processData = (data) => {
//     const totalCount = data.length;
//     const statusCount = data.reduce((acc, record) => {
//       acc[record.STATUS] = (acc[record.STATUS] || 0) + 1;
//       return acc;
//     }, {});

//     return Object.entries(statusCount).map(([key, value]) => ({
//       name: key,
//       value,
//       percentage: Math.round((value / totalCount) * 100) + '%',
//     }));
//   };

//   const chartData = processData(filteredData);

//   const options = {
//     data: chartData,
//     series: [
//       {
//         type: 'pie',
//         legendItemKey: 'name',
//         angleKey: 'value',
//         innerRadiusRatio: 0.7,
//         fills: ['#27AE60', '#012353', '#012353', '#27AE60'],
//         tooltip: {
//           renderer: ({ datum }) => `${datum.name}: ${datum.value} (${datum.percentage})`,
//         },
//       },
//     ],
//     legend: {
//       enabled: true,
//       position: 'right',
//       item: {
//         label: {
//           fontSize: 10,
//           color: '#000',
//           formatter: ({ value }) => {
//             const dataItem = chartData.find(item => item.name === value);
//             return `${value} (${dataItem.value})`; // Display name with count
//           },
//         },
//       },
//     },
//   };
  
//   return (
//     <div>
//       <FilterContainer>
//         <Select value={selectedDate} onChange={(e) => setSelectedDate(e.target.value)}>
//           <option value="">Date</option>
//           {Object.entries(dates).map(([date, count], index) => (
//             <option key={index} value={date}>{`${date} (${count})`}</option>
//           ))}
//         </Select>
//         <Select value={selectedStatus} onChange={(e) => setSelectedStatus(e.target.value)}>
//           <option value="">Status</option>
//           {Object.entries(statuses).map(([status, count], index) => (
//             <option key={index} value={status}>{`${status} (${count})`}</option>
//           ))}
//         </Select>
//         <Select value={selectedRole} onChange={(e) => setSelectedRole(e.target.value)}>
//           <option value="">Role</option>
//           {Object.entries(roles).map(([role, count], index) => (
//             <option key={index} value={role}>{`${role} (${count})`}</option>
//           ))}
//         </Select>
//         <Select value={selectedSession} onChange={(e) => setSelectedSession(e.target.value)}>
//           <option value="">Session</option>
//           {Object.entries(sessions).map(([session, count], index) => (
//             <option key={index} value={session}>{`${session} (${count})`}</option>
//           ))}
//         </Select>
//       </FilterContainer>
//       <ChartContainer>
//         <AgCharts options={options} style={{ width: '100%', height: '22vh', marginTop: '1vh' }} />
//       </ChartContainer>
//     </div>
//   );
// };

// export default AttendanceChart;




// import React, { useEffect, useState } from 'react';
// import axios from 'axios';
// import { AgCharts } from 'ag-charts-react';
// import styled from 'styled-components';
// import 'bootstrap/dist/css/bootstrap.min.css';

// // Styled Components
// const FilterContainer = styled.div`
//   display: flex;
//   justify-content: center;
//   margin-top: -1.6rem;
//   padding: 0;
//   background-color: #f8f9fa;
//   border-radius: 8px;
// `;

// const Select = styled.select`
//   width: 90%;
//   max-width: 200px;
//   padding: 5px;
//   border: 1px solid black;
//   border-radius: 5px;
//   font-size: 12px;
//   background-color: #f0f4f8;
//   box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.1);
//   transition: 0.3s ease;
//   margin: 0 5px; // Add margin for spacing

//   &:focus {
//     border-color: #5fa8d3;
//     outline: none;
//   }
// `;

// const ChartContainer = styled.div`
//   display: flex;
//   justify-content: center;
//   align-items: flex-start;
//   width: 100%;
//   margin-top: 0;
//   height: 28vh;
// `;

// const AttendanceChart = () => {
//   const [attendanceData, setAttendanceData] = useState([]);
//   const [filteredData, setFilteredData] = useState([]);
//   const [dates, setDates] = useState([]);
//   const [statuses, setStatuses] = useState([]);
//   const [roles, setRoles] = useState([]);
//   const [sessions, setSessions] = useState([]);
//   const [selectedDate, setSelectedDate] = useState('');
//   const [selectedStatus, setSelectedStatus] = useState('');
//   const [selectedRole, setSelectedRole] = useState('');
//   const [selectedSession, setSelectedSession] = useState('');

//   // Helper function to count occurrences
//   const getCountByCategory = (data, category) => {
//     return data.reduce((acc, record) => {
//       acc[record[category]] = (acc[record[category]] || 0) + 1;
//       return acc;
//     }, {});
//   };

//   useEffect(() => {
//     const fetchAttendanceData = async () => {
//       try {
//         const response = await axios.get('http://13.127.57.224:2081/api/staffattendance');
//         const data = response.data.map(record => ({
//           ...record,
//           DATE: new Date(record.DATE).toLocaleDateString(),
//         }));
//         setAttendanceData(data);

//         const uniqueDates = getCountByCategory(data, 'DATE');
//         const uniqueStatuses = getCountByCategory(data, 'STATUS');
//         const uniqueRoles = getCountByCategory(data, 'STAFF_ROLE');
//         const uniqueSessions = getCountByCategory(data, 'SESSION');

//         setDates(uniqueDates);
//         setStatuses(uniqueStatuses);
//         setRoles(uniqueRoles);
//         setSessions(uniqueSessions);
//       } catch (error) {
//         console.error('Error fetching staff attendance data:', error);
//       }
//     };

//     fetchAttendanceData();
//   }, []);

//   useEffect(() => {
//     let filtered = attendanceData;

//     if (selectedDate) filtered = filtered.filter(record => record.DATE === selectedDate);
//     if (selectedStatus) filtered = filtered.filter(record => record.STATUS === selectedStatus);
//     if (selectedRole) filtered = filtered.filter(record => record.STAFF_ROLE === selectedRole);
//     if (selectedSession) filtered = filtered.filter(record => record.SESSION === selectedSession);

//     setFilteredData(filtered);
//   }, [selectedDate, selectedStatus, selectedRole, selectedSession, attendanceData]);

//   const processData = (data) => {
//     const totalCount = data.length;
//     const statusCount = data.reduce((acc, record) => {
//       acc[record.STATUS] = (acc[record.STATUS] || 0) + 1;
//       return acc;
//     }, {});

//     return Object.entries(statusCount).map(([key, value]) => ({
//       name: key,
//       value,
//       percentage: Math.round((value / totalCount) * 100) + '%',
//     }));
//   };

//   const chartData = processData(filteredData);

//   const options = {
//     data: chartData,
//     series: [
//       {
//         type: 'donut',
//         calloutLabelKey: 'name',
//         angleKey: 'value',
//         innerRadiusRatio: 0.7,
//         fills: ['#27AE60', '#012353', '#012353', '#27AE60'],
//         tooltip: {
//           renderer: ({ datum }) => `${datum.name}: ${datum.value} (${datum.percentage})`,
//         },
//       },
//     ],
//     legend: {
//       enabled: false,
//       position: 'right',
//       item: {
//         label: {
//           fontSize: 10,
//           color: '#000',
//           formatter: ({ value }) => {
//             const dataItem = chartData.find(item => item.name === value);
//             return `${value} (${dataItem.value})`; // Display name with count
//           },
//         },
//       },
//     },
//   };

//   return (
//     <div>
//       <FilterContainer>
//         <Select value={selectedDate} onChange={(e) => setSelectedDate(e.target.value)}>
//           <option value="">Date</option>
//           {Object.entries(dates).map(([date, count], index) => (
//             <option key={index} value={date}>{`${date} (${count})`}</option>
//           ))}
//         </Select>
//         <Select value={selectedStatus} onChange={(e) => setSelectedStatus(e.target.value)}>
//           <option value="">Status</option>
//           {Object.entries(statuses).map(([status, count], index) => (
//             <option key={index} value={status}>{`${status} (${count})`}</option>
//           ))}
//         </Select>
//         <Select value={selectedRole} onChange={(e) => setSelectedRole(e.target.value)}>
//           <option value="">Role</option>
//           {Object.entries(roles).map(([role, count], index) => (
//             <option key={index} value={role}>{`${role} (${count})`}</option>
//           ))}
//         </Select>
//         <Select value={selectedSession} onChange={(e) => setSelectedSession(e.target.value)}>
//           <option value="">Session</option>
//           {Object.entries(sessions).map(([session, count], index) => (
//             <option key={index} value={session}>{`${session} (${count})`}</option>
//           ))}
//         </Select>
//       </FilterContainer>
//       <ChartContainer>
//         <AgCharts options={options} style={{ width: '100%', height: '22vh', marginTop: '1vh' }} />
//       </ChartContainer>
//     </div>
//   );
// };

// export default AttendanceChart;





// import React, { useEffect, useState, useRef } from 'react';
// import axios from 'axios';
// import { AgCharts } from 'ag-charts-react';
// import styled from 'styled-components';
// import 'bootstrap/dist/css/bootstrap.min.css';
// import { FaEllipsisV } from 'react-icons/fa'; // Import the three-dot icon

// // Styled Components
// const FilterChartContainer = styled.div`
//   display: flex;
//   flex-direction: column;
//   align-items: center;
//   margin: 1rem;
// `;

// const CombinedContainer = styled.div`
//   display: flex;
//   flex-direction: column;
//   align-items: center;
// `;

// const ChartContainer = styled.div`
//   display: flex; 
//   justify-content: flex-end; /* Align items to the right */
//   align-items: flex-start; /* Align items at the top */
//   width: 100%;
//   margin-bottom: 0.5rem;
//   height: 40vh;
//   position: relative; /* Allow for absolute positioning of the dropdown */
// `;

// const ChartWrapper = styled.div`
//   flex: 1; /* Allow the chart to take available space */
//   margin-right: 1rem; /* Add space between the chart and the icon */
// `;

// const DropdownContainer = styled.div`
//   position: absolute;
//   right: -1rem; /* Position the dropdown to the right */
//   background-color: white;
//   border: 1px solid #ccc;
//   box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.2);
//   padding: 5px;
//   z-index: 10;
//   flex-direction: column; /* Stack dropdown items vertically */
// `;

// const MenuIcon = styled(FaEllipsisV)`
//   cursor: pointer;
//   font-size: 24px;
//   z-index: 10; /* Ensure the icon is above other elements */
//   margin-top: -39px; /* Adjust this value to move it higher */
//   margin-left: auto; /* Pushes the icon to the far right */
//   margin-right: -1rem; /* Adjust this value to position it further right */
// `;


// const DropdownItem = styled.div`
//   margin: 3px 0;
// `;

// const Select = styled.select`
//   width: 90%;
//   max-width: 200px;
//   padding: 3px;
//   border: 1px solid black;
//   border-radius: 5px;
//   font-size: 10px;
//   background-color: #f0f4f8;
//   box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.1);
//   transition: 0.3s ease;

//   &:focus {
//     border-color: #5fa8d3;
//     outline: none;
//   }
// `;

// const AttendanceChart = () => {
//   const [attendanceData, setAttendanceData] = useState([]);
//   const [filteredData, setFilteredData] = useState([]);
//   const [dates, setDates] = useState([]);
//   const [statuses, setStatuses] = useState([]);
//   const [roles, setRoles] = useState([]);
//   const [sessions, setSessions] = useState([]);
//   const [selectedDate, setSelectedDate] = useState('');
//   const [selectedStatus, setSelectedStatus] = useState('');
//   const [selectedRole, setSelectedRole] = useState('');
//   const [selectedSession, setSelectedSession] = useState('');
//   const [dropdownVisible, setDropdownVisible] = useState(false);
//   const dropdownRef = useRef(null);

//   // Helper function to count occurrences
//   const getCountByCategory = (data, category) => {
//     return data.reduce((acc, record) => {
//       acc[record[category]] = (acc[record[category]] || 0) + 1;
//       return acc;
//     }, {});
//   };

//   useEffect(() => {
//     const fetchAttendanceData = async () => {
//       try {
//         const response = await axios.get('http://13.127.57.224:2081/api/staffattendance');
//         const data = response.data.map(record => ({
//           ...record,
//           DATE: new Date(record.DATE).toLocaleDateString(),
//         }));
//         setAttendanceData(data);

//         const uniqueDates = getCountByCategory(data, 'DATE');
//         const uniqueStatuses = getCountByCategory(data, 'STATUS');
//         const uniqueRoles = getCountByCategory(data, 'STAFF_ROLE');
//         const uniqueSessions = getCountByCategory(data, 'SESSION');

//         setDates(uniqueDates);
//         setStatuses(uniqueStatuses);
//         setRoles(uniqueRoles);
//         setSessions(uniqueSessions);
//       } catch (error) {
//         console.error('Error fetching staff attendance data:', error);
//       }
//     };

//     fetchAttendanceData();
//   }, []);

//   useEffect(() => {
//     let filtered = attendanceData;

//     if (selectedDate) filtered = filtered.filter(record => record.DATE === selectedDate);
//     if (selectedStatus) filtered = filtered.filter(record => record.STATUS === selectedStatus);
//     if (selectedRole) filtered = filtered.filter(record => record.STAFF_ROLE === selectedRole);
//     if (selectedSession) filtered = filtered.filter(record => record.SESSION === selectedSession);

//     setFilteredData(filtered);
//   }, [selectedDate, selectedStatus, selectedRole, selectedSession, attendanceData]);

//   const processData = (data) => {
//     const totalCount = data.length;
//     const statusCount = data.reduce((acc, record) => {
//       acc[record.STATUS] = (acc[record.STATUS] || 0) + 1;
//       return acc;
//     }, {});
  
//     return Object.entries(statusCount).map(([key, value]) => ({
//       name: key,
//       value,
//       percentage: Math.round((value / totalCount) * 100) + '%',
//       displayLabel: `${key} (${value})` // New field for legend and callout labels
//     }));
//   };
  
//   // Update chartData to include displayLabel
//   const chartData = processData(filteredData);
  
//   const options = {
//     data: chartData,
//     series: [
//       {
//         type: 'donut',
//         calloutLabelKey: 'displayLabel', // Use the new field for callout labels
//         angleKey: 'value',
//         innerRadiusRatio: 0.7,
//         fills: ['#27AE60', '#012353', '#012353', '#27AE60'],
//         tooltip: {
//           renderer: ({ datum }) => `${datum.displayLabel} (${datum.percentage})`, // Update tooltip to use displayLabel
//         },
//       },
//     ],
//     legend: {
//       enabled: true,
//       position: 'right',
//       spacing: 0, // Add spacing between the legend items and the right edge
//       item: {
//         label: {
//           fontSize: 10,
//           color: '#333',
//           formatter: ({ value }) => {
//             const dataItem = chartData.find(item => item.name === value);
//             return dataItem ? `${dataItem.displayLabel} (${dataItem.value})` : value;
//           },
//         },
//         marker: {
//           shape: 'square',
//           size: 6,
//         },
//         paddingX: 1 , // Increase horizontal padding to move items further right
//         paddingY: 5,  
//       },
    
    
    
//     },
//   };
  
//   // Close the dropdown when clicking outside of it
//   useEffect(() => {
//     const handleClickOutside = (event) => {
//       if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
//         setDropdownVisible(false);
//       }
//     };

//     document.addEventListener('mousedown', handleClickOutside);
//     return () => {
//       document.removeEventListener('mousedown', handleClickOutside);
//     };
//   }, [dropdownRef]);

//   return (
//     <FilterChartContainer>
//       <CombinedContainer>
//         <ChartContainer>
//           <ChartWrapper>
//             <AgCharts options={options} style={{ width: '100%', height: '28vh', marginTop: '-6vh' }} />
//           </ChartWrapper>
//           <MenuIcon onClick={() => setDropdownVisible(!dropdownVisible)} />
//           {dropdownVisible && (
//             <DropdownContainer ref={dropdownRef}>
//               <DropdownItem>
//                 <Select value={selectedDate} onChange={(e) => setSelectedDate(e.target.value)}>
//                   <option value="">Date</option>
//                   {Object.entries(dates).map(([date, count], index) => (
//                     <option key={index} value={date}>{`${date} (${count})`}</option>
//                   ))}
//                 </Select>
//               </DropdownItem>
//               <DropdownItem>
//                 <Select value={selectedStatus} onChange={(e) => setSelectedStatus(e.target.value)}>
//                   <option value="">Status</option>
//                   {Object.entries(statuses).map(([status, count], index) => (
//                     <option key={index} value={status}>{`${status} (${count})`}</option>
//                   ))}
//                 </Select>
//               </DropdownItem>
//               <DropdownItem>
//                 <Select value={selectedRole} onChange={(e) => setSelectedRole(e.target.value)}>
//                   <option value="">Role</option>
//                   {Object.entries(roles).map(([role, count], index) => (
//                     <option key={index} value={role}>{`${role} (${count})`}</option>
//                   ))}
//                 </Select>
//               </DropdownItem>
//               <DropdownItem>
//                 <Select value={selectedSession} onChange={(e) => setSelectedSession(e.target.value)}>
//                   <option value="">Session</option>
//                   {Object.entries(sessions).map(([session, count], index) => (
//                     <option key={index} value={session}>{`${session} (${count})`}</option>
//                   ))}
//                 </Select>
//               </DropdownItem>
//             </DropdownContainer>
//           )}
//         </ChartContainer>
//       </CombinedContainer>
//     </FilterChartContainer>
//   );
// };

// export default AttendanceChart;










 
import React, { useEffect, useState, useRef } from 'react';
import axios from 'axios';
import { AgCharts } from 'ag-charts-react';
import { FaEllipsisV } from 'react-icons/fa'; // Import the three-dot icon
import 'bootstrap/dist/css/bootstrap.min.css';
import './Admin_Model.css';
 
const AttendanceChart = () => {
  const [attendanceData, setAttendanceData] = useState([]);
  const [filteredData, setFilteredData] = useState([]);
  const [dates, setDates] = useState([]);
  const [statuses, setStatuses] = useState([]);
  const [roles, setRoles] = useState([]);
  const [sessions, setSessions] = useState([]);
  const [selectedDate, setSelectedDate] = useState('');
  const [selectedStatus, setSelectedStatus] = useState('');
  const [selectedRole, setSelectedRole] = useState('');
  const [selectedSession, setSelectedSession] = useState('');
  const [dropdownVisible, setDropdownVisible] = useState(false);
  const dropdownRef = useRef(null);
 
  // Helper function to count occurrences
  const getCountByCategory = (data, category) => {
    return data.reduce((acc, record) => {
      acc[record[category]] = (acc[record[category]] || 0) + 1;
      return acc;
    }, {});
  };
 
  useEffect(() => {
    const fetchAttendanceData = async () => {
      try {
        const response = await axios.get('http://13.127.57.224:2081/api/staffattendance');
        const data = response.data.map(record => ({
          ...record,
          DATE: new Date(record.DATE).toLocaleDateString(),
        }));
        setAttendanceData(data);
 
        const uniqueDates = getCountByCategory(data, 'DATE');
        const uniqueStatuses = getCountByCategory(data, 'STATUS');
        const uniqueRoles = getCountByCategory(data, 'STAFF_ROLE');
        const uniqueSessions = getCountByCategory(data, 'SESSION');
 
        setDates(uniqueDates);
        setStatuses(uniqueStatuses);
        setRoles(uniqueRoles);
        setSessions(uniqueSessions);
      } catch (error) {
        console.error('Error fetching staff attendance data:', error);
      }
    };
 
    fetchAttendanceData();
  }, []);
 
  useEffect(() => {
    let filtered = attendanceData;
 
    if (selectedDate) filtered = filtered.filter(record => record.DATE === selectedDate);
    if (selectedStatus) filtered = filtered.filter(record => record.STATUS === selectedStatus);
    if (selectedRole) filtered = filtered.filter(record => record.STAFF_ROLE === selectedRole);
    if (selectedSession) filtered = filtered.filter(record => record.SESSION === selectedSession);
 
    setFilteredData(filtered);
  }, [selectedDate, selectedStatus, selectedRole, selectedSession, attendanceData]);
 
  const processData = (data) => {
    const totalCount = data.length;
    const statusCount = data.reduce((acc, record) => {
      acc[record.STATUS] = (acc[record.STATUS] || 0) + 1;
      return acc;
    }, {});
 
    return Object.entries(statusCount).map(([key, value]) => ({
      name: key,
      value,
      percentage: Math.round((value / totalCount) * 100) + '%',
      displayLabel: `${key} (${value})` // New field for legend and callout labels
    }));
  };
 
  const chartData = processData(filteredData);
 
  const options = {
    data: chartData,
    series: [
      {
        type: 'donut',
        calloutLabelKey: 'displayLabel',
        angleKey: 'value',
        innerRadiusRatio: 0.7,
        fills: ['#27AE60', '#012353', '#012353', '#27AE60'],
        tooltip: {
          renderer: ({ datum }) => `${datum.displayLabel} (${datum.percentage})`,
        },
      },
    ],
    legend: {
      enabled: true,
      position: 'right',
      item: {
        label: {
          fontSize: 10,
          color: '#333',
          formatter: ({ value }) => {
            const dataItem = chartData.find(item => item.name === value);
            return dataItem ? `${dataItem.displayLabel} (${dataItem.value})` : value;
          },
        },
        marker: {
          shape: 'square',
          size: 6,
        },
        paddingX: 1 , // Increase horizontal padding to move items further right
        paddingY: 5,  
      },
    },
  };
 
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setDropdownVisible(false);
      }
    };
 
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [dropdownRef]);
 
  return (
    <div className="Staff_Chart_filter-chart-container">
      <div className="Staff_Chart_combined-container">
        <div className="Staff_Chart_chart-container">
          <div className="Staff_Chart_chart-wrapper">
            <AgCharts options={options} style={{ width: '100%', height: '28vh', marginTop: '-7vh' }} />
          </div>
          <FaEllipsisV className="Staff_Chart_menu-icon" onClick={() => setDropdownVisible(!dropdownVisible)} />
          {dropdownVisible && (
            <div className="Staff_Chart_dropdown-container" ref={dropdownRef}>
              <div className="Staff_Chart_dropdown-item">
                <select className="Staff_Chart_select-input" value={selectedDate} onChange={(e) => setSelectedDate(e.target.value)}>
                  <option value="">Date</option>
                  {Object.entries(dates).map(([date, count], index) => (
                    <option key={index} value={date}>{`${date} (${count})`}</option>
                  ))}
                </select>
              </div>
              <div className="Staff_Chart_dropdown-item">
                <select className="Staff_Chart_select-input" value={selectedStatus} onChange={(e) => setSelectedStatus(e.target.value)}>
                  <option value="">Status</option>
                  {Object.entries(statuses).map(([status, count], index) => (
                    <option key={index} value={status}>{`${status} (${count})`}</option>
                  ))}
                </select>
              </div>
              <div className="Staff_Chart_dropdown-item">
                <select className="Staff_Chart_select-input" value={selectedRole} onChange={(e) => setSelectedRole(e.target.value)}>
                  <option value="">Role</option>
                  {Object.entries(roles).map(([role, count], index) => (
                    <option key={index} value={role}>{`${role} (${count})`}</option>
                  ))}
                </select>
              </div>
              <div className="Staff_Chart_dropdown-item">
                <select className="Staff_Chart_select-input" value={selectedSession} onChange={(e) => setSelectedSession(e.target.value)}>
                  <option value="">Session</option>
                  {Object.entries(sessions).map(([session, count], index) => (
                    <option key={index} value={session}>{`${session} (${count})`}</option>
                  ))}
                </select>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
 
export default AttendanceChart;
 
