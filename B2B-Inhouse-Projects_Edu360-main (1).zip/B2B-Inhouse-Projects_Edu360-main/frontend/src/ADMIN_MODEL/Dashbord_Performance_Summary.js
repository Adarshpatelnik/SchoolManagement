
// import React, { useState, useEffect } from 'react';
// import { AgCharts } from 'ag-charts-react'; // Import AG Charts
// import axios from 'axios';
// import '@fortawesome/fontawesome-free/css/all.min.css'; // Import Font Awesome CSS
 
// const DashboardPerformanceSummary = () => {
//   const [selectedClass, setSelectedClass] = useState('');
//   const [selectedTerm, setSelectedTerm] = useState('');
//   const [selectedPerformance, setSelectedPerformance] = useState('');
//   const [selectedAcademicYear, setSelectedAcademicYear] = useState('');
//   const [classes, setClasses] = useState([]);
//   const [terms, setTerms] = useState([]);
//   const [performances, setPerformances] = useState([]);
//   const [academicYears, setAcademicYears] = useState([]);
//   const [chartData, setChartData] = useState([]);
//   const [loading, setLoading] = useState(false);
//   const [error, setError] = useState('');
//   const [dropdownOpen, setDropdownOpen] = useState(false);
 
//   const fetchData = async () => {
//     setLoading(true);
//     setError('');
//     try {
//       const response = await axios.get('http://13.127.57.224:2081/api/PerformanceSummary', {
//         params: {
//           CLASS: selectedClass,
//           ACADEMIC_YEAR: selectedAcademicYear,
//           TERM: selectedTerm,
//           PERFORMANCE: selectedPerformance,
//         },
//       });
 
//       const data = response.data;
 
//       // Extract unique values for filters
//       const uniqueClasses = [...new Set(data.map(item => item.CLASS))];
//       const uniqueAcademicYears = [...new Set(data.map(item => item.ACADEMIC_YEAR))];
//       const uniqueTerms = [...new Set(data.map(item => item.TERM))];
//       const uniquePerformances = [...new Set(data.map(item => item.PERFORMANCE))];
 
//       // Prepare chart data
//       const chartDataValues = uniquePerformances.map(performance => {
//         const item = data.find(d => d.PERFORMANCE === performance);
//         return {
//           performance,
//           percent: item ? parseFloat(item.PERCENT) : 0, // Convert percent to a float
//         }; // Create an object for AG Charts
//       });
 
//       console.log("Chart Data: ", chartDataValues); // Log chart data for debugging
 
//       setClasses(uniqueClasses);
//       setAcademicYears(uniqueAcademicYears);
//       setTerms(uniqueTerms);
//       setPerformances(uniquePerformances);
//       setChartData(chartDataValues); // Set the chart data
//     } catch (error) {
//       setError('Error fetching data. Please try again later.');
//       console.error('Error fetching data:', error);
//     } finally {
//       setLoading(false);
//     }
//   };
 
//   useEffect(() => {
//     fetchData();
//   }, [selectedClass, selectedTerm, selectedPerformance, selectedAcademicYear]);
 
//   const handleClassChange = (event) => {
//     setSelectedClass(event.target.value);
//   };
 
//   const handleTermChange = (event) => {
//     setSelectedTerm(event.target.value);
//   };
 
//   const handlePerformanceChange = (event) => {
//     setSelectedPerformance(event.target.value);
//   };
 
//   const handleAcademicYearChange = (event) => {
//     setSelectedAcademicYear(event.target.value);
//   };
 
//   const toggleDropdown = () => {
//     setDropdownOpen(!dropdownOpen);
//   };
 
//   const options = {
//     data: chartData,
//     series: [
//       {
//         type: 'bar',
//         xKey: 'performance',
//         yKey: 'percent',
//         label: {
//           enabled: true,
//           formatter: (params) => `${params.value}%`, // Format label
//         },
//       },
//     ],
//     axes: [
//       {
//         type: 'category',
//         position: 'bottom',
//         title: {
//           text: 'Performance',
//         },
//       },
//       {
//         type: 'number',
//         position: 'left',
//         title: {
//           text: 'Percentage',
//         },
//         min: 0,
//       },
//     ],
//   };
 
//   return (
//     <div className="card card-success" style={{ fontFamily: 'Arial, sans-serif', width: '100%', height: '180%' }}>
//       <div className="card-body">
//         {loading && <p>Loading...</p>}
//         {error && <p style={{ color: 'red' }}>{error}</p>}
//         <div style={{ marginBottom: '20px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
//           <div style={{ marginRight: '20px' }}>
//             <label htmlFor="classFilter" style={{ fontWeight: 'bold' }}></label>
//             <select
//               id="classFilter"
//               onChange={handleClassChange}
//               value={selectedClass}
//               style={{ marginLeft: '10px', borderColor: 'lightSkyBlue', padding: '5px', borderRadius: '5px' }}
//             >
//               <option value="">Class</option>
//               {classes.map((classItem) => (
//                 <option key={classItem} value={classItem}>
//                   {classItem}
//                 </option>
//               ))}
//             </select>
//           </div>
 
//           <div style={{ marginRight: '20px' }}>
//             <label htmlFor="termFilter" style={{ fontWeight: 'bold' }}></label>
//             <select
//               id="termFilter"
//               onChange={handleTermChange}
//               value={selectedTerm}
//               style={{ marginLeft: '10px', borderColor: 'lightSkyBlue', padding: '5px', borderRadius: '5px' }}
//             >
//               <option value="">Term</option>
//               {terms.map((term) => (
//                 <option key={term} value={term}>
//                   {term}
//                 </option>
//               ))}
//             </select>
//           </div>
 
//           <div style={{ marginRight: '20px' }}>
//             <label htmlFor="academicYearFilter" style={{ fontWeight: 'bold' }}></label>
//             <select
//               id="academicYearFilter"
//               onChange={handleAcademicYearChange}
//               value={selectedAcademicYear}
//               style={{ marginLeft: '10px', borderColor: 'lightSkyBlue', padding: '5px', borderRadius: '5px' }}
//             >
//               <option value="">Year</option>
//               {academicYears.map((year) => (
//                 <option key={year} value={year}>
//                   {year}
//                 </option>
//               ))}
//             </select>
//           </div>
 
//           <div style={{ marginRight: '20px'  }}>
            
//                 <label htmlFor="performanceFilter" style={{ fontWeight: 'bold' }}></label>
//                 <select
//                   id="performanceFilter"
//                   onChange={handlePerformanceChange}
//                   value={selectedPerformance}
//                   style={{ marginLeft: '10px', borderColor: 'lightSkyBlue', padding: '5px', borderRadius: '5px' }}
//                 >
//                   <option value="">Performance</option>
//                   {performances.map((performance) => (
//                     <option key={performance} value={performance}>
//                       {performance}
//                     </option>
//                   ))}
//                 </select>
//               </div>
      
//           </div>
//         </div>
 
//         <div style={{ height: '79%', width: '100%' }}>
//           <AgCharts options={options} /> {/* Use AG Charts for rendering the chart */}
//         </div>
//       </div>
//     </div>
//   );
// };
 
// export default DashboardPerformanceSummary;





// import React, { useState, useEffect } from 'react';
// import { AgCharts } from 'ag-charts-react';
// import axios from 'axios';
// import styled from 'styled-components';
// import '@fortawesome/fontawesome-free/css/all.min.css';

// // Styled Components for Filter
// const FilterContainer = styled.div`
//   display: flex;
//   justify-content: center;
//   margin-top: -20rem;
//   padding: 0;
//   background-color: #f8f9fa;
//   border-radius: 8px;
// `;

// const Select = styled.select`
//   width: 100%;
//   max-width: 200px;
//   padding: 5px;
//   border: 1px solid black;
//   border-radius: 5px;
//   font-size: 12px;
//   background-color: #f0f4f8;
//   box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.1);
//   transition: 0.3s ease;

//   &:focus {
//     border-color: #5fa8d3;
//     outline: none;
//   }
// `;

// const DashboardPerformanceSummary = () => {
//   const [selectedClass, setSelectedClass] = useState('');
//   const [selectedTerm, setSelectedTerm] = useState('');
//   const [selectedPerformance, setSelectedPerformance] = useState('');
//   const [selectedAcademicYear, setSelectedAcademicYear] = useState('');
//   const [classes, setClasses] = useState([]);
//   const [terms, setTerms] = useState([]);
//   const [performances, setPerformances] = useState([]);
//   const [academicYears, setAcademicYears] = useState([]);
//   const [chartData, setChartData] = useState([]);
//   const [loading, setLoading] = useState(false);
//   const [error, setError] = useState('');

//   const fetchData = async () => {
//     setLoading(true);
//     setError('');
//     try {
//       const response = await axios.get('http://13.127.57.224:2081/api/PerformanceSummary', {
//         params: {
//           CLASS: selectedClass,
//           ACADEMIC_YEAR: selectedAcademicYear,
//           TERM: selectedTerm,
//           PERFORMANCE: selectedPerformance,
//         },
//       });

//       const data = response.data;

//       const uniqueClasses = [...new Set(data.map(item => item.CLASS))];
//       const uniqueAcademicYears = [...new Set(data.map(item => item.ACADEMIC_YEAR))];
//       const uniqueTerms = [...new Set(data.map(item => item.TERM))];
//       const uniquePerformances = [...new Set(data.map(item => item.PERFORMANCE))];

//       const chartDataValues = uniquePerformances.map(performance => {
//         const item = data.find(d => d.PERFORMANCE === performance);
//         return {
//           performance,
//           percent: item ? parseFloat(item.PERCENT) : 0,
//         };
//       });

//       setClasses(uniqueClasses);
//       setAcademicYears(uniqueAcademicYears);
//       setTerms(uniqueTerms);
//       setPerformances(uniquePerformances);
//       setChartData(chartDataValues);
//     } catch (error) {
//       setError('Error fetching data. Please try again later.');
//       console.error('Error fetching data:', error);
//     } finally {
//       setLoading(false);
//     }
//   };

//   useEffect(() => {
//     fetchData();
//   }, [selectedClass, selectedTerm, selectedPerformance, selectedAcademicYear]);

//   const handleClassChange = (event) => {
//     setSelectedClass(event.target.value);
//   };

//   const handleTermChange = (event) => {
//     setSelectedTerm(event.target.value);
//   };

//   const handlePerformanceChange = (event) => {
//     setSelectedPerformance(event.target.value);
//   };

//   const handleAcademicYearChange = (event) => {
//     setSelectedAcademicYear(event.target.value);
//   };

//   const colorMap = {
//     'Performance A': '#012353',  // Dark Blue
//     'Performance B': '#27AE60',   // Green
//     'Performance C': '#FF9800',   // Orange
//     'Performance D': '#F44336',   // Red
//     'Performance E': '#9C27B0',   // Purple
//   };

//   const options = {
//     data: chartData,
//     series: [
//       {
//         type: 'bar',
//         xKey: 'performance',
//         yKey: 'percent',
//         label: {
//           enabled: false,
//           formatter: (params) => `${params.value}%`,
//         },
//         barWidth: 1,
//         fill: (params) => {
//           const color = colorMap[params.data.performance];
//           return color ? color : '#012353'; // Set a default color for undefined performance
//         },
//       },
//     ],
//     axes: [
//       {
//         type: 'category',
//         position: 'bottom',
//         title: {
//           text: 'Performance',
//         },
//       },
//       {
//         type: 'number',
//         position: 'left',
//         title: {
//           text: 'Percentage',
//         },
//         min: 0,
//       },
//     ],
//   };

//   return (
//     <div className="card card-success">
//       <div className="card-body">
//         {loading && <p>Loading...</p>}
//         {error && <p style={{ color: 'red' }}>{error}</p>}
//         <FilterContainer>
//           <Select value={selectedClass} onChange={handleClassChange}>
//             <option value="">Class</option>
//             {classes.map((classItem) => (
//               <option key={classItem} value={classItem}>{classItem}</option>
//             ))}
//           </Select>
//           <Select value={selectedTerm} onChange={handleTermChange}>
//             <option value="">Term</option>
//             {terms.map((term) => (
//               <option key={term} value={term}>{term}</option>
//             ))}
//           </Select>
//           <Select value={selectedAcademicYear} onChange={handleAcademicYearChange}>
//             <option value="">Year</option>
//             {academicYears.map((academicYear) => (
//               <option key={academicYear} value={academicYear}>{academicYear}</option>
//             ))}
//           </Select>
//           <Select value={selectedPerformance} onChange={handlePerformanceChange}>
//             <option value="">Performance</option>
//             {performances.map((performance) => (
//               <option key={performance} value={performance}>{performance}</option>
//             ))}
//           </Select>
//         </FilterContainer>
//         <AgCharts options={options} style={{ width: '100%', height: '38vh', marginTop: 'vh' }} />
//       </div>
//     </div>
//   );
// };

// export default DashboardPerformanceSummary;








// import React, { useState, useEffect } from 'react';
// import { AgCharts } from 'ag-charts-react';
// import axios from 'axios';
// import styled from 'styled-components';
// import '@fortawesome/fontawesome-free/css/all.min.css';

// // Styled Components for Filter
// const FilterContainer = styled.div`
//   display: flex;
//   justify-content: center;
//   margin-top: -20rem;
//   padding: 0;
//   background-color: #f8f9fa;
//   border-radius: 8px;
// `;

// const Select = styled.select`
//   width: 100%;
//   max-width: 200px;
//   padding: 5px;
//   border: 1px solid black;
//   border-radius: 5px;
//   font-size: 12px;
//   background-color: #f0f4f8;
//   box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.1);
//   transition: 0.3s ease;
//   margin: 0 10px; /* Add margin to create space between dropdowns */

//   &:focus {
//     border-color: #5fa8d3;
//     outline: none;
//   }
// `;

// const DashboardPerformanceSummary = () => {
//   const [selectedClass, setSelectedClass] = useState('');
//   const [selectedTerm, setSelectedTerm] = useState('');
//   const [selectedPerformance, setSelectedPerformance] = useState('');
//   const [selectedAcademicYear, setSelectedAcademicYear] = useState('');
//   const [classes, setClasses] = useState([]);
//   const [terms, setTerms] = useState([]);
//   const [performances, setPerformances] = useState([]);
//   const [academicYears, setAcademicYears] = useState([]);
//   const [chartData, setChartData] = useState([]);
//   const [loading, setLoading] = useState(false);
//   const [error, setError] = useState('');

//   const fetchData = async () => {
//     setLoading(true);
//     setError('');
//     try {
//       const response = await axios.get('http://13.127.57.224:2081/api/PerformanceSummary', {
//         params: {
//           CLASS: selectedClass,
//           ACADEMIC_YEAR: selectedAcademicYear,
//           TERM: selectedTerm,
//           PERFORMANCE: selectedPerformance,
//         },
//       });

//       const data = response.data;

//       const uniqueClasses = [...new Set(data.map(item => item.CLASS))];
//       const uniqueAcademicYears = [...new Set(data.map(item => item.ACADEMIC_YEAR))];
//       const uniqueTerms = [...new Set(data.map(item => item.TERM))];
//       const uniquePerformances = [...new Set(data.map(item => item.PERFORMANCE))];

//       const chartDataValues = uniquePerformances.map(performance => {
//         const item = data.find(d => d.PERFORMANCE === performance);
//         return {
//           performance,
//           percent: item ? parseFloat(item.PERCENT) : 0,
//         };
//       });

//       setClasses(uniqueClasses);
//       setAcademicYears(uniqueAcademicYears);
//       setTerms(uniqueTerms);
//       setPerformances(uniquePerformances);
//       setChartData(chartDataValues);
//     } catch (error) {
//       setError('Error fetching data. Please try again later.');
//       console.error('Error fetching data:', error);
//     } finally {
//       setLoading(false);
//     }
//   };

//   useEffect(() => {
//     fetchData();
//   }, [selectedClass, selectedTerm, selectedPerformance, selectedAcademicYear]);

//   const handleClassChange = (event) => {
//     setSelectedClass(event.target.value);
//   };

//   const handleTermChange = (event) => {
//     setSelectedTerm(event.target.value);
//   };

//   const handlePerformanceChange = (event) => {
//     setSelectedPerformance(event.target.value);
//   };

//   const handleAcademicYearChange = (event) => {
//     setSelectedAcademicYear(event.target.value);
//   };

//   const colorMap = {
//     'Performance A': '#012353',  // Dark Blue
//     'Performance B': '#27AE60',   // Green
//     'Performance C': '#FF9800',   // Orange
//     'Performance D': '#F44336',   // Red
//     'Performance E': '#9C27B0',   // Purple
//   };

//   const options = {
//     data: chartData,
//     series: [
//       {
//         type: 'bar',
//         xKey: 'performance',
//         yKey: 'percent',
//         label: {
//           enabled: false,
//           formatter: (params) => `${params.value}%`,
//         },
//         barWidth: 0.001, // Set to 0.01 for very thin bars
//         fill: (params) => {
//           const color = colorMap[params.data.performance];
//           return color ? color : '#012353'; // Set a default color for undefined performance
//         },
//       },
//     ],
//     axes: [
//       {
//         type: 'category',
//         position: 'bottom',
//         title: {
//           text: 'Performance',
//         },
//       },
//       {
//         type: 'number',
//         position: 'left',
//         title: {
//           text: 'Percentage',
//         },
//         min: 0,
//       },
//     ],
//   };
  

//   return (
//     <div className="card card-success">
//       <div className="">
//         {loading && <p>Loading...</p>}
//         {error && <p style={{ color: 'red' }}>{error}</p>}
//         <FilterContainer>
//           <Select value={selectedClass} onChange={handleClassChange}>
//             <option value="">Class</option>
//             {classes.map((classItem) => (
//               <option key={classItem} value={classItem}>{classItem}</option>
//             ))}
//           </Select>
//           <Select value={selectedTerm} onChange={handleTermChange}>
//             <option value="">Term</option>
//             {terms.map((term) => (
//               <option key={term} value={term}>{term}</option>
//             ))}
//           </Select>
//           <Select value={selectedAcademicYear} onChange={handleAcademicYearChange}>
//             <option value="">Year</option>
//             {academicYears.map((academicYear) => (
//               <option key={academicYear} value={academicYear}>{academicYear}</option>
//             ))}
//           </Select>
//           <Select value={selectedPerformance} onChange={handlePerformanceChange}>
//             <option value="">Performance</option>
//             {performances.map((performance) => (
//               <option key={performance} value={performance}>{performance}</option>
//             ))}
//           </Select>
//         </FilterContainer>
//         <AgCharts options={options} style={{ width: '100%', height: '38vh', marginTop: 'vh' }} />
//       </div>
//     </div>
//   );
// };

// export default DashboardPerformanceSummary;



// import React, { useState, useEffect } from 'react';
// import { AgCharts } from 'ag-charts-react';
// import axios from 'axios';
// import './Admin_Model.css'; // Import the CSS file
 
// const DashboardPerformanceSummary = () => {
//   const [selectedClass, setSelectedClass] = useState('');
//   const [selectedTerm, setSelectedTerm] = useState('');
//   const [selectedPerformance, setSelectedPerformance] = useState('');
//   const [selectedAcademicYear, setSelectedAcademicYear] = useState('');
//   const [classes, setClasses] = useState([]);
//   const [terms, setTerms] = useState([]);
//   const [performances, setPerformances] = useState([]);
//   const [academicYears, setAcademicYears] = useState([]);
//   const [chartData, setChartData] = useState([]);
//   const [loading, setLoading] = useState(false);
//   const [error, setError] = useState('');
 
//   const fetchData = async () => {
//     setLoading(true);
//     setError('');
//     try {
//       const response = await axios.get('http://13.127.57.224:2081/api/PerformanceSummary', {
//         params: {
//           CLASS: selectedClass,
//           ACADEMIC_YEAR: selectedAcademicYear,
//           TERM: selectedTerm,
//           PERFORMANCE: selectedPerformance,
//         },
//       });
 
//       const data = response.data;
//       const uniqueClasses = [...new Set(data.map(item => item.CLASS))];
//       const uniqueAcademicYears = [...new Set(data.map(item => item.ACADEMIC_YEAR))];
//       const uniqueTerms = [...new Set(data.map(item => item.TERM))];
//       const uniquePerformances = [...new Set(data.map(item => item.PERFORMANCE))];
 
//       const chartDataValues = uniquePerformances.map(performance => {
//         const item = data.find(d => d.PERFORMANCE === performance);
//         return {
//           performance,
//           percent: item ? parseFloat(item.PERCENT) : 0,
//         };
//       });
 
//       setClasses(uniqueClasses);
//       setAcademicYears(uniqueAcademicYears);
//       setTerms(uniqueTerms);
//       setPerformances(uniquePerformances);
//       setChartData(chartDataValues);
//     } catch (error) {
//       setError('Error fetching data. Please try again later.');
//       console.error('Error fetching data:', error);
//     } finally {
//       setLoading(false);
//     }
//   };
 
//   useEffect(() => {
//     fetchData();
//   }, [selectedClass, selectedTerm, selectedPerformance, selectedAcademicYear]);
 
//   const handleClassChange = (event) => setSelectedClass(event.target.value);
//   const handleTermChange = (event) => setSelectedTerm(event.target.value);
//   const handlePerformanceChange = (event) => setSelectedPerformance(event.target.value);
//   const handleAcademicYearChange = (event) => setSelectedAcademicYear(event.target.value);
 
//   const colorMap = {
//     'Performance A': '#012353',  // Dark Blue
//     'Performance B': '#27AE60',  // Green
//     'Performance C': '#FF9800',  // Orange
//     'Performance D': '#F44336',  // Red
//     'Performance E': '#9C27B0',  // Purple
//   };
 
//   const options = {
//     data: chartData,
//     series: [
//       {
//         type: 'bar',
//         xKey: 'performance',
//         yKey: 'percent',
//         label: {
//           enabled: false,
//           formatter: (params) => `${params.value}%`,
//         },
//         barWidth: 0.001,
//         fill: (params) => colorMap[params.data.performance] || '#012353',
//       },
//     ],
//     axes: [
//       {
//         type: 'category',
//         position: 'bottom',
//         title: {
//           text: '',
//         },
//       },
//       {
//         type: 'number',
//         position: 'left',
//         title: {
//           text: 'Percentage',
//         },
//         min: 0,
//       },
//     ],
//   };
 
//   return (
//     <div className="card card-success">
//       <div>
//         {loading && <p className="loading">Loading...</p>}
//         {error && <p className="error">{error}</p>}
//         <div className="Performance_Dashboard">
//           <select value={selectedClass} onChange={handleClassChange} className="Performance_Dashboard_Select">
//             <option value="">Class</option>
//             {classes.map((classItem) => (
//               <option key={classItem} value={classItem}>{classItem}</option>
//             ))}
//           </select>
//           <select value={selectedTerm} onChange={handleTermChange} className="Performance_Dashboard_Select">
//             <option value="">Term</option>
//             {terms.map((term) => (
//               <option key={term} value={term}>{term}</option>
//             ))}
//           </select>
//           <select value={selectedAcademicYear} onChange={handleAcademicYearChange} className="Performance_Dashboard_Select">
//             <option value="">Year</option>
//             {academicYears.map((academicYear) => (
//               <option key={academicYear} value={academicYear}>{academicYear}</option>
//             ))}
//           </select>
//           <select value={selectedPerformance} onChange={handlePerformanceChange} className="Performance_Dashboard_Select">
//             <option value="">Performance</option>
//             {performances.map((performance) => (
//               <option key={performance} value={performance}>{performance}</option>
//             ))}
//           </select>
//         </div>
//         <AgCharts options={options} style={{ height: '36vh', width: '100%' }} />
//       </div>
//     </div>
//   );
// };
 
// export default DashboardPerformanceSummary;
 

// import React, { useState, useEffect } from 'react';
// import { AgCharts } from 'ag-charts-react';
// import axios from 'axios';
// import './Admin_Model.css';
 
// const DashboardPerformanceSummary = () => {
//   const [selectedClass, setSelectedClass] = useState('');
//   const [selectedTerm, setSelectedTerm] = useState('');
//   const [selectedPerformance, setSelectedPerformance] = useState('');
//   const [selectedAcademicYear, setSelectedAcademicYear] = useState('');
//   const [classes, setClasses] = useState([]);
//   const [terms, setTerms] = useState([]);
//   const [performances, setPerformances] = useState([]);
//   const [academicYears, setAcademicYears] = useState([]);
//   const [chartData, setChartData] = useState([]);
//   const [loading, setLoading] = useState(false);
//   const [error, setError] = useState('');
 
//   const fetchData = async () => {
//     setLoading(true);
//     setError('');
//     try {
//       const response = await axios.get('http://13.127.57.224:2081/api/PerformanceSummary', {
//         params: {
//           CLASS: selectedClass,
//           ACADEMIC_YEAR: selectedAcademicYear,
//           TERM: selectedTerm,
//           PERFORMANCE: selectedPerformance,
//         },
//       });
 
//       const data = response.data;
//       const uniqueClasses = [...new Set(data.map(item => item.CLASS))];
//       const uniqueAcademicYears = [...new Set(data.map(item => item.ACADEMIC_YEAR))];
//       const uniqueTerms = [...new Set(data.map(item => item.TERM))];
//       const uniquePerformances = [...new Set(data.map(item => item.PERFORMANCE))];
 
//       const chartDataValues = uniquePerformances.map(performance => {
//         const item = data.find(d => d.PERFORMANCE === performance);
//         return {
//           performance,
//           percent: item ? parseFloat(item.PERCENT) : 0,
//         };
//       });
 
//       setClasses(uniqueClasses);
//       setAcademicYears(uniqueAcademicYears);
//       setTerms(uniqueTerms);
//       setPerformances(uniquePerformances);
//       setChartData(chartDataValues);
//     } catch (error) {
//       setError('Error fetching data. Please try again later.');
//       console.error('Error fetching data:', error);
//     } finally {
//       setLoading(false);
//     }
//   };
 
//   useEffect(() => {
//     fetchData();
//   }, [selectedClass, selectedTerm, selectedPerformance, selectedAcademicYear]);
 
//   const handleClassChange = (event) => setSelectedClass(event.target.value);
//   const handleTermChange = (event) => setSelectedTerm(event.target.value);
//   const handlePerformanceChange = (event) => setSelectedPerformance(event.target.value);
//   const handleAcademicYearChange = (event) => setSelectedAcademicYear(event.target.value);
 
//   const colorMap = {
//     'Performance A': '#012353',
//     'Performance B': '#27AE60',
//     'Performance C': '#FF9800',
//     'Performance D': '#F44336',
//     'Performance E': '#9C27B0',
//   };
 
//   const options = {
//     data: chartData,
//     series: [
//       {
//         type: 'bar',
//         xKey: 'performance',
//         yKey: 'percent',
//         label: {
//           enabled: false,
//           formatter: (params) => `${params.value}%`,
//         },
//         barWidth: 0.5,
//         fill: (params) => colorMap[params.data.performance] || '#012353',
//       },
//     ],
//     axes: [
//       {
//         type: 'category',
//         position: 'bottom',
//         title: {
//           text: '',
//         },
//       },
//       {
//         type: 'number',
//         position: 'left',
//         title: {
//           text: 'Percentage',
//         },
//         min: 0,
//       },
//     ],
//   };
 
//   return (
//     <div className="card card-success">
//       <div>
//         {loading && <p className="loading">Loading...</p>}
//         {error && <p className="error">{error}</p>}
//         <div className="Performance_Dashboard">
//           <select value={selectedClass} onChange={handleClassChange} className="Performance_Dashboard_Select">
//             <option value="">Class</option>
//             {classes.map((classItem) => (
//               <option key={classItem} value={classItem}>{classItem}</option>
//             ))}
//           </select>
//           <select value={selectedTerm} onChange={handleTermChange} className="Performance_Dashboard_Select">
//             <option value="">Term</option>
//             {terms.map((term) => (
//               <option key={term} value={term}>{term}</option>
//             ))}
//           </select>
//           <select value={selectedAcademicYear} onChange={handleAcademicYearChange} className="Performance_Dashboard_Select">
//             <option value="">Year</option>
//             {academicYears.map((academicYear) => (
//               <option key={academicYear} value={academicYear}>{academicYear}</option>
//             ))}
//           </select>
//           <select value={selectedPerformance} onChange={handlePerformanceChange} className="Performance_Dashboard_Select">
//             <option value="">Performance</option>
//             {performances.map((performance) => (
//               <option key={performance} value={performance}>{performance}</option>
//             ))}
//           </select>
//         </div>
//         <AgCharts options={options} style={{ height: '35vh', width: '100%' }} />
//       </div>
//     </div>
//   );
// };
 
// export default DashboardPerformanceSummary;








import React, { useState, useEffect, useMemo } from 'react';
import { AgCharts } from 'ag-charts-react';
import axios from 'axios';
import './Admin_Model.css';

const DashboardPerformanceSummary = () => {
  const [selectedClass, setSelectedClass] = useState('');
  const [selectedTerm, setSelectedTerm] = useState('');
  const [selectedPerformance, setSelectedPerformance] = useState('');
  const [selectedAcademicYear, setSelectedAcademicYear] = useState('');
  const [data, setData] = useState([]);
  const [classes, setClasses] = useState([]);
  const [terms, setTerms] = useState([]);
  const [performances, setPerformances] = useState([]);
  const [academicYears, setAcademicYears] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  // Fetch all data once
  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      setError('');
      try {
        const response = await axios.get('http://13.127.57.224:2081/api/PerformanceSummary');
        const fetchedData = response.data;

        // Extract unique filter values
        const uniqueClasses = [...new Set(fetchedData.map(item => item.CLASS))];
        const uniqueAcademicYears = [...new Set(fetchedData.map(item => item.ACADEMIC_YEAR))];
        const uniqueTerms = [...new Set(fetchedData.map(item => item.TERM))];
        const uniquePerformances = [...new Set(fetchedData.map(item => item.PERFORMANCE))];

        // Set data and filter options
        setData(fetchedData);
        setClasses(uniqueClasses);
        setAcademicYears(uniqueAcademicYears);
        setTerms(uniqueTerms);
        setPerformances(uniquePerformances);
      } catch (error) {
        setError('Error fetching data. Please try again later.');
        console.error('Error fetching data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  // Filter data based on user selection
  const filteredData = useMemo(() => {
    return data.filter(item =>
      (selectedClass ? item.CLASS === selectedClass : true) &&
      (selectedTerm ? item.TERM === selectedTerm : true) &&
      (selectedPerformance ? item.PERFORMANCE === selectedPerformance : true) &&
      (selectedAcademicYear ? item.ACADEMIC_YEAR === selectedAcademicYear : true)
    );
  }, [data, selectedClass, selectedTerm, selectedPerformance, selectedAcademicYear]);

  // Prepare chart data
  const chartData = useMemo(() => {
    const performanceMap = filteredData.reduce((acc, item) => {
      acc[item.PERFORMANCE] = (acc[item.PERFORMANCE] || 0) + parseFloat(item.PERCENT);
      return acc;
    }, {});

    return Object.keys(performanceMap).map(performance => ({
      performance,
      percent: performanceMap[performance],
    }));
  }, [filteredData]);

  const handleClassChange = (event) => setSelectedClass(event.target.value);
  const handleTermChange = (event) => setSelectedTerm(event.target.value);
  const handlePerformanceChange = (event) => setSelectedPerformance(event.target.value);
  const handleAcademicYearChange = (event) => setSelectedAcademicYear(event.target.value);

  const colorMap = {
    'Performance A': '#012353',
    'Performance B': '#27AE60',
    'Performance C': '#FF9800',
    'Performance D': '#F44336',
    'Performance E': '#9C27B0',
  };

  const options = {
    data: chartData,
    series: [
      {
        type: 'bar',
        xKey: 'performance',
        yKey: 'percent',
        label: {
          enabled: false,
          formatter: (params) => `${params.value}%`,
        },
        barWidth: 0.5,
        fill: (params) => colorMap[params.data.performance] || '#012353',
      },
    ],
    axes: [
      {
        type: 'category',
        position: 'bottom',
        title: {
          text: '',
        },
      },
      {
        type: 'number',
        position: 'left',
        title: {
          text: 'Percentage',
        },
        min: 0,
      },
    ],
  };

  return (
    <div className="card card-success">
      <div>
        {loading && <p className="loading">Loading...</p>}
        {error && <p className="error">{error}</p>}
        <div className="Performance_Dashboard">
          <select value={selectedClass} onChange={handleClassChange} className="Performance_Dashboard_Select">
            <option value="">Class</option>
            {classes.map((classItem) => (
              <option key={classItem} value={classItem}>{classItem}</option>
            ))}
          </select>
          <select value={selectedTerm} onChange={handleTermChange} className="Performance_Dashboard_Select">
            <option value="">Term</option>
            {terms.map((term) => (
              <option key={term} value={term}>{term}</option>
            ))}
          </select>
          <select value={selectedAcademicYear} onChange={handleAcademicYearChange} className="Performance_Dashboard_Select">
            <option value="">Year</option>
            {academicYears.map((academicYear) => (
              <option key={academicYear} value={academicYear}>{academicYear}</option>
            ))}
          </select>
          <select value={selectedPerformance} onChange={handlePerformanceChange} className="Performance_Dashboard_Select">
            <option value="">Performance</option>
            {performances.map((performance) => (
              <option key={performance} value={performance}>{performance}</option>
            ))}
          </select>
        </div>
        <AgCharts options={options} style={{ height: '35vh', width: '100%' }} />
      </div>
    </div>
  );
};

export default DashboardPerformanceSummary;
