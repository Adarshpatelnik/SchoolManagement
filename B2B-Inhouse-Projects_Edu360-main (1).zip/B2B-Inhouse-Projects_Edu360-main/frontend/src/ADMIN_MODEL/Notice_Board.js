
// import React, { useEffect, useState } from 'react';
// import axios from 'axios';
// import 'bootstrap/dist/css/bootstrap.min.css';

// function NoticeBoard() {
//   const [announcements, setAnnouncements] = useState([]);

//   // Backend API se announcements fetch karna
//   const fetchAnnouncements = async () => {
//     try {
//       const response = await axios.get('http://13.127.57.224:2081/api/noticeboard');
//       setAnnouncements(response.data); // Announcement ka data directly set kiya
//     } catch (error) {
//       console.error('Error fetching announcements:', error.message);
//     }
//   };

//   // Announcements ko har 10 seconds mein refresh karna
//   useEffect(() => {
//     fetchAnnouncements();
//     const intervalId = setInterval(fetchAnnouncements, 10000); // Refresh har 10 seconds mein
//     return () => clearInterval(intervalId); // Interval ko clear karna jab component unmount ho
//   }, []);

//   // State to track color change for each message
//   const [clickedIndices, setClickedIndices] = useState({});

//   // Handle click event on message to change color
//   const handleDescriptionClick = (index) => {
//     setClickedIndices((prev) => ({
//       ...prev,
//       [index]: true, // Color ko permanently change karne ke liye set to true
//     }));
//   };

//   return (
//     <div className="container " style={{ maxWidth: '100%', paddingTop: '0px', paddingBottom: '80%' }}> {/* Increased maxWidth to 800px */}
//       <h2 className="text-center mb-4">Important Notice</h2>
//       <div className="overflow-auto" style={{ maxHeight: '300px' }}> {/* Scrollable Container */}
//         <div className="list-group">
//           {announcements.map((announcement, index) => (
//             <div
//               key={index}
//               className="list-group-item list-group-item-action d-flex justify-content-start align-items-center p-"
//               style={{ fontSize: '1rem', cursor: 'pointer' }} // Increased font size to 1rem
//             >
//               <span
//                 className={`fw-bold me-2 ${clickedIndices[index] ? 'text-primary' : 'text-secondary'}`} // Color change logic
//                 onClick={() => handleDescriptionClick(index)} // Handle click event for message
//                 style={{ transition: 'color 0.3s ease' }} // Smooth transition for color change
//               >
//                 {announcement.DESCRIPTION} {/* Displaying message field */}
//               </span>
//               {announcement.pdfUrl && ( // Agar PDF URL available hai toh button dikhana
//                 <a href={announcement.pdfUrl} download className="btn btn-link ms-2"> {/* Download button for PDF */}
//                   Download PDF
//                 </a>
//               )}
//               {index === 0 && ( // Sirf pehle item ke liye "New" badge
//                 <span className="badge bg-danger" style={{ marginLeft: '10px' }}> {/* Red badge for "New" */}
//                   New
//                 </span>
//               )}
//             </div>
//           ))}
//         </div>
//       </div>
//     </div>
//   );
// }

// export default NoticeBoard;




// import React, { useEffect, useState } from 'react';
// import axios from 'axios';
// import 'bootstrap/dist/css/bootstrap.min.css';

// function NoticeBoard() {
//   const [announcements, setAnnouncements] = useState([]);

//   // Backend API se announcements fetch karna aur DESCRIPTION ko lowercase mein convert karna
//   const fetchAnnouncements = async () => {
//     try {
//       const response = await axios.get('http://13.127.57.224:2081/api/noticeboard');
//       const lowercasedAnnouncements = response.data.map(announcement => ({
//         ...announcement,
//         DESCRIPTION: announcement.DESCRIPTION.toLowerCase(), // Converting DESCRIPTION to lowercase
//       }));
//       setAnnouncements(lowercasedAnnouncements); // Announcement ka data set karna
//     } catch (error) {
//       console.error('Error fetching announcements:', error.message);
//     }
//   };

//   // Announcements ko har 10 seconds mein refresh karna
//   useEffect(() => {
//     fetchAnnouncements();
//     const intervalId = setInterval(fetchAnnouncements, 10000); // Refresh har 10 seconds mein
//     return () => clearInterval(intervalId); // Interval ko clear karna jab component unmount ho
//   }, []);

//   // State to track color change for each message
//   const [clickedIndices, setClickedIndices] = useState({});

//   // Handle click event on message to change color
//   const handleDescriptionClick = (index) => {
//     setClickedIndices((prev) => ({
//       ...prev,
//       [index]: true, // Color ko permanently change karne ke liye set to true
//     }));
//   };

//   return (
//     <div className="container " style={{ maxWidth: '100%', paddingTop: '0px', paddingBottom: '0%' }}> {/* Increased maxWidth to 800px */}
//       <div className="overflow-auto" style={{ maxHeight: '300px' }}> {/* Scrollable Container */}
//       <div className="list-group">
//   {announcements.map((announcement, index) => (
//     <div
//       key={index}
//       className="list-group-item list-group-item-action d-flex justify-content-start align-items-center py-2" // Adjusted padding
//       style={{ fontSize: '1rem', cursor: 'pointer' }} // Increased font size to 1rem
//     >
//       <span
//         className={`fw-bold me-2 ${clickedIndices[index] ? 'text-primary' : 'text-secondary'}`} // Corrected margin and color logic
//         onClick={() => handleDescriptionClick(index)} // Handle click event for message
//         style={{ transition: 'color 0.3s ease' }} // Smooth transition for color change
//       >
//         {announcement.DESCRIPTION} {/* Displaying message field */}
//       </span>
      
//       {announcement.pdfUrl && ( // If PDF URL is available, show download button
//         <a href={announcement.pdfUrl} download className="btn btn-link ms-2"> {/* Download button for PDF */}
//           Download PDF
//         </a>
//       )}

//       {index === 0 && ( // Show "New" badge only for the first item
//         <span className="badge bg-danger" style={{ marginLeft: '10px' }}> {/* Red badge for "New" */}
//           New
//         </span>
//       )}
//     </div>
//   ))}
// </div>

//       </div>
//     </div>
//   );
// }

// export default NoticeBoard;




import React, { useEffect, useState } from 'react';
import axios from 'axios';
import 'bootstrap/dist/css/bootstrap.min.css';
import './Admin_Model.css'; // Import the separate CSS file
 
function NoticeBoard() {
  const [announcements, setAnnouncements] = useState([]);
  const [clickedIndices, setClickedIndices] = useState({});
 
  // Fetch announcements from backend and convert DESCRIPTION to lowercase
  const fetchAnnouncements = async () => {
    try {
      const response = await axios.get('http://13.127.57.224:2081/api/noticeboard');
      const lowercasedAnnouncements = response.data.map(announcement => ({
        ...announcement,
        DESCRIPTION: announcement.DESCRIPTION.toLowerCase(),
      }));
      setAnnouncements(lowercasedAnnouncements);
    } catch (error) {
      console.error('Error fetching announcements:', error.message);
    }
  };
 
  // Refresh announcements every 10 seconds
  useEffect(() => {
    fetchAnnouncements();
    const intervalId = setInterval(fetchAnnouncements, 10000);
    return () => clearInterval(intervalId);
  }, []);
 
  // Handle click event on message to change color
  const handleDescriptionClick = (index) => {
    setClickedIndices((prev) => ({
      ...prev,
      [index]: true,
    }));
  };
 
  return (
    <div className="Notice_Board_container">
      <div className="overflow-auto">
        <div className="list-group">
          {announcements.map((announcement, index) => (
            <div
              key={index}
              className="list-group-item list-group-item-action"
            >
              <span
                className={`fw-bold me-2 ${clickedIndices[index] ? 'text-primary' : 'text-secondary'}`}
                onClick={() => handleDescriptionClick(index)}
              >
                {announcement.DESCRIPTION}
              </span>
 
              {announcement.pdfUrl && (
                <a href={announcement.pdfUrl} download className="btn btn-link ms-2">
                  Download PDF
                </a>
              )}
 
              {index === 0 && (
                <span className="badge bg-danger">
                  New
                </span>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
 
export default NoticeBoard;