

import React, { useState, useEffect } from 'react';
import { FaChevronLeft, FaChevronRight } from 'react-icons/fa';
import axios from 'axios';

const EventCalendar = () => {
  const [selectedDate, setSelectedDate] = useState(null);
  const [year, setYear] = useState(new Date().getFullYear());
  const [month, setMonth] = useState(new Date().getMonth());
  const [events, setEvents] = useState([]);

  useEffect(() => {
    fetchEvents();
  }, [year, month]);

  const fetchEvents = async () => {
    try {
      const response = await axios.get('http://13.127.57.224:2081/api/holidays', {
        params: {
          year,
          month: month + 1,
        },
      });
      const mappedEvents = response.data.map(event => ({
        holidayName: event.HOLIDAY_NAME,
        holidayMonth: event.HOLIDAY_MONTH,
        holidayYear: event.HOLIDAY_YEAR,
        startDate: new Date(event.START_DATE).toLocaleDateString('en-US'),
        endDate: new Date(event.END_DATE).toLocaleDateString('en-US'),
      }));
      setEvents(mappedEvents);
    } catch (error) {
      console.error('Error fetching events:', error);
    }
  };

  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const firstDayOfMonth = new Date(year, month, 1).getDay();

  const handleDateClick = (date) => {
    setSelectedDate(date);
  };

  const handlePrevMonth = () => {
    if (month === 0) {
      setMonth(11);
      setYear(year - 1);
    } else {
      setMonth(month - 1);
    }
  };

  const handleNextMonth = () => {
    if (month === 11) {
      setMonth(0);
      setYear(year + 1);
    } else {
      setMonth(month + 1);
    }
  };

  const monthName = new Date(year, month).toLocaleDateString('default', { month: 'long' });

  const generateCalendar = () => {
    const calendarDays = [];
    for (let i = 0; i < firstDayOfMonth; i++) {
      calendarDays.push(<div style={styles.emptyDay} key={`empty-${i}`}></div>);
    }

    for (let day = 1; day <= daysInMonth; day++) {
      const date = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
      const isToday = new Date().toLocaleDateString('en-CA') === date;
      const eventsForDate = events.filter(event =>
        new Date(event.startDate) <= new Date(date) && new Date(event.endDate) >= new Date(date)
      );

      calendarDays.push(
        <div
          style={{ ...styles.calendarDay, ...(isToday && styles.todayHighlight) }}
          key={date}
          onClick={() => handleDateClick(date)}
        >
          <span>{day}</span>
          {eventsForDate.map(event => (
            <div key={event.startDate} style={styles.eventItem}>
              <span>{event.holidayName}</span>
            </div>
          ))}
        </div>
      );
    }

    return calendarDays;
  };

  return (
    <div className="events-calendar" style={styles.eventsCalendar}>
      <div style={styles.eventsHeader}>
        <h3 style={styles.monthName}>{monthName} {year}</h3>
        <div style={styles.navigation}>
          <button style={styles.navigationButton} onClick={handlePrevMonth}>
            <FaChevronLeft />
          </button>
          <button style={styles.navigationButton} onClick={handleNextMonth}>
            <FaChevronRight />
          </button>
        </div>
      </div>
      <div style={styles.calendarGrid}>
        {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
          <div style={styles.calendarHeader} key={day}>
            {day}
          </div>
        ))}
        {generateCalendar()}
      </div>
    </div>
  );
};

const styles = {
  eventsCalendar: {
    maxWidth: '450px', // Set a maximum width for the calendar
    margin: '0px auto',
    fontFamily: 'Arial, sans-serif',
    background: 'linear-gradient(135deg, #e0f7fa, #fff)',
    padding: '24px',
    borderRadius: '12px',
    marginTop: '-10vh',
    boxShadow: '0 4px 10px rgba(0, 0, 0, 0.1)',
  },
  eventsHeader: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: '10px',
  },
  navigation: {
    display: 'flex',
  },
  navigationButton: {
    border: 'none',
    cursor: 'pointer',
    outline: 'none',
    fontSize: '12px', // Reduced font size
    padding: '4px 6px', // Adjusted padding
    color: '#2c3e50',
    transition: 'transform 0.2s ease',
    margin: '0 2px',
  },
  monthName: {
    margin: 0,
    fontSize: '14px', // Reduced font size
    fontWeight: 'bold',
    color: '#27ae60',
  },
  calendarDay: {
    backgroundColor: '#ffffff',
    padding: '4px', // Reduced padding
    textAlign: 'center',
    cursor: 'pointer',
    border: '1px solid #ddd',
    transition: 'background-color 0.3s',
    borderRadius: '4px',
    fontSize: '10px', // Reduced font size for day numbers
  },
  todayHighlight: {
    backgroundColor: '#2ecc71',
    color: '#fff',
    fontWeight: 'bold',
    boxShadow: '0 2px 5px rgba(0, 0, 0, 0.2)',
  },
  calendarGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(7, 1fr)',
    gap: '1px', // Reduced gap
    marginTop: '5px',
  },
  calendarHeader: {
    textAlign: 'center',
    fontWeight: 'bold',
    color: '#34495e',
    fontSize: '10px', // Reduced font size for headers
  },
  eventItem: {
    marginTop: '2px', // Reduced margin
    fontSize: '10px', // Reduced font size for event items
    backgroundColor: '#e74c3c',
    color: '#fff',
    borderRadius: '3px',
    padding: '2px 3px',
  },
  emptyDay: {
    backgroundColor: '#f7f9fc',
    border: '1px solid #ddd',
    height: '20px',
  },

  // Media queries for responsiveness
  '@media (max-width: 768px)': {
    eventsCalendar: {
      maxWidth: '90%', // Responsive adjustment
      padding: '8px',
    },
    calendarDay: {
      padding: '2px', // Reduced padding
    },
    calendarHeader: {
      fontSize: '10px', // Reduced font size
    },
    navigationButton: {
      fontSize: '10px', // Reduced font size
      padding: '2px 4px', // Adjusted padding
    },
  },
  '@media (max-width: 480px)': {
    calendarGrid: {
      gap: '1px', // Reduced gap for smaller screens
    },
    calendarDay: {
      padding: '2px', // Further reduced padding
      fontSize: '9px', // Smaller font size
    },
    navigationButton: {
      fontSize: '8px', // Smaller font size for buttons
      padding: '2px 3px', // Adjusted padding
    },
  },
};

export default EventCalendar;
