
//    import React, { useState, useEffect } from 'react';
//    import axios from 'axios';
//    import styled from 'styled-components';
//    import { FaUserGraduate, FaUserTie, FaChalkboardTeacher } from 'react-icons/fa';
//    import PerformanceSummary from './Dashbord_Performance_Summary';
//    import EventCalender from './Event_Calender';
//    import DashBoardStaffAttendance from './Staff_Attendance_Chart';
//    import DashbordStudentAttendance from './Student_Attendance_Chart';
//    import GirlBoy from './Girl_Boy.js';
//    import TimeTableschedule from './Time_Table_schedule.js';
//    import { Link } from 'react-router-dom';

//    import 'bootstrap/dist/css/bootstrap.min.css';

//     // Styled components
//    const Container = styled.div`
//      padding-top: 10px;
//      min-height: 100vh;
//      padding: 0 20px; 
//      max-width: 100%; 
//      margin: 0 auto; 
//      background-color: white; /* Softer background color for cleaner look */

//      @media (max-width: 1200px) {
//        max-width: 1000px;
//      }

//      @media (max-width: 992px) {
//        max-width: 800px; 
//      }

//      @media (max-width: 768px) {
//        padding: 0 10px; 
//        max-width: 100%; 
//      }

//      @media (max-width: 576px) {
//        padding: 0 5px; 
//        max-width: 100%; 
//      }
//    `;
//    const Card = styled.div`
//    background-color: #ffffff;
//    border-radius: 12px;
//    padding: 0px;
//    margin-bottom: 15%; /* Decreased margin */
//    margin-top: 0px;

//    min-height: 0; 
//    display: flex;
//    flex-direction: column;
//    justify-content: space-between;
//    transition: transform 0.3s ease, box-shadow 0.3s ease;
//    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.1); 

//    &:hover {
//      box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
//    }

//    @media (max-width: 768px) {
//      padding: 15px;
//      min-height: 250px;
//    }
//    `;
//    const InfoCard = styled.div`
//    display: flex;
//    align-items: center;
//    padding: 10px; /* Padding for spacing */
//    margin: 10px 0; /* Margin for spacing */
//    border-radius: 12px;
//    background: ${(props) => props.gradient};
//    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
//    transition: transform 0.3s ease, box-shadow 0.3s ease;
//    cursor: pointer;

//    &:hover {
//      transform: scale(1.03);
//      box-shadow: 0 6px 12px rgba(0, 0, 0, 0.2);
//    }

//    @media (max-width: 768px) {
//      flex-direction: column; /* Ensure alignment on smaller screens */
//      text-align: center;
//    }
//  `;

//  const InfoText = styled.div`
//    margin-left: 10%; /* Space between image and text */
//    color: #333;
//    display: flex; /* Use flexbox to align items */
//    flex-direction: row; /* Arrange text horizontally */
//    align-items: center; /* Center align items vertically */

//    strong {
//      font-size: 1rem;
//      margin-right: 20%; /* Space between strong text and value */
//      color: #6c757d; /* Light gray color for label */
//      font-weight: 500;
//      text-align: left; /* Align strong text to the left */
//    }

//    div {
//      font-size: 1.7rem;
//      color: #333; /* Dark color for number */
//      font-weight: bold;

//      text-align: right; /* Align value text to the left */
//    }

//    @media (max-width: 768px) {
//      margin-left: 0;
//      text-align: center;
//      flex-direction: column; /* Stack items vertically on smaller screens */
//      align-items: center; /* Center align items */
//    }
//  `;

//  const ImageContainer = styled.div`
//    width: 40px;
//    height: 40px;
//    border-radius: 0%;
//    overflow: hidden;
//    display: flex;
//    align-items: center;
//    justify-content: center;

//    img {
//      width: 100%;
//      height: 100%;
//      object-fit: cover;
//    }
//  `;
//    const Heading = styled.h3`
//    font-size: 1.2rem; 
//    font-weight: 500; 
//    font-family: 'Lato', sans-serif; 
//    color: black; 
//    margin-bottom: 30px; 
//    padding: 4px 10px; 
//     letter-spacing: 1.5px; 
//    text-shadow: 1px 1px 4px rgba(0, 0, 0, 0.15); 
//    background: linear-gradient(to right, #d3d3d3, #e8e8e8); /* Light gradient background */
//    border-radius: 6px;
//    display: inline-block;
//    transition: all 0.4s ease; 

//    @media (max-width: 400px) {
//      font-size: 1.4rem; 
//      padding: 10px 12px; 
//      margin-bottom: 20px;
//    }
//    `;
// //  const Greeting = () => {
// //    const [greetingMessage, setGreetingMessage] = useState('');

// //    useEffect(() => {
// //      const now = new Date();
// //      const hours = now.getHours();
// //      const date = now.toLocaleDateString('default', { day: 'numeric', month: 'long' });

// //      let greeting = '';
// //      if (hours < 12) greeting = 'Good Morning';
// //      else if (hours < 18) greeting = 'Good Afternoon';
// //      else greeting = 'Good Evening';

// //      setGreetingMessage(`${greeting}, ${date}`);
// //    }, []);

// //    return <h2 style={{ padding: '10px 0', color: '#333', fontSize: '1.5rem' }}>{greetingMessage}</h2>;
// //  };

//    const Dashboard = () => {
//      const [totalStudents, setTotalStudents] = useState(0);
//      const [totalStaff, setTotalStaff] = useState(0);
//      const [workingStaff, setWorkingStaff] = useState(0);
//      const [loading, setLoading] = useState(true);
//      const [error, setError] = useState(null);

//      useEffect(() => {
//        const fetchData = async () => {
//          try {
//            setLoading(true);
//            const responses = await Promise.all([
//              axios.get('http:13.127.57.224:2081/api/studentcountdetails'),
//              axios.get('http:13.127.57.224:2081/api/staffcount'),
//              axios.get('http:13.127.57.224:2081/api/workingStaff')
//            ]);

//            const [responseStudents, responseStaff, responseWorkingStaff] = responses;

//            setTotalStudents(responseStudents.data.totalStudents);
//            setTotalStaff(responseStaff.data.totalStaff);
//            setWorkingStaff(responseWorkingStaff.data.workingStaff);
//          } catch (error) {
//            setError(error.message);
//          } finally {
//            setLoading(false);
//          }
//        };

//        fetchData();
//      }, []);

//      if (loading) return <div>Loading...</div>;
//      if (error) return <div>{error}</div>;

//      return (
//        <Container className="container-fluid py-2">
// {/* <Greeting />  */}

//          <div className="container-fluid" style={{ marginTop: '5vh', width: '100%', padding: 0 }}>
//            <div className="row">
//              <div className="col-lg-4 col-md-3 mb-2">
//              <InfoCard gradient="linear-gradient(to right, #a8e6cf, #dcedc1)">
//    <ImageContainer>
//      <img src="schoolgirl.png" alt="Students" /> {/* Replace with your image source */}
//    </ImageContainer>
//    <InfoText>
//      <strong>Students</strong>
//      <div>{totalStudents}</div>
//    </InfoText>
//  </InfoCard>
//              </div>

//              <div className="col-lg-4 col-md-3 mb-4">
//                <InfoCard gradient="linear-gradient(to right, #ffecd2, #fcb69f)">
//                <ImageContainer>
//                  <img src="Baby.png" alt="Students" /> {/* Replace with your image source */}
//                </ImageContainer>
//                  <InfoText>
//                    <strong>Staff</strong>
//                    <div>{totalStaff}</div>
//                  </InfoText>
//                </InfoCard>
//              </div>

//              <div className="col-lg-4 col-md-3 mb-4">
//                <InfoCard gradient="linear-gradient(to right, #ffefba, #ffffff)">
//                <ImageContainer>
//                  <img src="teacherr.png" alt="Students" /> {/* Replace with your image source */}
//                </ImageContainer>
//                  <InfoText>
//                    <strong>Teaching </strong>
//                    <div>{workingStaff}</div>
//                  </InfoText>
//                </InfoCard>
//              </div>
//            </div>

//            <div className="row"   style={{ marginTop: '-3vh', }}>
//              <div className="col-lg-4">
//                <Card style={{ height: '35vh',  borderRadius: '16px' }}>
//                  <Heading>Student Ratio</Heading>
//                  <GirlBoy />
//                </Card>
//              </div>

//              <div className="col-lg-4">
//                <Card style={{ height: '35vh',  borderRadius: '16px' }}>
//                  <Heading>Student Attendance</Heading>
//                  <DashbordStudentAttendance />
//                </Card>
//              </div>

//              <div className="col-lg-4">
//                <Card style={{ height: '35vh', borderRadius: '16px' }}>
//                  <Heading>Staff Attendance</Heading>
//                  <DashBoardStaffAttendance />
//                </Card>
//              </div>
//            </div>


//            <div className="row"  style={{ marginTop: '-6vh',}}>

//            <div className="col-lg-4 ">
//                <Card style={{ height: '43vh',  borderRadius: '16px' }}>
//                  <Heading>Event Calendar</Heading>
//                  <EventCalender />
//                </Card>
//              </div>
//                  <div className="col-lg-6">
//                <Card style={{ height: '43vh',  borderRadius: '16px' }}>
//                  <Heading>Student Performance</Heading>
//                  <PerformanceSummary />
//                </Card>
//              </div>
            
          
//              <div className="row"  style={{ marginTop: '-9vh',}}>
//              <div className="col-lg-6">
//        <Card style={{ height: '43vh', borderRadius: '16px',  }}>
//          <Heading>Time Table Schedule</Heading>
//          <TimeTableschedule />
//        </Card>
    
//    </div>
//    </div>
        

//            </div>
//          </div>
//        </Container>
    
//      );
//    };

//   export default Dashboard;



// import React, { useState, useEffect } from 'react';
// import axios from 'axios';
// import styled from 'styled-components';
// import { FaUserGraduate, FaUserTie, FaChalkboardTeacher } from 'react-icons/fa';
// import PerformanceSummary from './Dashbord_Performance_Summary';
// import EventCalender from './Event_Calender';
// import DashBoardStaffAttendance from './Staff_Attendance_Chart';
// import DashbordStudentAttendance from './Student_Attendance_Chart';
// import GirlBoy from './Girl_Boy.js';
// import TimeTableschedule from './Time_Table_schedule.js';
// import NoticeBoard from './NoticeBoard.js';

// import 'bootstrap/dist/css/bootstrap.min.css';

// // Styled components
// const Container = styled.div`
//   padding-top: 10px;
//   min-height: 100vh;
//   padding: 0 20px;
//   max-width: 100%;
//   margin: 0 auto;
//   background-color: #F0F6FA	;

//   @media (max-width: 1200px) {
//     max-width: 1000px;
//   }
//   @media (max-width: 992px) {
//     max-width: 800px;
//   }
//   @media (max-width: 768px) {
//     padding: 0 10px;
//   }
//   @media (max-width: 576px) {
//     padding: 0 5px;
//   }
// `;

// const Card = styled.div`
//   background-color: #ffffff;
//   border: 2px solid #ccc; /* Add this line for a 1px border */
//   border-radius: 4px; /* Adjust the radius value as needed */
//   padding: 0px;
//   margin-bottom: 15%;
//   min-height: 0;
//   display: flex;
//   flex-direction: column;
//   justify-content: space-between;
//   transition: transform 0.3s ease, box-shadow 0.3s ease;
//   // box-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);

//   @media (max-width: 768px) {
//     padding: 15px;
//     min-height: 250px;
//   }
// `;


// // const InfoCard = styled.div`
// //   display: flex;
// //   align-items: center;
// //   padding: 10px;
// //   margin: 10px 0;
// //   border-radius: 6px;
// //   background: white;
// //   // box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
// //   transition: transform 0.3s ease, box-shadow 0.3s ease;
// //   cursor: pointer;

 
// //   @media (max-width: 768px) {
// //     flex-direction: column;
// //     text-align: center;
// //   }
// // `;

// const InfoText = styled.div`
//   display: flex;
//   flex-direction: column;
//   align-items: center;
//   justify-content: center;
//   color: #333;
//   margin: 0 auto; 
//   text-align: center;
//   height: 6%; /* Set height to match ImageContainer */
  
//   strong {
//     font-size: 1.3rem;
//     color: #6c757d;
//     font-weight: 500;
//     margin-bottom: px; /* Adjust margin for spacing */
//   }

//   div {
//     font-size: 1.3rem; /* Ensure this matches the strong tag size */
//     color: #333;
//     font-weight: bold;
//   }

//   /* Responsive styling */
//   @media (max-width: 768px) {
//     font-size: 1.2rem; 
//     padding: 10px;
//   }
// `;
// const InfoCard = styled.div`
//   display: flex;
//   align-items: center;
//   padding: 10px;
//   margin: 10px 0;
//   border-radius: 6px;
//   background: white;
//   box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15); 
//   transition: transform 0.3s ease, box-shadow 0.3s ease;
//   cursor: pointer;

//   &:hover {
//     transform: translateY(-2px); 
//     box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
//   }

//   @media (max-width: 768px) {
//     flex-direction: column; 
//     text-align: center;
//   }
// `;

// const ImageContainer = styled.div`
//   width: 60px;  
//   height: 60px;  
//   overflow: hidden; 
//   border-radius: 8px; 
//   display: flex; 
//   align-items: center;  
//   justify-content: center;  
//   margin-right: 15px; 

//   img {
//     width: 100%;  
//     height: 100%;  
//     object-fit: cover; 
//     display: block; 
//   }
// `;

// const Heading = styled.h3`
//   font-size: 1.1rem;
//   font-weight: 600; 
//   font-family: 'Lato', sans-serif;
//   color: #333;  
//   margin-bottom: 30px;
//   padding: 5px 10px;
//   letter-spacing: px;
//   border-radius:12px;
//   display: inline-block;
  
//   background: linear-gradient(135deg, #f0f0f0, #e0e0e0);
//   border-bottom: 1px solid #b0b0b0; 
  
//   transition: transform 0.3s ease, box-shadow 0.3s ease, background 0.3s ease;

 

//   @media (max-width: 400px) {
//     font-size: 1.2rem;
//     padding: 8px 16px;
//     margin-bottom: 20px;
//   }
// `;




// const Dashboard = () => {
//   const [totalStudents, setTotalStudents] = useState(0);
//   const [totalStaff, setTotalStaff] = useState(0);
//   const [workingStaff, setWorkingStaff] = useState(0);
//   const [loading, setLoading] = useState(true);
//   const [error, setError] = useState(null);

//   useEffect(() => {
//     const fetchData = async () => {
//       try {
//         setLoading(true);
//         const responses = await Promise.all([
//           axios.get('http://13.127.57.224:2081/api/studentcountdetails'),
//           axios.get('http://13.127.57.224:2081/api/staffcount'),
//           axios.get('http://13.127.57.224:2081/api/workingStaff')
//         ]);

//         const [responseStudents, responseStaff, responseWorkingStaff] = responses;

//         setTotalStudents(responseStudents.data.totalStudents);
//         setTotalStaff(responseStaff.data.totalStaff);
//         setWorkingStaff(responseWorkingStaff.data.workingStaff);
//       } catch (error) {
//         setError(error.message);
//       } finally {
//         setLoading(false);
//       }
//     };

//     fetchData();
//   }, []);

//   if (loading) return <div>Loading...</div>;
//   if (error) return <div>{error}</div>;

//   return (
//     <Container className="container-fluid py-1">

//       <div className="container-fluid" style={{ marginTop: '4vh', width: '100%', padding: 0 }}>
//         <div className="row">
//           <div className="col-lg-4 col-md- mb-"style={{ padding: '0 2px' }}>
//           <InfoCard gradient="">
//           <ImageContainer>
//                 <img src="girl.png" alt="Staff" />
//               </ImageContainer>
// <InfoText>
//   <strong>Students</strong>
//   <div>{totalStudents}</div>
// </InfoText>
// </InfoCard>
//           </div>

//           <div className="col-lg-4 col-md-3 mb-4"style={{ padding: '0 2px' }}>
//             <InfoCard gradient="">
//             <ImageContainer>
//                 <img src="Baby.png" alt="Staff" />
//               </ImageContainer>
//               <InfoText>
//                 <strong>Staff</strong>
//                 <div>{totalStaff}</div>
//               </InfoText>
//             </InfoCard>
//           </div>

//           <div className="col-lg-4 col-md-3 mb-4"style={{ padding: '0 2px' }}>
//             <InfoCard gradient="">
//             <ImageContainer>
//                 <img src="teacherr.png" alt="Staff" />
//               </ImageContainer>
//               <InfoText>
//                 <strong>Teaching </strong>
//                 <div>{workingStaff}</div>
//               </InfoText>
//             </InfoCard>
//           </div>
//         </div>

//         <div className="row"   style={{ marginTop: '-3vh'  }}>
//           <div className="col-lg-4"style={{ padding: '0 2px' }}>
//             <Card style={{ height: '35vh',  borderRadius: '16px', }}>
//               <Heading>Student Ratio</Heading>
//               <GirlBoy />
//             </Card>
//           </div>

//           <div className="col-lg-4"style={{ padding: '0 2px' }}>
//             <Card style={{ height: '35vh',  borderRadius: '16px' }}>
//               <Heading>Student Attendance</Heading>
//               <DashbordStudentAttendance />
//             </Card>
//           </div>

//           <div className="col-lg-4"style={{ padding: '0 2px' }}>
//             <Card style={{ height: '35vh', borderRadius: '16px' }}>
//               <Heading>Staff Attendance</Heading>
//               <DashBoardStaffAttendance />
//             </Card>
//           </div>
//         </div>


//         <div className="row"  style={{ marginTop: '-8vh',}}>

//         <div className="col-lg-4 "style={{ padding: '0 2px' }}>
//             <Card style={{ height: '74vh',  borderRadius: '16px' }}>
//               <Heading>Event Calendar</Heading>
//               <EventCalender />
//             </Card>
//           </div>
//               <div className="col-lg-4"style={{ padding: '0 2px' }}>
//             <Card style={{ height: '54vh',  borderRadius: '16px' }}>
//               <Heading>Student Performance</Heading>
//               <PerformanceSummary />
//             </Card>
//           </div>


//           <div className="col-lg-4"style={{ padding: '0 2px' }}>
//             <Card style={{ height: '54vh',  borderRadius: '16px' }}>
//               <Heading> Notice Board</Heading>
//               <NoticeBoard />
//             </Card>
//           </div>
         
       
//           <div className="row"  style={{ marginTop: '-7vh',}}>
//           <div className="col-lg-17"style={{ padding: '0 2px' }}>
//     <Card style={{ height: '52vh', borderRadius: '16px',  }}>
//       <Heading>Time Table Schedule</Heading>
//       <TimeTableschedule />
//     </Card>
 
// </div>

// {/* <div className="col-lg-4"style={{ padding: '0 2px' }}>
//     <Card style={{ height: '52vh', borderRadius: '16px',  }}>
//       <Heading>Message</Heading>
//       <Messages />
//     </Card>
 
// </div> */}
// </div>


//         </div>
//       </div>
//     </Container>
 
//   );
// };

// export default Dashboard;






import React, { useState, useEffect } from 'react';
import axios from 'axios';
import styled from 'styled-components';
import PerformanceSummary from './Dashbord_Performance_Summary';
import EventCalender from './Event_Calender';
import DashBoardStaffAttendance from './Staff_Attendance_Chart';
import DashbordStudentAttendance from './Student_Attendance_Chart';
import GirlBoy from './Girl_Boy.js';
import TimeTableschedule from './Time_Table_schedule.js';
import NoticeBoard from './Notice_Board.js';
 
import 'bootstrap/dist/css/bootstrap.min.css';
 
// Styled components with responsive styling
const Container = styled.div`
  padding-top: 10px;
  min-height: 100vh;
  padding: 0 20px;
  max-width: 100%;
  margin: 0 auto;
  background-color: #F0F6FA;
 
  @media (max-width: 1200px) {
    max-width: 1000px;
  }
  @media (max-width: 992px) {
    max-width: 800px;
  }
  @media (max-width: 768px) {
    padding: 0 10px;
  }
  @media (max-width: 576px) {
    padding: 0 5px;
  }
`;
 
const Card = styled.div`
  background-color: #ffffff;
  border: 2px solid #ccc;
  border-radius: 4px;
  padding: 0px;
  margin-bottom: 15%;
  min-height: 0;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  transition: transform 0.3s ease, box-shadow 0.3s ease;
 
  @media (max-width: 768px) {
    padding: 15px;
    min-height: 250px;
  }
`;
 
const InfoText = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  color: #333;
  margin: 0 auto;
  text-align: center;
  height: 6%;
 
  strong {
    font-size: 1.3rem;
    color: #6c757d;
    font-weight: 500;
  }
 
  div {
    font-size: 1.3rem;
    color: #333;
    font-weight: bold;
  }
 
  @media (max-width: 768px) {
    font-size: 1.2rem;
    padding: 10px;
  }
`;
 
const InfoCard = styled.div`
  display: flex;
  align-items: center;
  padding: 10px;
  margin: 10px 0;
  border-radius: 6px;
  background: white;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
  transition: transform 0.3s ease, box-shadow 0.3s ease;
  cursor: pointer;
 
  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
  }
 
  @media (max-width: 768px) {
    flex-direction: column;
    text-align: center;
  }
`;
 
const ImageContainer = styled.div`
  width: 60px;
  height: 60px;
  overflow: hidden;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-right: 15px;
 
  img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    display: block;
  }
`;
 
const Heading = styled.h3`
  font-size: 1.1rem;
  font-weight: 600;
  font-family: 'Lato', sans-serif;
  color: #333;
  margin-bottom: 30px;
  padding: 5px 10px;
  border-radius: 12px;
  display: inline-block;
  background: linear-gradient(135deg, #f0f0f0, #e0e0e0);
  border-bottom: 1px solid #b0b0b0;
  transition: transform 0.3s ease, box-shadow 0.3s ease, background 0.3s ease;
 
  @media (max-width: 400px) {
    font-size: 1.2rem;
    padding: 8px 16px;
    margin-bottom: 20px;
  }
`;
 
const Dashboard = () => {
  const [totalStudents, setTotalStudents] = useState(0);
  const [totalStaff, setTotalStaff] = useState(0);
  const [workingStaff, setWorkingStaff] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
 
  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const responses = await Promise.all([
          axios.get('http://13.127.57.224:2081/api/studentcountdetails'),
          axios.get('http://13.127.57.224:2081/api/staffcount'),
          axios.get('http://13.127.57.224:2081/api/workingStaff')
        ]);
 
        const [responseStudents, responseStaff, responseWorkingStaff] = responses;
 
        setTotalStudents(responseStudents.data.totalStudents);
        setTotalStaff(responseStaff.data.totalStaff);
        setWorkingStaff(responseWorkingStaff.data.workingStaff);
      } catch (error) {
        setError(error.message);
      } finally {
        setLoading(false);
      }
    };
 
    fetchData();
  }, []);
 
  if (loading) return <div>Loading...</div>;
  if (error) return <div>{error}</div>;
 
  return (
    <Container className="container-fluid py-1">
      <div className="container-fluid" style={{ marginTop: '4vh', width: '100%', padding: 0 }}>
        <div className="row">
          <div className="col-lg-4 col-md- mb-" style={{ padding: '0 2px' }}>
            <InfoCard>
              <ImageContainer>
                <img src="girl.png" alt="Students" />
              </ImageContainer>
              <InfoText>
                <strong>Students</strong>
                <div>{totalStudents}</div>
              </InfoText>
            </InfoCard>
          </div>
 
          <div className="col-lg-4 col-md-3 mb-4" style={{ padding: '0 2px' }}>
            <InfoCard>
              <ImageContainer>
                <img src="Baby.png" alt="Staff" />
              </ImageContainer>
              <InfoText>
                <strong>Staff</strong>
                <div>{totalStaff}</div>
              </InfoText>
            </InfoCard>
          </div>
 
          <div className="col-lg-4 col-md-3 mb-4" style={{ padding: '0 2px' }}>
            <InfoCard>
              <ImageContainer>
                <img src="teacherr.png" alt="Teaching Staff" />
              </ImageContainer>
              <InfoText>
                <strong>Teaching</strong>
                <div>{workingStaff}</div>
              </InfoText>
            </InfoCard>
          </div>
        </div>
 
        <div className="row" style={{ marginTop: '-3vh' }}>
          <div className="col-lg-4" style={{ padding: '0 2px' }}>
            <Card style={{ height: '35vh', borderRadius: '16px' }}>
              <Heading>Student Ratio</Heading>
              <GirlBoy />
            </Card>
          </div>
 
          <div className="col-lg-4" style={{ padding: '0 2px' }}>
            <Card style={{ height: '35vh', borderRadius: '16px' }}>
              <Heading>Student Attendance</Heading>
              <DashbordStudentAttendance />
            </Card>
          </div>
 
          <div className="col-lg-4" style={{ padding: '0 2px' }}>
            <Card style={{ height: '35vh', borderRadius: '16px' }}>
              <Heading>Staff Attendance</Heading>
              <DashBoardStaffAttendance />
            </Card>
          </div>
        </div>
 
        <div className="row" style={{ marginTop: '-8vh' }}>
          <div className="col-lg-4" style={{ padding: '0 2px' }}>
            <Card style={{ height: '54vh', borderRadius: '16px' }}>
              <Heading>Event Calendar</Heading>
              <EventCalender />
            </Card>
          </div>
 
          <div className="col-lg-4" style={{ padding: '0 2px' }}>
            <Card style={{ height: '54vh', borderRadius: '16px' }}>
              <Heading>Student Performance</Heading>
              <PerformanceSummary />
            </Card>
          </div>
 
          <div className="col-lg-4" style={{ padding: '0 2px' }}>
            <Card style={{ height: '54vh', borderRadius: '16px' }}>
              <Heading>Notice Board</Heading>
              <NoticeBoard />
            </Card>
          </div>
        </div>
 
        <div className="row" style={{ marginTop: '-7vh' }}>
          <div className="col-lg-12" style={{ padding: '0 2px' }}>
            <Card style={{ height: '52vh', borderRadius: '16px' }}>
              <Heading>Time Table Schedule</Heading>
              <TimeTableschedule />
            </Card>
          </div>
        </div>
      </div>
    </Container>
  );
};
 
export default Dashboard;
 
