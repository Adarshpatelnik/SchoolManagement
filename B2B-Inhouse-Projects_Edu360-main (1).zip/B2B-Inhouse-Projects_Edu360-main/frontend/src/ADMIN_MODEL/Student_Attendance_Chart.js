
// import React, { useEffect, useState } from 'react';
// import axios from 'axios';
// import { AgCharts } from 'ag-charts-react';
// import styled from 'styled-components';
// import 'bootstrap/dist/css/bootstrap.min.css';

// const FilterChartContainer = styled.div`
//   display: flex;
//   flex-direction: column;
//   align-items: center;
//   margin-top: -1.5rem;
//   width: 100%;
// `;

// const CombinedContainer = styled.div`
//   display: flex;
//   flex-direction: column;
//   width: 100%;
// `;

// const SelectContainer = styled.div`
//   display: flex;
//   justify-content: center;
//   gap: 10px;
//   margin-bottom: 1rem;
// `;

// const Select = styled.select`
//   width: 100%;
//   max-width: 200px;
//   padding: 5px;
//   border: 1px solid black;
//   border-radius: 5px;
//   font-size: 12px;
//   background-color: #f0f4f8;
//   box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.1);
//   transition: 0.3s ease;
//   margin: 0 10px; /* Add margin to create space between dropdowns */

//   &:focus {
//     border-color: #5fa8d3;
//     outline: none;
//   }
// `;

// const ChartContainer = styled.div`
//   display: flex;
//   justify-content: center;
//   align-items: flex-start;
//   flex-direction: column;
//   width: 100%;
//   margin-bottom: 0.4rem;
//   height: 30vh;
// `;

// const DashbordStudentAttendance = () => {
//   const [attendanceData, setAttendanceData] = useState([]);
//   const [filteredData, setFilteredData] = useState([]);
//   const [classes, setClasses] = useState([]);
//   const [dates, setDates] = useState([]);
//   const [sessions, setSessions] = useState([]);
//   const [selectedClass, setSelectedClass] = useState('');
//   const [selectedDate, setSelectedDate] = useState('');
//   const [selectedSession, setSelectedSession] = useState('');

//   useEffect(() => {
//     const fetchAttendanceData = async () => {
//       try {
//         const response = await axios.get('http://13.127.57.224:2081/api/studentattendance');
//         const data = response.data.map(record => ({
//           ...record,
//           DATE: new Date(record.DATE).toLocaleDateString(),
//         }));
//         setAttendanceData(data);

//         const uniqueClasses = [...new Set(data.map(record => record.CLASS))];
//         const uniqueDates = [...new Set(data.map(record => record.DATE))];
//         const uniqueSessions = [...new Set(data.map(record => record.SESSION))];

//         setClasses(uniqueClasses);
//         setDates(uniqueDates);
//         setSessions(uniqueSessions);
//       } catch (error) {
//         console.error('Error fetching student attendance data:', error);
//       }
//     };

//     fetchAttendanceData();
//   }, []);

//   const handleClassChange = (e) => setSelectedClass(e.target.value);
//   const handleDateChange = (e) => setSelectedDate(e.target.value);
//   const handleSessionChange = (e) => setSelectedSession(e.target.value);

//   useEffect(() => {
//     let filtered = attendanceData;

//     if (selectedClass) {
//       filtered = filtered.filter(record => record.CLASS === selectedClass);
//     }
//     if (selectedDate) {
//       filtered = filtered.filter(record => record.DATE === selectedDate);
//     }
//     if (selectedSession) {
//       filtered = filtered.filter(record => record.SESSION === selectedSession);
//     }

//     setFilteredData(filtered);
//   }, [selectedClass, selectedDate, selectedSession, attendanceData]);

//   const processData = (data) => {
//     const statusCount = data.reduce((acc, record) => {
//       acc[record.STATUS] = (acc[record.STATUS] || 0) + 1;
//       return acc;
//     }, {});

//     return Object.entries(statusCount).map(([key, value]) => ({
//       label: `${key}: ${value}`, // Combine label and count
//       value,
//     }));
//   };

//   const chartData = processData(filteredData);

//   const donutChartOptions = {
//     data: chartData,
//     series: [
//       {
//         type: 'pie',
//         legendItemKey: 'label',       
//          angleKey: 'value',
//         innerRadiusRatio: 0.7,
//         fills: ['#27AE60', '#012353', '#E0E0E0', '#F7B7A3', '#F0E3E4'],
//         strokes: ['#FFFFFF'],
//       },
//     ],
//     tooltip: {
//       renderer: ({ datum }) => `${datum.name}: ${datum.value} (${datum.percentage})`,
//     },
//     legend: {
//       enabled: true,
//       position: 'right',
//       item: {
//         label: {
//           fontSize: 10,
//           color: '#000',
//         },
//       },
//     },
//   };

//   return (
//     <FilterChartContainer>
//       <CombinedContainer>
//         <SelectContainer>
//           <Select value={selectedClass} onChange={handleClassChange}>
//             <option value="">Class</option>
//             {classes.map((classItem, index) => (
//               <option key={index} value={classItem}>{classItem}</option>
//             ))}
//           </Select>
//           <Select value={selectedDate} onChange={handleDateChange}>
//             <option value="">Date</option>
//             {dates.map((dateItem, index) => (
//               <option key={index} value={dateItem}>{dateItem}</option>
//             ))}
//           </Select>
//           <Select value={selectedSession} onChange={handleSessionChange}>
//             <option value="">Session</option>
//             {sessions.map((sessionItem, index) => (
//               <option key={index} value={sessionItem}>{sessionItem}</option>
//             ))}
//           </Select>
//         </SelectContainer>
//         <ChartContainer>
//           <AgCharts options={donutChartOptions} style={{ width: '100%', height: '22vh', marginTop: '-12vh' }} />
//         </ChartContainer>
//       </CombinedContainer>
//     </FilterChartContainer>
//   );
// };

// export default DashbordStudentAttendance;



// import React, { useEffect, useState, useRef } from 'react';
// import axios from 'axios';
// import { AgCharts } from 'ag-charts-react';
// import styled from 'styled-components';
// import 'bootstrap/dist/css/bootstrap.min.css';
// import { FaEllipsisV } from 'react-icons/fa'; // Import the three-dot icon

// const FilterChartContainer = styled.div`
//   display: flex;
//   flex-direction: column;
//   align-items: center;
//   margin-top: -1.5rem;
//   width: 100%;
// `;

// const CombinedContainer = styled.div`
//   display: flex;
//   flex-direction: column;
//   align-items: flex-end; /* Align items to the right */
//   width: 100%;
//   position: relative; /* Allow for absolute positioning of the dropdown */
// `;

// const SelectContainer = styled.div`
//   display: flex;
//   justify-content: center;
//   gap: 10px;
//   margin-bottom: 1rem;
// `;

// const Select = styled.select`
//   width: 100%;
//   max-width: 200px;
//   padding: 5px;
//   border: 1px solid black;
//   border-radius: 5px;
//   font-size: 12px;
//   background-color: #f0f4f8;
//   box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.1);
//   transition: 0.3s ease;
//   margin: 0 10px; /* Add margin to create space between dropdowns */

//   &:focus {
//     border-color: #5fa8d3;
//     outline: none;
//   }
// `;

// const ChartContainer = styled.div`
//   display: flex; /* Use flex to arrange icon and chart horizontally */
//   justify-content: flex-end; /* Align items to the right */
//   align-items: flex-start; /* Align items at the top */
//   width: 100%;
//   margin-bottom: 0.4rem;
//   height: 40vh;
//   position: relative; /* Allow for absolute positioning of the dropdown */
// `;

// const ChartWrapper = styled.div`
//   flex: 1; /* Allow the chart to take available space */
//   margin-right: 1rem; /* Add space between the chart and the icon */
// `;

// const DropdownContainer = styled.div`
//   position: absolute;
//   right: 0; /* Position the dropdown to the right */
//   background-color: white;
//   border: 1px solid #ccc;
//   box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.2);
//   padding: 10px;
//   z-index: 10;
//   flex-direction: column; /* Stack dropdown items vertically */
// `;


// const MenuIcon = styled(FaEllipsisV)`
//   cursor: pointer;
//   font-size: 24px;
//   z-index: 10; /* Ensure the icon is above other elements */
// `;

// const DropdownItem = styled.div`
//   margin: 5px 0;
// `;

// const DashbordStudentAttendance = () => {
//   const [attendanceData, setAttendanceData] = useState([]);
//   const [filteredData, setFilteredData] = useState([]);
//   const [classes, setClasses] = useState([]);
//   const [dates, setDates] = useState([]);
//   const [sessions, setSessions] = useState([]);
//   const [selectedClass, setSelectedClass] = useState('');
//   const [selectedDate, setSelectedDate] = useState('');
//   const [selectedSession, setSelectedSession] = useState('');
//   const [dropdownVisible, setDropdownVisible] = useState(false); // State to control dropdown visibility

//   const dropdownRef = useRef(null); // Ref for the dropdown

//   useEffect(() => {
//     const fetchAttendanceData = async () => {
//       try {
//         const response = await axios.get('http://13.127.57.224:2081/api/studentattendance');
//         const data = response.data.map(record => ({
//           ...record,
//           DATE: new Date(record.DATE).toLocaleDateString(),
//         }));
//         setAttendanceData(data);

//         const uniqueClasses = [...new Set(data.map(record => record.CLASS))];
//         const uniqueDates = [...new Set(data.map(record => record.DATE))];
//         const uniqueSessions = [...new Set(data.map(record => record.SESSION))];

//         setClasses(uniqueClasses);
//         setDates(uniqueDates);
//         setSessions(uniqueSessions);
//       } catch (error) {
//         console.error('Error fetching student attendance data:', error);
//       }
//     };

//     fetchAttendanceData();
//   }, []);

//   const handleClassChange = (e) => setSelectedClass(e.target.value);
//   const handleDateChange = (e) => setSelectedDate(e.target.value);
//   const handleSessionChange = (e) => setSelectedSession(e.target.value);

//   useEffect(() => {
//     let filtered = attendanceData;

//     if (selectedClass) {
//       filtered = filtered.filter(record => record.CLASS === selectedClass);
//     }
//     if (selectedDate) {
//       filtered = filtered.filter(record => record.DATE === selectedDate);
//     }
//     if (selectedSession) {
//       filtered = filtered.filter(record => record.SESSION === selectedSession);
//     }

//     setFilteredData(filtered);
//   }, [selectedClass, selectedDate, selectedSession, attendanceData]);

//   const processData = (data) => {
//     const statusCount = data.reduce((acc, record) => {
//       acc[record.STATUS] = (acc[record.STATUS] || 0) + 1;
//       return acc;
//     }, {});

//     return Object.entries(statusCount).map(([key, value]) => ({
//       label: `${key}: ${value}`, // Combine label and count
//       value,
//     }));
//   };

//   const chartData = processData(filteredData);

//   const donutChartOptions = {
//     data: chartData,
//     series: [
//       {
//         type: 'donut',
//         calloutLabelKey: 'label',
//         fontSize: 10,
//         angleKey: 'value',
//         innerRadiusRatio: 0.7,
        

//         fills: ['#27AE60', '#012353', '#E0E0E0', '#F7B7A3', '#F0E3E4'],
//         strokes: ['#FFFFFF'],
//       },
//     ],
//     tooltip: {
//       renderer: ({ datum }) => `${datum.label}: ${datum.value} (${((datum.value / chartData.reduce((acc, curr) => acc + curr.value, 0)) * 100).toFixed(2)}%)`, // Display percentage
//     },
//     legend: {
//       enabled: false,
//       position: 'left',
//       item: {
//         label: {
//           fontSize: 10,
//           color: '#000',
//         },
//       },
//     },
//   };

//   useEffect(() => {
//     const handleClickOutside = (event) => {
//       if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
//         setDropdownVisible(false);
//       }
//     };

//     // Add event listener for clicks
//     document.addEventListener('mousedown', handleClickOutside);
//     return () => {
//       document.removeEventListener('mousedown', handleClickOutside);
//     };
//   }, []);

//   return (
//     <FilterChartContainer>
//     <CombinedContainer>
//       <ChartContainer>
//         <ChartWrapper>
//           <AgCharts options={donutChartOptions}  style={{ width: '100%', height: '28vh', marginTop: '0vh' }}  />
//         </ChartWrapper>
//         <MenuIcon onClick={() => setDropdownVisible(!dropdownVisible)} />
//         {dropdownVisible && (
//           <DropdownContainer ref={dropdownRef}>
//               <DropdownItem>
//                 <Select value={selectedClass} onChange={handleClassChange}>
//                   <option value="">Class</option>
//                   {classes.map((classItem, index) => (
//                     <option key={index} value={classItem}>{classItem}</option>
//                   ))}
//                 </Select>
//               </DropdownItem>
//               <DropdownItem>
//                 <Select value={selectedDate} onChange={handleDateChange}>
//                   <option value="">Date</option>
//                   {dates.map((dateItem, index) => (
//                     <option key={index} value={dateItem}>{dateItem}</option>
//                   ))}
//                 </Select>
//               </DropdownItem>
//               <DropdownItem>
//                 <Select value={selectedSession} onChange={handleSessionChange}>
//                   <option value="">Session</option>
//                   {sessions.map((sessionItem, index) => (
//                     <option key={index} value={sessionItem}>{sessionItem}</option>
//                   ))}
//                 </Select>
//               </DropdownItem>
//               </DropdownContainer>
//         )}
//       </ChartContainer>
//     </CombinedContainer>
//   </FilterChartContainer>
//   )
// };

// export default DashbordStudentAttendance;




import React, { useEffect, useState, useRef } from 'react';
import axios from 'axios';
import { AgCharts } from 'ag-charts-react';
import styled from 'styled-components'
import 'bootstrap/dist/css/bootstrap.min.css';
import { FaEllipsisV } from 'react-icons/fa';
import './Admin_Model.css';
 
const DashbordStudentAttendance = () => {
  const [attendanceData, setAttendanceData] = useState([]);
  const [filteredData, setFilteredData] = useState([]);
  const [classes, setClasses] = useState([]);
  const [dates, setDates] = useState([]);
  const [sessions, setSessions] = useState([]);
  const [selectedClass, setSelectedClass] = useState('');
  const [selectedDate, setSelectedDate] = useState('');
  const [selectedSession, setSelectedSession] = useState('');
  const [dropdownVisible, setDropdownVisible] = useState(false);
 
  const dropdownRef = useRef(null);
 
  useEffect(() => {
    const fetchAttendanceData = async () => {
      try {
        const response = await axios.get('http://13.127.57.224:2081/api/studentattendance');
        const data = response.data.map(record => ({
          ...record,
          DATE: new Date(record.DATE).toLocaleDateString(),
        }));
        setAttendanceData(data);
 
        const uniqueClasses = [...new Set(data.map(record => record.CLASS))];
        const uniqueDates = [...new Set(data.map(record => record.DATE))];
        const uniqueSessions = [...new Set(data.map(record => record.SESSION))];
 
        setClasses(uniqueClasses);
        setDates(uniqueDates);
        setSessions(uniqueSessions);
      } catch (error) {
        console.error('Error fetching student attendance data:', error);
      }
    };
 
    fetchAttendanceData();
  }, []);
 
  const handleClassChange = (e) => setSelectedClass(e.target.value);
  const handleDateChange = (e) => setSelectedDate(e.target.value);
  const handleSessionChange = (e) => setSelectedSession(e.target.value);
 
  useEffect(() => {
    let filtered = attendanceData;
 
    if (selectedClass) {
      filtered = filtered.filter(record => record.CLASS === selectedClass);
    }
    if (selectedDate) {
      filtered = filtered.filter(record => record.DATE === selectedDate);
    }
    if (selectedSession) {
      filtered = filtered.filter(record => record.SESSION === selectedSession);
    }
 
    setFilteredData(filtered);
  }, [selectedClass, selectedDate, selectedSession, attendanceData]);
 
  const processData = (data) => {
    const statusCount = data.reduce((acc, record) => {
      acc[record.STATUS] = (acc[record.STATUS] || 0) + 1;
      return acc;
    }, {});
 
    return Object.entries(statusCount).map(([key, value]) => ({
      label: `${key}: ${value}`,
      value,
    }));
  };
 
  const chartData = processData(filteredData);
 
  const donutChartOptions = {
    data: chartData,
    series: [
      {
        type: 'donut',
        calloutLabelKey: 'label',
        angleKey: 'value',
        innerRadiusRatio: 0.7,
        fills: ['#27AE60', '#012353', '#E0E0E0', '#F7B7A3', '#F0E3E4'],
        strokes: ['#FFFFFF'],
      },
    ],
    tooltip: {
      renderer: ({ datum }) => `${datum.label}: ${datum.value} (${((datum.value / chartData.reduce((acc, curr) => acc + curr.value, 0)) * 100).toFixed(2)}%)`,
    },
    legend: {
      enabled: false,
      position: 'right',
      item: {
        label: {
          fontSize: 10,
          color: '#000',
        },
      },
    },
  };
 
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setDropdownVisible(false);
      }
    };
 
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);
 
  return (
    <div className="Student_Attendance_FilterChartContainer">
      <div className="Student_Attendance_CombinedContainer">
        <div className="Student_Attendance_ChartContainer">
          <div className="Student_Attendance_ChartWrapper">
            <AgCharts options={donutChartOptions} style={{ width: '100%', height: '26vh', marginTop: '0.2vh' }} />
          </div>
          <FaEllipsisV className="Student_Attendance_MenuIcon" onClick={() => setDropdownVisible(!dropdownVisible)} />
          {dropdownVisible && (
            <div className="Student_Attendance_DropdownContainer" ref={dropdownRef}>
              <div className="Student_Attendance_DropdownItem">
                <select className="Student_Attendance_Select" value={selectedClass} onChange={handleClassChange}>
                  <option value="">Class</option>
                  {classes.map((classItem, index) => (
                    <option key={index} value={classItem}>{classItem}</option>
                  ))}
                </select>
              </div>
              <div className="Student_Attendance_DropdownItem">
                <select className="Student_Attendance_Select" value={selectedDate} onChange={handleDateChange}>
                  <option value="">Date</option>
                  {dates.map((dateItem, index) => (
                    <option key={index} value={dateItem}>{dateItem}</option>
                  ))}
                </select>
              </div>
              <div className="Student_Attendance_DropdownItem">
                <select className="Student_Attendance_Select" value={selectedSession} onChange={handleSessionChange}>
                  <option value="">Session</option>
                  {sessions.map((sessionItem, index) => (
                    <option key={index} value={sessionItem}>{sessionItem}</option>
                  ))}
                </select>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
 
export default DashbordStudentAttendance;
 
