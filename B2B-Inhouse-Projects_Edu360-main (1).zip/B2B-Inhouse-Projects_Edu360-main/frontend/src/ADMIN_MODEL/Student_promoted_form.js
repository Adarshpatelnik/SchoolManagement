// import React, { useState, useEffect } from 'react';
// import axios from 'axios';
// import 'bootstrap/dist/css/bootstrap.min.css';
// // import Landing  from '/home/ec2-user/Edu360/SchoolManagement/frontend/src/ADMIN_MODEL/Landing.js';

// const StudentPromote = () => {
//   const [students, setStudents] = useState([]);
//   const [selectedStudents, setSelectedStudents] = useState([]);
//   const [selectAll, setSelectAll] = useState(false);
//   const [searchTerm, setSearchTerm] = useState('');
//   const [classFilter, setClassFilter] = useState('');
//   const [academicyearFilter, setacademicyearFilter] = useState('');
//   const [statusFilter, setStatusFilter] = useState('');
//   const [classes, setClasses] = useState([]);
//   const [academicyears, setacademicyears] = useState([]);
//   const [statuses, setStatuses] = useState([]);
//   const [loading, setLoading] = useState(false);
//   const [promotedStudents, setPromotedStudents] = useState([]);

//   useEffect(() => {
//     const fetchOptionsAndStudents = async () => {
//       setLoading(true);
//       try {
//         const response = await axios.get('http://13.127.57.224:2081/api/options');
//         setClasses(response.data.classes);
//         setacademicyears(response.data.academicyears);
//         setStatuses(response.data.statuses);
//         await fetchStudents();
//       } catch (error) {
//         console.error('Error fetching options or students:', error);
//       } finally {
//         setLoading(false);
//       }
//     };

//     fetchOptionsAndStudents();
//   }, [classFilter, academicyearFilter, statusFilter]);

//   useEffect(() => {
//     const style = document.createElement('style');
//     style.textContent = `
//       body, h1, h2, h3, h4, h5, h6, p, a, input, button, th, td, label, select {
//         font-family: 'Arial', sans-serif;
//       }
//       .header-input {
//         background-color: #009CE0;
//         color: white;
//         border: 2px solid #ccc;
//         padding: 5px;
//         border-radius: 3px;
//         box-shadow: inset 0 1px 2px rgba(234, 218, 218, 0.1);
//         text-align: center;
//         margin-right: 15px;
//       }
//       .header-input::placeholder {
//         color: white;
//       }
//       .filter-dropdown, .search-box {
//         width: 140px;
//         margin-right: 15px;
//       }
//       .filter-container label {
//         margin-right: 5px;
//       }
//       .table-container {
//         display: flex;
//         justify-content: center;
//       }
//       .table {
//         margin: 0 auto;
//         width: 100%;
//       }
//       .table th {
//         border: 1px solid black;
//         padding: 4px;
//         text-align: center;
//         white-space: nowrap;
//         overflow-y: auto;
//         text-overflow: ellipsis;
//         background-color: #D5DBDB;
//         color: black;
//         font-weight: bold;
//         height: 40px;
//         box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
//         transition: background-color 0.3s ease;
//       }
//       .table td {
//         border: 1px solid black;
//         padding: 7px;
//         white-space: nowrap;
//         text-align: left;
//         overflow-y: auto;
//         text-overflow: ellipsis;
//       }
//       .sticky-header th {
//         position: sticky;
//         top: 0;
//         z-index: 999;
//         background-color: #D5DBDB;
//         border: 1px solid black;
//       }
//       .table-container {
//         max-height: 68vh;
//         overflow-y: auto;
//          marginLeft: vh;
//       }
//       `;
//     document.head.appendChild(style);
//     return () => {
//       document.head.removeChild(style);
//     };
//   }, []);

//   const fetchStudents = async () => {
//     try {
//       const response = await axios.get('http://13.127.57.224:2081/api/promotestudent', {
//         params: {
//           classFilter: classFilter || undefined,
//           academicyearFilter: academicyearFilter || undefined,
//           statusFilter: statusFilter || undefined
//         }
//       });
//       setStudents(response.data);
//     } catch (error) {
//       console.error('Error fetching students:', error);
//     }
//   };

//   const handleSelectAll = () => {
//     setSelectedStudents(selectAll ? [] : students.filter(student => student.PERCENT > 40 && !promotedStudents.includes(student.STUDENT_ID)).map(student => student.STUDENT_ID));
//     setSelectAll(!selectAll);
//   };

//   const handleSelectStudent = (studentId) => {
//     setSelectedStudents(prevSelected => {
//       if (promotedStudents.includes(studentId)) {
//         return prevSelected; // Do not allow selecting already promoted students
//       }

//       if (prevSelected.includes(studentId)) {
//         return prevSelected.filter(id => id !== studentId);
//       } else {
//         return [...prevSelected, studentId];
//       }
//     });
//   };

//   const handlePromoteStudents = async () => {
//     try {
//       await axios.post('http://13.127.57.224:2081/api/promoteStudents', { selectedStudents });
//       // Update the local state to track promoted students
//       setPromotedStudents([...promotedStudents, ...selectedStudents]);
//       fetchStudents();
//       setSelectedStudents([]);
//       setSelectAll(false);
//       alert('Students promoted successfully!');
//     } catch (error) {
//       console.error('Error promoting students:', error);
//       alert('Error promoting students. Please try again.');
//     }
//   };

//   const handlePromoteFailStudents = async () => {
//     try {
//       await axios.post('http://13.127.57.224:2081/api/changeFailSession', { studentIds: selectedStudents, newacademicyear: '2024-2025' });
//       // Refresh the students list
//       fetchStudents();
//       alert('Fail students academicyear updated successfully!');
//     } catch (error) {
//       console.error('Error updating fail students:', error);
//       alert('Error updating fail students. Please try again.');
//     }
//   };
  
// const handleSearchChange = (event) => {
//     setSearchTerm(event.target.value);
//   };

//   const filteredStudents = students.filter(student => {
//     return (
//       (!searchTerm || student.STUDENT_NAME.toLowerCase().includes(searchTerm.toLowerCase())) &&
//       (!classFilter || student.CLASS === classFilter) &&
//       (!academicyearFilter || student.ACADEMIC_YEAR === academicyearFilter) &&
//       (!statusFilter || student.STATUS === statusFilter)
//     );
//   });

//   const hasFilteredStudents = searchTerm || classFilter || academicyearFilter || statusFilter;
//   const hasFailStudents = filteredStudents.some(student => student.PERCENT <= 40);

//   return (
//     <div className="container ">
            

//       <div className="container-fluid" style={{  marginTop: '8vh', width: '100%', padding: 0 }}>
      
//         <div className="mb-4">
//           <div className="row">
//             <div className="col-md-3 mb-2">
//               <input
//                 type="text"
//                 className="form-control"
//                 placeholder="Student Name"
//                 value={searchTerm}
//                 onChange={handleSearchChange}
//               />
//             </div>
//             <div className="col-md-2 mb-2">
//               <select
//                 className="form-control"
//                 value={classFilter}
//                 onChange={(e) => setClassFilter(e.target.value)}
//               >
//                 <option value="">Class</option>
//                 {classes.map(cls => <option key={cls} value={cls}>{cls}</option>)}
//               </select>
//             </div>
//             <div className="col-md-2 mb-2">
//               <select
//                 className="form-control"
//                 value={academicyearFilter}
//                 onChange={(e) => setacademicyearFilter(e.target.value)}
//               >
//                 <option value="">academicyear</option>
//                 {academicyears.map(aca => <option key={aca} value={aca}>{aca}</option>)}
//               </select>
//             </div>
//             <div className="col-md-2 mb-2">
//               <select
//                 className="form-control"
//                 value={statusFilter}
//                 onChange={(e) => setStatusFilter(e.target.value)}
//               >
//                 <option value="">Status</option>
//                 {statuses.map(stat => <option key={stat} value={stat}>{stat}</option>)}
//               </select>
//             </div>
//             <div className="col-md-2 mb-1">
//               <button
//                 className="btn btn-primary"
//                 onClick={handlePromoteStudents}
//                 style={{ background: 'darkblue', border: 'none' }}
//                 disabled={selectedStudents.length === 0}
//               >
//                 Promote Selected
//               </button>
//             </div>
//           </div>
//         </div>
//         <div className="table-container">
//           <table className="table table-bordered table-striped table-hover">
//             <thead className="sticky-header">
//               <tr>
//                 <th>
//                   <input
//                     type="checkbox"
//                     checked={selectAll}
//                     onChange={handleSelectAll}
//                   />
//                 </th>
//                 <th>Student ID</th>
//                 <th>Student Name</th>
//                 <th>Academic Year</th>
//                 <th>Class</th>
//                 <th>Percent</th>
//                 <th>Result</th>
//               </tr>
//             </thead>
//             <tbody>
//               {filteredStudents.map((student) => (
//                 <tr key={student.STUDENT_ID}>
//                   <td>
//                     <input
//                       type="checkbox"
//                       disabled={statusFilter === 'Fail' && student.PERCENT > 40 || promotedStudents.includes(student.STUDENT_ID)}
//                       checked={selectedStudents.includes(student.STUDENT_ID)}
//                       onChange={() => handleSelectStudent(student.STUDENT_ID)}
//                     />
//                   </td>
//                   <td>{student.STUDENT_ID}</td>
//                   <td>{student.STUDENT_NAME}</td>
//                   <td>{student.ACADEMIC_YEAR}</td>
//                   <td>{student.CLASS}</td>
//                   <td>{student.PERCENT}</td>
//                   <td>
//                     <span
//                       style={{
//                         color: student.PERCENT > 40 ? 'green' : 'red',
//                         fontWeight: 'bold',
//                         fontSize: '1.1rem'
//                       }}
//                     >
//                       {student.PERCENT > 40 ? 'Pass' : 'Fail'}
//                     </span>
//                   </td>
//                 </tr>
//               ))}
//             </tbody>
//           </table>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default StudentPromote;















// import React, { useState, useEffect } from 'react';
// import axios from 'axios';
// import 'bootstrap/dist/css/bootstrap.min.css';

// const StudentPromote = () => {
//   const [students, setStudents] = useState([]);
//   const [selectedStudents, setSelectedStudents] = useState([]);
//   const [selectAll, setSelectAll] = useState(false);
//   const [searchTerm, setSearchTerm] = useState('');
//   const [classFilter, setClassFilter] = useState('');
//   const [academicyearFilter, setacademicyearFilter] = useState('');
//   const [statusFilter, setStatusFilter] = useState('');
//   const [classes, setClasses] = useState([]);
//   const [academicyears, setacademicyears] = useState([]);
//   const [statuses, setStatuses] = useState([]);
//   const [loading, setLoading] = useState(false);
//   const [promotedStudents, setPromotedStudents] = useState([]);

//   useEffect(() => {
//     const fetchOptionsAndStudents = async () => {
//       setLoading(true);
//       try {
//         const response = await axios.get('http://13.127.57.224:2081/api/options');
//         setClasses(response.data.classes);
//         setacademicyears(response.data.academicyears);
//         setStatuses(response.data.statuses);
//         await fetchStudents(); // Fetch students once the options are set
//       } catch (error) {
//         console.error('Error fetching options or students:', error);
//       } finally {
//         setLoading(false);
//       }
//     };

//     fetchOptionsAndStudents();
//   }, []);

//   useEffect(() => {
//     fetchStudents();
//   }, [classFilter, academicyearFilter, statusFilter]);

//   useEffect(() => {
//     const style = document.createElement('style');
//     style.textContent = `
//       body, h1, h2, h3, h4, h5, h6, p, a, input, button, th, td, label, select {
//         font-family: 'Arial', sans-serif;
//       }
//       .header-input {
//         background-color: #009CE0;
//         color: white;
//         border: 2px solid #ccc;
//         padding: 5px;
//         border-radius: 3px;
//         box-shadow: inset 0 1px 2px rgba(234, 218, 218, 0.1);
//         text-align: center;
//         margin-right: 15px;
//       }
//       .header-input::placeholder {
//         color: white;
//       }
//       .filter-dropdown, .search-box {
//         width: 140px;
//         margin-right: 15px;
//       }
//       .filter-container label {
//         margin-right: 5px;
//       }
//       .table-container {
//         display: flex;
//         justify-content: center;
//         max-height: 68vh;
//         overflow-y: auto;
//       }
//       .table {
//         margin: 0 auto;
//         width: 100%;
//       }
//       .table th {
//         border: 1px solid black;
//         padding: 4px;
//         text-align: center;
//         background-color: #D5DBDB;
//         color: black;
//         font-weight: bold;
//       }
//       .table td {
//         border: 1px solid black;
//         padding: 7px;
//         text-align: left;
//       }
//       .sticky-header th {
//         position: sticky;
//         top: 0;
//         z-index: 999;
//         background-color: #D5DBDB;
//       }
//     `;
//     document.head.appendChild(style);
//     return () => {
//       document.head.removeChild(style);
//     };
//   }, []);

//   const fetchStudents = async () => {
//     try {
//       const response = await axios.get('http://13.127.57.224:2081/api/promotestudent', {
//         params: {
//           classFilter: classFilter || undefined,
//           academicyearFilter: academicyearFilter || undefined,
//           statusFilter: statusFilter || undefined,
//         },
//       });
//       setStudents(response.data); // Ensure that response data is set correctly
//     } catch (error) {
//       console.error('Error fetching students:', error);
//     }
//   };

//   const handleSelectAll = () => {
//     if (selectAll) {
//       setSelectedStudents([]);
//     } else {
//       const eligibleStudents = students.filter(student => student.PERCENT > 40 && !promotedStudents.includes(student.STUDENT_ID));
//       setSelectedStudents(eligibleStudents.map(student => student.STUDENT_ID));
//     }
//     setSelectAll(!selectAll);
//   };

//   const handleSelectStudent = (studentId) => {
//     setSelectedStudents(prevSelected => {
//       if (promotedStudents.includes(studentId)) {
//         return prevSelected; // Do not allow selecting already promoted students
//       }
//       if (prevSelected.includes(studentId)) {
//         return prevSelected.filter(id => id !== studentId);
//       } else {
//         return [...prevSelected, studentId];
//       }
//     });
//   };

//   const handlePromoteStudents = async () => {
//     try {
//       await axios.post('http://13.127.57.224:2081/api/promoteStudents', { selectedStudents });
//       setPromotedStudents([...promotedStudents, ...selectedStudents]);
//       fetchStudents();
//       setSelectedStudents([]);
//       setSelectAll(false);
//       alert('Students promoted successfully!');
//     } catch (error) {
//       console.error('Error promoting students:', error);
//       alert('Error promoting students. Please try again.');
//     }
//   };

//   const handlePromoteFailStudents = async () => {
//     try {
//       await axios.post('http://13.127.57.224:2081/api/changeFailSession', { studentIds: selectedStudents, newacademicyear: '2024-2025' });
//       fetchStudents();
//       alert('Fail students academicyear updated successfully!');
//     } catch (error) {
//       console.error('Error updating fail students:', error);
//       alert('Error updating fail students. Please try again.');
//     }
//   };

//   const handleSearchChange = (event) => {
//     setSearchTerm(event.target.value);
//   };

//   const filteredStudents = students.filter(student => {
//     return (
//       (!searchTerm || student.STUDENT_NAME.toLowerCase().includes(searchTerm.toLowerCase())) &&
//       (!classFilter || student.CLASS === classFilter) &&
//       (!academicyearFilter || student.ACADEMIC_YEAR === academicyearFilter) &&
//       (!statusFilter || student.STATUS === statusFilter)
//     );
//   });

//   return (
//     <div className="container">
//       <div className="container-fluid" style={{ marginTop: '8vh', width: '100%', padding: 0 }}>
//         <div className="mb-4">
//           <div className="row">
//             <div className="col-md-3 mb-2">
//               <input
//                 type="text"
//                 className="form-control"
//                 placeholder="Student Name"
//                 value={searchTerm}
//                 onChange={handleSearchChange}
//               />
//             </div>
//             <div className="col-md-2 mb-2">
//               <select
//                 className="form-control"
//                 value={classFilter}
//                 onChange={(e) => setClassFilter(e.target.value)}
//               >
//                 <option value="">Class</option>
//                 {classes.map(cls => <option key={cls} value={cls}>{cls}</option>)}
//               </select>
//             </div>
//             <div className="col-md-2 mb-2">
//               <select
//                 className="form-control"
//                 value={academicyearFilter}
//                 onChange={(e) => setacademicyearFilter(e.target.value)}
//               >
//                 <option value="">Academic Year</option>
//                 {academicyears.map(aca => <option key={aca} value={aca}>{aca}</option>)}
//               </select>
//             </div>
//             <div className="col-md-2 mb-2">
//               <select
//                 className="form-control"
//                 value={statusFilter}
//                 onChange={(e) => setStatusFilter(e.target.value)}
//               >
//                 <option value="">Status</option>
//                 {statuses.map(stat => <option key={stat} value={stat}>{stat}</option>)}
//               </select>
//             </div>
//             <div className="col-md-2 mb-1">
//               <button
//                 className="btn btn-primary"
//                 onClick={handlePromoteStudents}
//                 style={{ background: 'darkblue', border: 'none' }}
//                 disabled={selectedStudents.length === 0}
//               >
//                 Promote Selected
//               </button>
//             </div>
//           </div>
//         </div>
//         <div className="table-container">
//           <table className="table table-bordered table-striped table-hover">
//             <thead className="sticky-header">
//               <tr>
//                 <th>
//                   <input
//                     type="checkbox"
//                     checked={selectAll}
//                     onChange={handleSelectAll}
//                   />
//                 </th>
//                 <th>Student ID</th>
//                 <th>Student Name</th>
//                 <th>Academic Year</th>
//                 <th>Class</th>
//                 <th>Percent</th>
//                 <th>Result</th>
//               </tr>
//             </thead>
//             <tbody>
//               {filteredStudents.map((student) => (
//                 <tr key={student.STUDENT_ID}>
//                   <td>
//                     <input
//                       type="checkbox"
//                       checked={selectedStudents.includes(student.STUDENT_ID)}
//                       onChange={() => handleSelectStudent(student.STUDENT_ID)}
//                       disabled={promotedStudents.includes(student.STUDENT_ID)} // Disable if already promoted
//                     />
//                   </td>
//                   <td>{student.STUDENT_ID}</td>
//                   <td>{student.STUDENT_NAME}</td>
//                   <td>{student.ACADEMIC_YEAR}</td>
//                   <td>{student.CLASS}</td>
//                   <td>{student.PERCENT}</td>
//                   <td>{student.STATUS}</td>
//                 </tr>
//               ))}
//               {filteredStudents.length === 0 && (
//                 <tr>
//                   <td colSpan="7" className="text-center">No students found</td>
//                 </tr>
//               )}
//             </tbody>
//           </table>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default StudentPromote;



import React, { useState, useEffect } from 'react';
import axios from 'axios';
import 'bootstrap/dist/css/bootstrap.min.css';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';

const StudentPromote = () => {
  const [students, setStudents] = useState([]);
  const [selectedStudents, setSelectedStudents] = useState([]);
  const [classFilter, setClassFilter] = useState('');
  const [academicyearFilter, setAcademicyearFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [classes, setClasses] = useState([]);
  const [academicyears, setAcademicyears] = useState([]);
  const [statuses, setStatuses] = useState([]);
  const [loading, setLoading] = useState(false);
  const [promotedStudents, setPromotedStudents] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    const fetchOptionsAndStudents = async () => {
      setLoading(true);
      try {
        const response = await axios.get('http://13.127.57.224:2081/api/options');
        setClasses(response.data.classes);
        setAcademicyears(response.data.academicyears);
        setStatuses(response.data.statuses);
        await fetchStudents();
      } catch (error) {
        console.error('Error fetching options or students:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchOptionsAndStudents();
  }, []);

  useEffect(() => {
    fetchStudents();
  }, [classFilter, academicyearFilter, statusFilter, searchTerm]);

  const fetchStudents = async () => {
    try {
      const response = await axios.get('http://13.127.57.224:2081/api/promotestudent', {
        params: {
          classFilter: classFilter || undefined,
          academicyearFilter: academicyearFilter || undefined,
          statusFilter: statusFilter || undefined,
          searchTerm: searchTerm || undefined,
        },
      });
      setStudents(response.data);
    } catch (error) {
      console.error('Error fetching students:', error);
    }
  };

  const handlePromoteStudents = async () => {
    try {
      await axios.post('http://13.127.57.224:2081/api/promoteStudents', { selectedStudents });
      setPromotedStudents([...promotedStudents, ...selectedStudents]);
      fetchStudents();
      setSelectedStudents([]);
      alert('Students promoted successfully!');
    } catch (error) {
      console.error('Error promoting students:', error);
      alert('Error promoting students. Please try again.');
    }
  };

  const onSelectionChanged = (event) => {
    const selectedRows = event.api.getSelectedRows();
    setSelectedStudents(selectedRows.map(row => row.STUDENT_ID));
  };

  const handleSearchChange = (event) => {
    setSearchTerm(event.target.value);
  };

  const columnDefs = [
    {
      headerCheckboxSelection: true,
      checkboxSelection: true,
    },
    { headerName: 'Student ID', field: 'STUDENT_ID', filter: true },
    { headerName: 'Student Name', field: 'STUDENT_NAME', filter: true },
    { headerName: 'Academic Year', field: 'ACADEMIC_YEAR', filter: true },
    { headerName: 'Class', field: 'CLASS', filter: true },
    { headerName: 'Percent', field: 'PERCENT', filter: true },
    { headerName: 'Result', field: 'STATUS', filter: true },
  ];
  const defaultColDef = {
    floatingFilter: true,
    sortable: true,
    minWidth: 150,
    maxWidth: 180,
    resizable: true,
  };
  return (
    <div className="container">
      <div className="container-fluid" style={{ marginTop: '8vh', width: '100%', padding: 0 }}>
        <div className="mb-4">
          <div className="row">
            {/* <div className="col-md-3 mb-2">
              <input
                type="text"
                className="form-control"
                placeholder="Search by Student Name"
                value={searchTerm}
                onChange={handleSearchChange}
              />
            </div>
            <div className="col-md-2 mb-2">
              <select
                className="form-control"
                value={classFilter}
                onChange={(e) => setClassFilter(e.target.value)}
              >
                <option value="">Class</option>
                {classes.map(cls => <option key={cls} value={cls}>{cls}</option>)}
              </select>
            </div>
            <div className="col-md-2 mb-2">
              <select
                className="form-control"
                value={academicyearFilter}
                onChange={(e) => setAcademicyearFilter(e.target.value)}
              >
                <option value="">Academic Year</option>
                {academicyears.map(aca => <option key={aca} value={aca}>{aca}</option>)}
              </select>
            </div>
            <div className="col-md-2 mb-2">
              <select
                className="form-control"
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
              >
                <option value="">Status</option>
                {statuses.map(stat => <option key={stat} value={stat}>{stat}</option>)}
              </select>
            </div> */}
            <div className="col-md-2 mb-1">
              <button
                className="btn btn-primary"
                onClick={handlePromoteStudents}
                style={{ background: 'darkblue', border: 'none' }}
                disabled={selectedStudents.length === 0}
              >
                Promote Selected
              </button>
            </div>
          </div>
        </div>

        <div className="ag-theme-alpine" style={{ height: '505px', width: '100%' }}>
          <AgGridReact
            rowData={students}
            columnDefs={columnDefs}
            onSelectionChanged={onSelectionChanged}
            defaultColDef={defaultColDef}
            rowSelection="multiple"
            suppressRowClickSelection={true}
            enableFilter={true} // Ensures filters are enabled
          />
        </div>
      </div>
    </div>
  );
};

export default StudentPromote;
