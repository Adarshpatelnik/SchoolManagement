
// import React, { useState } from 'react';
// import axios from 'axios';
// import styled from 'styled-components';
// import 'bootstrap/dist/css/bootstrap.min.css';

// // Styled Components
// const FormWrapper = styled.div`
//     max-width: 100%;
//   margin: 0 auto; 
//     padding: 10px;
//     background-color: #f2f5f8;
//     border-radius: 8px;
//     box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
// `;

// const SectionTitle = styled.h3`
//     color: black;
//     padding-bottom: 10px;
//     margin-bottom: 20px;
//     border-bottom: 1px solid #012353;
// `;

// const StyledForm = styled.form`
//     display: block;
//     gap: 20px;
// `;

// const Label = styled.label`
//     color: #333;
//     // font-weight: bold;
// `;

// const Input = styled.input`
//     width: 100%;
//     padding: 10px;
//     border: 1px solid #ccc;
//     border-radius: 4px;
// `;

// const Select = styled.select`
//     width: 100%;
//     padding: 10px;
//     border: 1px solid #ccc;
//     border-radius: 4px;
// `;

// const Textarea = styled.textarea`
//     width: 100%;
//     padding: 10px;
//     border: 1px solid #ccc;
//     border-radius: 4px;
// `;

// const Button = styled.button`
//   width: 15%;
//      padding: 14px 28px;
//      background: linear-gradient(to right, #012353, #27ae60);
//      color: white;
//      justify-Content: center;
//      border: none;
//      border-radius: 4px;
//      cursor: pointer;
//      margin-top:10px;
//      display: flex;
//          align-items: center; // Center text vertically in the button


//      font-size: 16px;
//      transition: background-color 0.3s ease;

//      &:hover {
//         background-color: #0056b3;
//      }
 
// `;

// // Form Component
// const ApplicationForm = () => {
//     const [formData, setFormData] = useState({
//         FIRST_NAME: '',
//         MIDDLE_NAME: '',

//         LAST_NAME: '',
//         GENDER: '',
//         CONTACT_NUMBER: '',
//         CLASS: '',
//         STREAM: '',
//         OPTIONAL: '',
//         HOUSE_NUMBER: '',
//         HOUSE_BUILDING_NAME: '',
//         STREET_NAME: '',
//         LANDMARK: '',
//         CITY: '',
//         STATE: '',
//         POSTAL_CODE: '',
//         DATE_OF_BIRTH: '',
//         EMAIL: '',
//         ENROLLMENT_DATE: '',
//         NATIONALITY: '',
//         ORPHAN_STUDENT: '',
//         BIRTH_CERTIFICATE_NUMBER: '',
//         CAST: '',
//         RELIGION: '',
//         BLOOD_GROUP: '',
//         DISEASE_IF_ANY: '',
//         ADDITIONAL_NOTE: '',
//         IDENTIFICATION_MARK: '',
//         PREVIOUS_SCHOOL: '',
//         EMERGENCY_CONTACT_NAME: '',
//         EMERGENCY_CONTACT_NUMBER: '',
//         AADHAAR_NUMBER: '',
//         FATHER_NAME: '',
//         FATHER_ADHAR_ID: '',
//         FATHER_OCCUPATION: '',
//         FATHER_EDUCATION: '',
//         FATHER_MOBILE_NUMBER: '',
//         FATHER_INCOME: '',
//         MOTHER_NAME: '',
//         MOTHER_ADHAR_ID: '',
//         MOTHER_OCCUPATION: '',
//         MOTHER_EDUCATION: '',
//         MOTHER_MOBILE_NUMBER: '',
//         MOTHER_INCOME: '',
//         PRIMARY_CONTACT_NUMBER: ''
//     });

//     const handleChange = (e) => {
//         const { name, value } = e.target;
//         setFormData(prevState => ({
//             ...prevState,
//             [name]: value
//         }));
//     };

//     const handleSubmit = async (e) => {
//         e.preventDefault();
//         try {
//             const response = await axios.post('http://13.127.57.224:2081/api/application', formData);
//             alert('Data inserted successfully!');
//             setFormData({
//                 FIRST_NAME: '',
//                 MIDDLE_NAME: '',
//                 LAST_NAME: '',
//                 GENDER: '',
//                 CONTACT_NUMBER: '',
//                 CLASS: '',
//                 STREAM: '',
//                 OPTIONAL: '',
//                 HOUSE_NUMBER: '',
//                 HOUSE_BUILDING_NAME: '',
//                 STREET_NAME: '',
//                 LANDMARK: '',
//                  CITY: '',
//                   STATE: '',
//                  POSTAL_CODE: '',
//                   DATE_OF_BIRTH: '',
//                    EMAIL: '',
//                  ENROLLMENT_DATE: '',
//                  NATIONALITY: '',
//                 ORPHAN_STUDENT: '',
//                BIRTH_CERTIFICATE_NUMBER: '',
//                 CAST: '',
//                RELIGION: '',
//                   BLOOD_GROUP: '',
//         DISEASE_IF_ANY: '',
//         ADDITIONAL_NOTE: '',
//         IDENTIFICATION_MARK: '',
//         PREVIOUS_SCHOOL: '',
//         EMERGENCY_CONTACT_NAME: '',
//         EMERGENCY_CONTACT_NUMBER: '',
//         AADHAAR_NUMBER: '',
//         FATHER_NAME: '',
//         FATHER_ADHAR_ID: '',
//         FATHER_OCCUPATION: '',
//         FATHER_EDUCATION: '',
//         FATHER_MOBILE_NUMBER: '',
//         FATHER_INCOME: '',
//         MOTHER_NAME: '',
//         MOTHER_ADHAR_ID: '',
//         MOTHER_OCCUPATION: '',
//         MOTHER_EDUCATION: '',
//         MOTHER_MOBILE_NUMBER: '',
//         MOTHER_INCOME: '',
//         PRIMARY_CONTACT_NUMBER: ''
//             });
//         } catch (error) {
//             alert('Error inserting data.');
//         }
//     };

//     return (
//         <div className="container-fluid" style={{  marginLeft: '5vh', marginTop: '6vh', width: '96%', padding: 0  }}>
//             <FormWrapper>
//                 <StyledForm onSubmit={handleSubmit}>
//                     {/* Personal Information */}
//                     <SectionTitle>Personal Information</SectionTitle>
//                     <div className="row">
//                         <div className="col-md-4 mb-3">
//                             <Label htmlFor="FIRST_NAME">First Name</Label>
//                             <Input type="text" id="FIRST_NAME" name="FIRST_NAME" value={formData.FIRST_NAME} onChange={handleChange} required />
//                         </div>
//                         <div className="col-md-4 mb-3">
//                             <Label htmlFor="MIDDLE_NAME">Middle Name</Label>
//                             <Input type="text" id="MIDDLE_NAME" name="MIDDLE_NAME" value={formData.MIDDLE_NAME} onChange={handleChange} />
//                         </div>
//                         <div className="col-md-4 mb-3">
//                             <Label htmlFor="LAST_NAME">Last Name</Label>
//                             <Input type="text" id="LAST_NAME" name="LAST_NAME" value={formData.LAST_NAME} onChange={handleChange} required />
//                         </div>
//                         <div className="col-md-4 mb-3">
//                             <Label htmlFor="CLASS">Class</Label>
//                             <Input type="text" id="CLASS" name="CLASS" value={formData.CLASS} onChange={handleChange} required />
//                         </div>
//                         <div className="col-md-4 mb-3">
//                             <Label htmlFor="GENDER">Gender</Label>
//                             <Select id="GENDER" name="GENDER" value={formData.GENDER} onChange={handleChange} required>
//                                 <option value="">Select</option>
//                                 <option value="MALE">Male</option>
//                                 <option value="FEMALE">Female</option>
//                                 <option value="OTHER">Other</option>
//                             </Select>
//                         </div>


//                         <div className="col-md-4 mb-3">
//                             <Label htmlFor="CONTACT_NUMBER">Contact Number</Label>
//                             <Input type="text" id="CONTACT_NUMBER" name="CONTACT_NUMBER" value={formData.CONTACT_NUMBER} onChange={handleChange} required />
//                         </div>

//                         <div className="col-md-4 mb-3">
//                             <Label htmlFor="STREAM">Stream</Label>
//                             <Input type="text" id="STREAM" name="STREAM" value={formData.STREAM} onChange={handleChange} required />
//                         </div>
//                         <div className="col-md-4 mb-3">
//                             <Label htmlFor="OPTIONAL">Optional</Label>
//                             <Input type="text" id="OPTIONAL" name="OPTIONAL" value={formData.OPTIONAL} onChange={handleChange} required />
//                         </div>
//                         <div className="col-md-4 mb-3">
//                             <Label htmlFor="HOUSE_NUMBER"> House Number</Label>
//                             <Input type="text " id="HOUSE_NUMBER" name="HOUSE_NUMBER" value={formData.HOUSE_NUMBER} onChange={handleChange} required />
//                         </div>
//                         <div className="col-md-4 mb-3">
//                             <Label htmlFor="HOUSE_BUILDING_NAME">House Building Name</Label>
//                             <Textarea id="HOUSE_BUILDING_NAME" name="HOUSE_BUILDING_NAME" value={formData.HOUSE_BUILDING_NAME} onChange={handleChange} required />
//                         </div>
//                         <div className="col-md-4 mb-3">
//                             <Label htmlFor="STREET_NAME">Street Name</Label>
//                             <Input type="text" id="STREET_NAME" name="STREET_NAME" value={formData.STREET_NAME} onChange={handleChange} required />
//                         </div>


//                         <div className="col-md-4">
//                              <Label htmlFor="LANDMARK"> Land Mark</Label>
//                                          <Input type="text" id="LANDMARK" name="LANDMARK" value={formData.LANDMARK} onChange={handleChange} required />
//                              </div>
                       
//                              <div className="col-md-4">
//                              <Label htmlFor="CITY">City</Label>
//                                           <Input type="CITY" id="CITY" name="CITY" value={formData.CITY} onChange={handleChange} required />
//                              </div>
//                              <div className="col-md-4">
//                              <Label htmlFor="STATE">State</Label>
//                                           <Input type="text" id="STATE" name="STATE" value={formData.STATE} onChange={handleChange} required />
//                              </div>
//                              <div className="col-md-4">
//                              <Label htmlFor="POSTAL_CODE">Postal Code</Label>
//                                          <Input type="text" id="POSTAL_CODE" name="POSTAL_CODE" value={formData.POSTAL_CODE} onChange={handleChange} required />
//                              </div>


//                              <div className="col-md-4 mb-3">
//                             <Label htmlFor="DATE_OF_BIRTH">Date of Birth</Label>
//                             <Input type="date" id="DATE_OF_BIRTH" name="DATE_OF_BIRTH" value={formData.DATE_OF_BIRTH} onChange={handleChange} required />
//                         </div>

//                              <div className="col-md-4">
//                              <Label htmlFor="EMAIL">Email</Label>
//                                           <Input type="email" id="EMAIL" name="EMAIL" value={formData.EMAIL} onChange={handleChange} required />
//                              </div>
//                              <div className="col-md-4">
//                              <Label htmlFor="ENROLLMENT_DATE">Enrollment Date</Label>
//                                          <Input type="date" id="ENROLLMENT_DATE" name="ENROLLMENT_DATE" value={formData.ENROLLMENT_DATE} onChange={handleChange} required />
//                              </div>

//                              <div className="col-md-4">
//                              <Label htmlFor="ORPHAN_STUDENT">Orphan Student</Label>
//                                       <Select id="ORPHAN_STUDENT" name="ORPHAN_STUDENT" value={formData.ORPHAN_STUDENT} onChange={handleChange} required>
//                                           <option value="">Select</option>
//                                           <option value="YES">Yes</option>
//                                           <option value="NO">No</option>
//                                       </Select>
//                              </div>

//                              <div className="col-md-4">
//                              <Label htmlFor="BIRTH_CERTIFICATE_NUMBER">Birth Certificate Number</Label>
//                                          <Input type="text" id="BIRTH_CERTIFICATE_NUMBER" name="BIRTH_CERTIFICATE_NUMBER" value={formData.BIRTH_CERTIFICATE_NUMBER} onChange={handleChange} required />
//                              </div>


//                              <div className="col-md-4">
//                              <Label htmlFor="CAST">Cast</Label>
//                                           <Input type="text" id="CAST" name="CAST" value={formData.CAST} onChange={handleChange} required />
//                              </div>


//                              <div className="col-md-4">
//                              <Label htmlFor="RELIGION">Religion</Label>
//                                           <Input type="text" id="RELIGION" name="RELIGION" value={formData.RELIGION} onChange={handleChange} required />
//                              </div>

//                             <div className="col-md-4">
//                              <Label htmlFor="BLOOD_GROUP">Bloob Group</Label>
//                                           <Input type="text" id="BLOOD_GROUP" name="BLOOD_GROUP" value={formData.BLOOD_GROUP} onChange={handleChange} required />
//                             </div>


//                              <div className="col-md-4">
//                              <Label htmlFor="DISEASE_IF_ANY"> Disease If Any</Label>
//                                           <Input type="text" id="DISEASE_IF_ANY" name="DISEASE_IF_ANY" value={formData.DISEASE_IF_ANY} onChange={handleChange} required />
//                              </div>


//                              <div className="col-md-4">
//                              <Label htmlFor="ADDITIONAL_NOTE">Additional Note</Label>
//                                          <Input type="text" id="ADDITIONAL_NOTE" name="ADDITIONAL_NOTE" value={formData.ADDITIONAL_NOTE} onChange={handleChange} required />
//                              </div>


//                              <div className="col-md-4">
//                              <Label htmlFor="IDENTIFICATION_MARK"> Identification Mark</Label>
//                                         <Textarea id="IDENTIFICATION_MARK" name="IDENTIFICATION_MARK" value={formData.IDENTIFICATION_MARK} onChange={handleChange} required />
//                              </div>


//                              <div className="col-md-4">
//                              <Label htmlFor="PREVIOUS_SCHOOL">Previous School</Label>
//                                        <Input type="text" id="PREVIOUS_SCHOOL" name="PREVIOUS_SCHOOL" value={formData.PREVIOUS_SCHOOL} onChange={handleChange} required />
//                              </div>


//                              <div className="col-md-4">
//                            <Label htmlFor="EMERGENCY_CONTACT_NAME"> Emergency Contact Name</Label>
//                                           <Input type="text" id="EMERGENCY_CONTACT_NAME" name="EMERGENCY_CONTACT_NAME" value={formData.EMERGENCY_CONTACT_NAME} onChange={handleChange} required />
//                              </div>


//                              <div className="col-md-4">
//                              <Label htmlFor="EMERGENCY_CONTACT_NUMBER">Emergency Contact Number</Label>
//                                           <Input type="text" id="EMERGENCY_CONTACT_NUMBER" name="EMERGENCY_CONTACT_NUMBER" value={formData.EMERGENCY_CONTACT_NUMBER} onChange={handleChange} required />
//                              </div>


//                              <div className="col-md-4">
//                              <Label htmlFor="AADHAAR_NUMBER">Aadhaar Number</Label>
//                                           <Input type="text" id="AADHAAR_NUMBER" name="AADHAAR_NUMBER" value={formData.AADHAAR_NUMBER} onChange={handleChange} required />
//                              </div>


//                              <div className="col-md-4">
//                              <Label htmlFor="FATHER_NAME">Father Name</Label>
//                                         <Input type="text" id="FATHER_NAME" name="FATHER_NAME" value={formData.FATHER_NAME} onChange={handleChange} required />
//                              </div>


//                              <div className="col-md-4">
//                              <Label htmlFor="FATHER_ADHAR_ID">Father Adhar Id</Label>
//                                           <Input type="text" id="FATHER_ADHAR_ID" name="FATHER_ADHAR_ID" value={formData.FATHER_ADHAR_ID} onChange={handleChange} required />
//                              </div>


//                              <div className="col-md-4">
//                              <Label htmlFor="FATHER_OCCUPATION">Father Occupation</Label>
//                                           <Input type="text" id="FATHER_OCCUPATION" name="FATHER_OCCUPATION" value={formData.FATHER_OCCUPATION} onChange={handleChange} required />
//                             </div>



//                              <div className="col-md-4">
//                              <Label htmlFor="FATHER_EDUCATION">Father Education</Label>
//                                           <Input type="text" id="FATHER_EDUCATION" name="FATHER_EDUCATION" value={formData.FATHER_EDUCATION} onChange={handleChange} required />
//                              </div>

//                              <div className="col-md-4">
//                              <Label htmlFor="FATHER_MOBILE_NUMBER">Father Mobile Number</Label>
//                                           <Input type="text" id="FATHER_MOBILE_NUMBER" name="FATHER_MOBILE_NUMBER" value={formData.FATHER_MOBILE_NUMBER} onChange={handleChange} required />
//                              </div>

//                              <div className="col-md-4">
//                              <Label htmlFor="FATHER_INCOME">Father Income</Label>
//                                          <Input type="text" id="FATHER_INCOME" name="FATHER_INCOME" value={formData.FATHER_INCOME} onChange={handleChange} required />
//                              </div>


//                              <div className="col-md-4">
//                              <Label htmlFor="MOTHER_NAME">Mother Name</Label>
//                                          <Input type="text" id="MOTHER_NAME" name="MOTHER_NAME" value={formData.MOTHER_NAME} onChange={handleChange} required />
//                             </div>


//                              <div className="col-md-4">
//                             <Label htmlFor="MOTHER_ADHAR_ID">Mother Adhar Id</Label>
//                                         <Input type="text" id="MOTHER_ADHAR_ID" name="MOTHER_ADHAR_ID" value={formData.MOTHER_ADHAR_ID} onChange={handleChange} required />
//                             </div>


//                              <div className="col-md-4">
//                             <Label htmlFor="MOTHER_OCCUPATION">Mother Occupation</Label>
//                                           <Input type="text" id="MOTHER_OCCUPATION" name="MOTHER_OCCUPATION" value={formData.MOTHER_OCCUPATION} onChange={handleChange} required />
//                              </div>


//                              <div className="col-md-4">
//                             <Label htmlFor="MOTHER_EDUCATION">Mother Education</Label>
//                                           <Input type="text" id="MOTHER_EDUCATION" name="MOTHER_EDUCATION" value={formData.MOTHER_EDUCATION} onChange={handleChange} required />
//                              </div>


//                              <div className="col-md-4">
//                              <Label htmlFor="MOTHER_MOBILE_NUMBER"> Mother Mobile Number</Label>
//                                       <Input type="text" id="MOTHER_MOBILE_NUMBER" name="MOTHER_MOBILE_NUMBER" value={formData.MOTHER_MOBILE_NUMBER} onChange={handleChange} required />
//                             </div>


//                              <div className="col-md-4">
//                                  <Label htmlFor="MOTHER_INCOME"> Mother Income  </Label>
//                                  <Input type="text" id="MOTHER_INCOME" name="MOTHER_INCOME" value={formData.MOTHER_INCOME} onChange={handleChange} required />
//                              </div>


//                              <div className="col-md-4">
//                              <Label htmlFor="PRIMARY_CONTACT_NUMBER">Primary Contact Number</Label>
//                                           <Input type="text" id="PRIMARY_CONTACT_NUMBER" name="PRIMARY_CONTACT_NUMBER" value={formData.PRIMARY_CONTACT_NUMBER} onChange={handleChange} required />
//                              </div>





//                     </div>

//                     {/* Add more sections as needed */}

//                     {/* Submit Button */}
//                     <div className="row">
//                         <div className="col-md-12">
//                             <Button type="submit">Submit</Button>
//                         </div>
//                     </div>
//                 </StyledForm>
//             </FormWrapper>
//         </div>
//     );
// };

// export default ApplicationForm;






import React, { useState } from "react";
import axios from "axios";
import './Admin_Model.css';  // Import the new CSS file
import "bootstrap/dist/css/bootstrap.min.css";
 
const ApplicationForm = () => {
    const [formData, setFormData] = useState({
        FIRST_NAME: "",
        MIDDLE_NAME: "",
        LAST_NAME: "",
        GENDER: "",
        CONTACT_NUMBER: "",
        CLASS: "",
        STREAM: "",
        OPTIONAL: "",
        HOUSE_NUMBER: "",
        HOUSE_BUILDING_NAME: "",
        STREET_NAME: "",
        LANDMARK: "",
        CITY: "",
        STATE: "",
        POSTAL_CODE: "",
        DATE_OF_BIRTH: "",
        EMAIL: "",
        ENROLLMENT_DATE: "",
        ORPHAN_STUDENT: "",
        BIRTH_CERTIFICATE_NUMBER: "",
        CAST: "",
        RELIGION: "",
        BLOOD_GROUP: "",
        DISEASE_IF_ANY: "",
        ADDITIONAL_NOTE: "",
        IDENTIFICATION_MARK: "",
        PREVIOUS_SCHOOL: "",
        EMERGENCY_CONTACT_NAME: "",
        EMERGENCY_CONTACT_NUMBER: "",
        AADHAAR_NUMBER: "",
        FATHER_NAME: "",
        FATHER_ADHAR_ID: "",
        FATHER_OCCUPATION: "",
        FATHER_EDUCATION: "",
        FATHER_MOBILE_NUMBER: "",
        FATHER_INCOME: "",
        MOTHER_NAME: "",
        MOTHER_ADHAR_ID: "",
        MOTHER_OCCUPATION: "",
        MOTHER_EDUCATION: "",
        MOTHER_MOBILE_NUMBER: "",
        MOTHER_INCOME: "",
        PRIMARY_CONTACT_NUMBER: "",
    });
 
    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData((prevState) => ({
            ...prevState,
            [name]: value,
        }));
    };
 
    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            await axios.post("http://13.127.57.224:2081/api/application", formData);
            alert("Data inserted successfully!");
            setFormData({
                FIRST_NAME: "",
                MIDDLE_NAME: "",
                LAST_NAME: "",
                GENDER: "",
                CONTACT_NUMBER: "",
                CLASS: "",
                STREAM: "",
                OPTIONAL: "",
                HOUSE_NUMBER: "",
                HOUSE_BUILDING_NAME: "",
                STREET_NAME: "",
                LANDMARK: "",
                CITY: "",
                STATE: "",
                POSTAL_CODE: "",
                DATE_OF_BIRTH: "",
                EMAIL: "",
                ENROLLMENT_DATE: "",
                ORPHAN_STUDENT: "",
                BIRTH_CERTIFICATE_NUMBER: "",
                CAST: "",
                RELIGION: "",
                BLOOD_GROUP: "",
                DISEASE_IF_ANY: "",
                ADDITIONAL_NOTE: "",
                IDENTIFICATION_MARK: "",
                PREVIOUS_SCHOOL: "",
                EMERGENCY_CONTACT_NAME: "",
                EMERGENCY_CONTACT_NUMBER: "",
                AADHAAR_NUMBER: "",
                FATHER_NAME: "",
                FATHER_ADHAR_ID: "",
                FATHER_OCCUPATION: "",
                FATHER_EDUCATION: "",
                FATHER_MOBILE_NUMBER: "",
                FATHER_INCOME: "",
                MOTHER_NAME: "",
                MOTHER_ADHAR_ID: "",
                MOTHER_OCCUPATION: "",
                MOTHER_EDUCATION: "",
                MOTHER_MOBILE_NUMBER: "",
                MOTHER_INCOME: "",
                PRIMARY_CONTACT_NUMBER: "",
            });
        } catch (error) {
            alert("Error inserting data.");
        }
    };
 
    return (
        <div className="ApplicationForm_container container-fluid">
            <div className="ApplicationForm_wrapper">
                <form className="ApplicationForm_form" onSubmit={handleSubmit}>
                    <div className="ApplicationForm_form-group">
                    <h3 className="ApplicationForm_sectionTitle">Personal Information</h3>
                    <div className="row">
                        <div className="col-md-4 mb-3">
                            <label htmlFor="FIRST_NAME" className="ApplicationForm_label">
                                First Name
                            </label>
                            <input
                                type="text"
                                id="FIRST_NAME"
                                name="FIRST_NAME"
                                value={formData.FIRST_NAME}
                                onChange={handleChange}
                                className="ApplicationForm_input"
                            />
                        </div>
                        <div className="col-md-4 mb-3">
                            <label htmlFor="MIDDLE_NAME" className="ApplicationForm_label">
                                Middle Name
                            </label>
                            <input
                                type="text"
                                id="MIDDLE_NAME"
                                name="MIDDLE_NAME"
                                value={formData.MIDDLE_NAME}
                                onChange={handleChange}
                                className="ApplicationForm_input"
                            />
                        </div>
                        <div className="col-md-4 mb-3">
                            <label htmlFor="LAST_NAME" className="ApplicationForm_label">
                                Last Name
                            </label>
                            <input
                                type="text"
                                id="LAST_NAME"
                                name="LAST_NAME"
                                value={formData.LAST_NAME}
                                onChange={handleChange}
                                className="ApplicationForm_input"
 
                            />
                        </div>
                        <div className="col-md-4 mb-3">
                            <label htmlFor="GENDER" className="ApplicationForm_label">
                                Gender
                            </label>
                            <select
                                id="GENDER"
                                name="GENDER"
                                value={formData.GENDER}
                                onChange={handleChange}
                                className="ApplicationForm_select"
                            >
                                <option value="">Select</option>
                                <option value="MALE">Male</option>
                                <option value="FEMALE">Female</option>
                                <option value="OTHER">Other</option>
                            </select>
                        </div>
                        <div className="col-md-4 mb-3">
                            <label htmlFor="CONTACT_NUMBER" className="ApplicationForm_label">
                                Contact Number
                            </label>
                            <input
                                type="text"
                                id="CONTACT_NUMBER"
                                name="CONTACT_NUMBER"
                                value={formData.CONTACT_NUMBER}
                                onChange={handleChange}
                                className="ApplicationForm_input"
                            />
                        </div>
                        <div className="col-md-4 mb-3">
                            <label htmlFor="CLASS" className="ApplicationForm_label">
                                Class
                            </label>
                            <input
                                type="text"
                                id="CLASS"
                                name="CLASS"
                                value={formData.CLASS}
                                onChange={handleChange}
                                className="ApplicationForm_input"
                            />
                        </div>
                        <div className="col-md-4 mb-3">
                            <label htmlFor="STREAM" className="ApplicationForm_label">
                                Stream
                            </label>
                            <input
                                type="text"
                                id="STREAM"
                                name="STREAM"
                                value={formData.STREAM}
                                onChange={handleChange}
                                className="ApplicationForm_input"
                            />
                        </div>
                        <div className="col-md-4 mb-3">
                            <label htmlFor="OPTIONAL" className="ApplicationForm_label">
                                Optional
                            </label>
                            <input
                                type="text"
                                id="OPTIONAL"
                                name="OPTIONAL"
                                value={formData.OPTIONAL}
                                onChange={handleChange}
                                className="ApplicationForm_input"
                            />
                        </div>
                        <div className="col-md-4 mb-3">
                            <label htmlFor="DATE_OF_BIRTH" className="ApplicationForm_label">
                                Date of Birth
                            </label>
                            <input
                                type="date"
                                id="DATE_OF_BIRTH"
                                name="DATE_OF_BIRTH"
                                value={formData.DATE_OF_BIRTH}
                                onChange={handleChange}
                                className="ApplicationForm_input"
                            />
                        </div>
                        <div className="col-md-4 mb-3">
                            <label htmlFor="EMAIL" className="ApplicationForm_label">
                                Email
                            </label>
                            <input
                                type="email"
                                id="EMAIL"
                                name="EMAIL"
                                value={formData.EMAIL}
                                onChange={handleChange}
                                className="ApplicationForm_input"
                            />
                        </div>
                        <div className="col-md-4 mb-3">
                            <label
                                htmlFor="ENROLLMENT_DATE"
                                className="ApplicationForm_label"
                            >
                                Enrollment Date
                            </label>
                            <input
                                type="date"
                                id="ENROLLMENT_DATE"
                                name="ENROLLMENT_DATE"
                                value={formData.ENROLLMENT_DATE}
                                onChange={handleChange}
                                className="ApplicationForm_input"
                            />
                        </div>
                        <div className="col-md-4 mb-3">
                            <label htmlFor="ORPHAN_STUDENT" className="ApplicationForm_label">Orphan Student</label>
                            <select
                                id="ORPHAN_STUDENT"
                                name="ORPHAN_STUDENT"
                                value={formData.ORPHAN_STUDENT}
                                onChange={handleChange}
                                className="ApplicationForm_select"
                            >
                                <option value="">Select</option>
                                <option value="YES">Yes</option>
                                <option value="NO">No</option>
                            </select>
                        </div>
                        <div className="col-md-4 mb-3">
                            <label htmlFor="BIRTH_CERTIFICATE_NUMBER" className="ApplicationForm_label">Birth Certificate Number</label>
                            <input
                                type="text"
                                id="BIRTH_CERTIFICATE_NUMBER"
                                name="BIRTH_CERTIFICATE_NUMBER"
                                value={formData.BIRTH_CERTIFICATE_NUMBER}
                                onChange={handleChange}
                                className="ApplicationForm_input"
                            />
                        </div>
                        <div className="col-md-4 mb-3">
                            <label htmlFor="CAST" className="ApplicationForm_label">Caste</label>
                            <input
                                type="text"
                                id="CAST"
                                name="CAST"
                                value={formData.CAST}
                                onChange={handleChange}
                                className="ApplicationForm_input"
                            />
                        </div>
                        <div className="col-md-4 mb-3">
                            <label htmlFor="RELIGION" className="ApplicationForm_label">Religion</label>
                            <input
                                type="text"
                                id="RELIGION"
                                name="RELIGION"
                                value={formData.RELIGION}
                                onChange={handleChange}
                                className="ApplicationForm_input"
                            />
                        </div>
                        <div className="col-md-4 mb-3">
                            <label htmlFor="BLOOD_GROUP" className="ApplicationForm_label">Blood Group</label>
                            <input
                                type="text"
                                id="BLOOD_GROUP"
                                name="BLOOD_GROUP"
                                value={formData.BLOOD_GROUP}
                                onChange={handleChange}
                                className="ApplicationForm_input"
                            />
                        </div>
                        <div className="col-md-4 mb-3">
                            <label htmlFor="DISEASE_IF_ANY" className="ApplicationForm_label">Disease (if any)</label>
                            <input
                                type="text"
                                id="DISEASE_IF_ANY"
                                name="DISEASE_IF_ANY"
                                value={formData.DISEASE_IF_ANY}
                                onChange={handleChange}
                                className="ApplicationForm_input"
                            />
                        </div>
                        <div className="col-md-4 mb-3">
                            <label htmlFor="ADDITIONAL_NOTE" className="ApplicationForm_label">Additional Note</label>
                            <input
                                type="text"
                                id="ADDITIONAL_NOTE"
                                name="ADDITIONAL_NOTE"
                                value={formData.ADDITIONAL_NOTE}
                                onChange={handleChange}
                                className="ApplicationForm_input"
                            />
                        </div>
                        <div className="col-md-4 mb-3">
                            <label htmlFor="IDENTIFICATION_MARK" className="ApplicationForm_label">Identification Mark</label>
                            <input
                                type="text"
                                id="IDENTIFICATION_MARK"
                                name="IDENTIFICATION_MARK"
                                value={formData.IDENTIFICATION_MARK}
                                onChange={handleChange}
                                className="ApplicationForm_input"
                            />
                        </div>
                        <div className="col-md-4 mb-3">
                            <label htmlFor="PREVIOUS_SCHOOL" className="ApplicationForm_label">Previous School</label>
                            <input
                                type="text"
                                id="PREVIOUS_SCHOOL"
                                name="PREVIOUS_SCHOOL"
                                value={formData.PREVIOUS_SCHOOL}
                                onChange={handleChange}
                                className="ApplicationForm_input"
                            />
                        </div>
                        <div className="col-md-4 mb-3">
                            <label htmlFor="EMERGENCY_CONTACT_NAME" className="ApplicationForm_label">Emergency Contact Name</label>
                            <input
                                type="text"
                                id="EMERGENCY_CONTACT_NAME"
                                name="EMERGENCY_CONTACT_NAME"
                                value={formData.EMERGENCY_CONTACT_NAME}
                                onChange={handleChange}
                                className="ApplicationForm_input"
                            />
                        </div>
                        <div className="col-md-4 mb-3">
                            <label htmlFor="EMERGENCY_CONTACT_NUMBER" className="ApplicationForm_label">Emergency Contact Number</label>
                            <input
                                type="text"
                                id="EMERGENCY_CONTACT_NUMBER"
                                name="EMERGENCY_CONTACT_NUMBER"
                                value={formData.EMERGENCY_CONTACT_NUMBER}
                                onChange={handleChange}
                                className="ApplicationForm_input"
                            />
                        </div>
                        <div className="col-md-4 mb-3">
                            <label htmlFor="AADHAAR_NUMBER" className="ApplicationForm_label">Aadhaar Number</label>
                            <input
                                type="text"
                                id="AADHAAR_NUMBER"
                                name="AADHAAR_NUMBER"
                                value={formData.AADHAAR_NUMBER}
                                onChange={handleChange}
                                className="ApplicationForm_input"
                            />
                        </div>
                        </div>
                        </div>
                        <div className="ApplicationForm_form-group">
                        <h3 className="ApplicationForm_sectionTitle">Address Information</h3>
                        <div className="row">
                        <div className="col-md-4 mb-3">
                            <label htmlFor="HOUSE_NUMBER" className="ApplicationForm_label">
                                House Number
                            </label>
                            <input
                                type="text"
                                id="HOUSE_NUMBER"
                                name="HOUSE_NUMBER"
                                value={formData.HOUSE_NUMBER}
                                onChange={handleChange}
                                className="ApplicationForm_input"
                            />
                        </div>
                        <div className="col-md-4 mb-3">
                            <label
                                htmlFor="HOUSE_BUILDING_NAME"
                                className="ApplicationForm_label"
                            >
                                Building Name
                            </label>
                            <input
                                type="text"
                                id="HOUSE_BUILDING_NAME"
                                name="HOUSE_BUILDING_NAME"
                                value={formData.HOUSE_BUILDING_NAME}
                                onChange={handleChange}
                                className="ApplicationForm_input"
                            />
                        </div>
                        <div className="col-md-4 mb-3">
                            <label htmlFor="STREET_NAME" className="ApplicationForm_label">
                                Street Name
                            </label>
                            <input
                                type="text"
                                id="STREET_NAME"
                                name="STREET_NAME"
                                value={formData.STREET_NAME}
                                onChange={handleChange}
                                className="ApplicationForm_input"
                            />
                        </div>
                        <div className="col-md-4 mb-3">
                            <label htmlFor="LANDMARK" className="ApplicationForm_label">
                                Landmark
                            </label>
                            <input
                                type="text"
                                id="LANDMARK"
                                name="LANDMARK"
                                value={formData.LANDMARK}
                                onChange={handleChange}
                                className="ApplicationForm_input"
                            />
                        </div>
                        <div className="col-md-4 mb-3">
                            <label htmlFor="CITY" className="ApplicationForm_label">
                                City
                            </label>
                            <input
                                type="text"
                                id="CITY"
                                name="CITY"
                                value={formData.CITY}
                                onChange={handleChange}
                                className="ApplicationForm_input"
                            />
                        </div>
                        <div className="col-md-4 mb-3">
                            <label htmlFor="STATE" className="ApplicationForm_label">
                                State
                            </label>
                            <input
                                type="text"
                                id="STATE"
                                name="STATE"
                                value={formData.STATE}
                                onChange={handleChange}
                                className="ApplicationForm_input"
                            />
                        </div>
                        <div className="col-md-4 mb-3">
                            <label htmlFor="POSTAL_CODE" className="ApplicationForm_label">
                                Postal Code
                            </label>
                            <input
                                type="text"
                                id="POSTAL_CODE"
                                name="POSTAL_CODE"
                                value={formData.POSTAL_CODE}
                                onChange={handleChange}
                                className="ApplicationForm_input"
                            />
                        </div>
                        </div>
                        </div>
                        <div className="ApplicationForm_form-group">
                        <h3 className="ApplicationForm_sectionTitle">Parent's Information</h3>
                        <div className="row">
                        <div className="col-md-4 mb-3">
                            <label htmlFor="FATHER_NAME" className="ApplicationForm_label">Father's Name</label>
                            <input
                                type="text"
                                id="FATHER_NAME"
                                name="FATHER_NAME"
                                value={formData.FATHER_NAME}
                                onChange={handleChange}
                                className="ApplicationForm_input"
                            />
                        </div>
                        <div className="col-md-4 mb-3">
                            <label htmlFor="FATHER_ADHAR_ID" className="ApplicationForm_label">Father's Aadhaar ID</label>
                            <input
                                type="text"
                                id="FATHER_ADHAR_ID"
                                name="FATHER_ADHAR_ID"
                                value={formData.FATHER_ADHAR_ID}
                                onChange={handleChange}
                                className="ApplicationForm_input"
                            />
                        </div>
                        <div className="col-md-4 mb-3">
                            <label htmlFor="FATHER_OCCUPATION" className="ApplicationForm_label">Father's Occupation</label>
                            <input
                                type="text"
                                id="FATHER_OCCUPATION"
                                name="FATHER_OCCUPATION"
                                value={formData.FATHER_OCCUPATION}
                                onChange={handleChange}
                                className="ApplicationForm_input"
                            />
                        </div>
                        <div className="col-md-4 mb-3">
                            <label htmlFor="FATHER_EDUCATION" className="ApplicationForm_label">Father's Education</label>
                            <input
                                type="text"
                                id="FATHER_EDUCATION"
                                name="FATHER_EDUCATION"
                                value={formData.FATHER_EDUCATION}
                                onChange={handleChange}
                                className="ApplicationForm_input"
                            />
                        </div>
                        <div className="col-md-4 mb-3">
                            <label htmlFor="FATHER_MOBILE_NUMBER" className="ApplicationForm_label">Father's Mobile Number</label>
                            <input
                                type="text"
                                id="FATHER_MOBILE_NUMBER"
                                name="FATHER_MOBILE_NUMBER"
                                value={formData.FATHER_MOBILE_NUMBER}
                                onChange={handleChange}
                                className="ApplicationForm_input"
                            />
                        </div>
                        <div className="col-md-4 mb-3">
                            <label htmlFor="FATHER_INCOME" className="ApplicationForm_label">Father's Income</label>
                            <input
                                type="text"
                                id="FATHER_INCOME"
                                name="FATHER_INCOME"
                                value={formData.FATHER_INCOME}
                                onChange={handleChange}
                                className="ApplicationForm_input"
                            />
                        </div>
                        <div className="col-md-4 mb-3">
                            <label htmlFor="MOTHER_NAME" className="ApplicationForm_label">Mother's Name</label>
                            <input
                                type="text"
                                id="MOTHER_NAME"
                                name="MOTHER_NAME"
                                value={formData.MOTHER_NAME}
                                onChange={handleChange}
                                className="ApplicationForm_input"
                            />
                        </div>
                        <div className="col-md-4 mb-3">
                            <label htmlFor="MOTHER_ADHAR_ID" className="ApplicationForm_label">Mother's Aadhaar ID</label>
                            <input
                                type="text"
                                id="MOTHER_ADHAR_ID"
                                name="MOTHER_ADHAR_ID"
                                value={formData.MOTHER_ADHAR_ID}
                                onChange={handleChange}
                                className="ApplicationForm_input"
                            />
                        </div>
                        <div className="col-md-4 mb-3">
                            <label htmlFor="MOTHER_OCCUPATION" className="ApplicationForm_label">Mother's Occupation</label>
                            <input
                                type="text"
                                id="MOTHER_OCCUPATION"
                                name="MOTHER_OCCUPATION"
                                value={formData.MOTHER_OCCUPATION}
                                onChange={handleChange}
                                className="ApplicationForm_input"
                            />
                        </div>
                        <div className="col-md-4 mb-3">
                            <label htmlFor="MOTHER_EDUCATION" className="ApplicationForm_label">Mother's Education</label>
                            <input
                                type="text"
                                id="MOTHER_EDUCATION"
                                name="MOTHER_EDUCATION"
                                value={formData.MOTHER_EDUCATION}
                                onChange={handleChange}
                                className="ApplicationForm_input"
                            />
                        </div>
                        <div className="col-md-4 mb-3">
                            <label htmlFor="MOTHER_MOBILE_NUMBER" className="ApplicationForm_label">Mother's Mobile Number</label>
                            <input
                                type="text"
                                id="MOTHER_MOBILE_NUMBER"
                                name="MOTHER_MOBILE_NUMBER"
                                value={formData.MOTHER_MOBILE_NUMBER}
                                onChange={handleChange}
                                className="ApplicationForm_input"
                            />
                        </div>
                        <div className="col-md-4 mb-3">
                            <label htmlFor="MOTHER_INCOME" className="ApplicationForm_label">Mother's Income</label>
                            <input
                                type="text"
                                id="MOTHER_INCOME"
                                name="MOTHER_INCOME"
                                value={formData.MOTHER_INCOME}
                                onChange={handleChange}
                                className="ApplicationForm_input"
                            />
                        </div>
                        <div className="col-md-4 mb-3">
                            <label htmlFor="PRIMARY_CONTACT_NUMBER" className="ApplicationForm_label">Primary Contact Number</label>
                            <input
                                type="text"
                                id="PRIMARY_CONTACT_NUMBER"
                                name="PRIMARY_CONTACT_NUMBER"
                                value={formData.PRIMARY_CONTACT_NUMBER}
                                onChange={handleChange}
                                className="ApplicationForm_input"
                            />
                        </div>
                    </div>
                    </div>
 
                    <div className="row">
                        <div className="ApplicationForm_Button_div">
                            <button type="submit" className="ApplicationForm_button">
                                Submit
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    );
};
 
export default ApplicationForm;