


// import React, { useEffect, useState } from 'react';
// import axios from 'axios';
// import { AgCharts } from 'ag-charts-react';
// import styled from 'styled-components';
// import 'bootstrap/dist/css/bootstrap.min.css';
// import { Container, Row, Col } from 'reactstrap'; // Importing necessary components

// const FilterContainer = styled.div`
//   display: flex;
//   justify-content: center;
//   margin-bottom: -1rem; 
//   margin-top: -1.5rem; 
// `;

// const Select = styled.select`
//   width: 100%;
//   max-width: 200px; 
//   padding: 5px;
//   border: px solid black;
//   border-radius: 5px;
//   font-size: 12px;
//   background-color: #f0f4f8;
//   box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.1);
//   transition: 0.3s ease;

//   &:focus {
//     border-color: #5fa8d3;
//     outline: none;
//   }
// `;

// const ChartContainer = styled.div`
//   display: flex;
//   justify-content: center;
//   align-items: flex-start;
//   flex-direction: column;
//   width: 100%;
//   margin-bottom: 0rem; 
//   height: 28vh; /* Increased height for the chart */
// `;

// const GirlBoy = () => {
//   const [attendanceData, setAttendanceData] = useState([]);
//   const [filteredData, setFilteredData] = useState([]);
//   const [selectedClass, setSelectedClass] = useState('');
//   const [classes, setClasses] = useState([]);

//   useEffect(() => {
//     const fetchAttendanceData = async () => {
//       try {
//         const response = await axios.get('http://13.127.57.224:2081/api/studentcount');
//         const data = response.data.map(record => ({
//           GENDER: record.GENDER === 'MALE' ? 'Male' : 'Female',
//           count: record.STUDENT_COUNT,
//           CLASS: record.CLASS,
//         }));

//         setAttendanceData(data);
//         const uniqueClasses = [...new Set(data.map(item => item.CLASS))];
//         setClasses(uniqueClasses);
//       } catch (error) {
//         console.error('Error fetching student attendance data:', error);
//       }
//     };

//     fetchAttendanceData();
//   }, []);

//   useEffect(() => {
//     const filtered = attendanceData.filter(record =>
//       selectedClass ? record.CLASS === selectedClass : true
//     );
//     setFilteredData(filtered);
//   }, [selectedClass, attendanceData]);

//   const getGenderCounts = () => {
//     let boys = 0;
//     let girls = 0;

//     filteredData.forEach(record => {
//       if (record.GENDER === 'Male') boys += record.count;
//       if (record.GENDER === 'Female') girls += record.count;
//     });

//     return { boys, girls };
//   };

//   const { boys, girls } = getGenderCounts();
//   const totalStudents = boys + girls;

//   const donutChartData = [
//     { asset: `Boys: ${boys}`, amount: boys },
//     { asset: `Girls: ${girls}`, amount: girls },
//   ];


//   const donutChartOptions = {
//     data: donutChartData,
//     series: [
//       {
//         type: 'donut',
//         calloutLabelKey: 'asset',
//         angleKey: 'amount',
//         innerRadiusRatio: 0.7,
//         innerLabels: [
//           {
//             text: 'Students',
//             fontWeight: 'bold',
//             fontSize: 10,
//           },
//           {
//             text: totalStudents.toString(),
//             spacing: 1,
//             fontSize: 14,
//             color: 'green',
//           },
//         ],
//         fills: ['#012353', '#27AE60'],
//         calloutLabel: {
//           enabled: true,
//           formatter: ({ datum }) => {
//             const percentage = ((datum.amount / totalStudents) * 100).toFixed(1);
//             return `${datum.asset}\n${percentage}%`; // Separate percentage on a new line
//           },
//           fontSize: 12,
//           fontWeight: 'bold',
//         },
//       },
//     ],
//     legend: {
//       enabled: false,
//     },
//   };
  
//   return (
//     <Container>
//       <Row className="justify-content-center">
//         <Col xs={12} md={6}>
//           <FilterContainer>
//             <Select value={selectedClass} onChange={e => setSelectedClass(e.target.value)}>
//               <option value="">Class</option>
//               {classes.map((classItem, index) => (
//                 <option key={index} value={classItem}>{classItem}</option>
//               ))}
//             </Select>
//           </FilterContainer>
//         </Col>
//         <Col xs={10}>
//           <ChartContainer>
//             <AgCharts options={donutChartOptions} style={{ width: '100%', height: '23vh', marginTop: '-2vh' }} />
//           </ChartContainer>
//         </Col>
//       </Row>
//     </Container>
//   );
// };

// export default GirlBoy;









import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { AgCharts } from 'ag-charts-react';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Container, Row, Col } from 'reactstrap'; // Importing necessary components
import './Admin_Model.css';
 
const GirlBoy = () => {
  const [attendanceData, setAttendanceData] = useState([]);
  const [filteredData, setFilteredData] = useState([]);
  const [selectedClass, setSelectedClass] = useState('');
  const [classes, setClasses] = useState([]);

  useEffect(() => {
    const fetchAttendanceData = async () => {
      try {
        const response = await axios.get('http://13.127.57.224:2081/api/studentcount');
        const data = response.data.map(record => ({
          GENDER: record.GENDER === 'MALE' ? 'Male' : 'Female',
          count: record.STUDENT_COUNT,
          CLASS: record.CLASS,
        }));

        setAttendanceData(data);
        const uniqueClasses = [...new Set(data.map(item => item.CLASS))];
        setClasses(uniqueClasses);
      } catch (error) {
        console.error('Error fetching student attendance data:', error);
      }
    };

    fetchAttendanceData();
  }, []);

  useEffect(() => {
    const filtered = attendanceData.filter(record =>
      selectedClass ? record.CLASS === selectedClass : true
    );
    setFilteredData(filtered);
  }, [selectedClass, attendanceData]);

  const getGenderCounts = () => {
    let boys = 0;
    let girls = 0;

    filteredData.forEach(record => {
      if (record.GENDER === 'Male') boys += record.count;
      if (record.GENDER === 'Female') girls += record.count;
    });

    return { boys, girls };
  };

  const { boys, girls } = getGenderCounts();
  const totalStudents = boys + girls;

  const donutChartData = [
    { asset: `Boys: ${boys}`, amount: boys },
    { asset: `Girls: ${girls}`, amount: girls },
  ];


  const donutChartOptions = {
    data: donutChartData,
    series: [
      {
        type: 'donut',
        calloutLabelKey: 'asset',
        angleKey: 'amount',
        innerRadiusRatio: 0.7,
        innerLabels: [
          {
            text: 'Students',
            fontWeight: 'bold',
            fontSize: 10,
          },
          {
            text: totalStudents.toString(),
            spacing: 1,
            fontSize: 14,
            color: 'green',
          },
        ],
        fills: ['#012353', '#27AE60'],
        calloutLabel: {
          enabled: true,
          formatter: ({ datum }) => {
            const percentage = ((datum.amount / totalStudents) * 100).toFixed(1);
            return `${datum.asset}\n${percentage}%`; // Separate percentage on a new line
          },
          fontSize: 12,
          fontWeight: 'bold',
        },
      },
    ],
    legend: {
      enabled: false,
    },
  };
 
  return (
    <Container>
      <Row className="justify-content-center">
        <Col xs={12} md={6}>
          <div className="Girl_Boy_filter-container">
            <select
              className="Girl_Boy_select"
              value={selectedClass}
              onChange={e => setSelectedClass(e.target.value)}
            >
              <option value="">Class</option>
              {classes.map((classItem, index) => (
                <option key={index} value={classItem}>{classItem}</option>
              ))}
            </select>
          </div>
        </Col>
        <Col xs={10}>
          <div className="Girl_Boy_chart-container">
            <AgCharts options={donutChartOptions} style={{ width: '100%', height: '22vh', marginTop: '-3vh' }} />
          </div>
        </Col>
      </Row>
    </Container>
  );
};
 
export default GirlBoy;
 
