

import React from 'react';
import SidebarComponent from './Sidebar';
import NavbarComponent from './navbar';

const App = () => {
  return (
    <div>
      <NavbarComponent />
      <SidebarComponent />

      {/* Your main content here */}
      <div className="main-content">
        {/* Add your main content or routes here */}
      </div>
    </div>
  );
};

export default App;
