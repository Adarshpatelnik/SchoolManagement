
// import React, { useState, useEffect } from 'react';
// import axios from 'axios';
// import styled, { keyframes } from 'styled-components';
// // import Landing  from '/home/ec2-user/Edu360/SchoolManagement/frontend/src/ADMIN_MODEL/Landing.js';

// const fadeIn = keyframes`
//   from {
//     opacity: 0;
//   }
//   to {
//     opacity: 1;
//   }
// `;

// const LoginContainer = styled.div`
//   display: flex;
//   justify-content: center;
//   align-items: center;
//   height: 100vh;
//   background: ;
//   background-size: cover;
// `;

// const FormWrapper = styled.div`
//   padding: px;
//   border-radius: 5px;
//   max-width: 100%;
//   width: 100%;
//   text-align: center;
//   transition: transform 0.3s ease, box-shadow 0.3s ease;

//   &:hover {
//     box-shadow: 0 15px 35px rgba(0, 0, 0, 0.2);
//   }
// `;

// const Form = styled.form`
//   width: 100%;
//   display: grid;
//   grid-template-columns: repeat(4, 1fr);
//   gap: 10px;
//   background: #dcdcdc;
//   justify-items: center;
//   padding: 4px;
// `;

// const InputWrapper = styled.div`
//   position: relative;
//   width: 100%;
//   max-width: 250px;
//   margin-bottom: px;
// `;

// const Input = styled.input`
//   width: 100%;
//   padding: 12px 15px;
//   margin-bottom: 10px;
//   border: 2px solid #ccc;
//   border-radius: 10px;
//   font-size: 16px;
//   box-sizing: border-box;
//   transition: border-color 0.3s ease;

//   &:focus {
//     border-color: #2980b9;
//     outline: none;
//   }
// `;

// const Button = styled.button`
//   grid-column: span 4;
//   width: 15%;
//   padding: 10px;
//   background: linear-gradient(to right, #012353, #27ae60);
//   color: white;
//   border: none;
//   border-radius: 10px;
//   cursor: pointer;
//   font-size: 18px;
//   transition: background 0.3s ease, transform 0.3s ease;
//   margin: 20px 0;

//   &:hover {
//     transform: translateY(-2px);
//   }
// `;

// const ResetButton = styled(Button)`
//   background: linear-gradient(to right, #012353, #27ae60);
//   margin-top: 1;
//   width: auto; /* Set to auto to fit content */
//   padding: 8px 16px; /* Adjusted padding */
//   font-size: 16px; /* Adjusted font size */

 
// `;

// const Message = styled.p`
//   color: red;
//   font-size: 14px;
//   text-align: left;
//   margin-top: -10px;
//   margin-bottom: 10px;
// `;


// const FiltersAndResetContainer = styled.div`
//   display: flex;
//   flex-direction: column; /* Stack filters and reset button vertically */
//   align-items: center;
//   padding: 0 10px;
// `;

// const FilterGroup = styled.div`
//   display: flex;
//   align-items: left;
//   gap: 10px; /* Spacing between filters */
//   margin-bottom: 0px;
// `;

// const FilterItem = styled.div`
//   display: flex;
//   align-items: center;
//   gap: 10px; /* Space between label and select box */
// `;

// const Label = styled.label`
//   font-size: 16px;
//   color: #333;
//   font-weight: bold;
// `;

// const ClassSelect = styled.select`
//   padding: 8px;
//   border: 2px solid #ccc;
//   border-radius: 5px;
//   font-size: 16px;
//   box-sizing: border-box;
//   transition: border-color 0.3s ease;

//   &:focus {
//     border-color: #2980b9;
//     outline: none;
//   }
// `;

// const TermSelect = styled.select`
//   padding: 8px;
//   border: 2px solid #ccc;
//   border-radius: 5px;
//   font-size: 16px;
//   box-sizing: border-box;
//   transition: border-color 0.3s ease;

//   &:focus {
//     border-color: #2980b9;
//     outline: none;
//   }
// `;

// const StudentGradeBookEntry = () => {
//   const [formID, setFormID] = useState({
//     STUDENT_ID: '',
//     SUBJECT_NAME: '',
//     PERIODIC_TEST_1: '',
//     NOTE_BOOK_1: '',
//     SUBJECT_ENRICHMENT_1: '',
//     HALF_YEARLY: '',
//     WORK_EDUCATION_1: '',
//     ART_EDUCATION_1: '',
//     HEALTH_AND_HYGIENE_1: '',
//     REGULARITY_AND_PUNCTUALLITY_1: '',
//     PERIODIC_TEST_2: '',
//     NOTE_BOOK_2: '',
//     SUBJECT_ENRICHMENT_2: '',
//     ANNUAL: '',
//     WORK_EDUCATION_2: '',
//     ART_EDUCATION_2: '',
//     HEALTH_AND_HYGIENE_2: '',
//     REGULARITY_AND_PUNCTUALLITY_2: ''
//   });

//   const [errors, setErrors] = useState({});
//   const [term, setTerm] = useState('Term 1');
//   const [classOptions, setClassOptions] = useState([]);
//   const [selectedClass, setSelectedClass] = useState('');

//   useEffect(() => {
//     const fetchClasses = async () => {
//       try {
//         const response = await fetch('http://13.127.57.224:2081/api/classfilter');
//         if (!response.ok) {
//           throw new Error('Failed to fetch data');
//         }
//         const data = await response.json();
//         setClassOptions(data);
//       } catch (error) {
//         console.error('Error fetching data:', error);
//         setErrors(prevErrors => ({ ...prevErrors, fetchError: error.message }));
//       }
//     };

//     fetchClasses();
//   }, []);

//   const handleChange = (e) => {
//     const { name, value } = e.target;
//     setFormID(prevState => ({
//       ...prevState,
//       [name]: value
//     }));
//   };

//   const handleReset = () => {
//     setFormID({
//       STUDENT_ID: '',
//       SUBJECT_NAME: '',
//       PERIODIC_TEST_1: '',
//       NOTE_BOOK_1: '',
//       SUBJECT_ENRICHMENT_1: '',
//       HALF_YEARLY: '',
//       WORK_EDUCATION_1: '',
//       ART_EDUCATION_1: '',
//       HEALTH_AND_HYGIENE_1: '',
//       REGULARITY_AND_PUNCTUALLITY_1: '',
//       PERIODIC_TEST_2: '',
//       NOTE_BOOK_2: '',
//       SUBJECT_ENRICHMENT_2: '',
//       ANNUAL: '',
//       WORK_EDUCATION_2: '',
//       ART_EDUCATION_2: '',
//       HEALTH_AND_HYGIENE_2: '',
//       REGULARITY_AND_PUNCTUALLITY_2: ''
//     });
//     setTerm('Term 1');
//     setSelectedClass('');
//     setErrors({});
//   };

//   const handleSubmit = async (e) => {
//     e.preventDefault();

//     const formData = { ...formID, term, class: selectedClass };

//     try {
//       const response = await axios.post('http://13.127.57.224:2081/api/insertmarks', formData);
//       console.log('Response:', response.data);
//       alert('Data processed successfully!');
//       handleReset(); // Reset the form after successful submission
//     } catch (error) {
//       console.error('Error:', error);
//       alert('Error processing data. Please check the console for details.');
//     }
//   };

//   return (
//     <LoginContainer>
//         {/* <Landing /> */}
      
//             <div className="container-fluid" style={{  marginTop: '-17vh', width: '100%', padding: 0 }}>
//       <FormWrapper>
   
        
//         <FiltersAndResetContainer>
//           <FilterGroup>
//             <FilterItem>
//               <Label htmlFor="class"></Label>
//               <ClassSelect
//                 id="class"
//                 name="class"
//                 value={selectedClass}
//                 onChange={(e) => setSelectedClass(e.target.value)}
//               >
//                 <option value=""> class</option>
//                 {classOptions.map(cls => (
//                   <option key={cls.class} value={cls.class}>
//                     {cls.class}
//                   </option>
//                 ))}
//               </ClassSelect>
//             </FilterItem>

//             <FilterItem>
//               <Label htmlFor="term"></Label>
//               <TermSelect
//                 id="term"
//                 name="term"
//                 value={term}
//                 onChange={(e) => setTerm(e.target.value)}
//               >
//                 <option value="Term 1">Term 1</option>
//                 <option value="Term 2">Term 2</option>
//               </TermSelect>
//             </FilterItem>

//             <ResetButton
//               type="button"
//               onClick={handleReset}
//             >
//               Reset
//             </ResetButton>
//           </FilterGroup>
//         </FiltersAndResetContainer>

//         <Form onSubmit={handleSubmit}>
//           <InputWrapper>
//             <Label htmlFor="STUDENT_ID">Student ID:</Label>
//             <Input
//               id="STUDENT_ID"
//               name="STUDENT_ID"
//               type="text"
//               value={formID.STUDENT_ID}
//               onChange={handleChange}
//             />
//             {errors.STUDENT_ID && <Message>{errors.STUDENT_ID}</Message>}
//           </InputWrapper>
//           <InputWrapper>
//             <Label htmlFor="SUBJECT_NAME">Subject:</Label>
//             <Input
//               id="SUBJECT_NAME"
//               name="SUBJECT_NAME"
//               type="text"
//               value={formID.SUBJECT_NAME}
//               onChange={handleChange}
//             />
//             {errors.SUBJECT_NAME && <Message>{errors.SUBJECT_NAME}</Message>}
//           </InputWrapper>
//           {/* Additional input fields based on selected term */}
//           {term === 'Term 1' && (
//             <>
//               <InputWrapper>
//                 <Label htmlFor="PERIODIC_TEST_1">Periodic Test 1:</Label>
//                 <Input
//                   id="PERIODIC_TEST_1"
//                   name="PERIODIC_TEST_1"
//                   type="text"
//                   value={formID.PERIODIC_TEST_1}
//                   onChange={handleChange}
//                 />
//               </InputWrapper>
//               <InputWrapper>
//                 <Label htmlFor="NOTE_BOOK_1">Note Book 1:</Label>
//                 <Input
//                   id="NOTE_BOOK_1"
//                   name="NOTE_BOOK_1"
//                   type="text"
//                   value={formID.NOTE_BOOK_1}
//                   onChange={handleChange}
//                 />
//               </InputWrapper>
//               <InputWrapper>
//                 <Label htmlFor="SUBJECT_ENRICHMENT_1">Subject Enrichment 1:</Label>
//                 <Input
//                   id="SUBJECT_ENRICHMENT_1"
//                   name="SUBJECT_ENRICHMENT_1"
//                   type="text"
//                   value={formID.SUBJECT_ENRICHMENT_1}
//                   onChange={handleChange}
//                 />
//               </InputWrapper>
//               <InputWrapper>
//                 <Label htmlFor="HALF_YEARLY">Half Yearly:</Label>
//                 <Input
//                   id="HALF_YEARLY"
//                   name="HALF_YEARLY"
//                   type="text"
//                   value={formID.HALF_YEARLY}
//                   onChange={handleChange}
//                 />
//               </InputWrapper>
//               <InputWrapper>
//                 <Label htmlFor="WORK_EDUCATION_1">Work Education 1:</Label>
//                 <Input
//                   id="WORK_EDUCATION_1"
//                   name="WORK_EDUCATION_1"
//                   type="text"
//                   value={formID.WORK_EDUCATION_1}
//                   onChange={handleChange}
//                 />
//               </InputWrapper>
//               <InputWrapper>
//                 <Label htmlFor="ART_EDUCATION_1">Art Education 1:</Label>
//                 <Input
//                   id="ART_EDUCATION_1"
//                   name="ART_EDUCATION_1"
//                   type="text"
//                   value={formID.ART_EDUCATION_1}
//                   onChange={handleChange}
//                 />
//               </InputWrapper>
//               <InputWrapper>
//                 <Label htmlFor="HEALTH_AND_HYGIENE_1">Health and Hygiene 1:</Label>
//                 <Input
//                   id="HEALTH_AND_HYGIENE_1"
//                   name="HEALTH_AND_HYGIENE_1"
//                   type="text"
//                   value={formID.HEALTH_AND_HYGIENE_1}
//                   onChange={handleChange}
//                 />
//               </InputWrapper>
//               <InputWrapper>
//                 <Label htmlFor="REGULARITY_AND_PUNCTUALLITY_1">Regularity and Punctuality 1:</Label>
//                 <Input
//                   id="REGULARITY_AND_PUNCTUALLITY_1"
//                   name="REGULARITY_AND_PUNCTUALLITY_1"
//                   type="text"
//                   value={formID.REGULARITY_AND_PUNCTUALLITY_1}
//                   onChange={handleChange}
//                 />
//               </InputWrapper>
//             </>
//           )}

//           {term === 'Term 2' && (
//             <>
//               <InputWrapper>
//                 <Label htmlFor="PERIODIC_TEST_2">Periodic Test 2:</Label>
//                 <Input
//                   id="PERIODIC_TEST_2"
//                   name="PERIODIC_TEST_2"
//                   type="text"
//                   value={formID.PERIODIC_TEST_2}
//                   onChange={handleChange}
//                 />
//               </InputWrapper>
//               <InputWrapper>
//                 <Label htmlFor="NOTE_BOOK_2">Note Book 2:</Label>
//                 <Input
//                   id="NOTE_BOOK_2"
//                   name="NOTE_BOOK_2"
//                   type="text"
//                   value={formID.NOTE_BOOK_2}
//                   onChange={handleChange}
//                 />
//               </InputWrapper>
//               <InputWrapper>
//                 <Label htmlFor="SUBJECT_ENRICHMENT_2">Subject Enrichment 2:</Label>
//                 <Input
//                   id="SUBJECT_ENRICHMENT_2"
//                   name="SUBJECT_ENRICHMENT_2"
//                   type="text"
//                   value={formID.SUBJECT_ENRICHMENT_2}
//                   onChange={handleChange}
//                 />
//               </InputWrapper>
//               <InputWrapper>
//                 <Label htmlFor="ANNUAL">Annual:</Label>
//                 <Input
//                   id="ANNUAL"
//                   name="ANNUAL"
//                   type="text"
//                   value={formID.ANNUAL}
//                   onChange={handleChange}
//                 />
//               </InputWrapper>
//               <InputWrapper>
//                 <Label htmlFor="WORK_EDUCATION_2">Work Education 2:</Label>
//                 <Input
//                   id="WORK_EDUCATION_2"
//                   name="WORK_EDUCATION_2"
//                   type="text"
//                   value={formID.WORK_EDUCATION_2}
//                   onChange={handleChange}
//                 />
//               </InputWrapper>
//               <InputWrapper>
//                 <Label htmlFor="ART_EDUCATION_2">Art Education 2:</Label>
//                 <Input
//                   id="ART_EDUCATION_2"
//                   name="ART_EDUCATION_2"
//                   type="text"
//                   value={formID.ART_EDUCATION_2}
//                   onChange={handleChange}
//                 />
//               </InputWrapper>
//               <InputWrapper>
//                 <Label htmlFor="HEALTH_AND_HYGIENE_2">Health and Hygiene 2:</Label>
//                 <Input
//                   id="HEALTH_AND_HYGIENE_2"
//                   name="HEALTH_AND_HYGIENE_2"
//                   type="text"
//                   value={formID.HEALTH_AND_HYGIENE_2}
//                   onChange={handleChange}
//                 />
//               </InputWrapper>
//               <InputWrapper>
//                 <Label htmlFor="REGULARITY_AND_PUNCTUALLITY_2">Regularity and Punctuality 2:</Label>
//                 <Input
//                   id="REGULARITY_AND_PUNCTUALLITY_2"
//                   name="REGULARITY_AND_PUNCTUALLITY_2"
//                   type="text"
//                   value={formID.REGULARITY_AND_PUNCTUALLITY_2}
//                   onChange={handleChange}
//                 />
//               </InputWrapper>
//             </>
//           )}

//           <Button type="submit">Submit</Button>
//         </Form>
//       </FormWrapper>
//       </div>
//     </LoginContainer>
//   );
// };

// export default StudentGradeBookEntry;






import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './Admin_Model.css';
 
const StudentGradeBookEntry = () => {
  const [formID, setFormID] = useState({
    STUDENT_ID: '',
    SUBJECT_NAME: '',
    PERIODIC_TEST_1: '',
    NOTE_BOOK_1: '',
    SUBJECT_ENRICHMENT_1: '',
    HALF_YEARLY: '',
    WORK_EDUCATION_1: '',
    ART_EDUCATION_1: '',
    HEALTH_AND_HYGIENE_1: '',
    REGULARITY_AND_PUNCTUALLITY_1: '',
    PERIODIC_TEST_2: '',
    NOTE_BOOK_2: '',
    SUBJECT_ENRICHMENT_2: '',
    ANNUAL: '',
    WORK_EDUCATION_2: '',
    ART_EDUCATION_2: '',
    HEALTH_AND_HYGIENE_2: '',
    REGULARITY_AND_PUNCTUALLITY_2: ''
  });
 
  const [errors, setErrors] = useState({});
  const [term, setTerm] = useState('Term 1');
  const [classOptions, setClassOptions] = useState([]);
  const [selectedClass, setSelectedClass] = useState('');
 
  useEffect(() => {
    const fetchClasses = async () => {
      try {
        const response = await fetch('http://13.127.57.224:2081/api/classfilter');
        if (!response.ok) {
          throw new Error('Failed to fetch data');
        }
        const data = await response.json();
        setClassOptions(data);
      } catch (error) {
        console.error('Error fetching data:', error);
        setErrors(prevErrors => ({ ...prevErrors, fetchError: error.message }));
      }
    };
 
    fetchClasses();
  }, []);
 
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormID(prevState => ({
      ...prevState,
      [name]: value
    }));
  };
 
  const handleReset = () => {
    setFormID({
      STUDENT_ID: '',
      SUBJECT_NAME: '',
      PERIODIC_TEST_1: '',
      NOTE_BOOK_1: '',
      SUBJECT_ENRICHMENT_1: '',
      HALF_YEARLY: '',
      WORK_EDUCATION_1: '',
      ART_EDUCATION_1: '',
      HEALTH_AND_HYGIENE_1: '',
      REGULARITY_AND_PUNCTUALLITY_1: '',
      PERIODIC_TEST_2: '',
      NOTE_BOOK_2: '',
      SUBJECT_ENRICHMENT_2: '',
      ANNUAL: '',
      WORK_EDUCATION_2: '',
      ART_EDUCATION_2: '',
      HEALTH_AND_HYGIENE_2: '',
      REGULARITY_AND_PUNCTUALLITY_2: ''
    });
    setTerm('Term 1');
    setSelectedClass('');
    setErrors({});
  };
 
  const handleSubmit = async (e) => {
    e.preventDefault();
 
    const formData = { ...formID, term, class: selectedClass };
 
    try {
      const response = await axios.post('http://13.127.57.224:2081/api/insertmarks', formData);
      console.log('Response:', response.data);
      alert('Data processed successfully!');
      handleReset(); // Reset the form after successful submission
    } catch (error) {
      console.error('Error:', error);
      alert('Error processing data. Please check the console for details.');
    }
  };
 
  return (
    <div className="Grade_Entry_Book_Container">
      <div className="Grade_Entry_Book_FormWrapper">
      <h2>Grade Entry</h2>
        <div className="Grade_Entry_Book_FiltersAndResetContainer">
          <div className="Grade_Entry_Book_FilterGroup">
            <div className="Grade_Entry_Book_FilterItem">
              <label htmlFor="class" className="Grade_Entry_Book_Label">Class:</label>
              <select
                id="class"
                name="class"
                value={selectedClass}
                onChange={(e) => setSelectedClass(e.target.value)}
                className="Grade_Entry_Book_ClassSelect"
              >
                <option value="">Select class</option>
                {classOptions.map(cls => (
                  <option key={cls.class} value={cls.class}>
                    {cls.class}
                  </option>
                ))}
              </select>
            </div>
 
            <div className="Grade_Entry_Book_FilterItem">
              <label htmlFor="term" className="Grade_Entry _Book_Label">Term:</label>
              <select
                id="term"
                name="term"
                value={term}
                onChange={(e) => setTerm(e.target.value)}
                className="Grade_Entry_Book_TermSelect"
              >
                <option value="Term 1">Term 1</option>
                <option value="Term 2">Term 2</option>
              </select>
            </div>
            <button onClick={handleReset} className="Grade_Entry_Book_ResetButton">Reset</button>
          </div>
        </div>
 
       
     
    <form onSubmit={handleSubmit}>
    <div className="Grade_Entry_Book_FormContainer">
  <div className="Grade_Entry_Book_InputWrapper">
    <label htmlFor="STUDENT_ID" className="Grade_Entry_Book_Label">Student ID:</label>
    <input
      id="STUDENT_ID"
      name="STUDENT_ID"
      type="text"
      value={formID.STUDENT_ID}
      onChange={handleChange}
      className="Grade_Entry_Book_Input"
      placeholder="Enter student ID"
      required
    />
    {errors.STUDENT_ID && <p className="Grade_Entry_Book_Message">{errors.STUDENT_ID}</p>}
  </div>
 
  <div className="Grade_Entry_Book_InputWrapper">
    <label htmlFor="SUBJECT_NAME" className="Grade_Entry_Book_Label">Subject Name:</label>
    <input
      id="SUBJECT_NAME"
      name="SUBJECT_NAME"
      type="text"
      value={formID.SUBJECT_NAME}
      onChange={handleChange}
      className="Grade_Entry_Book_Input"
      placeholder="Enter subject name"
      required
    />
    {errors.SUBJECT_NAME && <p className="Grade_Entry_Book_Message">{errors.SUBJECT_NAME}</p>}
  </div>
 
  {term === 'Term 1' && (
    <>
      <div className="Grade_Entry_Book_InputWrapper">
        <label htmlFor="PERIODIC_TEST_1" className="Grade_Entry_Book_Label">Periodic Test 1:</label>
        <input
          id="PERIODIC_TEST_1"
          name="PERIODIC_TEST_1"
          type="number"
          value={formID.PERIODIC_TEST_1}
          onChange={handleChange}
          className="Grade_Entry_Book_Input"
          placeholder='Enter Grade'
          required
        />
        {errors.PERIODIC_TEST_1 && <p className="Grade_Entry_Book_Message">{errors.PERIODIC_TEST_1}</p>}
      </div>
 
      <div className="Grade_Entry_Book_InputWrapper">
        <label htmlFor="NOTE_BOOK_1" className="Grade_Entry_Book_Label">Note Book 1:</label>
        <input
          id="NOTE_BOOK_1"
          name="NOTE_BOOK_1"
          type="number"
          value={formID.NOTE_BOOK_1}
          onChange={handleChange}
          className="Grade_Entry_Book_Input"
          placeholder='Enter Grade'
          required
         
        />
        {errors.NOTE_BOOK_1 && <p className="Grade_Entry_Book_Message">{errors.NOTE_BOOK_1}</p>}
      </div>
 
      <div className="Grade_Entry_Book_InputWrapper">
        <label htmlFor="SUBJECT_ENRICHMENT_1" className="Grade_Entry_Book_Label">Subject Enrichment 1:</label>
        <input
          id="SUBJECT_ENRICHMENT_1"
          name="SUBJECT_ENRICHMENT_1"
          type="number"
          value={formID.SUBJECT_ENRICHMENT_1}
          onChange={handleChange}
          className="Grade_Entry_Book_Input"
         placeholder='Enter Grade'
          required
        />
        {errors.SUBJECT_ENRICHMENT_1 && <p className="Grade_Entry_Book_Message">{errors.SUBJECT_ENRICHMENT_1}</p>}
      </div>
 
      <div className="Grade_Entry_Book_InputWrapper">
        <label htmlFor="HALF_YEARLY" className="Grade_Entry_Book_Label">Half Yearly:</label>
        <input
          id="HALF_YEARLY"
          name="HALF_YEARLY"
          type="number"
          value={formID.HALF_YEARLY}
          onChange={handleChange}
          className="Grade_Entry_Book_Input"
          placeholder='Enter Grade'
          required
        />
        {errors.HALF_YEARLY && <p className="Grade_Entry_Book_Message">{errors.HALF_YEARLY}</p>}
      </div>
 
      <div className="Grade_Entry_Book_InputWrapper">
        <label htmlFor="WORK_EDUCATION_1" className="Grade_Entry_Book_Label">Work Education 1:</label>
        <input
          id="WORK_EDUCATION_1"
          name="WORK_EDUCATION_1"
          type="text"
          value={formID.WORK_EDUCATION_1}
          onChange={handleChange}
          className="Grade_Entry_Book_Input"
          placeholder='Enter Grade'
          required
        />
        {errors.WORK_EDUCATION_1 && <p className="Grade_Entry_Book_Message">{errors.WORK_EDUCATION_1}</p>}
      </div>
 
      <div className="Grade_Entry_Book_InputWrapper">
        <label htmlFor="ART_EDUCATION_1" className="Grade_Entry_Book_Label">Art Education 1:</label>
        <input
          id="ART_EDUCATION_1"
          name="ART_EDUCATION_1"
          type="text"
          value={formID.ART_EDUCATION_1}
          onChange={handleChange}
          className="Grade_Entry_Book_Input"
          placeholder='Enter Grade'
          required
        />
        {errors.ART_EDUCATION_1 && <p className="Grade_Entry_Book_Message">{errors.ART_EDUCATION_1}</p>}
      </div>
 
      <div className="Grade_Entry_Book_InputWrapper">
        <label htmlFor="HEALTH_AND_HYGIENE_1" className="Grade_Entry_Book_Label">Health and Hygiene 1:</label>
        <input
          id="HEALTH_AND_HYGIENE_1"
          name="HEALTH_AND_HYGIENE_1"
          type="text"
          value={formID.HEALTH_AND_HYGIENE_1}
          onChange={handleChange}
          className="Grade_Entry_Book_Input"
          placeholder='Enter Grade'
          required
        />
        {errors.HEALTH_AND_HYGIENE_1 && <p className="Grade_Entry_Book_Message">{errors.HEALTH_AND_HYGIENE_1}</p>}
      </div>
 
      <div className="Grade_Entry_Book_InputWrapper">
        <label htmlFor="REGULARITY_AND_PUNCTUALLITY_1" className="Grade_Entry_Book_Label">Regularity and Punctuality 1:</label>
        <input
          id="REGULARITY_AND_PUNCTUALLITY_1"
          name="REGULARITY_AND_PUNCTUALLITY_1"
          type="text"
          value={formID.REGULARITY_AND_PUNCTUALLITY_1}
          onChange={handleChange}
          className="Grade_Entry_Book_Input"
          placeholder='Enter Grade'
          required
        />
        {errors.REGULARITY_AND_PUNCTUALLITY_1 && <p className="Grade_Entry_Book_Message">{errors.REGULARITY_AND_PUNCTUALLITY_1}</p>}
      </div>
    </>
  )}
 
  {term === 'Term 2' && (
    <>
      <div className="Grade_Entry_Book_InputWrapper">
        <label htmlFor="PERIODIC_TEST_2" className="Grade_Entry_Book_Label">Periodic Test 2:</label>
        <input
          id="PERIODIC_TEST_2"
          name="PERIODIC_TEST_2"
          type="text"
          value={formID.PERIODIC_TEST_2}
          onChange={handleChange}
          className="Grade_Entry_Book_Input"
          placeholder='Enter Grade'
          required
        />
        {errors.PERIODIC_TEST_2 && <p className="Grade_Entry_Book_Message">{errors.PERIODIC_TEST_2}</p>}
      </div>
 
      <div className="Grade_Entry_Book_InputWrapper">
        <label htmlFor="NOTE_BOOK_2" className="Grade_Entry_Book_Label">Note Book 2:</label>
        <input
          id="NOTE_BOOK_2"
          name="NOTE_BOOK_2"
          type="text"
          value={formID.NOTE_BOOK_2}
          onChange={handleChange}
          className="Grade_Entry_Book_Input"
          placeholder='Enter Grade'
          required
        />
        {errors.NOTE_BOOK_2 && <p className="Grade_Entry_Book_Message">{errors.NOTE_BOOK_2}</p>}
      </div>
 
      <div className="Grade_Entry_Book_InputWrapper">
        <label htmlFor="SUBJECT_ENRICHMENT_2" className="Grade_Entry_Book_Label">Subject Enrichment 2:</label>
        <input
          id="SUBJECT_ENRICHMENT_2"
          name="SUBJECT_ENRICHMENT_2"
          type="text"
          value={formID.SUBJECT_ENRICHMENT_2}
          onChange={handleChange}
          className="Grade_Entry_Book_Input"
          placeholder='Enter Grade'
          required
        />
        {errors.SUBJECT_ENRICHMENT_2 && <p className="Grade_Entry_Book_Message">{errors.SUBJECT_ENRICHMENT_2}</p>}
      </div>
 
      <div className="Grade_Entry_Book_InputWrapper">
        <label htmlFor="ANNUAL" className="Grade_Entry_Book_Label">Annual:</label>
        <input
          id="ANNUAL"
          name="ANNUAL"
          type="text"
          value={formID.ANNUAL}
          onChange={handleChange}
          className="Grade_Entry_Book_Input"
          placeholder='Enter Grade'
          required
        />
        {errors.ANNUAL && <p className="Grade_Entry_Book_Message">{errors.ANNUAL}</p>}
      </div>
 
      <div className="Grade_Entry_Book_InputWrapper">
        <label htmlFor="WORK_EDUCATION_2" className="Grade_Entry_Book_Label">Work Education 2:</label>
        <input
          id="WORK_EDUCATION_2"
          name="WORK_EDUCATION_2"
          type="text"
          value={formID.WORK_EDUCATION_2}
          onChange={handleChange}
          className="Grade_Entry_Book_Input"
          placeholder='Enter Grade'
          required
        />
        {errors.WORK_EDUCATION_2 && <p className="Grade_Entry_Book_Message">{errors.WORK_EDUCATION_2}</p>}
      </div>
 
      <div className="Grade_Entry_Book_InputWrapper">
        <label htmlFor="ART_EDUCATION_2" className="Grade_Entry_Book_Label">Art Education 2:</label>
        <input
          id="ART_EDUCATION_2"
          name="ART_EDUCATION_2"
          type="text"
          value={formID.ART_EDUCATION_2}
          onChange={handleChange}
          className="Grade_Entry_Book_Input"
          placeholder='Enter Grade'
          required
        />
        {errors.ART_EDUCATION_2 && <p className="Grade_Entry_Book_Message">{errors.ART_EDUCATION_2}</p>}
      </div>
 
      <div className="Grade_Entry_Book_InputWrapper">
        <label htmlFor="HEALTH_AND_HYGIENE_2" className="Grade_Entry_Book_Label">Health and Hygiene 2:</label>
        <input
          id="HEALTH_AND_HYGIENE_2"
          name="HEALTH_AND_HYGIENE_2"
          type="text"
          value={formID.HEALTH_AND_HYGIENE_2}
          onChange={handleChange}
          className="Grade_Entry_Book_Input"
          placeholder='Enter Grade'
          required
        />
        {errors.HEALTH_AND_HYGIENE_2 && <p className="Grade_Entry_Book_Message">{errors.HEALTH_AND_HYGIENE_2}</p>}
      </div>
 
      <div className="Grade_Entry_Book_InputWrapper">
        <label htmlFor="REGULARITY_AND_PUNCTUALLITY_2" className="Grade_Entry_Book_Label">Regularity and Punctuality 2:</label>
        <input
          id="REGULARITY_AND_PUNCTUALLITY_2"
          name="REGULARITY_AND_PUNCTUALLITY_2"
          type="text"
          value={formID.REGULARITY_AND_PUNCTUALLITY_2}
          onChange={handleChange}
          className="Grade_Entry_Book_Input"
          placeholder='Enter Grade'
          required
        />
        {errors.REGULARITY_AND_PUNCTUALLITY_2 && <p className="Grade_Entry_Book_Message">{errors.REGULARITY_AND_PUNCTUALLITY_2}</p>}
      </div>
 
      {/* Add more Term 2 specific fields if needed */}
    </>
  )}
  </div>
  <div className="Grade_Entry_Book_Submit_Btn_Main">
  <button type="submit" className="Grade_Entry_Book_SubmitButton">Submit</button>
  </div>
</form>
 
 
       
      </div>
    </div>
  );
};
 
export default StudentGradeBookEntry;
 
 