import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import './Admin_Model.css';  // Import the new CSS file
 
const AdminNotification = () => {
  const [notifications, setNotifications] = useState([]);
  const [showPopup, setShowPopup] = useState(false);
  const [newNotificationCount, setNewNotificationCount] = useState(0);
  const navigate = useNavigate();
 
  useEffect(() => {
    const fetchNotifications = async () => {
      try {
        const response = await axios.get('http://13.127.57.224:2081/api/student-edit-request');
        console.log(response.data); // Log the data to check its structure
        setNotifications(response.data);
        const unreadCount = response.data.filter((notif) => notif.isNew).length;
        setNewNotificationCount(unreadCount); // Set the count of new notifications
      } catch (error) {
        console.error('Error fetching notifications:', error);
      }
    };
 
    fetchNotifications();
  }, []);
 
  const handleShowNotification = (notification) => {
    if (notification.isNew) {
      // Update notifications state to mark as read
      setNotifications((prevNotifications) =>
        prevNotifications.map((notif) =>
          notif.REQUEST_ID === notification.REQUEST_ID
            ? { ...notif, isNew: false }
            : notif
        )
      );
      // Decrease the count of new notifications
      setNewNotificationCount((prevCount) => prevCount - 1);
    }
 
    // Navigate to StudentDataTable with REQUEST_ID
    navigate(`/Student_Data_Table?REQUEST_ID=${notification.REQUEST_ID}`);
    setShowPopup(false); // Close the popup after selecting a notification
  };
 
  return (
    <div className="Admin_Notification_container">
      <div className="bellIconContainer">
        <span className="bell" onClick={() => setShowPopup(!showPopup)}>🔔</span>
        {newNotificationCount > 0 && (
          <span className="bounceBadge">{newNotificationCount}</span>
        )}
      </div>
 
      {showPopup && (
        <div className="popup">
          {notifications.length === 0 ? (
            <p className="noNotificationText">No notifications</p>
          ) : (
            notifications.map((notification) => (
              <div
                key={notification.REQUEST_ID}
                className={`notificationItem ${notification.isNew ? 'fadeIn' : ''}`}
                style={{
                  backgroundColor: notification.isNew ? '#e0f7fa' : '#fff', // Highlight new notifications
                }}
                onClick={() => handleShowNotification(notification)}
              >
                <span
                  className={`notificationMessage ${notification.isNew ? 'bold' : ''}`}
                >
                  {notification.ISSUE}
                </span>
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
};
 
export default AdminNotification;
 

