

//   import React, { useEffect, useRef, useState } from 'react';
//   import styled from 'styled-components';
//   import { Link, useLocation, useNavigate } from 'react-router-dom';
//   import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
//   import { faBars, faPowerOff } from '@fortawesome/free-solid-svg-icons';
//   import 'bootstrap/dist/css/bootstrap.min.css'; // Import Bootstrap
//   import AdminNotification from './Admin_Notification.js';
//   import { Modal, Button } from 'react-bootstrap'; // Import Bootstrap Modal components
//   import Message from './Messages.js';

//   const Navbar = styled.div`
//   position: fixed;
//   top: 0;
//   left: ${props => (props.sidebarVisible ? '14%' : '2%')};
//   height: 9%;
//   width: 100%;
//   background-color: #e3f2fd; /* Powder Blue */
//   color: Black;
//   display: flex;
//   align-items: center;
//   padding: 0 4rem;
//   border-bottom: 1px solid #e1e6eb;
//   transition: left 0.3s ease, width 0.3s ease;
//   z-index: 999;
//   box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1); /* Soft shadow */

//   @media only screen and (max-width: 768px) {
//     left: 0;
//     padding: 0 1rem;
//   }
// `;

  
//   const Sidebar = styled.div`
//     position: fixed;
//     top: 0;
//     left: 0;
//     width: ${props => (props.sidebarVisible ? '14%' : '0')};
//     height: 100%;
//     background-color: #2e4053;
//     overflow-x: hidden;
//     transition: 0.3s;
//     z-index: 1000;
//   `;
  
//   const NavItem = styled(Link)`
//     color: Black;
//     text-decoration: none;
//     margin-left: 2.5rem;
//     font-size: 1.1rem;
  
//     @media only screen and (max-width: 768px) {
//       margin-left: 1rem;
//       font-size: 0.9rem;
//     }
//   `;
  
//   const ToggleButton = styled.div`
//     font-size: 1.1rem;
//     color: Black;
//     cursor: pointer;
//     position: absolute;
//     top: 1.1rem;
//     left: 3.8rem;
//     z-index: 1001;
  
//     @media only screen and (max-width: 768px) {
//       left: 1.1rem;
//       top: 1.1rem;
//     }
//   `;
  
//   const LogoutButton = styled.button`
//     border: none;
//     color: black;
//     cursor: pointer;
//     display: flex;
//     align-items: center;
//     font-size: 1.1rem;
//     padding: 0.4rem 0.4rem;
//     background: transparent;
//     position: absolute; 
//     right: ${props => (props.sidebarVisible ? '15rem' : '3rem')};
//     top: 50%; 
//     transform: translateY(-50%);
  
//     &:active {
//       color: black;
//     }
  
//     @media only screen and (max-width: 768px) {
//       right: ${props => (props.sidebarVisible ? '6rem' : '1rem')};
//       font-size: 0.9rem;
//     }
//   `;
  
//   const AdminNotificationWrapper = styled.div`
//     position: absolute;
//     right: ${props => (props.sidebarVisible ? '17rem' : '5rem')};
//     top: 50%;
//     transform: translateY(-50%);
//     cursor: pointer;
  
//     @media only screen and (max-width: 768px) {
//       right: ${props => (props.sidebarVisible ? '8rem' : '3rem')};
//     }
//   `;

//   const HomeWrapper = styled.div`
//   position: absolute;
//   right: ${props => (props.sidebarVisible ? '20rem' : '7rem')};
//   top: 50%;
//   transform: translateY(-50%);
//   cursor: pointer;

//   @media only screen and (max-width: 768px) {
//     right: ${props => (props.sidebarVisible ? '8rem' : '3rem')};
//   }
// `;

// const MessageWrapper = styled.div`
// position: absolute;
// right: ${props => (props.sidebarVisible ? '25rem' : '15rem')};
// top: 50%;
// transform: translateY(-50%);
// cursor: pointer;

// @media only screen and (max-width: 768px) {
//   right: ${props => (props.sidebarVisible ? '8rem' : '3rem')};
// }
// `;
  
//   const StyledNavItem = styled.div`
//     display: inline-block;
//     font-size: 1.1rem;
//     padding: 13px 16px;
//     color: Black;
//     border-radius: 12px;
//     margin-right: 40rem;
//     text-transform: uppercase; /* Make text uppercase */

//     @media only screen and (max-width: 768px) {
//       padding: 10px 12px;
//       font-size: 0.9rem;
//       margin-left: 1rem;
//     }
//   `;
  
//   const Greeting = ({ userRole }) => {
//     const [greetingMessage, setGreetingMessage] = useState('');
  
//     useEffect(() => {
//       const now = new Date();
//       const hours = now.getHours();
  
//       let greeting = '';
//       if (hours < 12) greeting = 'Good Morning';
//       else if (hours < 18) greeting = 'Good Afternoon';
//       else greeting = 'Good Evening';
  
//       setGreetingMessage(`${greeting}, ${userRole || 'User'}!`);
//     }, [userRole]);
  
//     return (
//       <div style={{ 
//         display: 'flex', 
//         flexDirection: 'column',
//         alignItems: 'flex-start', 
//         padding: '10px 20px', 
//         background: 'transparent', 
//         color: '#333',
//         fontSize: '1rem'
//       }}>
//         <h2 style={{
//           fontSize: '0.9rem',
//           color: 'black',
//           textShadow: '1px 1px 2px rgba(0, 0, 0, 0.2)',
//           margin: 0,
//         }}>
//           {greetingMessage}
//         </h2>
//       </div>
//     );
//   };
  
//   // Navbar Component
//   const NavbarComponent = ({ toggleSidebar, sidebarVisible }) => {
//     const location = useLocation();
//     const navigate = useNavigate();
//     const [showModal, setShowModal] = useState(false); // State to control modal visibility
  
//     const getCurrentPageName = () => {
//       const pageNames = {
        // '/DashBoard': 'DashBoard',
        // '/Enrollment': 'Enrollment List',
        // '/Grad_Report': 'Grade Report',
        // '/Student_Profile': 'Student Profile',
        // '/parent_profile': 'Parent Profile',
        // '/Student_Attendance': 'Student Attendance',
        // '/Student_Academic_Performance': 'Student Academic Performance',
        // '/Student_health': 'Student Health',
        // '/Student_Grad_Book': 'Student Grad Book',
        // '/Student_performance': 'Student Performance',
        // '/Assignment': 'Assignment',
        // '/Assignment_Form': 'Assignment Form',
        // '/Application_form': 'Application Form',
        // '/StudentFill_Attendance': 'Fill Attendance',
        // '/Student_Grade_Book_Entry': 'Grade Book Entry',
        // '/Student_promoted_form': 'Student Promoted Form',
        // '/Staff_Attendance': 'Staff Attendance',
        // '/Staff_Profile': 'Staff Profile',
        // '/Messages': 'Messages',
        // '/Time_Table_schedule': 'Time Table schedule',
        // '/Joining_Latter': 'Joining Latter',
//       };
  
//       return pageNames[location.pathname] || 'Dashboard';
//     };
  
//     const handleLogout = () => {
//       setShowModal(true); // Show modal when logout is clicked
//     };
  
//     const confirmLogout = () => {
//       setShowModal(false); // Hide modal
//       navigate('/Login'); // Navigate to login page
//     };
  
//     return (
//       <>
//         <Sidebar sidebarVisible={sidebarVisible}>
//           {/* Sidebar content goes here */}
//         </Sidebar>
//         <Navbar sidebarVisible={sidebarVisible} className="d-flex align-items-center justify-content-between">
//           <ToggleButton onClick={toggleSidebar}>
//             <FontAwesomeIcon icon={faBars} />
//           </ToggleButton>
         
//           <Greeting userRole="Admin" />
  
//           <StyledNavItem>{getCurrentPageName()}</StyledNavItem>
//           <HomeWrapper  sidebarVisible={sidebarVisible} to="/DashBoard" isActive={location.pathname === '/DashBoard'} className="d-none d-md-block">
//             Home
//           </HomeWrapper>

//           <MessageWrapper
//         sidebarVisible={sidebarVisible}
//         to="/Message"
//         isActive={location.pathname === '/Message'}
//         className="d-none d-md-block"
//       >
//         <Message sidebarVisible={sidebarVisible} />
//       </MessageWrapper>

//           <LogoutButton onClick={handleLogout} sidebarVisible={sidebarVisible}>
//             <FontAwesomeIcon icon={faPowerOff} />
//           </LogoutButton>
//           <AdminNotificationWrapper sidebarVisible={sidebarVisible}>
//             <AdminNotification />
//           </AdminNotificationWrapper>
//         </Navbar>
  
//         {/* Logout Confirmation Modal */}
//         <Modal show={showModal} onHide={() => setShowModal(false)}>
//           <Modal.Header closeButton>
//             <Modal.Title>Confirm Logout</Modal.Title>
//           </Modal.Header>
//           <Modal.Body>Are you sure you want to log out?</Modal.Body>
//           <Modal.Footer>
//             <Button variant="secondary" onClick={() => setShowModal(false)}>
//               No
//             </Button>
//             <Button variant="primary" onClick={confirmLogout}>
//               Yes
//             </Button>
//           </Modal.Footer>
//         </Modal>
//       </>
//     );
//   };
  
//   export default NavbarComponent;
  


import React, { useEffect, useState } from 'react';
import styled from 'styled-components';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faBars, faPowerOff } from '@fortawesome/free-solid-svg-icons';
import 'bootstrap/dist/css/bootstrap.min.css'; // Import Bootstrap
import AdminNotification from './Admin_Notification.js';
import { Modal, Button } from 'react-bootstrap'; // Import Bootstrap Modal components
import Message from './Messages.js';

const Navbar = styled.div`
  position: fixed;
  top: 0;
  left: ${props => (props.sidebarVisible ? '14%' : '2%')};
  height: 9%;
  width: 100%;
  background-color: #e3f2fd; /* Powder Blue */
  color: Black;
  display: flex;
  align-items: center;
  padding: 0 4rem;
  border-bottom: 1px solid #e1e6eb;
  transition: left 0.3s ease, width 0.3s ease;
  z-index: 999;
  box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1); /* Soft shadow */

  @media only screen and (max-width: 768px) {
    left: 0;
    padding: 0 1rem;
  }
`;

const Sidebar = styled.div`
  position: fixed;
  top: 0;
  left: 0;
  width: ${props => (props.sidebarVisible ? '14%' : '0')};
  height: 100%;
  background-color: #2e4053;
  overflow-x: hidden;
  transition: 0.3s;
  z-index: 1000;
`;

const NavItem = styled(Link)`
  color: Black;
  text-decoration: none;
  margin-left: 2.5rem;
  font-size: 1.1rem;

  @media only screen and (max-width: 768px) {
    margin-left: 1rem;
    font-size: 0.9rem;
  }
`;

const ToggleButton = styled.div`
  font-size: 1.1rem;
  color: Black;
  cursor: pointer;
  position: absolute;
  top: 1.1rem;
  left: 3.8rem;
  z-index: 1001;

  @media only screen and (max-width: 768px) {
    left: 1.1rem;
    top: 1.1rem;
  }
`;

const LogoutButton = styled.button`
  border: none;
  color: black;
  cursor: pointer;
  display: flex;
  align-items: center;
  font-size: 1.1rem;
  padding: 0.4rem 0.4rem;
  background: transparent;
  position: absolute; 
  right: ${props => (props.sidebarVisible ? '15rem' : '3rem')};
  top: 50%; 
  transform: translateY(-50%);

  &:active {
    color: black;
  }

  @media only screen and (max-width: 768px) {
    right: ${props => (props.sidebarVisible ? '6rem' : '1rem')};
    font-size: 0.9rem;
  }
`;

const AdminNotificationWrapper = styled.div`
  position: absolute;
  right: ${props => (props.sidebarVisible ? '17rem' : '5rem')};
  top: 50%;
  transform: translateY(-50%);
  cursor: pointer;

  @media only screen and (max-width: 768px) {
    right: ${props => (props.sidebarVisible ? '8rem' : '3rem')};
  }
`;

const HomeWrapper = styled.div`
  position: absolute;
  right: ${props => (props.sidebarVisible ? '20rem' : '7rem')};
  top: 50%;
  transform: translateY(-50%);
  cursor: pointer;

  @media only screen and (max-width: 768px) {
    right: ${props => (props.sidebarVisible ? '8rem' : '3rem')};
  }
`;

const MessageWrapper = styled.div`
position: absolute;
right: ${props => (props.sidebarVisible ? '25rem' : '15rem')};
top: 50%;
transform: translateY(-50%);
cursor: pointer;

@media only screen and (max-width: 768px) {
  right: ${props => (props.sidebarVisible ? '8rem' : '3rem')};
}
`;

const StyledNavItem = styled.div`
  display: inline-block;
  font-size: 1.1rem;
  padding: 13px 16px;
  color: Black;
  border-radius: 12px;
  margin-right: 40rem;
  text-transform: uppercase; /* Make text uppercase */

  @media only screen and (max-width: 768px) {
    padding: 10px 12px;
    font-size: 0.9rem;
    margin-left: 1rem;
  }
`;

const Greeting = ({ userRole }) => {
  const [greetingMessage, setGreetingMessage] = useState('');

  useEffect(() => {
    const now = new Date();
    const hours = now.getHours();

    let greeting = '';
    if (hours < 12) greeting = 'Good Morning';
    else if (hours < 18) greeting = 'Good Afternoon';
    else greeting = 'Good Evening';

    setGreetingMessage(`${greeting}, ${userRole || 'User'}!`);
  }, [userRole]);

  return (
    <div style={{ 
      display: 'flex', 
      flexDirection: 'column',
      alignItems: 'flex-start', 
      padding: '10px 20px', 
      background: 'transparent', 
      color: '#333',
      fontSize: '1rem'
    }}>
      <h2 style={{
        fontSize: '0.9rem',
        color: 'black',
        textShadow: '1px 1px 2px rgba(0, 0, 0, 0.2)',
        margin: 0,
      }}>
        {greetingMessage}
      </h2>
    </div>
  );
};

// Navbar Component
const NavbarComponent = ({ toggleSidebar, sidebarVisible }) => {
  const location = useLocation();
  const navigate = useNavigate();
  const [showModal, setShowModal] = useState(false); // State to control modal visibility
  const [showMessageOptions, setShowMessageOptions] = useState(false); // State to control message options modal

  const getCurrentPageName = () => {
    const pageNames = {
      '/DashBoard': 'DashBoard',
        '/Enrollment': 'Enrollment List',
        '/Grad_Report': 'Grade Report',
        '/Student_Profile': 'Student Profile',
        '/parent_profile': 'Parent Profile',
        '/Student_Attendance': 'Student Attendance',
        '/Student_Academic_Performance': 'Student Academic Performance',
        '/Student_health': 'Student Health',
        '/Student_Grad_Book': 'Student Grad Book',
        '/Student_performance': 'Student Performance',
        '/Assignment': 'Assignment',
        '/Assignment_Form': 'Assignment Form',
        '/Application_form': 'Application Form',
        '/StudentFill_Attendance': 'Fill Attendance',
        '/Student_Grade_Book_Entry': 'Grade Book Entry',
        '/Student_promoted_form': 'Student Promoted Form',
        '/Staff_Attendance': 'Staff Attendance',
        '/Staff_Profile': 'Staff Profile',
        '/Messages': 'Messages',
        '/Time_Table_schedule': 'Time Table schedule',
        '/Joining_Latter': 'Joining Latter',
        '/Hiring': ' Teacher Hiring Form',

    };

    return pageNames[location.pathname] || 'Dashboard';
  };

  const handleLogout = () => {
    setShowModal(true); // Show logout confirmation modal
  };

  const confirmLogout = () => {
    setShowModal(false);
    navigate('/Login'); // Navigate to login page
  };

  return (
    <>
      <Sidebar sidebarVisible={sidebarVisible}>
        {/* Sidebar content goes here */}
      </Sidebar>
      <Navbar sidebarVisible={sidebarVisible} className="d-flex align-items-center justify-content-between">
        <ToggleButton onClick={toggleSidebar}>
          <FontAwesomeIcon icon={faBars} />
        </ToggleButton>
       
        <Greeting userRole="Admin" />

        <StyledNavItem>{getCurrentPageName()}</StyledNavItem>
        <HomeWrapper sidebarVisible={sidebarVisible} to="/DashBoard" className="d-none d-md-block">
          Home
        </HomeWrapper>

          <MessageWrapper
            sidebarVisible={sidebarVisible}
            onClick={() => setShowMessageOptions(true)} // Open message options modal
          >
            Message
          </MessageWrapper>

        <LogoutButton onClick={handleLogout} sidebarVisible={sidebarVisible}>
          <FontAwesomeIcon icon={faPowerOff} />
        </LogoutButton>
        <AdminNotificationWrapper sidebarVisible={sidebarVisible}>
          <AdminNotification />
        </AdminNotificationWrapper>
      </Navbar>

      {/* Message Options Modal */}
      <Modal show={showMessageOptions} onHide={() => setShowMessageOptions(false)}>
        <Modal.Header closeButton>
          <Modal.Title>Choose an Option</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Button variant="primary" onClick={() => navigate('/Notice_Form')}>
            Notice Form
          </Button>
          <Button variant="secondary" onClick={() => navigate('/Messages')} style={{ marginLeft: '68%',margin:'30%' }}>
            Message Form
          </Button>
        </Modal.Body>
      </Modal>

      {/* Logout Confirmation Modal */}
      <Modal show={showModal} onHide={() => setShowModal(false)}>
        <Modal.Header closeButton>
          <Modal.Title>Confirm Logout</Modal.Title>
        </Modal.Header>
        <Modal.Body>Are you sure you want to log out?</Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowModal(false)}>
            No
          </Button>
          <Button variant="danger" onClick={confirmLogout}>
            Yes
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
};

export default NavbarComponent;


