
// import React, { useEffect, useRef } from 'react';
// import { useLocation } from 'react-router-dom';
// import NavbarComponent from './navbar';
// import SidebarComponent from './Sidebar';

// const Layout = ({ children, toggleSidebar, sidebarVisible }) => {
//   const location = useLocation();
//   const layoutRef = useRef(null);

//   const shouldShowSidebarAndNavbar = () => {
//     const path = location.pathname;
//     return !['/', '/Login', '/Signup'].includes(path);
//   };

//   // Handle clicks outside sidebar and navbar
//   const handleClickOutside = (event) => {
//     if (layoutRef.current && !layoutRef.current.contains(event.target)) {
//       toggleSidebar(); // Close the sidebar
//     }
//   };

//   useEffect(() => {
//     document.addEventListener('mousedown', handleClickOutside);
//     return () => {
//       document.removeEventListener('mousedown', handleClickOutside);
//     };
//   }, []);

//   return (
//     <div ref={layoutRef} style={{ position: 'relative' }}>
//       {shouldShowSidebarAndNavbar() && (
//         <>
//           <NavbarComponent toggleSidebar={toggleSidebar} sidebarVisible={sidebarVisible} />
//           <div className="d-flex flex-grow-1">
//             <div
//               className={`bg-light border-end ${sidebarVisible ? 'd-block' : 'd-none d-md-block'}`}
//               style={{ width: sidebarVisible ? '16%' : '0', transition: 'width 0.4s' }}
//             >
//               <SidebarComponent isVisible={sidebarVisible} />
//             </div>
//             <div className="flex-grow-4 p-4">
//               {children}
//             </div>
//           </div>
//         </>
//       )}
//       {!shouldShowSidebarAndNavbar() && children}
//     </div>
//   );
// };

// export default Layout;





import React, { useEffect, useRef ,useState} from 'react';
import { useLocation } from 'react-router-dom';
import NavbarComponent from './navbar';
import SidebarComponent from './Sidebar';

const Layout = ({ children, toggleSidebar, sidebarVisible }) => {
  const location = useLocation();
  const layoutRef = useRef(null);
  const [isSidebarHovered, setSidebarHovered] = useState(false);

  const shouldShowSidebarAndNavbar = () => {
    const path = location.pathname;
    return !['/', '/Login', '/Signup','/Staff_Dashbord','/Notice_Form','/Staff_Attandance','/Messages' ,'/Staff_Assignment_Table','/Staff_Grade Entry','/Student_Dashboard', '/Edit_Form','/Staff_Assignment','/Staff_Grade_Entry','/Student_Assignment','/Student_Attendance_Dashbord','/Staff_Student_InformationAssignment','/Staff_Assignment_Form','/Staff_Select_Assignment','/Staff_Approve_Assignment','/Staff_Assignment_Overview'].includes(path);
  };

  // Handle clicks outside sidebar and navbar
  const handleClickOutside = (event) => {
    if (layoutRef.current && !layoutRef.current.contains(event.target)) {
      toggleSidebar(); // Close the sidebar
    }
  };

  useEffect(() => {
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  return (
    <div ref={layoutRef} style={{ position: 'relative' }}>
      {shouldShowSidebarAndNavbar() && (
        <>
          <NavbarComponent toggleSidebar={toggleSidebar} sidebarVisible={sidebarVisible} />
          <div className="d-flex">
            <div
              className={`bg-light border-end ${sidebarVisible ? 'd-block' : 'd-none d-md-block'}`}
              onMouseEnter={() => setSidebarHovered(true)}
              onMouseLeave={() => setSidebarHovered(false)}
              style={{ width: sidebarVisible ? '4%' : '5%', transition: 'width 0.4s' }}
            >
              <SidebarComponent isVisible={sidebarVisible || isSidebarHovered} />
              </div>
            <div
              className="flex-grow-1 p-4"
              style={{
                marginLeft: sidebarVisible ? '12%' : '0', // Shift content next to sidebar
                transition: 'margin-left 0.4s',
              }}
            >
              {children}
            </div>
          </div>
        </>
      )}
      {!shouldShowSidebarAndNavbar() && children}
    </div>
  );
};

export default Layout;


// import React, { useEffect, useRef, useState } from 'react';
// import { useLocation } from 'react-router-dom';
// import NavbarComponent from './navbar';
// import SidebarComponent from './Sidebar';

// const Layout = ({ children, toggleSidebar, sidebarVisible }) => {
//   const location = useLocation();
//   const layoutRef = useRef(null);
//   const [isSidebarHovered, setSidebarHovered] = useState(false);

//   const shouldShowSidebarAndNavbar = () => {
//     const path = location.pathname;
//     return !['/', '/Login', '/Signup', '/Staff_Dashbord', '/Staff_Grade Entry', '/Student_Dashboard', '/Edit_Form', '/Staff_Assignment', '/Staff_Grade_Entry', '/Student_Assignment', '/Student_Attendance_Dashbord', '/Staff_Student_InformationAssignment', '/Staff_Assignment_Form', '/Staff_Select_Assignment', '/Staff_Approve_Assignment', '/Staff_Assignment_Overview'].includes(path);
//   };

//   // Handle clicks outside sidebar and navbar
//   const handleClickOutside = (event) => {
//     if (layoutRef.current && !layoutRef.current.contains(event.target)) {
//       toggleSidebar(); // Close the sidebar
//     }
//   };

//   useEffect(() => {
//     document.addEventListener('mousedown', handleClickOutside);
//     return () => {
//       document.removeEventListener('mousedown', handleClickOutside);
//     };
//   }, []);

//   return (
//     <div ref={layoutRef} style={{ position: 'relative' }}>
//       {shouldShowSidebarAndNavbar() && (
//         <>
//           <NavbarComponent toggleSidebar={toggleSidebar} sidebarVisible={sidebarVisible} />
//           <div className="d-flex">
//             <div
//               className={`bg-light border-end ${sidebarVisible ? 'd-block' : 'd-none d-md-block'}`}
//               onMouseEnter={() => setSidebarHovered(true)}
//               onMouseLeave={() => setSidebarHovered(false)}
//               style={{
//                 width: sidebarVisible || isSidebarHovered ? '12%' : '4%', // Wider when visible or hovered
//                 transition: 'width 0.4s'
//               }}
//             >
//               <SidebarComponent isVisible={sidebarVisible || isSidebarHovered} />
//             </div>
//             <div
//               className="flex-grow-1 p-4"
//               style={{
//                 marginLeft: sidebarVisible || isSidebarHovered ? '12%' : '0', // Adjust content based on sidebar state
//                 transition: 'margin-left 0.4s',
//               }}
//             >
//               {children}
//             </div>
//           </div>
//         </>
//       )}
//       {!shouldShowSidebarAndNavbar() && children}
//     </div>
//   );
// };

// export default Layout;
