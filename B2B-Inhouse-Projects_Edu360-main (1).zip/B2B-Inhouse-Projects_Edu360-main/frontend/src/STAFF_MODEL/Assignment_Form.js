import React, { useState, useEffect } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import styled from 'styled-components';


const Container = styled.div`
  width: 100%;
  padding: 10px;
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
`;

const Card = styled.div`
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
  border-radius: 12px;
  overflow: hidden;
  background: #ffffff;
`;

const CardHeader = styled.div`
background: linear-gradient(to right, #012353, #27AE60);
  color: white;
  padding: 10px;
`;

const HeaderContent = styled.div`
  display: flex;
  align-items: center;
`;



const Title = styled.h1`
  font-size: 1.3rem;
  margin-left: 15px;
  font-weight: 500;
`;

const CardBody = styled.div`
  padding: 10px;
  background-color: #f8f9fa;
`;

const FormGroup = styled.div`
  margin-bottom: 1rem;
`;

const FormLabel = styled.label`
  font-size: 1.2rem;
  font-weight: 600;
  margin-bottom: 0.5rem;
  color: #2c3e50;
  display: block;
`;

const FormControl = styled.input`
  width: 100%;
  height: 45px;
  font-size: 1rem;
  padding: 0.75rem;
  border: 1px solid #ced4da;
  border-radius: 5px;
  transition: border-color 0.3s ease, box-shadow 0.3s ease;

  &:focus {
    border-color: #3498db;
    box-shadow: 0 0 0 0.2rem rgba(52, 152, 219, 0.25);
    outline: none;
  }
`;

const FormSelect = styled.select`
  width: 100%;
  height: 45px;
  font-size: 1rem;
  padding: 0.75rem;
  border: 1px solid #ced4da;
  border-radius: 5px;
  transition: border-color 0.3s ease, box-shadow 0.3s ease;

  &:focus {
    border-color: #3498db;
    box-shadow: 0 0 0 0.2rem rgba(52, 152, 219, 0.25);
    outline: none;
  }
`;

const RadioButtonLabel = styled.label`
  font-size: 1rem;
  display: flex;
  align-items: center;
  margin-right: 15px;
  color: #2c3e50;
`;

const RadioButtonInput = styled.input`
  margin-right: 8px;
`;

const SubmitButton = styled.button`
  background: linear-gradient(to right, #012353, #27AE60);
  color: white;
  border: none;
  padding: 5px 35px;
  font-size: 1.2rem;
  cursor: pointer;
  border-radius: 5px;
  transition: background 0.3s ease, transform 0.3s ease, box-shadow 0.3s ease;

  &:hover {
    background: linear-gradient(to right, #2980b9, #27ae60);
    transform: scale(1.05);
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
  }

  &:active {
    background: linear-gradient(to right, #1f618d, #1e8449);
  }
`;

const Notification = styled.div`
  padding: 10px;
  margin-top: 10px;
  border-radius: 5px;
  color: white;
  background-color: ${props => (props.success ? '#27AE60' : '#e74c3c')};
`;

const AssignmentForm = () => {
  const [formData, setFormData] = useState({
    StartDate: '',
    Class: '',
    Subject: '',
    AssignmentType: '',
    AssignmentDescription: '',
    SubmissionStartDate: '',
    SubmissionEndDate: '',
    ClassOptions: [],
    SubjectOptions: []
  });

  const [assignments, setAssignments] = useState([]);
  const [notification, setNotification] = useState({ show: false, success: false, message: '' });

  useEffect(() => {
    fetch('http://13.127.57.224:2081/api/assignment')
      .then(response => response.json())
      .then(data => {
        // Check if data is an array before mapping
        if (Array.isArray(data)) {
          setFormData(prevState => ({
            ...prevState,
            ClassOptions: data.map(item => item.CLASS),
            SubjectOptions: data.map(item => ({ id: item.SUBJECT, name: item.SUBJECT }))
          }));
        } else {
          console.error('Expected an array, but got:', data);
        }
      })
      .catch(error => {
        console.error('Error fetching data:', error);
      });
  }, []);
  

  const handleChange = (e) => {
    const { id, value } = e.target;
    setFormData(prevState => ({ ...prevState, [id]: value }));
  };

  const handleDateChange = (date, id) => {
    setFormData(prevState => ({ ...prevState, [id]: date }));
  };

  const handleAssignmentTypeChange = (e) => {
    const { value } = e.target;
    setFormData(prevState => ({ ...prevState, AssignmentType: value }));
  };

  const handleAddRow = () => {
    fetch('http://13.127.57.224:2081/api/assignmentdata', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(formData),
    })
      .then(response => {
        if (response.ok) {
          setNotification({ show: true, success: true, message: 'Assignment added successfully!' });
          return response.json();
        } else {
          setNotification({ show: true, success: false, message: 'Error adding assignment.' });
          throw new Error('Error adding assignment.');
        }
      })
      .then(data => {
        setAssignments([...assignments, formData]);
        setFormData({
          StartDate: '',
          Class: '',
          Subject: '',
          AssignmentType: '',
          AssignmentDescription: '',
          SubmissionStartDate: '',
          SubmissionEndDate: '',
          ClassOptions: formData.ClassOptions,
          SubjectOptions: formData.SubjectOptions
        });
      })
      .catch((error) => {
        console.error('Error:', error);
      });
  };

  return (
    <Container>
       {/* <Landing /> */}
       <div className="container-fluid" style={{ marginLeft: 'vh', marginTop: '5vh', width: '99%', padding: 0 }}>
      <Card>
        <CardHeader>
          <HeaderContent>
            
            <Title>Class Assignment</Title>
          </HeaderContent>
        </CardHeader>
        <CardBody>
          <div className="row">
            <div className="col-md-6">
              <FormGroup>
                <FormLabel htmlFor="StartDate">Start Date:</FormLabel>
                <DatePicker
                  id="StartDate"
                  selected={formData.StartDate}
                  onChange={(date) => handleDateChange(date, "StartDate")}
                  className="form-control"
                  dateFormat="dd/MM/yyyy"
                  placeholderText="Select Date"
                />
              </FormGroup>
            </div>
            <div className="col-md-6">
              <FormGroup>
                <FormLabel htmlFor="Class">Class</FormLabel>
                <FormSelect
                  id="Class"
                  value={formData.Class}
                  onChange={handleChange}
                >
                  <option value="">Select class</option>
                  {formData.ClassOptions.map((option, index) => (
                    <option key={index} value={option}>{option}</option>
                  ))}
                </FormSelect>
              </FormGroup>
            </div>
            <div className="col-md-6">
              <FormGroup>
                <FormLabel htmlFor="Subject">Subject</FormLabel>
                <FormSelect
                  id="Subject"
                  value={formData.Subject}
                  onChange={handleChange}
                >
                  <option value="">Select subject</option>
                  {formData.SubjectOptions.map((option) => (
                    <option key={option.id} value={option.id}>{option.name}</option>
                  ))}
                </FormSelect>
              </FormGroup>
            </div>
            <div className="col-md-6">
              <FormGroup>
                <FormLabel>Assignment Type</FormLabel>
                <div>
                  {['Reading', 'Writing', 'Project', 'Activity'].map(type => (
                    <RadioButtonLabel key={type}>
                      <RadioButtonInput
                        type="radio"
                        value={type}
                        checked={formData.AssignmentType === type}
                        onChange={handleAssignmentTypeChange}
                      />
                      {type}
                    </RadioButtonLabel>
                  ))}
                </div>
              </FormGroup>
            </div>
            <div className="col-md-12">
              <FormGroup>
                <FormLabel htmlFor="AssignmentDescription">Assignment Description</FormLabel>
                <FormControl
                  type="text"
                  id="AssignmentDescription"
                  value={formData.AssignmentDescription}
                  onChange={handleChange}
                  placeholder="Enter Description"
                />
              </FormGroup>
            </div>
            <div className="col-md-6">
              <FormGroup>
                <FormLabel htmlFor="SubmissionStartDate">Submission Start Date</FormLabel>
                <DatePicker
                  id="SubmissionStartDate"
                  selected={formData.SubmissionStartDate}
                  onChange={(date) => handleDateChange(date, "SubmissionStartDate")}
                  className="form-control"
                  dateFormat="dd/MM/yyyy"
                  placeholderText="Select Date"
                />
              </FormGroup>
            </div>
            <div className="col-md-6">
              <FormGroup>
                <FormLabel htmlFor="SubmissionEndDate">Submission End Date</FormLabel>
                <DatePicker
                  id="SubmissionEndDate"
                  selected={formData.SubmissionEndDate}
                  onChange={(date) => handleDateChange(date, "SubmissionEndDate")}
                  className="form-control"
                  dateFormat="dd/MM/yyyy"
                  placeholderText="Select Date"
                />
              </FormGroup>
            </div>
          </div>
          <div className="row">
            <div className="col-md-12 text-right">
              <SubmitButton onClick={handleAddRow}>Submit</SubmitButton>
            </div>
          </div>
          {notification.show && (
            <Notification success={notification.success}>
              {notification.message}
            </Notification>
          )}
        </CardBody>
      </Card>
      </div>
    </Container>
  );
};

export default AssignmentForm;





