import React, { useState, useEffect } from 'react';
import axios from 'axios';
import styled from 'styled-components';
import { useParams, useNavigate } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faAngleDoubleLeft, faEdit, faSave } from '@fortawesome/free-solid-svg-icons';

const FormWrapper = styled.div`
      max-width: 100%;
    margin: 30px auto;
    padding: 10px;
    background-color: #f2f5f8;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
`;

const Title = styled.h1`
    font-size: 1.5rem;
    padding: 1.3rem;
    background-color: #34495E;
    color: #FFFFFF;
    border-radius: 10px;
    display: flex;
    align-items: center; /* Center items vertically */
`;

const StyledForm = styled.form`
    display: flex;
    flex-direction: column;
    gap: 20px;
`;

const Section = styled.div`
    margin-top: 20px;
`;

const SectionTitle = styled.h3`
    color: black;
    padding-bottom: 10px;
    margin-bottom: 10px;
    position: relative;
    display: inline-block;

    &::after {
        content: '';
        position: absolute;
        left: 0;
        bottom: 0;
        width: 100%;
        height: 3px;
        background: linear-gradient(to right, #012353, #27ae60);
    }
`;

const Label = styled.label`
    color: #333;
`;

const Input = styled.input`
    width: calc(100% - 20px);
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 4px;
    font-size: 14px;
    transition: border-color 0.3s ease;

    &:focus {
        outline: none;
        border-color: #007bff;
        box-shadow: 0 0 5px rgba(0, 123, 255, 0.5);
    }
`;

const Select = styled.select`
    width: calc(100% - 20px);
    padding: 7px;
    border: 1px solid #ccc;
    border-radius: 10px;
    font-size: 14px;
`;

const Textarea = styled.textarea`
    width: calc(100% - 20px);
    padding: 7px;
    border: 1px solid #ccc;
    border-radius: 10px;
    font-size: 14px;
    transition: border-color 0.3s ease;

    &:focus {
        outline: none;
        border-color: #007bff;
        box-shadow: 0 0 5px rgba(0, 123, 255, 0.5);
    }
`;

const Button = styled.button`
    padding: 10px 40px;
    background: linear-gradient(to right, #012353, #27ae60);
    color: #fff;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    transition: background-color 0.3s ease;
`;

const StaffDetail = () => {
    const { staffId } = useParams();
    const [formData, setFormData] = useState({
        STAFF_ID: '',
        STAFF_NAME: '',
        CONTACT_NUMBER: '',
        STAFF_ROLE: '',
        DATE_OF_JOINING: '',
        MONTHLY_SALARY: '',
        FATHER_HUSBAND_NAME: '',
        GENDER: '',
        EXPERIENCE: '',
        ADHAR_ID: '',
        RELIGION: '',
        EMAIL: '',
        EDUCATION: '',
        BLOOD_GROUP: '',
        DATE_OF_BIRTH: '',
        ADDRESS: '',
        CITY: '',
        STATE: '',
        POSTAL_CODE: '',
        EXIT_DATE: '',
      
    });

    const navigate = useNavigate();
    const [editMode, setEditMode] = useState(false);

    useEffect(() => {
        const fetchData = async () => {
            try {
                const response = await axios.get(`http://13.127.57.224:2081/api/staffupdate/${staffId}`);
                const data = response.data;
                data.DATE_OF_BIRTH = data.DATE_OF_BIRTH ? data.DATE_OF_BIRTH.split('T')[0] : '';
                data.DATE_OF_JOINING = data.DATE_OF_JOINING ? data.DATE_OF_JOINING.split('T')[0] : '';
                data.EXIT_DATE = data.EXIT_DATE ? data.EXIT_DATE.split('T')[0] : '';
                setFormData(data);
                setEditMode(false);
            } catch (error) {
                console.error('Error fetching data:', error);
            }
        };

        if (staffId) {
            fetchData();
        }
    }, [staffId]);

    const handleChange = (e) => {
        const { name, value } = e.target;

        if (name === 'DATE_OF_BIRTH' || name === 'DATE_OF_JOINING' || name === 'EXIT_DATE') {
            const formattedDate = value ? new Date(value).toISOString().split('T')[0] : '';
            setFormData(prevState => ({
                ...prevState,
                [name]: formattedDate
            }));
        } else {
            setFormData(prevState => ({
                ...prevState,
                [name]: value
            }));
        }
    };

    const handleBackClick = () => {
        navigate(-1);
    };

    const handleEditClick = () => {
        setEditMode(true);
    };

    const handleSaveClick = async (e) => {
        e.preventDefault();
        try {
            if (editMode) {
                await axios.put(`http://13.127.57.224:2081/api/staffupdate/${staffId}`, formData);
                alert('Data updated successfully!');
                navigate(-1); // Navigate back to the previous page
            }
            setEditMode(false);
        } catch (error) {
            console.error('Error updating data:', error);
            alert('Error updating data. Please check console for details.');
        }
    };

    return (
        <div>
            <FormWrapper>
                <Title>
                    <FontAwesomeIcon icon={faAngleDoubleLeft} style={{ marginRight: '10px' }} onClick={handleBackClick} />
                    Staff Details
                </Title>
                <StyledForm onSubmit={handleSaveClick}>
                    <Section>
                        <SectionTitle>Staff Information</SectionTitle>
                        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '20px' }}>
                            <div>
                                <Label htmlFor="STAFF_ID">Staff ID</Label>
                                <Input
                                    type="text"
                                    id="STAFF_ID"
                                    name="STAFF_ID"
                                    value={formData.STAFF_ID}
                                    onChange={handleChange}
                                    required
                                    readOnly={!editMode}
                                />
                            </div>
                           
                            <div>
                                <Label htmlFor="STAFF_NAME">Staff Name</Label>
                                <Input
                                    type="text"
                                    id="STAFF_NAME"
                                    name="STAFF_NAME"
                                    value={formData.STAFF_NAME}
                                    onChange={handleChange}
                                    readOnly={!editMode}
                                />
                            </div>
                            <div>
                                <Label htmlFor="CONTACT_NUMBER">Contact Number</Label>
                                <Input
                                    type="text"
                                    id="CONTACT_NUMBER"
                                    name="CONTACT_NUMBER"
                                    value={formData.CONTACT_NUMBER}
                                    onChange={handleChange}
                                    readOnly={!editMode}
                                />
                            </div>
                            <div>
                                <Label htmlFor="STAFF_ROLE">Staff Role</Label>
                                <Input
                                    type="text"
                                    id="STAFF_ROLE"
                                    name="STAFF_ROLE"
                                    value={formData.STAFF_ROLE}
                                    onChange={handleChange}
                                    readOnly={!editMode}
                                />
                            </div>
                            <div>
                                <Label htmlFor="DATE_OF_JOINING">Date of Joining</Label>
                                <Input
                                    type="date"
                                    id="DATE_OF_JOINING"
                                    name="DATE_OF_JOINING"
                                    value={formData.DATE_OF_JOINING}
                                    onChange={handleChange}
                                    readOnly={!editMode}
                                />
                            </div>
                            <div>
                                <Label htmlFor="MONTHLY_SALARY">Monthly Salary</Label>
                                <Input
                                    type="text"
                                    id="MONTHLY_SALARY"
                                    name="MONTHLY_SALARY"
                                    value={formData.MONTHLY_SALARY}
                                    onChange={handleChange}
                                    readOnly={!editMode}
                                />
                            </div>
                            <div>
                                <Label htmlFor="FATHER_HUSBAND_NAME">Father/Husband Name</Label>
                                <Input
                                    type="text"
                                    id="FATHER_HUSBAND_NAME"
                                    name="FATHER_HUSBAND_NAME"
                                    value={formData.FATHER_HUSBAND_NAME}
                                    onChange={handleChange}
                                    readOnly={!editMode}
                                />
                            </div>
                            <div>
                                <Label htmlFor="GENDER">Gender</Label>
                                <Select
                                  type="text"
                                    id="GENDER"
                                    name="GENDER"
                                    value={formData.GENDER}
                                    onChange={handleChange}
                                    disabled={!editMode}
                                >
                                    <option value="">Select Gender</option>
                                    <option value="Male">Male</option>
                                    <option value="Female">Female</option>
                                    <option value="Other">Other</option>
                                </Select>
                            </div>
                            <div>
                                <Label htmlFor="EXPERIENCE">Experience</Label>
                                <Input
                                    type="text"
                                    id="EXPERIENCE"
                                    name="EXPERIENCE"
                                    value={formData.EXPERIENCE}
                                    onChange={handleChange}
                                    readOnly={!editMode}
                                />
                            </div>
                            <div>
                                <Label htmlFor="ADHAR_ID">Aadhar ID</Label>
                                <Input
                                    type="text"
                                    id="ADHAR_ID"
                                    name="ADHAR_ID"
                                    value={formData.ADHAR_ID}
                                    onChange={handleChange}
                                    readOnly={!editMode}
                                />
                            </div>
                            <div>
                                <Label htmlFor="RELIGION">Religion</Label>
                                <Input
                                    type="text"
                                    id="RELIGION"
                                    name="RELIGION"
                                    value={formData.RELIGION}
                                    onChange={handleChange}
                                    readOnly={!editMode}
                                />
                            </div>
                            <div>
                                <Label htmlFor="EMAIL">Email</Label>
                                <Input
                                    type="email"
                                    id="EMAIL"
                                    name="EMAIL"
                                    value={formData.EMAIL}
                                    onChange={handleChange}
                                    readOnly={!editMode}
                                />
                            </div>
                            <div>
                                <Label htmlFor="EDUCATION">Education</Label>
                                <Input
                                    type="text"
                                    id="EDUCATION"
                                    name="EDUCATION"
                                    value={formData.EDUCATION}
                                    onChange={handleChange}
                                    readOnly={!editMode}
                                />
                            </div>
                            <div>
                                <Label htmlFor="BLOOD_GROUP">Blood Group</Label>
                                <Select
                                    id="BLOOD_GROUP"
                                    name="BLOOD_GROUP"
                                    value={formData.BLOOD_GROUP}
                                    onChange={handleChange}
                                    required
                                    disabled={!editMode}
                                >
                                    <option value="">Select Blood Group</option>
                                    <option value="A+">A+</option>
                                    <option value="A-">A-</option>
                                    <option value="B+">B+</option>
                                    <option value="B-">B-</option>
                                    <option value="AB+">AB+</option>
                                    <option value="AB-">AB-</option>
                                    <option value="O+">O+</option>
                                    <option value="O-">O-</option>
                                </Select>
                            </div>
                            <div>
                                <Label htmlFor="DATE_OF_BIRTH">Date of Birth</Label>
                                <Input
                                    type="date"
                                    id="DATE_OF_BIRTH"
                                    name="DATE_OF_BIRTH"
                                    value={formData.DATE_OF_BIRTH}
                                    onChange={handleChange}
                                    readOnly={!editMode}
                                />
                            </div>
                            <div>
                                <Label htmlFor="ADDRESS">Address</Label>
                                <Textarea
                                    id="ADDRESS"
                                    name="ADDRESS"
                                    value={formData.ADDRESS}
                                    onChange={handleChange}
                                    rows="3"
                                    readOnly={!editMode}
                                />
                            </div>
                            <div>
                                <Label htmlFor="CITY">City</Label>
                                <Input
                                    type="text"
                                    id="CITY"
                                    name="CITY"
                                    value={formData.CITY}
                                    onChange={handleChange}
                                    readOnly={!editMode}
                                />
                            </div>
                            <div>
                                <Label htmlFor="STATE">State</Label>
                                <Input
                                    type="text"
                                    id="STATE"
                                    name="STATE"
                                    value={formData.STATE}
                                    onChange={handleChange}
                                    readOnly={!editMode}
                                />
                            </div>
                            <div>
                                <Label htmlFor="POSTAL_CODE">Postal Code</Label>
                                <Input
                                    type="text"
                                    id="POSTAL_CODE"
                                    name="POSTAL_CODE"
                                    value={formData.POSTAL_CODE}
                                    onChange={handleChange}
                                    readOnly={!editMode}
                                />
                            </div>
                          
<div>
                                <Label htmlFor="EXIT_DATE">Exit Date</Label>
                                <Input
                                    type="date"
                                    id="EXIT_DATE"
                                    name="EXIT_DATE"
                                    value={formData.EXIT_DATE}
                                    onChange={handleChange}
                                    readOnly={!editMode}
                                />
                            </div>
                       </div>
                       </Section>
               <div style={{ display: 'flex', justifyContent: 'center', gap: '10px' }}>
                        {!editMode && (
                            <Button type="button" onClick={handleEditClick}>
                                <FontAwesomeIcon icon={faEdit} style={{ marginRight: '5px' }} />
                                Edit
                            </Button>
                        )}
                        {editMode && (
                            <Button type="submit">
                                <FontAwesomeIcon icon={faSave} style={{ marginRight: '5px' }} />
                                Save
                            </Button>
                             )}
                    </div>
                </StyledForm>
            </FormWrapper>
        </div>
    );
};

export default StaffDetail;