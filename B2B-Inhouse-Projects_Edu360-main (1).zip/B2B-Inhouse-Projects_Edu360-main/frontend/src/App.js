// import React, { useState, useRef, useEffect } from 'react'; 
// import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
// import Layout from './ADMIN_MODEL/MainLayout';
// import { log } from './logger';
// import 'bootstrap/dist/css/bootstrap.min.css';

// // Import your page components
// import Login from './SECURITY & OTHERS/Login';
// import Signup from './SECURITY & OTHERS/Signup';
// import Home from './SECURITY & OTHERS/Home';
// import NotFound from './SECURITY & OTHERS/NotFound'; 
// import PrivateRoutes from './SECURITY & OTHERS/PrivateRoutes';
// import { AuthProvider } from './SECURITY & OTHERS/AuthContext';
// import ErrorBoundary from './SECURITY & OTHERS/ErrorBoundary';

// // All the imported page components for the private routes
// import DashBoard from './ADMIN_MODEL/DashBoard';
// import StudentProfile from './STUDENT_MODEL/Student_Profile';
// import StudentAttendance from './STUDENT_MODEL/Student_Attendance';
// import StudentFillAttendance from './STUDENT_MODEL/StudentFill_Attendance';
// import StaffProfile from './STAFF_MODEL/Staff_Profile';
// import StaffAttendance from './STAFF_MODEL/Staff_Attendance';
// import TimeTable from './ADMIN_MODEL/Time_Table';
// import ExamSheduling from './ADMIN_MODEL/Exam_Sheduling';
// import Event from './ADMIN_MODEL/Event';
// import Enrollment from './ADMIN_MODEL/Enrollment';
// import StudentDetail from './STUDENT_MODEL/Student_Detail';
// import StaffDetail from './STAFF_MODEL/Staff_Detail';
// import ParentDetail from './STUDENT_MODEL/Parent_Detail';
// import Landing from './ADMIN_MODEL/Landing';
// import AttendanceChart from './ADMIN_MODEL/Staff_Attendance_Chart';
// import PerformanceSummary from './ADMIN_MODEL/Dashbord_Performance_Summary';
// import EventCalender from './ADMIN_MODEL/Event_Calender';
// import MissionVision from './SECURITY & OTHERS/MissionVision';
// import Contact from './SECURITY & OTHERS/Contact';
// import Aboutus from './SECURITY & OTHERS/About_us';
// import Services from './SECURITY & OTHERS/Services';
// import ParentProfile from './STUDENT_MODEL/parent_profile';
// import Applicationform from './ADMIN_MODEL/Application_form';
// import Studenthealth from './STUDENT_MODEL/Student_health';
// import AcademicPerformance from './STUDENT_MODEL/Student_Academic_Performance';
// import AssignmentForm from './STAFF_MODEL/Assignment_Form';
// import Assignment from './STAFF_MODEL/Assignment';
// import DashbordStudentAttendance from './ADMIN_MODEL/Student_Attendance_Chart';
// import StudentGradeBookEntry from './ADMIN_MODEL/Student_Grade_Book_Entry';
// import Studentperformance from './STUDENT_MODEL/Student_performance';
// import StudentGradBook from './STUDENT_MODEL/Student_Grad_Book';
// import Studentpromotedform from './ADMIN_MODEL/Student_promoted_form';
// import GradReport from './ADMIN_MODEL/Grad_Report';
// import Messages from './ADMIN_MODEL/Messages';
// import StudentDashboard from './STUDENT_DASHBOARD/Student_Dashboard';
// import Studenteventcalendar from './STUDENT_DASHBOARD/Student_eventcalendar';
// import Studenterformance from './STUDENT_DASHBOARD/Student_performance_Chart';
// import StudentLanding from './STUDENT_DASHBOARD/Student_landing';

// const App = () => {
//   const [sidebarVisible, setSidebarVisible] = useState(false);
//   const sidebarRef = useRef(null);

//   useEffect(() => {
//     log('App component rendered');
//   }, []);

//   const toggleSidebar = () => setSidebarVisible(!sidebarVisible);

//   const handleClickOutside = (event) => {
//     if (sidebarRef.current && !sidebarRef.current.contains(event.target)) {
//       setSidebarVisible(false);
//     }
//   };

//   // Helper function for Protected Routes
//   const withLayout = (element) => (
//     <Layout toggleSidebar={toggleSidebar} sidebarVisible={sidebarVisible}>
//       {element}
//     </Layout>
//   );

//   return (
//     <AuthProvider>
//       <Router>
//         <div className="d-flex flex-column vh-100">
//           <ErrorBoundary>
//             <Routes>
//               {/* Public Routes */}
//               <Route path="/" element={<Home />} />
//               <Route path="/Login" element={<Login />} />
//               <Route path="/Signup" element={<Signup />} />

//               {/* Protected Routes with Layout */}
//               <Route element={<PrivateRoutes />}>
//                 <Route path="/DashBoard" element={withLayout(<DashBoard />)} />
//                 <Route path="/Student_Profile" element={withLayout(<StudentProfile />)} />
//                 <Route path="/Student_Attendance" element={withLayout(<StudentAttendance />)} />
//                 <Route path="/StudentFill_Attendance" element={withLayout(<StudentFillAttendance />)} />
//                 <Route path="/Staff_Profile" element={withLayout(<StaffProfile />)} />
//                 <Route path="/Staff_Attendance" element={withLayout(<StaffAttendance />)} />
//                 <Route path="/Time_Table" element={withLayout(<TimeTable />)} />
//                 <Route path="/Exam_Sheduling" element={withLayout(<ExamSheduling />)} />
//                 <Route path="/Event" element={withLayout(<Event />)} />
//                 <Route path="/Enrollment" element={withLayout(<Enrollment />)} />
//                 <Route path="/Student_Detail/:studentId" element={withLayout(<StudentDetail />)} />
//                 <Route path="/Staff_Detail/:staffId" element={withLayout(<StaffDetail />)} />
//                 <Route path="/Parent_Detail/:studentId" element={withLayout(<ParentDetail />)} />
//                 <Route path="/Landing" element={withLayout(<Landing />)} />
//                 <Route path="/AttendanceChart" element={withLayout(<AttendanceChart />)} />
//                 <Route path="/PerformanceSummary" element={withLayout(<PerformanceSummary />)} />
//                 <Route path="/EventCalender" element={withLayout(<EventCalender />)} />
//                 <Route path="/MissionVision" element={withLayout(<MissionVision />)} />
//                 <Route path="/Contact" element={withLayout(<Contact />)} />
//                 <Route path="/Aboutus" element={withLayout(<Aboutus />)} />
//                 <Route path="/Services" element={withLayout(<Services />)} />
//                 <Route path="/parent_profile" element={withLayout(<ParentProfile />)} />
//                 <Route path="/Application_form" element={withLayout(<Applicationform />)} />
//                 <Route path="/Student_health" element={withLayout(<Studenthealth />)} />
//                 <Route path="/Student_Academic_Performance" element={withLayout(<AcademicPerformance />)} />
//                 <Route path="/Assignment_Form" element={withLayout(<AssignmentForm />)} />
//                 <Route path="/Assignment" element={withLayout(<Assignment />)} />
//                 <Route path="/DashbordStudent_Attendance" element={withLayout(<DashbordStudentAttendance />)} />
//                 <Route path="/Student_Grade_Book_Entry" element={withLayout(<StudentGradeBookEntry />)} />
//                 <Route path="/Student_performance" element={withLayout(<Studentperformance />)} />
//                 <Route path="/Student_Grad_Book" element={withLayout(<StudentGradBook />)} />
//                 <Route path="/Student_promoted_form" element={withLayout(<Studentpromotedform />)} />
//                 <Route path="/Grad_Report" element={withLayout(<GradReport />)} />
//                 <Route path="/Messages" element={withLayout(<Messages />)} />
//                 <Route path="/Student_Dashboard" element={withLayout(<StudentDashboard />)} />
//                 <Route path="/Student_eventcalendar" element={withLayout(<Studenteventcalendar />)} />
//                 <Route path="/Student_performance_Chart" element={withLayout(<Studenterformance />)} />
//                 <Route path="/Student_landing" element={withLayout(<StudentLanding />)} />
//               </Route>

//               {/* 404 - Not Found Route */}
//               <Route path="*" element={<NotFound />} />
//             </Routes>
//           </ErrorBoundary>
//         </div>
//       </Router>
//     </AuthProvider>
//   );
// };

// export default App;



import React, { useState, useRef } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css'; // Import Bootstrap CSS

// SECURITY & OTHERS Pages
import { log } from './logger';
import ErrorBoundary from './SECURITY & OTHERS/ErrorBoundary'; // Import the ErrorBoundary
import NotFound from './SECURITY & OTHERS/NotFound.js'; // Import the NotFound component

import Login from './SECURITY & OTHERS/Login.js';
import Home from './SECURITY & OTHERS/Home.js';
import Signup from './SECURITY & OTHERS/Signup.js';
import MissionVision from './SECURITY & OTHERS/MissionVision.js';
import Contact from './SECURITY & OTHERS/Contact.js';
import Aboutus from './SECURITY & OTHERS/About_us.js';
import Services from './SECURITY & OTHERS/Services.js';
import PrivateRoutes from './SECURITY & OTHERS/PrivateRoutes'; // Import the PrivateRoutes component
import { AuthProvider } from './SECURITY & OTHERS/AuthContext';

// ADMIN_MODEL Pages
import Layout from './ADMIN_MODEL/MainLayout'; // Import the Layout component
import Landing from './ADMIN_MODEL/Landing.js';

import TimeTable from './ADMIN_MODEL/Time_Table.js';
import ExamSheduling from './ADMIN_MODEL/Exam_Sheduling.js';
import Event from './ADMIN_MODEL/Event.js';
import DashBoard from './ADMIN_MODEL/DashBoard.js';
import PerformanceSummary from './ADMIN_MODEL/Dashbord_Performance_Summary.js';
import EventCalender from './ADMIN_MODEL/Event_Calender.js';
import Applicationform from './ADMIN_MODEL/Application_form.js';
import Enrollment from './ADMIN_MODEL/Enrollment.js';
import AttendanceChart from './ADMIN_MODEL/Staff_Attendance_Chart.js';
import DashbordStudentAttendance from './ADMIN_MODEL/Student_Attendance_Chart.js';
import Studentpromotedform from './ADMIN_MODEL/Student_promoted_form.js';
import GradReport from './ADMIN_MODEL/Grad_Report.js';
import Messages from './ADMIN_MODEL/Messages.js';
import AdminNotification from './ADMIN_MODEL/Admin_Notification.js';
import StudentGradeBookEntry from './ADMIN_MODEL/Student_Grade_Book_Entry.js';
import GirlBoy from './ADMIN_MODEL/Girl_Boy.js';
import TimeTableschedule from './ADMIN_MODEL/Time_Table_schedule.js';
import JoiningLatter from './ADMIN_MODEL/Joining_Latter';
import NoticeForm from './ADMIN_MODEL/Notice_Form';
import Hiring from './ADMIN_MODEL/Hiring';

// STAFF_MODEL Pages
import StaffProfile from './STAFF_MODEL/Staff_Profile.js';
import StaffAttendance from './STAFF_MODEL/Staff_Attendance.js';
import AssignmentForm from './STAFF_MODEL/Assignment_Form.js';
import Assignment from './STAFF_MODEL/Assignment.js';
import StaffDetail from './STAFF_MODEL/Staff_Detail.js';

// STAFF_DASHBORD Pages
import Staffnavbar from './STAFF_DASHBORD/Staff_navbar.js';
import StaffAssignmentOverview from './STAFF_DASHBORD/Staff_Assignment_Overview.js';
import Staffcalendar from './STAFF_DASHBORD/Staff_calendar.js';
import StaffDashbord from './STAFF_DASHBORD/Staff_Dashbord.js';
import Staffshedule from './STAFF_DASHBORD/Staff_shedule.js';
import StaffGradeEntry from './STAFF_DASHBORD/Staff_Grade_Entry.js';
import StaffAssignmentsDashboard from './STAFF_DASHBORD/Staff_Assignments_Dashboard.js';
import StaffAssignmentForm from './STAFF_DASHBORD/Staff_Assignment_Form.js';
import StaffSelectAssignment from './STAFF_DASHBORD/Staff_Select_Assignment';
import StaffApproveAssignment from './STAFF_DASHBORD/Staff_Approve_Assignment';
import StaffStudentInformationAssignment from './STAFF_DASHBORD/Staff_Student_InformationAssignment';
import StaffTimeTableschedule from './STAFF_DASHBORD/Staff_TimeTable_schedule';
import StaffAssignmentTable from './STAFF_DASHBORD/Staff_Assignment_Table';
import StudentList from './STAFF_DASHBORD/Student_List';
import StaffAssignmentList from './STAFF_DASHBORD/Staff_Assignment_List';
import StaffAssignmentDetail from './STAFF_DASHBORD/Staff_Assignment_Detail';
import StaffAttandance from './STAFF_DASHBORD/Staff_Attandance';

// STUDENT_MODEL Pages
import ParentProfile from './STUDENT_MODEL/parent_profile.js';
import Studenthealth from './STUDENT_MODEL/Student_health.js';
import AcademicPerformance from './STUDENT_MODEL/Student_Academic_Performance.js';
import StudentDetail from './STUDENT_MODEL/Student_Detail.js';
import ParentDetail from './STUDENT_MODEL/Parent_Detail.js';
import StudentAttendance from './STUDENT_MODEL/Student_Attendance.js';
import StudentProfile from './STUDENT_MODEL/Student_Profile.js';
import StudentFillAttendance from './STUDENT_MODEL/StudentFill_Attendance.js';
import StudentGradBook from './STUDENT_MODEL/Student_Grad_Book.js';
import Studentperformance from './STUDENT_MODEL/Student_performance.js';

// STUDENT_DASHBOARD Pages
import StudentDashboard from './STUDENT_DASHBOARD/Student_Dashboard.js';
import Studenteventcalendar from './STUDENT_DASHBOARD/Student_eventcalendar.js';
import Studenterformance from './STUDENT_DASHBOARD/Student_performance_Chart.js';
import StudentLanding from './STUDENT_DASHBOARD/Student_landing.js';
import EditForm from './STUDENT_DASHBOARD/Edit_Form.js';
import StudentDataTable from './STUDENT_DASHBOARD/Student_Data_Table.js';
import StudentAttendanceDashbord from './STUDENT_DASHBOARD/Student_Attendance_Dashbord'; // Ensure this file exists
import StudentAssignment from './STUDENT_DASHBOARD/Student_Assignment';
import StudentTimeTableschedule from './STUDENT_DASHBOARD/Student_TimeTable_schedule';
import DeveloperDashboard from './SECURITY & OTHERS/DeveloperDashboard.js';
import BulkLoad from './ADMIN_MODEL/BulkLoad.js';


const App = () => {
  const [sidebarVisible, setSidebarVisible] = useState(false);
  const sidebarRef = useRef(null);

  const toggleSidebar = () => {
    setSidebarVisible(!sidebarVisible);
  };

  const handleClickOutside = (event) => {
    if (sidebarRef.current && !sidebarRef.current.contains(event.target)) {
      setSidebarVisible(false);
    }
  };

  // Helper function for Protected Routes
  const withLayout = (element) => (
    <Layout toggleSidebar={toggleSidebar} sidebarVisible={sidebarVisible}>
      {element}
    </Layout>
  );

  return (
    <AuthProvider>
      <Router>
        <div className="d-flex flex-column vh-100">
        <ErrorBoundary>
          <Routes>
            {/* Public Routes */}
            <Route path="/" element={<Home />} />
            <Route path="/Login" element={<Login />} />
            <Route path="/Signup" element={<Signup />} />

            {/* Protected Routes */}
            <Route element={<PrivateRoutes />}>
             

              <Route path="/BulkLoad" element={<BulkLoad />} />
              <Route path="/DeveloperDashboard" element={<DeveloperDashboard />} />
              <Route path="/Student_Profile" element={withLayout(<StudentProfile />)} />
              <Route path="/DashBoard" element={withLayout(<DashBoard />)} />
              <Route path="/Student_Attendance" element={withLayout(<StudentAttendance />)} />
              <Route path="/StudentFill_Attendance" element={withLayout(<StudentFillAttendance />)} />
              <Route path="/Staff_Profile" element={withLayout(<StaffProfile />)} />
              <Route path="/Staff_Attendance" element={withLayout(<StaffAttendance />)} />
              <Route path="/Time_Table" element={withLayout(<TimeTable />)} />
              <Route path="/Exam_Sheduling" element={withLayout(<ExamSheduling />)} />
              <Route path="/Event" element={withLayout(<Event />)} />
              <Route path="/Enrollment" element={withLayout(<Enrollment />)} />
              <Route path="/Student_Detail/:studentId" element={withLayout(<StudentDetail />)} />
              <Route path="/Staff_Detail/:staffId" element={withLayout(<StaffDetail />)} />
              <Route path="/Parent_Detail/:studentId" element={withLayout(<ParentDetail />)} />
              <Route path="/Landing" element={withLayout(<Landing />)} />
              <Route path="/AttendanceChart" element={withLayout(<AttendanceChart />)} />
              <Route path="/PerformanceSummary" element={withLayout(<PerformanceSummary />)} />
              <Route path="/EventCalender" element={withLayout(<EventCalender />)} />
              <Route path="/MissionVision" element={withLayout(<MissionVision />)} />
              <Route path="/Contact" element={withLayout(<Contact />)} />
              <Route path="/Aboutus" element={withLayout(<Aboutus />)} />
              <Route path="/Services" element={withLayout(<Services />)} />
              <Route path="/parent_profile" element={withLayout(<ParentProfile />)} />
              <Route path="/Application_form" element={withLayout(<Applicationform />)} />
              <Route path="/Student_health" element={withLayout(<Studenthealth />)} />
              <Route path="/Student_Academic_Performance" element={withLayout(<AcademicPerformance />)} />
              <Route path="/Assignment_Form" element={withLayout(<AssignmentForm />)} />
              <Route path="/Assignment" element={withLayout(<Assignment />)} />
              <Route path="/DashbordStudent_Attendance" element={withLayout(<DashbordStudentAttendance />)} />
              <Route path="/Student_Grade_Book_Entry" element={withLayout(<StudentGradeBookEntry />)} />
              <Route path="/Student_performance" element={withLayout(<Studentperformance />)} />
              <Route path="/Student_Grad_Book" element={withLayout(<StudentGradBook />)} />
              <Route path="/Student_promoted_form" element={withLayout(<Studentpromotedform />)} />
              <Route path="/Grad_Report" element={withLayout(<GradReport />)} />
              <Route path="/Messages" element={withLayout(<Messages />)} />
              <Route path="/Student_Dashboard" element={withLayout(<StudentDashboard />)} />
              <Route path="/Student_eventcalendar" element={withLayout(<Studenteventcalendar />)} />
              <Route path="/Student_performance_Chart" element={withLayout(<Studenterformance />)} />
              <Route path="/Student_landing" element={withLayout(<StudentLanding />)} />
              <Route path="/Edit_Form" element={withLayout(<EditForm />)} />
              <Route path="/Student_Data_Table" element={withLayout(<StudentDataTable />)} />
              <Route path="/Student_Assignment" element={withLayout(<StudentAssignment />)} />
              <Route path="/Student_TimeTable_schedule" element={withLayout(<StudentTimeTableschedule />)} />
              {/* <Route path="/Student_landing" element={<StudentLanding />} /> */}
              <Route path="/Staff_navbar" element={withLayout(<Staffnavbar />)} />
              <Route path="/Staff_assignment_overview" element={withLayout(<StaffAssignmentOverview />)} />
              <Route path="/Staff_calendar" element={withLayout(<Staffcalendar />)} />
              <Route path="/Staff_Dashbord" element={withLayout(<StaffDashbord />)} />
              <Route path="/Staff_schedule" element={withLayout(<Staffshedule />)} />
              <Route path="/Staff_grade_entry" element={withLayout(<StaffGradeEntry />)} />
              <Route path="/Staff_assignments_dashboard" element={withLayout(<StaffAssignmentsDashboard />)} />
              <Route path="/Staff_assignment_form" element={withLayout(<StaffAssignmentForm />)} />
              <Route path="/Staff_select_assignment" element={withLayout(<StaffSelectAssignment />)} />
              <Route path="/Staff_approve_assignment" element={withLayout(<StaffApproveAssignment />)} />
              <Route path="/Staff_student_information_assignment" element={withLayout(<StaffStudentInformationAssignment />)} />
              <Route path="/Staff_time_table_schedule" element={withLayout(<StaffTimeTableschedule />)} />
              <Route path="/Student_attendance_dashboard" element={withLayout(<StudentAttendanceDashbord />)} />
        
              {/* Routes for Admin Model */}
              <Route path="/admin_notification" element={withLayout(<AdminNotification />)} />
              <Route path="/student_grade_book_entry" element={withLayout(<StudentGradeBookEntry />)} />
              <Route path="/girl_boy" element={withLayout(<GirlBoy />)} />
              <Route path="/time_table_schedule" element={withLayout(<TimeTableschedule />)} />
              <Route path="/joining_latter" element={withLayout(<JoiningLatter />)} />
              <Route path="/Staff_Assignment_Table" element={withLayout(<StaffAssignmentTable />)} />
              <Route path="/Student_List" element={withLayout(<StudentList />)} />
              <Route path="/Staff_Assignment_List" element={withLayout(<StaffAssignmentList />)} />
              <Route path="/Staff_Assignment_Detail" element={withLayout(<StaffAssignmentDetail />)} />
              <Route path="/Notice_Form" element={withLayout(<NoticeForm />)} />
              <Route path="/Staff_Attandance" element={withLayout(<StaffAttandance />)} />
              <Route path="/Hiring" element={withLayout(<Hiring />)} />

              </Route>
             {/* Catch-all 404 Route */}
             <Route path="*" element={<NotFound />} />
              
          </Routes>
          </ErrorBoundary>
        </div>
      </Router>
    </AuthProvider>
  );
};

export default App;
