

// import React, { useState, useEffect } from 'react';
// import 'bootstrap/dist/css/bootstrap.min.css';
// import { Doughnut } from 'react-chartjs-2';
// import styled from 'styled-components';
// import { Chart as ChartJS, ArcElement, Title, Tooltip, Legend, CategoryScale, LinearScale, BarElement } from 'chart.js';
// import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
// import { faClipboardList as faClipboardListSolid } from '@fortawesome/free-solid-svg-icons';
// import Staffcalendar from './Staff_calendar';
// import Staffshedule from './Staff_shedule.js';
// import Staffnavbar from './Staff_navbar.js';
// import StaffAssignmentsDashboard from './Staff_Assignments_Dashboard.js';

// // Registering Chart.js components
// ChartJS.register(ArcElement, Title, Tooltip, Legend, CategoryScale, LinearScale, BarElement);

// // Styled Components
// const Container = styled.div`
//   padding: 20px;
//   width: 100%;
//   height: 100vh;
//   margin: 0;
//   background-color: #f4f7fa;
// `;

// const Header = styled.div`
//   background: linear-gradient(to right, #012353, #27ae60);
//   color: white;
//   padding: 40px;
//   border-radius: 20px;
//   text-align: center;
//   margin-bottom: 20px;
//   box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
// `;

// const ChartContainer = styled.div`
//   display: flex;
//   flex-wrap: wrap;
//   gap: 20px;
//   margin-bottom: 30px;
// `;

// const ChartCard = styled.div`
//   flex: 1 1 30%;
//   background-color: #ffffff;
//   border-radius: 20px;
//   box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
//   overflow: hidden;
//   transition: transform 0.3s;

//   &:hover {
//     transform: translateY(-5px);
//     box-shadow: 0 8px 30px rgba(0, 0, 0, 0.2);
//   }
// `;

// const ChartHeader = styled.div`
//   background: linear-gradient(#92ea89, #859d9d, #c2e2e2);
//   color: white;
//   padding: 20px;
//   border-radius: 20px 20px 0 0;
//   display: flex;
//   align-items: center;
//   font-weight: bold;

//   svg {
//     margin-right: 10px;
//     font-size: 36px;
//   }
// `;

// const ChartContent = styled.div`
//   padding: 20px;
//   min-height: 300px;
// `;

// const FlexRow = styled.div`
//   display: flex;
//   gap: 20px;
//   margin-top: 20px;
//   flex: 1;
// `;

// const StaffDashboard = () => {
//   const [attendanceData, setAttendanceData] = useState({
//     present_count: 0,
//     absent_count: 0,
//     leave_count: 0,
//   });

//   const [unsubmittedAssignments, setUnsubmittedAssignments] = useState([]);

//   const teacherInfo = {
//     name: 'John Doe',
//     image: 'AI.avif',
//   };

//   useEffect(() => {
//     const fetchAttendanceData = async () => {
//       try {
//         const response = await fetch('http://13.127.57.224:2081/api/STAFFDASHBOARD');
//         if (!response.ok) {
//           const errorText = await response.text();
//           throw new Error(`Network response was not ok: ${errorText}`);
//         }
//         const data = await response.json();
//         setAttendanceData(data);
//       } catch (error) {
//         console.error('Error fetching attendance data:', error);
//       }
//     };

//     fetchAttendanceData();
//   }, []);

//   useEffect(() => {
//     const fetchAssignmentData = async () => {
//       try {
//         const response = await fetch('http://13.127.57.224:2081/api/ASSIGMENTDASH');
//         if (!response.ok) {
//           const errorText = await response.text();
//           throw new Error(`Network response was not ok: ${errorText}`);
//         }
//         const data = await response.json();
//         setUnsubmittedAssignments(data);
//       } catch (error) {
//         console.error('Error fetching assignment data:', error);
//       }
//     };

//     fetchAssignmentData();
//   }, []);

//   return (
//     <>
//       <Staffnavbar />
//       <Container>
//         <Header>
//           <h1>Staff Dashboard</h1>
//           <h2>Welcome, {teacherInfo.name}</h2>
//           <div className="teacher-info">
//             <img
//               src={teacherInfo.image}
//               alt="Teacher"
//               style={{ width: '100px', height: '100px' }}
//             />
//             <span>{teacherInfo.name}</span>
//           </div>
//         </Header>
//         <FlexRow>
//           <Staffshedule />
//           <StaffAssignmentsDashboard />
//           <Staffcalendar />
//           <ChartContainer>
//             <ChartCard>
//               <ChartHeader>
//                 <FontAwesomeIcon icon={faClipboardListSolid} color="white" />
//                 Attendance Summary
//               </ChartHeader>
//               <ChartContent>
//                 <Doughnut
//                   data={{
//                     labels: ['Present', 'Absent', 'Leave'],
//                     datasets: [
//                       {
//                         data: [
//                           attendanceData.present_count,
//                           attendanceData.absent_count,
//                           attendanceData.leave_count,
//                         ],
//                         backgroundColor: ['#4caf50', '#f44336', '#ff9800'],
//                       },
//                     ],
//                   }}
//                 />
//               </ChartContent>
//             </ChartCard>
//           </ChartContainer>
//         </FlexRow>
//       </Container>
//     </>
//   );
// };

// export default StaffDashboard;





// import React from 'react';
// import 'bootstrap/dist/css/bootstrap.min.css';
// import styled from 'styled-components';
// import Staffcalendar from './Staff_calendar';
// import Staffshedule from './Staff_shedule.js';
// import Staffnavbar from './Staff_navbar.js';
// import StaffAssignmentsDashboard from './Staff_Assignments_Dashboard.js';
// import StaffAttandanceSummery from './Staff_Attandance_Summery'; // Import your component

// // Styled components
// const Container = styled.div`
//   padding-top: 10px;
//   min-height: 100vh;
//   padding: 0 20px; 
//   max-width: 100%; 
//   margin: 0 auto; 
//   background-color: #e9ecef; /* Softer background color for cleaner look */

//   @media (max-width: 1200px) {
//     max-width: 1000px;
//   }

//   @media (max-width: 992px) {
//     max-width: 800px; 
//   }

//   @media (max-width: 768px) {
//     padding: 0 10px; 
//     max-width: 100%; 
//   }

//   @media (max-width: 576px) {
//     padding: 0 5px; 
//     max-width: 100%; 
//   }
// `;

// const Card = styled.div`
//   background-color: #ffffff;
//   border-radius: 12px;
//   padding: 0px;
//   margin-bottom: 15%; /* Decreased margin */
//   margin-top: 0px;

//   min-height: 0; 
//   display: flex;
//   flex-direction: column;
//   justify-content: space-between;
//   transition: transform 0.3s ease, box-shadow 0.3s ease;
//   box-shadow: 0 6px 12px rgba(0, 0, 0, 0.1); 

//   &:hover {
//     box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
//   }

//   @media (max-width: 768px) {
//     padding: 15px;
//     min-height: 250px;
//   }
// `;

// const Heading = styled.h3`
//   font-size: 1.3rem; 
//   font-weight: 700; 
//   font-family: 'Lato', sans-serif; 
//   color: black; 
//   margin-bottom: 30px; 
//   padding: 12px 15px; 
//   letter-spacing: 1.5px; 
//   text-shadow: 1px 1px 4px rgba(0, 0, 0, 0.15); 
//   background: linear-gradient(to right, #d3d3d3, #e8e8e8); /* Light gradient background */
//   border-radius: 6px;
//   display: inline-block;
//   transition: all 0.4s ease; 

//   @media (max-width: 400px) {
//     font-size: 1.4rem; 
//     padding: 10px 12px; 
//     margin-bottom: 20px;
//   }
// `;

// const Dashboard = () => { // Define the Dashboard function
//   return (
//     <div className="container-fluid" style={{ marginTop: '6vh', width: '100%', padding: 0 }}>
//       <Staffnavbar />
//       <Container className="container-fluid py-2">
//         <div className="container-fluid" style={{ marginTop: '6vh', width: '100%', padding: 0 }}>
//           <div className="row">
//             <div className="col-lg-4">
//               <Card style={{ height: '47vh', borderRadius: '16px' }}>
//                 <Heading>             Assignments Overview                </Heading>
//                 <StaffAssignmentsDashboard />
//               </Card>
//             </div>

//             <div className="col-lg-4">
//               <Card style={{ height: '47vh', borderRadius: '16px' }}>
//                 <Heading>Student Attendance</Heading>
//                 <Staffshedule />
//               </Card>
//             </div>

//             <div className="col-lg-4">
//               <Card style={{ height: '47vh', borderRadius: '16px' }}>
//                 <Heading>                Attendance Summary                </Heading>
//                 <StaffAttandanceSummery />
//               </Card>
//             </div>
//           </div>

//           <div className="row">
//             <div className="col-lg-4">
//               <Card style={{ height: '45vh', borderRadius: '16px' }}>
//                 <Heading>Calendar</Heading>
//                 <Staffcalendar />
//               </Card>
//             </div>
//           </div>
//         </div>
//       </Container>
//     </div>
//   );
// };

// export default Dashboard;





import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import styled from 'styled-components';
import Staffcalendar from './Staff_calendar';
import Staffshedule from './Staff_shedule.js';
import Staffnavbar from './Staff_navbar.js';
import StaffAssignmentsDashboard from './Staff_Assignments_Dashboard.js';
import StaffAttandanceSummery from './Staff_Attandance_Summery';
import StaffTimeTableschedule from './Staff_TimeTable_schedule';
import StudentList from './Student_List';
import StaffAttandance from './Staff_Attandance';

// Styled components for new UI
const Container = styled.div`
  padding-top: 10px;
  min-height: 100vh;
  padding: 0 20px;
  max-width: 100%;
  margin: 0 auto;
  background-color: #F0F6FA	;

  @media (max-width: 1200px) {
    max-width: 1000px;
  }
  @media (max-width: 992px) {
    max-width: 800px;
  }
  @media (max-width: 768px) {
    padding: 0 10px;
  }
  @media (max-width: 576px) {
    padding: 0 5px;
  }
`;


const Card = styled.div`
  background-color: #ffffff;
  border: 2px solid #ccc; /* Add this line for a 1px border */
  border-radius: 4px; /* Adjust the radius value as needed */
  padding: 0px;
  margin-bottom: 15%;
  min-height: 0;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  transition: transform 0.3s ease, box-shadow 0.3s ease;
  // box-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);

  @media (max-width: 768px) {
    padding: 15px;
    min-height: 250px;
  }
`;
const Section = styled.div`
  background-color: #ffffff;
  border-radius: 20px; /* Smoother rounded corners */
  padding: 0px;
  width: 100%; /* Take full width of the grid cell */
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1); /* Soft shadow for modern look */
  transition: all 0.3s ease;
  
  // &:hover {
  //   transform: translateY(-10px); /* Smooth hover effect */
  //   box-shadow: 0 15px 40px rgba(0, 0, 0, 0.15);
  // }

  @media (max-width: 768px) {
    padding: 20px;
  }
`;


const Heading = styled.h3`
font-size: 1.2rem; 
font-weight: 500; 
font-family: 'Lato', sans-serif; 
color: black; 
margin-bottom: 30px; 
padding: 4px 10px; 
width: 100%;
text-shadow: 1px 1px 4px rgba(0, 0, 0, 0.15); 
background: linear-gradient(to right, #d3d3d3, #e8e8e8); /* Light gradient background */
border-radius: 12px;
display: inline-block;
transition: all 0.4s ease; 

@media (max-width: 400px) {
  font-size: 1.4rem; 
  padding: 10px 12px; 
  margin-bottom: 20px;
}
`;



const Dashboard = () => {
  return (
    <div className="container-fluid" style={{ marginTop: '14vh', width: '100%', padding: 0 }}>
      <Staffnavbar />
      <Container>


        
      <div className="row"   style={{ marginTop: '-3vh'  }}>
          <div className="col-lg-4"style={{ padding: '0 2px' }}>
            <Card style={{ height: '45vh',  borderRadius: '16px', }}>
            <Heading>Attendance Summary</Heading>
            <StaffAttandanceSummery />
            </Card>
          </div>
     

          <div className="col-lg-4"style={{ padding: '0 2px' }}>
          <Card style={{ height: '45vh',  borderRadius: '16px', }}>
                      <Heading>Calendar</Heading>
          <Staffcalendar />
          </Card>
</div>    

<div className="col-lg-4"style={{ padding: '0 2px' }}>
<Card style={{ height: '45vh',  borderRadius: '16px', }}>   
         <Heading>My Attendance</Heading>
          <StaffAttandance />
          </Card>
          </div>
      
      


   <div className="row"  
   
   style={{ marginTop: '-7vh'  }}>


<div className="col-lg-4"style={{ padding: '0 2px' }}>
<Card style={{ height: '45vh',  borderRadius: '16px', }}>   
         <Heading>Assignments Overview</Heading>
          <StaffAssignmentsDashboard />
          </Card>
          </div>
       

        
      <div className="col-lg-8"style={{ padding: '0 2px' }}>
            <Card style={{ height: '45vh',  borderRadius: '16px', }}>        
        <Heading>Student List</Heading>
        <StudentList />
      </Card>
      </div>
      </div>


      <div className="row"  
   
   style={{ marginTop: '-16vh'  }}>
      <div className="col-lg-11"style={{ padding: '0 2px' }}>
            <Card style={{ height: '69vh',  borderRadius: '16px', }}>        
        <Heading>Staff Shedule</Heading>
        <StaffTimeTableschedule />
      </Card>
      </div>
       

       </div>
       </div>

        {/* <Section>
          <Heading>Time Table schedule</Heading>
          <StaffTimeTableschedule />
        </Section> */}
      </Container>
    </div>
  );
};

export default Dashboard;
