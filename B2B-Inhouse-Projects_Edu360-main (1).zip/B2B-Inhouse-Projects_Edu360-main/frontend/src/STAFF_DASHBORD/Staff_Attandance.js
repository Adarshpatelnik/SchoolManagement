
//     import React, { useState, useEffect } from 'react';
//     import axios from 'axios';

//     const StaffAttandance = () => {
//     const [attendanceType, setAttendanceType] = useState('attendance');
//     const [currentDate, setCurrentDate] = useState(new Date());
//     const [showPopup, setShowPopup] = useState(false);
//     const [selectedDate, setSelectedDate] = useState(null);
//     const [markedDates, setMarkedDates] = useState({});
//     const [leaveStatusData, setLeaveStatusData] = useState({});
//     const [pendingUpdates, setPendingUpdates] = useState({});
//     const [leaveDetails, setLeaveDetails] = useState({
//         staffId: '',
//         leaveType: '',
//         startDate: '',
//         endDate: '',
//         reason: '',
//         contactnumber: ''
//     });

//     const today = new Date();

//     useEffect(() => {
//         fetchLeaveStatus();
//     }, []);

//     const fetchLeaveStatus = async () => {
//         try {
//         const res = await axios.get("http://13.127.57.224:2081/update-leave-status");
//         if (res.status === 200) {
//             const leaveStatus = res.data;
//             const leaveStatusMap = {};
//             leaveStatus.forEach((leave) => {
//             const startDate = new Date(leave.START_DATE);
//             const endDate = new Date(leave.END_DATE);
//             for (let d = new Date(startDate); d <= endDate; d.setDate(d.getDate() + 1)) {
//                 leaveStatusMap[d.toDateString()] = leave.STATUS;
//             }
//             });
//             setLeaveStatusData(leaveStatusMap);
//             // Clear pending updates that have been confirmed by the server
//             setPendingUpdates(prev => {
//             const newPending = { ...prev };
//             Object.keys(leaveStatusMap).forEach(date => {
//                 delete newPending[date];
//             });
//             return newPending;
//             });
//         }
//         } catch (error) {
//         console.error('Error fetching leave status:', error);
//         }
//     };

//     const handleRadioChange = (e) => {
//         setAttendanceType(e.target.value);
//         setShowPopup(e.target.value === 'leave');
//     };

//     const handleInputChange = (e) => {
//         const { name, value } = e.target;
//         setLeaveDetails((prevDetails) => ({
//         ...prevDetails,
//         [name]: value
//         }));
//     };

//     const handleSubmit = async (e) => {
//         e.preventDefault();
//         if (!leaveDetails.staffId || !leaveDetails.leaveType || !leaveDetails.startDate || !leaveDetails.endDate || !leaveDetails.reason || !leaveDetails.contactnumber) {
//         alert("Please fill out all fields before submitting.");
//         return;
//         }

//         try {
//         const response = await axios.post("http://13.127.57.224:2081/submit-leave", leaveDetails);
//         if (response.status === 200) {
//             alert('Leave application submitted successfully!');
//             // Instead of immediately updating leaveStatusData, add to pendingUpdates
//             const startDate = new Date(leaveDetails.startDate);
//             const endDate = new Date(leaveDetails.endDate);
//             const newPendingUpdates = { ...pendingUpdates };
//             for (let d = new Date(startDate); d <= endDate; d.setDate(d.getDate() + 1)) {
//             newPendingUpdates[d.toDateString()] = 'PENDING';
//             }
//             setPendingUpdates(newPendingUpdates);
//             setLeaveDetails({
//             staffId: '',
//             leaveType: '',
//             startDate: '',
//             endDate: '',
//             reason: '',
//             contactnumber: ''
//             });
//             setShowPopup(false);
//         }
//         } catch (error) {
//         alert('Failed to submit leave application.');
//         console.error('Error:', error);
//         }
//     };

//     const markAttendance = async (status) => {
//         try {
//         const attendanceData = {
//             STAFF_ID: leaveDetails.staffId || '106',
//             DATE: selectedDate,
//             STATUS: status
//         };
//         const res = await axios.post("http://13.127.57.224:2081/submit-attendance", attendanceData);
//         if (res.status === 200) {
//             alert(`Attendance marked as ${status} for ${selectedDate}`);
//             setMarkedDates((prev) => ({ ...prev, [selectedDate]: status.toLowerCase() }));
//             // Immediately update the calendar color for the current date
//             const dateCell = document.querySelector(`[data-date="${selectedDate}"]`);
//             if (dateCell) {
//             dateCell.style.backgroundColor = status.toLowerCase() === 'present' ? '#4CAF50' : '#F44336';
//             dateCell.style.color = 'white';
//             }
//         }
//         } catch (error) {
//         alert(`Failed to mark attendance as ${status}.`);
//         }
//         setShowPopup(false);
//     };

//     const handleMarkPresent = () => markAttendance('Present');
//     const handleMarkAbsent = () => markAttendance('Absent');

//     const handleConfirmAttendance = (status) => {
//         if (status === 'Present') {
//         handleMarkPresent();
//         } else {
//         handleMarkAbsent();
//         }
//     };

//     const getMonthName = () => {
//         const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
//         return monthNames[currentDate.getMonth()];
//     };

//     const prevMonth = () => {
//         setCurrentDate(new Date(currentDate.setMonth(currentDate.getMonth() - 1)));
//     };

//     const nextMonth = () => {
//         setCurrentDate(new Date(currentDate.setMonth(currentDate.getMonth() + 1)));
//     };

//     const getDaysOfWeek = () => ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

//     const getDaysInMonth = () => {
//         const month = currentDate.getMonth();
//         const year = currentDate.getFullYear();
//         const date = new Date(year, month + 1, 0);
//         const daysInMonth = [];
//         for (let i = 1; i <= date.getDate(); i++) {
//         daysInMonth.push(i);
//         }
//         return daysInMonth;
//     };

//     const isCurrentDate = (day) => (
//         today.getDate() === day &&
//         today.getMonth() === currentDate.getMonth() &&
//         today.getFullYear() === currentDate.getFullYear()
//     );

//     const handleDateClick = (day) => {
//         const selectedDateObj = new Date(currentDate.getFullYear(), currentDate.getMonth(), day);
//         const formattedSelectedDate = selectedDateObj.toDateString();

//         if (formattedSelectedDate === today.toDateString() && !markedDates[formattedSelectedDate]) {
//         setSelectedDate(formattedSelectedDate);
//         setShowPopup(true);
//         } else if (markedDates[formattedSelectedDate]) {
//         alert("Attendance for this date has already been marked.");
//         } else {
//         alert("You can only select today's date.");
//         }
//     };

//     const closePopup = () => {
//         setShowPopup(false);
//         setSelectedDate(null);
//         if (attendanceType === 'leave') {
//         setAttendanceType('attendance');
//         }
//     };

//     const getLeaveStatusColor = (date) => {
//         const leaveStatus = leaveStatusData[date];
//         if (leaveStatus === 'PENDING') {
//         return 'yellow';
//         } else if (leaveStatus === 'APPROVED') {
//         return 'blue';
//         } else if (leaveStatus === 'REJECTED') {
//         return 'maroon';
//         }
//         return '';
//     };

//     const handleOutsideClick = (e) => {
//         if (showPopup && !e.target.closest('#popup-content')) {
//         closePopup();
//         }
//     };

//     useEffect(() => {
//         document.addEventListener('mousedown', handleOutsideClick);
//         return () => {
//         document.removeEventListener('mousedown', handleOutsideClick);
//         };
//     }, [showPopup]);

//     const styles = {
//         container: {
//         fontFamily: 'Arial, sans-serif',
//         Width: '100%',
//         margin: '0 auto',
//         padding: '1px',
//         marginTop:'-rem',
//         border: '2px solid #ccc',
//         borderRadius: '10px',
//         boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)',
//         },
//         radioContainer: {
//         display: 'flex',
//         justifyContent: 'center',
//         marginBottom: '4px',
//         gap: '20px',
//         fontWeight: '600', 
//         },
//         radioLabel: {
//         display: 'flex',
//         alignItems: 'center',
//         gap: '4px',
//         cursor: 'pointer',
//         },
//         radioInput: {
//         margin: 0,
//         cursor: 'pointer',
//         },
//         navContainer: {
//         display: 'flex',
//         justifyContent: 'space-between',
//         alignItems: 'center',
//         padding: '5px',
//         backgroundColor: '#4285f4',
//         color: 'white',
//         marginBottom: '1px',
//         },
//         navButton: {
//         background: 'none',
//         border: 'none',
//         color: 'white',
//         cursor: 'pointer',
//         fontSize: '18px',
//         padding: '5px 10px',
//         },
//         monthYear: {
//         fontSize: '18px',
//         fontWeight: 'bold',
//         },
//         daysGrid: {
//         display: 'grid',
//         gridTemplateColumns: 'repeat(7, 1fr)',
//         gap: '1px',
//         textAlign: 'center',
//         marginBottom: '1px',
//         },
//         dayHeader: {
//         fontWeight: 'bold',
//         padding: '1px',
//         color: 'black',
//         },
//         dateCell: {
//         padding: '8px',
//         cursor: 'pointer',
//         borderRadius: '5px',
//         transition: 'background-color 0.2s',
//         width: '100%',
//         height: '20px',
//         },
//         pendingLeave: {
//         backgroundColor: '#FFC107',
//         borderRadius: '50%',
//         width: '40px',
//         height: '40px',
//         display: 'flex',
//         justifyContent: 'flex-end',
//         alignItems: 'center',
//         paddingRight: '10px',
//         marginLeft: '2px',
//         },
//         today: {
//         backgroundColor: '#e8f0fe',
//         fontWeight: 'bold',
//         borderRadius: '50%',
//         padding: 'rem',
//         },
//         present: { backgroundColor: '#4CAF50', color: 'white' },
//         absent: { backgroundColor: '#F44336', color: 'white' },
//         approvedLeave: { backgroundColor: '#2196F3', color: 'white' },
//         rejectedLeave: { backgroundColor: '#800000', color: 'white' },
//         popup: {
//         position: 'fixed',
//         top: '30%',
//         left: '50%',
//         transform: 'translate(-50%, -50%)',
//         padding: '10px',
//         width: attendanceType === 'leave' ? '280px' : '300px',
//         height: attendanceType === 'leave' ? '400px' : 'auto',
//         backgroundColor: 'white',
//         border: '1px solid #ccc',
//         borderRadius: '10px',
//         boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)',
//         zIndex: 1000,
//         },
//         popupHeader: {
//         display: 'flex',
//         justifyContent: 'space-between',
//         alignItems: 'center',
//         marginBottom: '-1px',
//         },
//         closeButton: {
//         background: 'none',
//         border: 'none',
//         fontSize: '18px',
//         cursor: 'pointer',
//         },
//         form: {
//         display: 'flex',
//         flexDirection: 'column',
//         gap: '10px',
//         },
//         input: {
//         padding: '5px',
//         borderRadius: '3px',
//         border: '1px solid #ccc',
//         },
//         submitButton: {
//         padding: '8px',
//         backgroundColor: '#4285f4',
//         color: 'white',
//         border: 'none',
//         borderRadius: '3px',
//         cursor: 'pointer',
//         },
//         legendContainer: {
//         display: 'flex',
//         justifyContent: 'space-between',
//         marginTop: '5px',
//         gap: '1px',
//         marginBottom: '5px',
//         },
//         legendItem: {
//         display: 'flex',
//         alignItems: 'center',
//         gap: '5px',
//         fontSize: '12px',
//         fontWeight: '500',
//         },
//         legendColor: {
//         width: '8px',
//         height: '8px',
//         borderRadius: '50%',
//         },
//         overlay: {
//         position: 'fixed',
//         top: 0,
//         left: 0,
//         width: '100%',
//         height: '100%',
//         backgroundColor: 'rgba(0, 0, 0, 0.5)',
//         zIndex: 999,
//         },
//         attendanceButton: {
//         padding: '1px 10px',
//         color: 'white',
//         border: 'none',
//         borderRadius: '3px',
//         cursor: 'pointer',
//         marginTop: '-1px',
//         marginRight: '2px',
//         marginBottom: '1px',
//         },
//     };

//     return (
//         <div style={styles.container}>
//         <div style={styles.radioContainer}>
//             <label style={styles.radioLabel}>
//             <input
//                 type="radio"
//                 value="attendance"
//                 checked={attendanceType === 'attendance'}
//                 onChange={handleRadioChange}
//                 style={styles.radioInput}
//             />
//             Attendance
//             </label>
//             <label style={styles.radioLabel}>
//             <input
//                 type="radio"
//                 value="leave"
//                 checked={attendanceType === 'leave'}
//                 onChange={handleRadioChange}
//                 style={styles.radioInput}
//             />
//             Leave
//             </label>
//         </div>

//         <div style={styles.navContainer}>
//             <button onClick={prevMonth} style={styles.navButton}>{"<"}</button>
//             <div style={styles.monthYear}>{getMonthName()} {currentDate.getFullYear()}</div>
//             <button onClick={nextMonth} style={styles.navButton}>{">"}</button>
//         </div>

//         <div style={styles.daysGrid}>
//             {getDaysOfWeek().map((day, index) => (
//             <div key={index} style={styles.dayHeader}>{day}</div>
//             ))}
//             {getDaysInMonth().map((day) => {
//             const dateObj = new Date(currentDate.getFullYear(), currentDate.getMonth(), day);
//             const dateString = dateObj.toDateString();
//             const leaveColor = getLeaveStatusColor(dateString);
//             const pendingStatus = pendingUpdates[dateString];

//             return (
//                 <div
//                 key={day}
//                 data-date={dateString}
//                 onClick={() => handleDateClick(day)}
//                 style={{
//                     ...styles.dateCell,
//                     ...(isCurrentDate(day) ? styles.today : {}),
//                     ...(markedDates[dateString] === 'present' ? styles.present : {}),
//                     ...(markedDates[dateString] === 'absent' ? styles.absent : {}),
//                     ...(leaveColor === 'yellow' ? styles.pendingLeave : {}),
//                     ...(leaveColor === 'blue' ? styles.approvedLeave : {}),
//                     ...(leaveColor === 'maroon' ? styles.rejectedLeave : {}),
//                     ...(pendingStatus === 'present' ? { backgroundColor: '#A5D6A7' } : {}),
//                     ...(pendingStatus === 'absent' ? { backgroundColor: '#EF9A9A' } : {}),
//                     ...(pendingStatus === 'PENDING' ? { backgroundColor: '#FFF59D' } : {}),
//                 }}
//                 >
//                 {day}
//                 </div>
//             );
//             })}
//         </div>

//         {showPopup && (
//             <div style={styles.overlay}>
//             <div style={styles.popup}>
//                 <div id="popup-content">
//                 <div style={styles.popupHeader}>
//                     <h3>{attendanceType === 'attendance' ? 'Mark Attendance' : 'Apply for Leave'}</h3>
//                     <button onClick={closePopup} style={styles.closeButton}>×</button>
//                 </div>
//                 {attendanceType === 'attendance' ? (
//                     <div>
//                     <p>Mark attendance for {selectedDate}?</p>
//                     <div style={{ display: 'flex', justifyContent: 'center' }}>
//                         <button
//                         onClick={() => handleConfirmAttendance('Present')}
//                         style={{ ...styles.attendanceButton, backgroundColor: '#4CAF50' }}
//                         >
//                         Present
//                         </button>
//                         <button
//                         onClick={() => handleConfirmAttendance('Absent')}
//                         style={{ ...styles.attendanceButton, backgroundColor: '#F44336' }}
//                         >
//                         Absent
//                         </button>
//                     </div>
//                     </div>
//                 ) : (
//                     <form onSubmit={handleSubmit} style={styles.form}>
//                     <input
//                         type="text"
//                         name="staffId"
//                         placeholder="Staff ID"
//                         value={leaveDetails.staffId}
//                         onChange={handleInputChange}
//                         required
//                         style={styles.input}
//                     />
//                     <select
//                         name="leaveType"
//                         value={leaveDetails.leaveType}
//                         onChange={handleInputChange}
//                         required
//                         style={styles.input}
//                     >
//                         <option value="">Select leave type</option>
//                         <option value="CASUAL LEAVE">Casual Leave</option>
//                         <option value="SICK LEAVE">Sick Leave</option>
//                         <option value="MATERNITY LEAVE">Maternity Leave</option>
//                         <option value="PATERNITY LEAVE">Paternity Leave</option>
//                         <option value="EARNED LEAVE">Earned Leave</option>
//                         <option value="COMPENSATORY LEAVE">Compensatory Leave</option>
//                         <option value="SPECIAL LEAVE">Special Leave</option>
//                         <option value="STUDY LEAVE">Study Leave</option>
//                         <option value="EMERGENCY LEAVE">Emergency Leave</option>
//                     </select>
//                     <input
//                         type="date"
//                         name="startDate"
//                         value={leaveDetails.startDate}
//                         onChange={handleInputChange}
//                         required
//                         style={styles.input}
//                     />
//                     <input
//                         type="date"
//                         name="endDate"
//                         value={leaveDetails.endDate}
//                         onChange={handleInputChange}
//                         required
//                         style={styles.input}
//                     />
//                     <textarea
//                         name="reason"
//                         placeholder="Reason for leave"
//                         value={leaveDetails.reason}
//                         onChange={handleInputChange}
//                         required
//                         style={styles.input}
//                     />
//                     <input
//                         type="text"
//                         name="contactnumber"
//                         placeholder="Contact details"
//                         value={leaveDetails.contactnumber}
//                         onChange={handleInputChange}
//                         required
//                         style={styles.input}
//                     />
//                     <button type="submit" style={styles.submitButton}>Submit</button>
//                     </form>
//                 )}
//                 </div>
//             </div>
//             </div>
//         )}

//         <div style={styles.legendContainer}>
//             <div style={styles.legendItem}>
//             <div style={{ ...styles.legendColor, backgroundColor: '#4CAF50' }}></div>
//             <span>Present</span>
//             </div>
//             <div style={styles.legendItem}>
//             <div style={{ ...styles.legendColor, backgroundColor: '#F44336' }}></div>
//             <span>Absent</span>
//             </div>
//             <div style={styles.legendItem}>
//             <div style={{ ...styles.legendColor, backgroundColor: '#FFC107' }}></div>
//             <span>Pending Leave</span>
//             </div>
//             <div style={styles.legendItem}>
//             <div style={{ ...styles.legendColor, backgroundColor: '#2196F3' }}></div>
//             <span>Approved Leave</span>
//             </div>
//             <div style={styles.legendItem}>
//             <div style={{ ...styles.legendColor, backgroundColor: '#800020' }}></div>
//             <span>Rejected Leave</span>
//             </div>
//         </div>
//         </div>
//     );
//     }

//     export default StaffAttandance;













// staff id for hardcoded leave 

import React, { useState, useEffect } from 'react';
import axios from 'axios';

const AttendanceCalendar = () => {
  const [attendanceType, setAttendanceType] = useState('attendance');
  const [currentDate, setCurrentDate] = useState(new Date());
  const [showPopup, setShowPopup] = useState(false);
  const [selectedDate, setSelectedDate] = useState(null);
  const [markedDates, setMarkedDates] = useState({});
  const [leaveData, setLeaveData] = useState({});
  const [leaveDetails, setLeaveDetails] = useState({
    leaveType: '',
    startDate: '',
    endDate: '',
    reason: '',
    contactNumber: ''
  });
  const [staffId, setStaffId] = useState(""); // Added for dynamic staffId
  const today = new Date();

  useEffect(() => {
    fetchAttendanceData();
    fetchLeaveData();
  }, []);
  
//old hardcode staff id

  const fetchAttendanceData = async () => {
    try {
      const staffId = '106'; // Replace with actual staff ID or user input
      const res = await axios.get(`http://localhost:2000/api/get-attendance?staffId=${staffId}`);
      if (res.status === 200) {
        const attendanceData = res.data;
        const newMarkedDates = {};
        attendanceData.forEach((record) => {
          const date = new Date(record.DATE).toDateString();
          newMarkedDates[date] = record.STATUS.toLowerCase();
        });
        setMarkedDates(newMarkedDates);
      }
    } catch (error) {
      console.error('Error fetching attendance data:', error);
    }
  };
  
const fetchLeaveData = async () => {
    try {
      const res = await axios.get(`http://localhost:2000/api/get-leave?staffId=${staffId}`);
      if (res.status === 200) {
        const leaveData = res.data;
        const newLeaveData = {};
        leaveData.forEach((leave) => {
          const startDate = new Date(leave.START_DATE);
          const endDate = new Date(leave.END_DATE);
          for (let d = new Date(startDate); d <= endDate; d.setDate(d.getDate() + 1)) {
            newLeaveData[d.toDateString()] = leave.STATUS;
          }
        });
        setLeaveData(newLeaveData);
      }
    } catch (error) {
      console.error("Error fetching leave data:", error);
    }
  };

  const handleRadioChange = (e) => {
    setAttendanceType(e.target.value);
    setShowPopup(e.target.value === 'leave');
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setLeaveDetails((prevDetails) => ({
      ...prevDetails,
      [name]: value
    }));
  };


  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!leaveDetails.leaveType || !leaveDetails.startDate || !leaveDetails.endDate || !leaveDetails.reason || !leaveDetails.contactNumber) {
      alert("Please fill out all fields before submitting.");
      return;
    }

    try {
      const response = await axios.post("http://localhost:2000/submit-leave", {
        ...leaveDetails,
        staffId
      });
      if (response.status === 200) {
        alert("Leave application submitted successfully!");
        setLeaveDetails({
          leaveType: "",
          startDate: "",
          endDate: "",
          reason: "",
          contactNumber: ""
        });
        setShowPopup(false);
        fetchLeaveData();
      }
    } catch (error) {
      alert('Failed to submit leave application.');
      console.error('Error:', error);
    }
  };

  const markAttendance = async (status) => {
    try {
      const attendanceData = {
        // STAFF_ID: leaveDetails.staffId || '106', //dynamic ke liye comment krna hoga only one row 
        DATE: selectedDate,
        STATUS: status
      };
      const res = await axios.post("http://localhost:2000/submit-attendance", attendanceData);
      if (res.status === 200) {
        alert(`Attendance marked as ${status} for ${selectedDate}`);
        setMarkedDates((prev) => ({ ...prev, [selectedDate]: status.toLowerCase() }));
        fetchAttendanceData(); // Refresh attendance data after marking
      }
    } catch (error) {
      alert(`Failed to mark attendance as ${status}.`);
    }
    setShowPopup(false);
  };

  const handleMarkPresent = () => markAttendance('Present');
  const handleMarkAbsent = () => markAttendance('Absent');

  const handleConfirmAttendance = (status) => {
    if (status === 'Present') {
      handleMarkPresent();
    } else {
      handleMarkAbsent();
    }
  };

  const getMonthName = () => {
    const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    return monthNames[currentDate.getMonth()];
  };

  const prevMonth = () => {
    setCurrentDate(new Date(currentDate.setMonth(currentDate.getMonth() - 1)));
  };

  const nextMonth = () => {
    setCurrentDate(new Date(currentDate.setMonth(currentDate.getMonth() + 1)));
  };

  const getDaysOfWeek = () => ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

  const getDaysInMonth = () => {
    const month = currentDate.getMonth();
    const year = currentDate.getFullYear();
    const date = new Date(year, month + 1, 0);
    const daysInMonth = [];
    for (let i = 1; i <= date.getDate(); i++) {
      daysInMonth.push(i);
    }
    return daysInMonth;
  };

  const isCurrentDate = (day) => (
    today.getDate() === day &&
    today.getMonth() === currentDate.getMonth() &&
    today.getFullYear() === currentDate.getFullYear()
  );

  const handleDateClick = (day) => {
    const selectedDateObj = new Date(currentDate.getFullYear(), currentDate.getMonth(), day);
    const formattedSelectedDate = selectedDateObj.toDateString();

    if (formattedSelectedDate === today.toDateString() && !markedDates[formattedSelectedDate]) {
      setSelectedDate(formattedSelectedDate);
      setShowPopup(true);
    } else if (markedDates[formattedSelectedDate]) {
      alert(`Attendance for this date is already marked as ${markedDates[formattedSelectedDate]}.`);
    } else {
      alert("You can only select today's date for marking attendance.");
    }
  };

  const closePopup = () => {
    setShowPopup(false);
    setSelectedDate(null);
    if (attendanceType === 'leave') {
      setAttendanceType('attendance');
    }
  };

  const getLeaveStatusColor = (date) => {
    const leaveStatus = leaveData[date];
    if (leaveStatus === 'PENDING') {
      return '#FFC107'; // Yellow
    } else if (leaveStatus === 'APPROVED') {
      return '#2196F3'; // Blue
    } else if (leaveStatus === 'REJECTED') {
      return '#A9A9A9'; // grey
    }
    return '';
  };

  const handleOutsideClick = (e) => {
    if (showPopup && !e.target.closest('#popup-content')) {
      closePopup();
    }
  };

  useEffect(() => {
    document.addEventListener('mousedown', handleOutsideClick);
    return () => {
      document.removeEventListener('mousedown', handleOutsideClick);
    };
  }, [showPopup]);

  const styles = {
    container: {
      fontFamily: 'Arial, sans-serif',
      maxWidth: '420px',
      margin: '0 auto',
      padding: '1px',
      border: '2px solid #ccc',
      borderRadius: '10px',
      boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)',
    },
    radioContainer: {
      display: 'flex',
      justifyContent: 'center',
      marginBottom: '10px',
      gap: '20px',
      fontWeight: '600', 
    },
    radioLabel: {
      display: 'flex',
      alignItems: 'center',
      gap: '4px',
      cursor: 'pointer',
    },
    radioInput: {
      margin: 0,
      cursor: 'pointer',
    },
    navContainer: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      padding: '5px',
      backgroundColor: '#4285f4',
      
      color: 'white',
      marginBottom: '15px',
    },
    navButton: {
      background: 'none',
      border: 'none',
      color: 'white',
      cursor: 'pointer',
      fontSize: '18px',
      padding: '5px 10px',
    },
    monthYear: {
      fontSize: '18px',
      fontWeight: 'bold',
    },
    daysGrid: {
      display: 'grid',
      gridTemplateColumns: 'repeat(7, 1fr)',
      gap: '1px',
      textAlign: 'center',
      marginBottom: '10px',
    },
    dayHeader: {
      fontWeight: 'bold',
      padding: '1px',
      color: 'black',
    },
    dateCell: {
      padding: '8px',
      cursor: 'pointer',
      borderRadius: '50%',// Change this to make the cell circular
      transition: 'background-color 0.2s',
      width: '40px',
      height: '40px',
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
    },
    today: {
      backgroundColor: '#e8f0fe',
      fontWeight: 'bold',
      borderRadius: '50%',
    },
    present: { backgroundColor: '#4CAF50', color: 'white' },
    absent: { backgroundColor: '#F44336', color: 'white' },
    popup: {
      position: 'fixed',
      top: '30%',
      left: '50%',
      transform: 'translate(-50%, -50%)',
      padding: '10px',
      width: attendanceType === 'leave' ? '280px' : '300px',
      height: attendanceType === 'leave' ? '400px' : 'auto',
      backgroundColor: 'white',
      border: '1px solid #ccc',
      borderRadius: '10px',
      boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)',
      zIndex: 1000,
    },
    popupHeader: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: '-1px',
    },
    closeButton: {
      background: 'none',
      border: 'none',
      fontSize: '18px',
      cursor: 'pointer',
    },
    form: {
      display: 'flex',
      flexDirection: 'column',
      gap: '10px',
    },
    input: {
      padding: '5px',
      borderRadius: '3px',
      border: '1px solid #ccc',
    },
    submitButton: {
      padding: '8px',
      backgroundColor: '#4285f4',
      color: 'white',
      border: 'none',
      borderRadius: '3px',
      cursor: 'pointer',
    },
    legendContainer: {
      display: 'flex',
      justifyContent: 'space-between',
      marginTop: '5px',
      gap: '1px',
      marginBottom: '5px',
    },
    legendItem: {
      display: 'flex',
      alignItems: 'center',
      gap: '5px',
      fontSize: '12px',
      fontWeight: '500',
    },
    legendColor: {
      width: '8px',
      height: '8px',
      borderRadius: '50%',
    },
    overlay: {
      position: 'fixed',
      top: 0,
      left: 0,
      width: '100%',
      height: '100%',
      backgroundColor: 'rgba(0, 0, 0, 0.5)',
      zIndex: 999,
    },
    attendanceButton: {
      padding: '1px 10px',
      color: 'white',
      border: 'none',
      borderRadius: '3px',
      cursor: 'pointer',
      marginTop: '-1px',
      marginRight: '2px',
      marginBottom: '1px',
    },
  };

  return (
    <div style={styles.container}>
      <div style={styles.radioContainer}>
        <label style={styles.radioLabel}>
          <input
            type="radio"
            value="attendance"
            checked={attendanceType === 'attendance'}
            onChange={handleRadioChange}
            style={styles.radioInput}
          />
          Attendance
        </label>
        <label style={styles.radioLabel}>
          <input
            type="radio"
            value="leave"
            checked={attendanceType === 'leave'}
            onChange={handleRadioChange}
            style={styles.radioInput}
          />
          Leave
        </label>
      </div>

      <div style={styles.navContainer}>
        <button onClick={prevMonth} style={styles.navButton}>{"<"}</button>
        <div style={styles.monthYear}>{getMonthName()} {currentDate.getFullYear()}</div>
        <button onClick={nextMonth} style={styles.navButton}>{">"}</button>
      </div>

      <div style={styles.daysGrid}>
        {getDaysOfWeek().map((day, index) => (
          <div key={index} style={styles.dayHeader}>{day}</div>
        ))}
        {getDaysInMonth().map((day) => {
          const dateObj = new Date(currentDate.getFullYear(), currentDate.getMonth(), day);
          const dateString = dateObj.toDateString();
          const leaveStatus = leaveData[dateString];
          const attendanceStatus = markedDates[dateString];

          let cellStyle = { ...styles.dateCell };
          if (isCurrentDate(day)) {
            cellStyle = { ...cellStyle, ...styles.today };
          }
          if (attendanceStatus === 'present') {
            cellStyle = { ...cellStyle, ...styles.present };
          } else if (attendanceStatus === 'absent') {
            cellStyle = { ...cellStyle, ...styles.absent };
          } else if (leaveStatus) {
            cellStyle = { ...cellStyle, backgroundColor: getLeaveStatusColor(dateString) };
          }

          return (
            <div
              key={day}
              data-date={dateString}
              onClick={() => handleDateClick(day)}
              style={cellStyle}
            >
              {day}
            </div>
          );
        })}
      </div>



      {showPopup && (
        <div style={styles.overlay}>
          <div style={styles.popup}>
            <div id="popup-content">
              <div style={styles.popupHeader}>
                <h3>{attendanceType === 'attendance' ? 'Mark Attendance' : 'Apply for Leave'}</h3>
                <button onClick={closePopup} style={styles.closeButton}>×</button>
              </div>
              {attendanceType === 'attendance' ? (
                <div>
                  <p>Mark attendance for {selectedDate}?</p>
                  <div style={{ display: 'flex', justifyContent: 'center' }}>
                    <button
                      onClick={() => handleConfirmAttendance('Present')}
                      style={{ ...styles.attendanceButton, backgroundColor: '#4CAF50' }}
                    >
                      Present
                    </button>
                    <button
                      onClick={() => handleConfirmAttendance('Absent')}
                      style={{ ...styles.attendanceButton, backgroundColor: '#F44336' }}
                    >
                      Absent
                    </button>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleSubmit} style={styles.form}>
                <select
                    name="leaveType"
                    value={leaveDetails.leaveType}
                    onChange={handleInputChange}
                    required
                    style={styles.input}
                  >
                    <option value="">Select leave type</option>
                    <option value="CASUAL LEAVE">Casual Leave</option>
                    <option value="SICK LEAVE">Sick Leave</option>
                    <option value="MATERNITY LEAVE">Maternity Leave</option>
                    <option value="PATERNITY LEAVE">Paternity Leave</option>
                    <option value="EARNED LEAVE">Earned Leave</option>
                    <option value="COMPENSATORY LEAVE">Compensatory Leave</option>
                    <option value="SPECIAL LEAVE">Special Leave</option>
                    <option value="STUDY LEAVE">Study Leave</option>
                    <option value="EMERGENCY LEAVE">Emergency Leave</option>
                  </select>
                  <input
                    type="date"
                    name="startDate"
                    value={leaveDetails.startDate}
                    onChange={handleInputChange}
                    required
                    style={styles.input}
                  />
                  <input
                    type="date"
                    name="endDate"
                    value={leaveDetails.endDate}
                    onChange={handleInputChange}
                    required
                    style={styles.input}
                  />
                  <textarea
                    name="reason"
                    placeholder="Reason for leave"
                    value={leaveDetails.reason}
                    onChange={handleInputChange}
                    required
                    style={styles.input}
                  />
                  <input
                    type="text"
                    name="contactNumber"
                    placeholder="Contact details"
                    value={leaveDetails.contactNumber}
                    onChange={handleInputChange}
                    required
                    style={styles.input}
                  />
                  <button type="submit" style={styles.submitButton}>Submit</button>
                </form>
              )}
            </div>
          </div>
        </div>
      )}

      <div style={styles.legendContainer}>
        <div style={styles.legendItem}>
          <div style={{ ...styles.legendColor, backgroundColor: '#4CAF50' }}></div>
          <span>Present</span>
        </div>
        <div style={styles.legendItem}>
          <div style={{ ...styles.legendColor, backgroundColor: '#F44336' }}></div>
          <span>Absent</span>
        </div>
        <div style={styles.legendItem}>
          <div style={{ ...styles.legendColor, backgroundColor: '#FFC107' }}></div>
          <span>Pending Leave</span>
        </div>
        <div style={styles.legendItem}>
          <div style={{ ...styles.legendColor, backgroundColor: '#2196F3' }}></div>
          <span>Approved Leave</span>
        </div>
        <div style={styles.legendItem}>
          <div style={{ ...styles.legendColor, backgroundColor: '#A9A9A9' }}></div>
          <span>Rejected Leave</span>
        </div>
      </div>
    </div>
  );
}

export default AttendanceCalendar;