

import React, { useEffect, useState } from 'react';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import axios from 'axios';
import Staffnavbar from './Staff_navbar.js';

// Function to format the date (remove timezone)
const formatDate = (dateString) => {
  if (!dateString) return '';
  try {
    const date = new Date(dateString);
    const formattedDate = date.toLocaleDateString('en-GB'); // Format date in DD/MM/YYYY
    return formattedDate;
  } catch (error) {
    console.error("Error formatting date:", error);
    return '';
  }
};

function StaffSelectAssignment() {
  const [rowData, setRowData] = useState([]);
  const [selectedRows, setSelectedRows] = useState([]); // To store selected rows
  const [message, setMessage] = useState(""); // For showing automatic messages

  const columnDefs = [
    {
      headerCheckboxSelection: true,
      checkboxSelection: true,
      headerName: "Select",
      width: 50,
    },
    { field: "ASSIGNMENT_ID", headerName: "Assignment ID", filter: true },
    { field: "STUDENT_ID", headerName: "Student ID", filter: true },
    { field: "STUDENT_NAME", headerName: "Student Name", filter: true },
    { field: "CLASS_ID", headerName: "Class ID", filter: true },
    { field: "SUBJECT_NAME", headerName: "Subject Name", filter: true },
    { field: "CLASS_TEACHER", headerName: "Class Teacher", filter: true },
    { field: "ASSIGNMENT_TYPE", headerName: "Assignment Type", filter: true },
    { field: "ASSIGNMENT_DESC", headerName: "Assignment Description", filter: true },
    {
      field: "SUBMISSION_START_DATE",
      headerName: "Submission Start Date",
      filter: true,
      valueFormatter: (params) => formatDate(params.value),
    },
    {
      field: "SUBMISSION_END_DATE",
      headerName: "Submission End Date",
      filter: true,
      valueFormatter: (params) => formatDate(params.value),
    },
    {
      field: "TeacherApprovalStatus",
      headerName: "Teacher Approval Status",
      filter: true,
    },
    {
      field: "STUDENT_SUBMITTED_DATE",
      headerName: "Student Submitted Date",
      filter: true,
      valueFormatter: (params) => formatDate(params.value),
    },
    {
      field: "SUBMISSION_DATE",
      headerName: "Submission Date",
      filter: true,
      valueFormatter: (params) => formatDate(params.value),
    },
    { field: "IS_SUBMITTED", headerName: "Is Submitted", filter: true },
    {
      field: "STUDENT_STATUS",
      headerName: "Student Status",
      filter: true,
    }
  ];

  const fetchAssignments = async () => {
    try {
      console.log("Fetching assignment data...");
      const response = await axios.get('http://13.127.57.224:2081/api/get-assignment-data');
      console.log("Data fetched successfully:", response.data);
      setRowData(response.data);
    } catch (error) {
      console.error('Error fetching assignments:', error);
      if (error.response) {
        console.error("Error response data:", error.response.data);
        console.error("Error response status:", error.response.status);
      }
      setMessage("Error fetching assignments data!");
    }
  };

  useEffect(() => {
    fetchAssignments();
  }, []);

  const onSelectionChanged = (event) => {
    console.log("Selection changed:", event.api.getSelectedRows());
    setSelectedRows(event.api.getSelectedRows());
  };

  const handleSubmit = async () => {
    try {
      console.log("Submitting selected rows:", selectedRows);

      // Step 1: Approval API calls (Only the approval part remains)
      const approvalPromises = selectedRows.map(row =>
        axios.post('http://13.127.57.224:2081/api/teacher-approval', {
          assignmentId: row.ASSIGNMENT_ID,
          studentId: row.STUDENT_ID,
          submittedDate: row.STUDENT_SUBMITTED_DATE,
          status: 'APPROVED',
        })
      );

      await Promise.all(approvalPromises);
      console.log("Approval API calls completed successfully.");

      // Step 2: Update the row data after submission and approval
      const remainingData = rowData.filter(
        row => !selectedRows.some(selected => selected.ASSIGNMENT_ID === row.ASSIGNMENT_ID)
      );
      setRowData(remainingData);

      setMessage("Approved successfully!");
    } catch (error) {
      console.error("Error during submission approval:", error);
      if (error.response) {
        console.error("Error response data:", error.response.data);
        console.error("Error response status:", error.response.status);
      }
      setMessage("Error during approval!");
    }
  };

  const handleCancel = async () => {
    try {
      console.log("Cancelling selected rows:", selectedRows);
      const cancellationPromises = selectedRows.map(row =>
        axios.post('http://13.127.57.224:2081/api/teacher-approval', {
          assignmentId: row.ASSIGNMENT_ID,
          studentId: row.STUDENT_ID,
          submittedDate: row.STUDENT_SUBMITTED_DATE,
          status: 'CANCEL',
        })
      );

      await Promise.all(cancellationPromises);
      console.log("Cancellation API calls completed successfully.");

      const remainingData = rowData.filter(
        row => !selectedRows.some(selected => selected.ASSIGNMENT_ID === row.ASSIGNMENT_ID)
      );
      setRowData(remainingData);

      setMessage("Rejected successfully!");
    } catch (error) {
      console.error("Error during rejection:", error);
      if (error.response) {
        console.error("Error response data:", error.response.data);
        console.error("Error response status:", error.response.status);
      }
      setMessage("Error during rejection!");
    }
  };

  return (
    <>      <Staffnavbar />

    <div style={{ padding: '20px',marginTop: '6vh'  }}>
      <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: '10px' }}>
        <div>
          <button
            onClick={handleSubmit}
            style={{
              backgroundColor: '#28a745',
              color: 'white',
              padding: '10px 15px',
              border: 'none',
              borderRadius: '5px',
              marginRight: '10px',
              cursor: 'pointer'
            }}
          >
            Submit
          </button>
          <button
            onClick={handleCancel}
            style={{
              backgroundColor: '#dc3545',
              color: 'white',
              padding: '10px 15px',
              border: 'none',
              borderRadius: '5px',
              cursor: 'pointer'
            }}
          >
            Cancel
          </button>
        </div>
        {message && <span style={{ color: 'green', fontWeight: 'bold', marginLeft: '15px' }}>{message}</span>}
      </div>
      <div className="ag-theme-alpine" style={{ height: '600px', width: '100%', overflowY: 'auto' }}>
        <AgGridReact
          rowData={rowData}
          columnDefs={columnDefs}
          rowSelection="multiple"
          onSelectionChanged={onSelectionChanged}
          domLayout="autoHeight"
        />
      </div>
    </div>
    </>
  );
}

export default StaffSelectAssignment;