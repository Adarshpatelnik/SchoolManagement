// import React, { useState, useEffect } from 'react';
// import axios from 'axios';
// import { FaCalendarAlt } from 'react-icons/fa'; // Importing icons from react-icons
// import Staffnavbar from './Staff_navbar.js';

// // StudentAssignmentTable component
// const StaffStudentInformationAssignment = () => {
//   const [assignments, setAssignments] = useState([]);

//   // Fetch student assignment data from the API
//   useEffect(() => {
//     fetchAssignments();
//   }, []);

//   // Fetch assignments data from the API
//   const fetchAssignments = async () => {
//     try {
//       const response = await axios.get('http://13.127.57.224:2081/api/StudentInformationForAssignment'); // API URL for student assignments
//       setAssignments(response.data);
//     } catch (error) {
//       console.error('Error fetching student assignments:', error);
//     }
//   };

//   return (
//     <>
//           <Staffnavbar />

//     <div className="schedule-card" style={styles.cardContainer}>
//       <div style={styles.cardHeader}>
//         <div style={styles.header}>
//           <FaCalendarAlt style={styles.icon} />
//           Student Assignment Information
//         </div>
//       </div>

//       {assignments.length > 0 ? (
//         <table style={styles.scheduleTable}>
//           <thead>
//             <tr>
//               <th style={styles.tableHeader}>Student ID</th>
//               <th style={styles.tableHeader}>Student Name</th>
//               <th style={styles.tableHeader}>Class</th>
//               <th style={styles.tableHeader}>Assignment Type</th>
//               <th style={styles.tableHeader}>Subject</th>
//               <th style={styles.tableHeader}>Assignment Description</th>
//             </tr>
//           </thead>
//           <tbody>
//             {assignments.map((assignment) => (
//               <tr key={assignment.STUDENT_ID} style={styles.scheduleRow}>
//                 <td style={styles.scheduleCell}>{assignment.STUDENT_ID}</td>
//                 <td style={styles.scheduleCell}>{assignment.STUDNET_NAME}</td>
//                 <td style={styles.scheduleCell}>{assignment.CLASS_ID}</td>
//                 <td style={styles.scheduleCell}>{assignment.ASSIGNMENT_TYPE}</td>
//                 <td style={styles.scheduleCell}>{assignment.SUBJECT_NAME}</td>
//                 <td style={styles.scheduleCell}>{assignment.ASSIGNMENT_DESC}</td>
//               </tr>
//             ))}
//           </tbody>
//         </table>
//       ) : (
//         <p style={styles.noSchedule}>No assignments available.</p>
//       )}
//     </div>
    
//     </>
//   );
// };

// // Styles for the component
// const styles = {
//   cardContainer: {
//     backgroundColor: '#fff',
//     borderRadius: '8px',
//     boxShadow: '0 6px 20px rgba(0, 0, 0, 0.05)',
//     padding: '10px',
//     width: 'auto',
//     maxWidth: '80%',
//     margin: '15px auto',
//     marginTop:'10vh',
//     display: 'flex',
//     flexDirection: 'column',
//     justifyContent: 'center',
//     alignItems: 'center',
//   },
//   cardHeader: {
//     display: 'flex',
//     justifyContent: 'center',
//     alignItems: 'center',
//     borderBottom: '1px solid #ddd',
//     paddingBottom: '8px',
//     marginBottom: '12px',
//     width: '100%',
//     background: 'linear-gradient(#92ea89, #859d9d, #c2e2e2)',
//     color: 'white',
//     borderRadius: '8px 8px 0 0',
//     paddingTop: '10px',
//   },
//   header: {
//     fontSize: '1.5rem',
//     fontWeight: '600',
//     display: 'flex',
//     alignItems: 'center',
//     textAlign: 'center',
//   },
//   icon: {
//     marginRight: '10px',
//     fontSize: '2.2rem',
//     color: '#487b79',
//     boxShadow: '0 4px 10px rgba(0, 0, 0, 0.2)',
//   },
//   scheduleTable: {
//     width: '100%',
//     borderCollapse: 'collapse',
//     marginTop: '8px',
//   },
//   tableHeader: {
//     textAlign: 'left',
//     padding: '8px',
//     backgroundColor: '#2c3e50',
//     color: 'white',
//     fontWeight: 'bold',
//     textTransform: 'uppercase',
//     letterSpacing: '0.8px',
//     fontSize: '0.9rem',
//   },
//   scheduleRow: {
//     backgroundColor: '#ecf0f1',
//     transition: 'background-color 0.3s ease',
//   },
//   scheduleCell: {
//     padding: '8px',
//     borderBottom: '1px solid #ddd',
//     color: '#2c3e50',
//     textAlign: 'left',
//     fontSize: '0.9rem',
//   },
//   noSchedule: {
//     textAlign: 'center',
//     fontSize: '1rem',
//     color: '#7f8c8d',
//     fontStyle: 'italic',
//     marginTop: '15px',
//   },
// };

// export default StaffStudentInformationAssignment;


import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { FaCalendarAlt } from 'react-icons/fa';
import Staffnavbar from './Staff_navbar.js';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';

// StudentAssignmentTable component
const StaffStudentInformationAssignment = () => {
  const [assignments, setAssignments] = useState([]);

  // Fetch student assignment data from the API
  useEffect(() => {
    fetchAssignments();
  }, []);

  // Fetch assignments data from the API
  const fetchAssignments = async () => {
    try {
      const response = await axios.get('http://13.127.57.224:2081/api/StudentInformationForAssignment');
      setAssignments(response.data);
    } catch (error) {
      console.error('Error fetching student assignments:', error);
    }
  };

  const columnDefs = [
    { headerName: "Student ID", field: "STUDENT_ID" },
    { headerName: "Student Name", field: "STUDNET_NAME" },
    { headerName: "Class", field: "CLASS_ID" },
    { headerName: "Assignment Type", field: "ASSIGNMENT_TYPE" },
    { headerName: "Subject", field: "SUBJECT_NAME" },
    { headerName: "Assignment Description", field: "ASSIGNMENT_DESC" },
  ];

  return (
    <>
      <Staffnavbar />

      <div className="schedule-card" style={styles.cardContainer}>
        <div style={styles.cardHeader}>
          <div style={styles.header}>
            <FaCalendarAlt style={styles.icon} />
            Student Assignment Information
          </div>
        </div>

        {assignments.length > 0 ? (
          <div className="ag-theme-alpine" style={styles.gridContainer}>
            <AgGridReact
              rowData={assignments}
              columnDefs={columnDefs}
              pagination={true}
              paginationPageSize={10}
              defaultColDef={{
                flex: 1,
                minWidth: 150,
                filter: true,
                sortable: true,
                resizable: true,
              }}
              suppressPaginationPanel={true} // Add this to suppress the pagination panel
            />
          </div>
        ) : (
          <p style={styles.noSchedule}>No assignments available.</p>
        )}
      </div>
    </>
  );
};

// Styles for the component
const styles = {
  cardContainer: {
    backgroundColor: '#fff',
    borderRadius: '8px',
    boxShadow: '0 6px 20px rgba(0, 0, 0, 0.1)',
    padding: '20px',
    width: 'auto',
    maxWidth: '100%',
    margin: '15px auto',
    marginTop: '10vh',
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'center',
  },
  cardHeader: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    borderBottom: '2px solid #92ea89',
    paddingBottom: '10px',
    marginBottom: '12px',
    width: '100%',
    background: 'linear-gradient(135deg, #92ea89, #c2e2e2)',
    color: 'black',
    borderRadius: '8px 8px 0 0',
    paddingTop: '10px',
  },
  header: {
    fontSize: '1.8rem',
    fontWeight: '600',
    display: 'flex',
    alignItems: 'center',
    textAlign: 'center',
  },
  icon: {
    marginRight: '10px',
    fontSize: '2.2rem',
    color: '#487b79',
  },
  gridContainer: {
    width: '100%',
    height: '400px', // Adjust height as needed
    marginTop: '10px',
  },
  noSchedule: {
    textAlign: 'center',
    fontSize: '1rem',
    color: '#7f8c8d',
    fontStyle: 'italic',
    marginTop: '15px',
  },
};

export default StaffStudentInformationAssignment;


