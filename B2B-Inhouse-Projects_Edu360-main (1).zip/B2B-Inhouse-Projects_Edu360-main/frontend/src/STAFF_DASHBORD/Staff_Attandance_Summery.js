



// import React, { useState, useEffect } from 'react';
// import 'bootstrap/dist/css/bootstrap.min.css';
// import { Doughnut } from 'react-chartjs-2';
// import styled from 'styled-components';
// import { Chart as ChartJS, ArcElement, Title, Tooltip, Legend } from 'chart.js';

// // Registering Chart.js components
// ChartJS.register(ArcElement, Title, Tooltip, Legend);

// // Styled Components
// const Container = styled.div`
//   padding: 0px; /* Increased padding */
//   width: 100%;
//   height: 50vh; /* Increased height */
//   margin: 0;
//   background-color: #f4f7fa;
// `;

// const ChartContainer = styled.div`
//   display: flex;
//   flex-wrap: wrap;
//   gap: 0px; /* Added gap between charts */
//   margin-bottom: 0px; /* Added margin */
// `;

// const ChartCard = styled.div`
//   flex: 1 1 40%; /* Increased the base size of the chart card */
//   background-color: #ffffff;
//   border-radius: 0px;
//   // box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
//   overflow: hidden;
//   transition: transform 0.3s;

 
// `;

// const ChartContent = styled.div`
//   padding: 10px; /* Increased padding */
//   width: 100%;
//   min-height: 250px; /* Increased minimum height for better layout */
//   height: auto; /* Set height to auto to accommodate chart size */
// `;

// const FlexRow = styled.div`
//   display: flex;
//   gap: 0px;
//   margin-top: 0px;
//   flex: 1;
// `;

// const StaffAttendanceSummary = () => {
//   const [attendanceData, setAttendanceData] = useState({
//     present_count: 0,
//     absent_count: 0,
//     leave_count: 0,
//   });

//   const [unsubmittedAssignments, setUnsubmittedAssignments] = useState([]);

//   useEffect(() => {
//     const fetchAttendanceData = async () => {
//       try {
//         const response = await fetch('http://13.127.57.224:2081/api/STAFFDASHBOARD');
//         if (!response.ok) {
//           const errorText = await response.text();
//           throw new Error(`Network response was not ok: ${errorText}`);
//         }
//         const data = await response.json();
//         setAttendanceData(data);
//       } catch (error) {
//         console.error('Error fetching attendance data:', error);
//       }
//     };

//     fetchAttendanceData();
//   }, []);

//   useEffect(() => {
//     const fetchAssignmentData = async () => {
//       try {
//         const response = await fetch('http://13.127.57.224:2081/api/ASSIGMENTDASH');
//         if (!response.ok) {
//           const errorText = await response.text();
//           throw new Error(`Network response was not ok: ${errorText}`);
//         }
//         const data = await response.json();
//         setUnsubmittedAssignments(data);
//       } catch (error) {
//         console.error('Error fetching assignment data:', error);
//       }
//     };

//     fetchAssignmentData();
//   }, []);

//   return (
//     <Container>
//       <FlexRow>
//         <ChartContainer>
//           <ChartCard>
//             <ChartContent>
//               <Doughnut
//                 data={{
//                   labels: ['Present', 'Absent', 'Leave'],
//                   datasets: [
//                     {
//                       data: [
//                         attendanceData.present_count,
//                         attendanceData.absent_count,
//                         attendanceData.leave_count,
//                       ],
//                       backgroundColor: ['#4caf50', '#f44336', '#ff9800'],
//                     },
//                   ],
//                 }}
//                 options={{ maintainAspectRatio: false }} // This will allow the chart to take the height of the container
//               />
//             </ChartContent>
//           </ChartCard>
//         </ChartContainer>
//       </FlexRow>
//     </Container>
//   );
// };

// export default StaffAttendanceSummary;



// import React, { useState, useEffect } from 'react';
// import 'bootstrap/dist/css/bootstrap.min.css';
// import { Doughnut } from 'react-chartjs-2';
// import styled from 'styled-components';
// import { Chart as ChartJS, ArcElement, Title, Tooltip, Legend } from 'chart.js';

// // Registering Chart.js components
// ChartJS.register(ArcElement, Title, Tooltip, Legend);

// // Styled Components
// const Container = styled.div`
//   padding: 0px;
//   width: 100%;
//   height: 50vh;
//     margin-top: -5rem;

//   margin: 0;
//   background-color: #f4f7fa;
// `;

// const ChartContainer = styled.div`
//   display: flex;
//   flex-wrap: wrap;
//   gap: 0px;
//     width: 100%;

//     margin-top: -1rem;
// `;

// const ChartCard = styled.div`
//   flex: 1 1 40%;
//   background-color: #ffffff;
//   border-radius: 8px;
//   // box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
//   overflow: hidden;
//   transition: transform 0.3s;
// `;

// const ChartContent = styled.div`
//   padding: 10px;
//   width: 100%;
//   min-height: 250px;
//   height: auto;
// `;

// const FlexRow = styled.div`
//   display: flex;
//   gap: 20px;
//   margin-top: 0px;
//   flex: 1;
// `;

// const StaffAttendanceSummary = () => {
//   const [attendanceData, setAttendanceData] = useState({
//     present_count: 0,
//     absent_count: 0,
//     leave_count: 0,
//   });

//   useEffect(() => {
//     const fetchAttendanceData = async () => {
//       try {
//         const response = await fetch('http://13.127.57.224:2081/api/STAFFDASHBOARD');
//         if (!response.ok) {
//           const errorText = await response.text();
//           throw new Error(`Network response was not ok: ${errorText}`);
//         }
//         const data = await response.json();
//         setAttendanceData(data);
//       } catch (error) {
//         console.error('Error fetching attendance data:', error);
//       }
//     };

//     fetchAttendanceData();
//   }, []);

//   return (
//     <Container>
//       <FlexRow>
//         <ChartContainer>
//           <ChartCard>
//             <ChartContent>
//               <Doughnut
//                 data={{
//                   labels: ['Present', 'Absent', 'Leave'],
//                   datasets: [
//                     {
//                       label: 'Staff Attendance',
//                       data: [
//                         attendanceData.present_count,
//                         attendanceData.absent_count,
//                         attendanceData.leave_count,
//                       ],
//                       backgroundColor: ['#4caf50', '#f44336', '#ff9800'],
//                       cutout: '70%', // Set inner radius ratio to mimic innerRadiusRatio: 0.7
//                     },
//                   ],
//                 }}
//                 options={{
//                   maintainAspectRatio: false,
//                   plugins: {
//                     legend: {
//                       display: true,
//                       position: 'right',
//                     },
//                     tooltip: {
//                       callbacks: {
//                         label: (tooltipItem) =>
//                           `${tooltipItem.label}: ${tooltipItem.raw}`,
//                       },
//                     },
//                   },
//                 }}
//               />
//             </ChartContent>
//           </ChartCard>
//         </ChartContainer>
//       </FlexRow>
//     </Container>
//   );
// };

// export default StaffAttendanceSummary;




// import React, { useState, useEffect } from 'react';
// import 'bootstrap/dist/css/bootstrap.min.css';
// import { AgCharts } from 'ag-charts-react';
// import styled from 'styled-components';

// // Styled Components
// const Container = styled.div`
//   width: 100%;
//   margin-top: -11rem;
//   background-color: #f4f7fa;
//   display: flex;
//   justify-content: top;
//   align-items: center;
// `;

// const ChartCard = styled.div`
//   width: 50vw;  // Adjust width as needed for the chart size
//   height: 34vh; // Adjust height as needed for the chart size
//   background-color: #ffffff;
//   border-radius: 8px;
//   overflow: hidden;
//     margin-top: -17rem;

//   padding: 1px;
//   // box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
//   transition: transform 0.3s;
// `;

// const ChartContent = styled.div`
//   width: 100%;

//   height: 100%;
// `;

// const StaffAttendanceSummary = () => {
//   const [attendanceData, setAttendanceData] = useState({
//     present_count: 0,
//     absent_count: 0,
//     leave_count: 0,
//   });

//   useEffect(() => {
//     const fetchAttendanceData = async () => {
//       try {
//         const response = await fetch('http://13.127.57.224:2081/api/STAFFDASHBOARD');
//         if (!response.ok) {
//           const errorText = await response.text();
//           throw new Error(`Network response was not ok: ${errorText}`);
//         }
//         const data = await response.json();
//         setAttendanceData(data);
//       } catch (error) {
//         console.error('Error fetching attendance data:', error);
//       }
//     };

//     fetchAttendanceData();
//   }, []);

//   const options = {
//     data: [
//       { label: 'Present', count: attendanceData.present_count, color: '#4caf50' },
//       { label: 'Absent', count: attendanceData.absent_count, color: '#f44336' },
//       { label: 'Leave', count: attendanceData.leave_count, color: '#ff9800' },
//     ],
//     series: [
//       {
//         type: 'donut',
//         angleKey: 'count',
//         labelKey: 'label',
//         innerRadiusRatio: 0.7,
//         fills: ['#4caf50', '#f44336', '#ff9800'],
//         calloutLabel: {
//           enabled: true,
//           fontSize: 12,
//           fontWeight: 'bold',
//           formatter: ({ datum }) => {
//             const total = attendanceData.present_count + attendanceData.absent_count + attendanceData.leave_count;
//             const percentage = ((datum.count / total) * 100).toFixed(1);
//             return `${datum.label}\n${percentage}%`;
//           },
//         },
//         innerLabels: [
//           {
//             text: 'Attendance',
//             fontWeight: 'bold',
//             fontSize: 10,
//           },
//           {
//             text: `${attendanceData.present_count + attendanceData.absent_count + attendanceData.leave_count}`,
//             spacing: 1,
//             fontSize: 14,
//             color: 'green',
//           },
//         ],
//       },
//     ],
//     legend: {
//       enabled: true,
//       position: 'right',
//       item: {
//         fontSize: 12,
//         marker: {
//           shape: 'circle',
//         },
//       },
//     },
//     tooltip: {
//       renderer: ({ datum }) => ({
//         content: `${datum.label}: ${datum.count}`,
//       }),
//     },
//   };

//   return (
//     <Container>
//       <ChartCard>
//         <ChartContent>
//           <AgCharts options={options} style={{ width: '100%', height: '34vh' }} />
//         </ChartContent>
//       </ChartCard>
//     </Container>
//   );
// };

// export default StaffAttendanceSummary;










import React, { useState, useEffect } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import { AgCharts } from 'ag-charts-react'; // Ensure correct import
import styled from 'styled-components';

// Styled Components
const Container = styled.div`
  width: 100%;
  margin-top: -11rem;
  background-color: #f4f7fa;
  display: flex;
  justify-content: top;
  align-items: center;
`;

const ChartCard = styled.div`
  width: 50vw;
  height: 34vh;
  background-color: #ffffff;
  border-radius: 8px;
  overflow: hidden;
  margin-top: -17rem;
  padding: 1px;
  transition: transform 0.3s;
`;

const ChartContent = styled.div`
  width: 100%;
  height: 100%;
`;

const StaffAttendanceSummary = () => {
  const [attendanceData, setAttendanceData] = useState({
    present_count: 0,
    absent_count: 0,
    leave_count: 0,
  });

  useEffect(() => {
    const fetchAttendanceData = async () => {
      try {
        const response = await fetch('http://13.127.57.224:2081/api/STAFFDASHBOARD');
        if (!response.ok) {
          const errorText = await response.text();
          throw new Error(`Network response was not ok: ${errorText}`);
        }
        const data = await response.json();
        setAttendanceData(data);
      } catch (error) {
        console.error('Error fetching attendance data:', error);
      }
    };

    fetchAttendanceData();
  }, []);

  const totalAttendance = attendanceData.present_count + attendanceData.absent_count + attendanceData.leave_count;

  const options = {
    data: [
      { label: 'Present', count: attendanceData.present_count, color: '#4caf50' },
      { label: 'Absent', count: attendanceData.absent_count, color: '#f44336' },
      { label: 'Leave', count: attendanceData.leave_count, color: '#ff9800' },
    ],
    series: [
      {
        type: 'donut',
        angleKey: 'count',
        labelKey: 'label',
        innerRadiusRatio: 0.7,
        fills: ['#4caf50', '#f44336', '#ff9800'],
        calloutLabelKey: 'label',
        calloutLabel: {
          enabled: true,
          fontSize: 12,
          fontWeight: 'bold',
          formatter: ({ datum }) => {
            const percentage = ((datum.count / totalAttendance) * 100).toFixed(1);
            return `${datum.label}\n${percentage}%`;
          },
        },
        innerLabels: [
          {
            text: 'Attendance',
            fontWeight: 'bold',
            fontSize: 10,
          },
          {
            text: `${totalAttendance}`,
            fontWeight: 'bold',
            fontSize: 14,
            color: 'green',
          },
        ],
      },
    ],
    legend: {
      enabled: true,
      position: 'right',
      item: {
        fontSize: 12,
        marker: {
          shape: 'circle',
        },
      },
    },
    tooltip: {
      renderer: ({ datum }) => ({
        content: `${datum.label}: ${datum.count}`,
      }),
    },
  };

  return (
    <Container>
      <ChartCard>
        <ChartContent>
          <AgCharts options={options} style={{ width: '100%', height: '34vh' }} />
        </ChartContent>
      </ChartCard>
    </Container>
  );
};

export default StaffAttendanceSummary;
