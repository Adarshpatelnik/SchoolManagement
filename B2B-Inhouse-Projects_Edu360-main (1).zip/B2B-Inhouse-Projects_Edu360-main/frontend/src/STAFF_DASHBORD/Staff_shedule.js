// import React, { useState, useEffect } from 'react';
// import axios from 'axios';
// import { FaCalendarAlt, FaRedoAlt } from 'react-icons/fa'; // Importing icons from react-icons

// // TeacherScheduleTable component
// const Staffshedule = ({ teacherName = 'Mr. John Doe' }) => {
//   const [schedule, setSchedule] = useState([]);

//   // Fetch teacher's schedule data from API
//   useEffect(() => {
//     fetchTeacherSchedule();
//   }, [teacherName]);

//   // Fetch schedule data from the API
//   const fetchTeacherSchedule = async () => {
//     try {
//       const response = await axios.get('http://13.127.57.224:2081/api/schedule', {
//         params: { teacherName },
//       });
//       setSchedule(response.data);
//     } catch (error) {
//       console.error('Error fetching teacher schedule:', error);
//     }
//   };

//   // Refresh the schedule (manually)
//   const handleRefresh = () => {
//     fetchTeacherSchedule(); // Trigger fetching the schedule again
//   };

//   return (
//     <div className="schedule-card" style={styles.cardContainer}>
    

//       {schedule.length > 0 ? (
//         <table style={styles.scheduleTable}>
//           <thead>
//             <tr>
//               <th style={styles.tableHeader}>Class ID</th>
//               <th style={styles.tableHeader}>Subject</th>
//               <th style={styles.tableHeader}>Time Slot</th>
//               <th style={styles.tableHeader}>Period</th>
//             </tr>
//           </thead>
//           <tbody>
//             {schedule.map((classInfo) => (
//               <tr key={classInfo.CLASS_ID} style={styles.scheduleRow}>
//                 <td style={styles.scheduleCell}>{classInfo.CLASS_ID}</td>
//                 <td style={styles.scheduleCell}>{classInfo.SUBJECT}</td>
//                 <td style={styles.scheduleCell}>{classInfo.TIME_SLOT || "Not Scheduled"}</td>
//                 <td style={styles.scheduleCell}>{classInfo.PERIOD || "N/A"}</td>
//               </tr>
//             ))}
//           </tbody>
//         </table>
//       ) : (
//         <p style={styles.noSchedule}>No schedule available.</p>
//       )}
//     </div>
//   );
// };

// // Styles for the component
// const styles = {
//   cardContainer: {
//     backgroundColor: '#fff',
//     borderRadius: '8px',  // Reduced border radius
//     boxShadow: '0 6px 20px rgba(0, 0, 0, 0.05)', // Reduced shadow
//     padding: '10px', // Reduced padding for compactness
//     width: 'auto', // Set width to auto to let it adjust to content width
//     maxWidth: '30%',  // Set a smaller max-width
//     margin: '15px auto', // Center the card
//     display: 'flex',
//     flexDirection: 'column',
//     justifyContent: 'center',
//     alignItems: 'center',
//   },
//   cardHeader: {
//     display: 'flex',
//     justifyContent: 'center', // Center the content horizontally
//     alignItems: 'center',
//     borderBottom: '1px solid #ddd', // Thinner border
//     paddingBottom: 'px',  // Reduced padding
//     marginBottom: '2px',  // Reduced margin
//     width: '100%',
//     background: 'linear-gradient(#92ea89, #859d9d, #c2e2e2)', // Gradient background for the header
//     color: 'white',
//     borderRadius: '8px 8px 0 0', // Rounded top corners for the header
//     paddingTop: '1px', // Extra padding on top for better alignment
//   },
//   header: {
//     fontSize: '1.5rem',  // Slightly larger font size for header
//     fontWeight: '600',
//     display: 'flex',
//     alignItems: 'center',
//     textAlign: 'center', // Center the text
//   },
//   icon: {
//     marginRight: '10px',  // Space between icon and text
//     fontSize: '2.2rem',  // Increased icon size for better visibility
//     color: '#487b79',  // Solid color for icon (blue)
//     boxShadow: '0 4px 10px rgba(0, 0, 0, 0.2)', // Added subtle shadow for a "pop" effect
//   },
//   refreshIcon: {
//     fontSize: '1.6rem',  // Slightly smaller refresh icon
//     color: '#fff',
//     cursor: 'pointer',
//     transition: 'color 0.3s ease',
//   },
//   scheduleTable: {
//     width: '100%',
//     borderCollapse: 'collapse',
//     marginTop: 'px',  // Reduced margin
//   },
//   tableHeader: {
//     textAlign: 'left',
//     padding: '6px',  // Reduced padding for headers
//     backgroundColor: '#2c3e50',
//     color: 'white',
//     fontWeight: 'bold',
//     textTransform: 'uppercase',
//     letterSpacing: '0.8px',  // Reduced letter spacing
//     fontSize: '0.8rem',  // Smaller font size for headers
//   },
//   scheduleRow: {
//     backgroundColor: '#ecf0f1',
//     transition: 'background-color 0.3s ease',
//   },
//   scheduleCell: {
//     padding: '6px',  // Reduced padding in cells
//     borderBottom: '1px solid #ddd',
//     color: '#2c3e50',
//     textAlign: 'left',
//     fontSize: '0.8rem',  // Reduced font size in cells
//   },
//   noSchedule: {
//     textAlign: 'center',
//     fontSize: '1rem',  // Smaller font size for no schedule message
//     color: '#7f8c8d',
//     fontStyle: 'italic',
//     marginTop: '1px',  // Reduced margin
//   },
// };

// export default Staffshedule;
import React, { useState, useEffect } from 'react';
import axios from 'axios';

// TeacherScheduleTable component
const Staffshedule = ({ teacherName = 'Mr. John Doe' }) => {
  const [schedule, setSchedule] = useState([]);

  // Fetch teacher's schedule data from API
  useEffect(() => {
    fetchTeacherSchedule();
  }, [teacherName]);

  // Fetch schedule data from the API
  const fetchTeacherSchedule = async () => {
    try {
      const response = await axios.get('http://13.127.57.224:2081/api/schedule', {
        params: { teacherName },
      });
      setSchedule(response.data);
    } catch (error) {
      console.error('Error fetching teacher schedule:', error);
    }
  };

  // Refresh the schedule (manually)
  const handleRefresh = () => {
    fetchTeacherSchedule(); // Trigger fetching the schedule again
  };

  return (
    <div style={styles.cardContainer}>
      {schedule.length > 0 ? (
        <div style={styles.tableContainer}>
          <table style={styles.scheduleTable}>
            <thead>
              <tr>
                <th style={styles.tableHeader}>Class ID</th>
                <th style={styles.tableHeader}>Subject</th>
                <th style={styles.tableHeader}>Time Slot</th>
                <th style={styles.tableHeader}>Period</th>
              </tr>
            </thead>
            <tbody>
              {schedule.map((classInfo) => (
                <tr key={classInfo.CLASS_ID} style={styles.scheduleRow}>
                  <td style={styles.scheduleCell}>{classInfo.CLASS_ID}</td>
                  <td style={styles.scheduleCell}>{classInfo.SUBJECT}</td>
                  <td style={styles.scheduleCell}>{classInfo.TIME_SLOT || "Not Scheduled"}</td>
                  <td style={styles.scheduleCell}>{classInfo.PERIOD || "N/A"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <p style={styles.noSchedule}>No schedule available.</p>
      )}
    </div>
  );
};

// Styles for the component
const styles = {
  cardContainer: {
    backgroundColor: '#ffffff',
    borderRadius: '0px',
    // boxShadow: '0 12px 40px rgba(0, 0, 0, 0.2)',
    padding: '0px',
    width: '100%',
    maxWidth: '100%',
    margin: '0px auto',
    overflow: 'hidden',
    transition: 'all 0.3s ease',
    hover: {
      transform: 'translateY(-5px)',
    },
  },
  tableContainer: {
    maxHeight: '300px', // Limit the height of the table
    overflowY: 'auto', // Enable vertical scrolling if the content overflows
    overflowX: 'hidden',
    paddingRight: '10px', // Add some space for scrollbar
  },
  scheduleTable: {
    width: '100%',
    borderCollapse: 'collapse',
    marginTop: '0px',
    backgroundColor: '#fdfdfd',
    borderRadius: '0 0 20px 20px',
    overflow: 'hidden',
  },
  tableHeader: {
    textAlign: 'left',
    padding: '5px 10px', // Adjusted padding for better spacing
    background: 'linear-gradient(135deg, #6c757d, #343a40)', // Subtle gradient background
    color: 'white',
    fontWeight: 'bold',
    fontSize: '0.9rem', // Slightly increased font size for better readability
    letterSpacing: '1px', // Add letter spacing for a cleaner look
    // borderRadius: '6px', // Rounded corners for a modern look
    boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)', // Light shadow for depth
    transition: 'background-color 0.3s ease', // Smooth hover transition
    textTransform: 'capitalize', // Better text casing for a modern feel
    textShadow: '1px 1px 3px rgba(0, 0, 0, 0.1)', // Subtle text shadow
  },
  
  scheduleRow: {
    transition: 'background-color 0.3s ease',
    backgroundColor: '#f6f6f6',
    ':hover': {
      backgroundColor: '#e0f7fa',
    },
  },
  scheduleCell: {
    padding: '10px',
    borderBottom: '1px solid #ddd',
    color: '#2c3e50',
    fontSize: '0.85rem',
  },
  noSchedule: {
    textAlign: 'center',
    fontSize: '1rem',
    color: '#7f8c8d',
    fontStyle: 'italic',
    marginTop: '20px',
  },
};

export default Staffshedule;

