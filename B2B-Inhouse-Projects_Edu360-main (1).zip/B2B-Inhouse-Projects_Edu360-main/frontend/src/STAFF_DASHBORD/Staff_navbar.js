// import React from 'react';
// import { Navbar, Nav, NavDropdown } from 'react-bootstrap';
// import { Link } from 'react-router-dom';

// const Staffnavbar = () => {
//     const navbarStyle = {
//         backgroundColor: '#f8f9fa', // Light background
//         padding: '10px 20px', // Padding for the navbar
//         position: 'fixed', // Fix the navbar to the top
//         top: 0, // Align it to the top
//         left: 0, // Align it to the left
//         width: '100%', // Full width of the viewport
//         zIndex: 1000 // Ensure it's above other elements
//     };

//     const navLinkStyle = {
//         margin: '0 20px', // Margin between links
//         color: '#007bff', // Link color
//     };

//     const logoutStyle = {
//         color: '#dc3545', // Logout button color
//         fontWeight: 'bold', // Bold text for Logout
//     };

//     const brandFontSize = 1.5; // Font size for the brand

//     // Define the logo dimensions and margins
//     const brandLogoWidth = 2; // Reduced width of the logo in rem
//     const brandLogoHeight = 2; // Reduced height of the logo in rem
//     const brandLogoMarginRight = 0.2; // Right margin for the logo in rem
//     const brandLogoMarginBottom = 0.2; // Bottom margin for the logo in rem

//     return (
//         <Navbar style={navbarStyle} expand="lg">
//             <img 
//                 src="02 1.jpg" 
//                 alt="B2B360 Logo" 
//                 style={{ 
//                     width: `${brandLogoWidth}rem`, 
//                     height: `${brandLogoHeight}rem`, 
//                     marginRight: `${brandLogoMarginRight}rem`, 
//                     marginBottom: `${brandLogoMarginBottom}rem` 
//                 }} 
//             />
//             <span
//                 style={{
//                     fontFamily: 'Playfair Display, serif',
//                     fontSize: `${brandFontSize}em`, // Use the defined font size
//                     fontWeight: 'bold',
//                     backgroundImage: 'linear-gradient(to right, #012353, #27AE60)',
//                     WebkitBackgroundClip: 'text',
//                     WebkitTextFillColor: 'transparent',
//                 }}
//             >
//                 EDU<span style={{ color: '#dc3545' }}>3</span>6<span style={{ color: '#28a745' }}>0</span>
//             </span>
//             <Navbar.Toggle aria-controls="basic-navbar-nav" />
//             <Navbar.Collapse id="basic-navbar-nav" className="justify-content-end"> {/* Align Nav to the end */}
//                 <Nav className="d-flex justify-content-end"> {/* Align items to the right */}
//                     <Nav.Link as={Link} to="/Staff_Dashbord" style={navLinkStyle}>Home</Nav.Link>
//                     <Nav.Link as={Link} to="/Staff_Grade Entry" style={navLinkStyle}>Grady Entry</Nav.Link>

//                     {/* <NavDropdown title="" id="basic-nav-dropdown" style={navLinkStyle}>
//                         <NavDropdown.Item as={Link} to="/service1">Service 1</NavDropdown.Item>
//                         <NavDropdown.Item as={Link} to="/service2">Service 2</NavDropdown.Item>
//                         <NavDropdown.Item as={Link} to="/service3">Service 3</NavDropdown.Item>
//                     </NavDropdown> */}
//                     <Nav.Link href="/Login" style={logoutStyle}>Logout</Nav.Link>
//                 </Nav>
//             </Navbar.Collapse>
//         </Navbar>
//     );
// };

// export default Staffnavbar;








import React, { useState } from 'react';
import { Navbar, Nav, NavDropdown, Modal, Button } from 'react-bootstrap'; // Import Modal and Button
import { Link } from 'react-router-dom';
import { FaPowerOff } from 'react-icons/fa'; // Import the logout icon

const Staffnavbar = () => {
    const [showModal, setShowModal] = useState(false); // State to control the modal visibility
    const [isLoggingOut, setIsLoggingOut] = useState(false); // State to manage logout action

    const navbarStyle = {
        backgroundColor: '#f8f9fa',
        padding: '10px 20px',
        position: 'fixed',
        top: 0,
        left: 0,
        width: '100%',
        zIndex: 1000
    };

    const navLinkStyle = {
        margin: '0 20px',
        color: 'black',
        textDecoration: 'none',
        fontWeight: '500',
        transition: 'color 0.3s',
    };

    const logoutStyle = {
        color: 'black',
        fontWeight: 'bold',
        textDecoration: 'none',
        transition: 'color 0.3s',
        display: 'flex',
        alignItems: 'center',
    };

    const brandFontSize = 1.5;
    const brandLogoWidth = 2;
    const brandLogoHeight = 2;
    const brandLogoMarginRight = 0.2;
    const brandLogoMarginBottom = 0.2;

    // Function to show the logout confirmation modal
    const handleLogoutClick = () => {
        setShowModal(true); // Show the modal when logout button is clicked
    };

    // Function to confirm logout
    const handleConfirmLogout = () => {
        setIsLoggingOut(true);
        // You can perform the actual logout logic here, like clearing the session or redirecting
        // Redirect to login page or clear session after logging out
        window.location.href = "/Login"; // For now, it redirects to login page
    };

    // Function to cancel logout
    const handleCloseModal = () => {
        setShowModal(false); // Close the modal without logging out
    };

    return (
        <>
            <Navbar style={navbarStyle} expand="lg">
                <img 
                    src="02 1.jpg" 
                    alt="B2B360 Logo" 
                    style={{ 
                        width: `${brandLogoWidth}rem`, 
                        height: `${brandLogoHeight}rem`, 
                        marginRight: `${brandLogoMarginRight}rem`, 
                        marginBottom: `${brandLogoMarginBottom}rem` 
                    }} 
                />
                <span
                    style={{
                        fontFamily: 'Playfair Display, serif',
                        fontSize: `${brandFontSize}em`,
                        fontWeight: 'bold',
                        backgroundImage: 'linear-gradient(to right, #012353, #27AE60)',
                        WebkitBackgroundClip: 'text',
                        WebkitTextFillColor: 'transparent',
                    }}
                >
                    EDU<span style={{ color: '#dc3545' }}>3</span>6<span style={{ color: '#28a745' }}>0</span>
                </span>
                <Navbar.Toggle aria-controls="basic-navbar-nav" />
                <Navbar.Collapse id="basic-navbar-nav" className="justify-content-end">
                    <Nav className="d-flex justify-content-end">
                        <Nav.Link as={Link} to="/Staff_Dashbord" style={navLinkStyle}>Home</Nav.Link>

                        <Nav.Link as={Link} to="/Staff_Grade_Entry" style={navLinkStyle}>Grade Entry</Nav.Link>

                        <NavDropdown title="Assignment" id="basic-nav-dropdown" style={navLinkStyle}>
                            <NavDropdown.Item as={Link} to="/Staff_Assignment_Form">Assignment Form</NavDropdown.Item>
                            <NavDropdown.Item as={Link} to="/Staff_Assignment_Table">Assignment Table</NavDropdown.Item>

                            <NavDropdown.Item as={Link} to="/Staff_Select_Assignment">Assignment Approval</NavDropdown.Item>

                            <NavDropdown.Item as={Link} to="/Staff_Approve_Assignment">Assignment Record</NavDropdown.Item>
                        </NavDropdown>
                        <Nav.Link onClick={handleLogoutClick} style={logoutStyle}>
                            <FaPowerOff style={{ marginRight: '5px' }} />  
                        </Nav.Link>
                    </Nav>
                </Navbar.Collapse>
            </Navbar>

            {/* Modal for logout confirmation */}
            <Modal show={showModal} onHide={handleCloseModal}>
                <Modal.Header closeButton>
                    <Modal.Title>Confirm Logout</Modal.Title>
                </Modal.Header>
                <Modal.Body>Are you sure you want to log out?</Modal.Body>
                <Modal.Footer>
                    <Button variant="secondary" onClick={handleCloseModal}>
                        No
                    </Button>
                    <Button variant="primary" onClick={handleConfirmLogout}>
                        Yes
                    </Button>
                </Modal.Footer>
            </Modal>
        </>
    );
};

export default Staffnavbar;
