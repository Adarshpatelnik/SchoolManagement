import React, { useState, useEffect } from 'react';
import { AgGridReact } from 'ag-grid-react';
import axios from 'axios';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import Staffnavbar from './Staff_navbar.js';

const StaffAssignmentTable = () => {
  // State to store data and loading status
  const [rowData, setRowData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null); // State to track errors

  // Column definitions for AG Grid
  const columnDefs = [
    { headerName: 'Assignment ID', field: 'ASSIGNMENT_ID', sortable: true, filter: true },
    { headerName: 'Class ID', field: 'CLASS_ID', sortable: true, filter: true },
    { headerName: 'Assignment Type', field: 'ASSIGNMENT_TYPE', sortable: true, filter: true },
    { headerName: 'Subject Name', field: 'SUBJECT_NAME', sortable: true, filter: true },
    { headerName: 'Assignment Description', field: 'ASSIGNMENT_DESC', sortable: true, filter: true },
    {
      headerName: 'Submission Start Date',
      field: 'SUBMISSION_START_DATE',
      sortable: true,
      filter: true,
      valueFormatter: (params) => params.value ? formatDate(params.value) : ''
    },
    {
      headerName: 'Submission End Date',
      field: 'SUBMISSION_END_DATE',
      sortable: true,
      filter: true,
      valueFormatter: (params) => params.value ? formatDate(params.value) : ''
    }
  ];

  // Utility function to format date to DD-MM-YYYY
  const formatDate = (date) => {
    try {
      const formattedDate = new Date(date);
      const day = String(formattedDate.getDate()).padStart(2, '0');
      const month = String(formattedDate.getMonth() + 1).padStart(2, '0'); // Months are 0-indexed
      const year = formattedDate.getFullYear();
      return `${day}-${month}-${year}`;
    } catch (err) {
      console.error('Date formatting error:', err);
      return '';
    }
  };

  // Fetch data from the backend API
  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get('http://13.127.57.224:2081/api/assignmentstable');
        console.log('API Response:', response.data); // Debug log for fetched data
        setRowData(response.data);
      } catch (err) {
        console.error('Error fetching data:', err);
        setError('Failed to fetch data. Please try again later.');
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  return (
    <>   
     <Staffnavbar />
    <div className="ag-theme-alpine" style={{ height: 350, width: '100%', padding: '20px', overflowX: 'auto' ,marginTop: '5vh' }}>
      <h2>Assignment Table</h2>
      {loading ? (
        <p>Loading data...</p>
      ) : error ? (
        <div style={{ color: 'red' }}>
          <p>{error}</p>
        </div>
      ) : (
        <AgGridReact
          rowData={rowData}
          columnDefs={columnDefs}
          defaultColDef={{ flex: 1, minWidth: 100 }}
        />
      )}
    </div>
    </>
  );
};

export default StaffAssignmentTable;