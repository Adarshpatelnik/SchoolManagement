import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom'; // Import useNavigate
import axios from 'axios';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';

const StaffAssignmentList = () => {
  const [Mystudent, setMystudent] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const navigate = useNavigate(); // Initialize useNavigate

  // Handle the click to navigate to the student assignment table
  const handleClassClick = (classId) => {
    navigate(`/Mystudentdetail/${classId}`);
  };

  // Column Definitions with custom cell renderer
  const columnDefs = [
    {
      headerName: 'Class',
      field: 'CLASS_SECTION',
      sortable: true,
      filter: true,
      cellRenderer: (params) => {
        const classSection = params.value; // Access value of CLASS_SECTION
        if (!classSection) return null; // Don't render the link if classSection is empty

        // Use <a> tag and handle navigation via handleClassClick
        return (
          <a
            href="Mystudentdetail"
            onClick={(e) => {
              e.preventDefault(); // Prevent default link behavior
              handleClassClick(classSection); // Navigate to the student assignment table
            }}
            style={{ color: 'blue', textDecoration: 'underline', fontWeight: 'bold' }}
          >
            {classSection}
          </a>
        );
      }
    },
    { headerName: 'Student Id', field: 'STUDENT_ID', sortable: true, filter: true },
    { headerName: 'Assignment Id', field: 'ASSIGNMENT_ID', sortable: true, filter: true },
    { headerName: 'Student Name', field: 'STUDENT_NAME', sortable: true, filter: true },
    { headerName: 'Gender', field: 'GENDER', sortable: true, filter: true },
    { headerName: 'Contact Number', field: 'CONTACT_NUMBER', sortable: true, filter: true },
    { headerName: 'Subject', field: 'SUBJECT_NAME', sortable: true, filter: true },
    { headerName: 'DUE TODAY', field: 'OnTimeAssignments', sortable: true, filter: true },
    { headerName: 'DUE DATE PASSED', field: 'LateAssignments', sortable: true, filter: true },
    { headerName: 'DUE LATTER', field: 'UpcomingAssignments', sortable: true, filter: true },
    { headerName: 'Assignment Count', field: 'assignmentCount', sortable: true, filter: true }
  ];

  // Fetching data
  const fetchTeacherMystudent = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await axios.get('http://13.127.57.224:2081/api/StaffAssignmentDashboad');
      const assignmentData = processAssignments(response.data);
      setMystudent(assignmentData);
    } catch (error) {
      console.error('Error fetching teacher Mystudent:', error);
      setError('Failed to load data');
    } finally {
      setLoading(false);
    }
  }, []);

  // Process the data to count assignments
  const processAssignments = (data) => {
    const assignmentCountMap = data.reduce((acc, curr) => {
      const assignmentId = curr.ASSIGNMENT_ID;
      if (!acc[assignmentId]) {
        acc[assignmentId] = { ...curr, assignmentCount: 0 };
      }
      acc[assignmentId].assignmentCount++;
      return acc;
    }, {});
    return Object.values(assignmentCountMap);
  };

  useEffect(() => {
    fetchTeacherMystudent();
  }, [fetchTeacherMystudent]);

  return (
    <div className="Mystudent-card" style={styles.cardContainer}>
      <div style={styles.cardHeader}>
        <div style={styles.header}>
          <span>Student List</span>
        </div>
      </div>

      {loading ? (
        <p style={styles.noMystudent}>Loading...</p>
      ) : error ? (
        <p style={styles.noMystudent}>{error}</p>
      ) : Mystudent.length > 0 ? (
        <div className="ag-theme-alpine" style={styles.agGridContainer}>
          <AgGridReact
            columnDefs={columnDefs}
            rowData={Mystudent}
            pagination={true}
            domLayout="autoHeight"
            suppressRowClickSelection={true}
          />
        </div>
      ) : (
        <p style={styles.noMystudent}>No MyStudentList available.</p>
      )}
    </div>
  );
};

const styles = {
  cardContainer: {
    backgroundColor: '#fff',
    borderRadius: '8px',
    boxShadow: '0 6px 20px rgba(0, 0, 0, 0.1)',
    padding: '20px',
    width: '100vw',
    height: '100vh',
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'flex-start',
    alignItems: 'center',
    overflow: 'hidden',
    overflowY: 'auto',
  },
  cardHeader: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    borderBottom: '1px solid #ddd',
    paddingBottom: '15px',
    marginBottom: '20px',
    width: '100%',
    background: 'linear-gradient(#92ea89, #859d9d, #c2e2e2)',
    color: 'white',
    fontSize: '10px',  
    borderRadius: '8px 8px 0 0',
    paddingTop: '15px',
  },
  header: {
    fontSize: '1.5rem',
    fontWeight: '600',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    textAlign: 'center',
  },
  noMystudent: {
    textAlign: 'center',
    fontSize: '1.5rem',
    color: '#7f8c8d',
    fontStyle: 'italic',
    marginTop: '50px',
  },
  agGridContainer: {
    width: '100%',
    height: 'auto',
    overflowY: 'auto',
    overflowX: 'auto',
  },
};

export default StaffAssignmentList;
