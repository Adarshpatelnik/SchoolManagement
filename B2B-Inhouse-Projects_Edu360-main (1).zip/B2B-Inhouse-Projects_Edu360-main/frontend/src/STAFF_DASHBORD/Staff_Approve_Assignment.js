// import React, { useState, useEffect } from 'react';
// import { AgGridReact } from 'ag-grid-react';
// import 'ag-grid-community/styles/ag-grid.css';
// import 'ag-grid-community/styles/ag-theme-alpine.css';
// import axios from 'axios';
// import Staffnavbar from './Staff_navbar.js';

// const StaffApproveAssignment = () => {
//     const [rowData, setRowData] = useState([]);
//     const [selectedRows, setSelectedRows] = useState([]);

//     // Fetch data from API when the component mounts
//     useEffect(() => {
//         axios.get('http://13.127.57.224:2081/api/get-assignment-data')
//             .then(response => {
//                 setRowData(response.data);
//             })
//             .catch(error => {
//                 console.error("Error fetching assignment data", error);
//             });
//     }, []);

//     // Define the columns for AG Grid
//     const columnDefs = [
//         {
//             headerName: "Select", 
//             field: "select", 
//             checkboxSelection: true,
//             headerCheckboxSelection: true, // Select all checkbox
//             width: 80
//         },
//         { headerName: "Assignment ID", field: "ASSIGNMENT_ID" },
//         { headerName: "Student ID", field: "STUDENT_ID" },
//         { headerName: "Student Name", field: "STUDENT_NAME" },
//         { headerName: "Class ID", field: "CLASS_ID" },
//         { headerName: "Assignment Type", field: "ASSIGNMENT_TYPE" },
//         { headerName: "Subject Name", field: "SUBJECT_NAME" },
//         { headerName: "Assignment Description", field: "ASSIGNMENT_DESC", width: 200 },
//         { headerName: "Submission Start Date", field: "SUBMISSION_START_DATE" },
//         { headerName: "Submission End Date", field: "SUBMISSION_END_DATE" },
//         { headerName: "Submission Date", field: "SUBMISSION_DATE" },
//         { headerName: "Student Submitted Date", field: "STUDENT_SUBMITTED_DATE" }
//     ];

//     // Handle row selection
//     const onSelectionChanged = (event) => {
//         const selectedNodes = event.api.getSelectedNodes();
//         const selectedData = selectedNodes.map(node => node.data);
//         setSelectedRows(selectedData);
//     };

//     // Handle Submit button
//     const handleSubmit = () => {
//         selectedRows.forEach(async (row) => {
//             if (row.STUDENT_SUBMITTED_DATE) {
//                 await axios.post('http://13.127.57.224:2081/api/teacher-approval', {
//                     assignmentId: row.ASSIGNMENT_ID,
//                     studentId: row.STUDENT_ID,
//                     submittedDate: row.STUDENT_SUBMITTED_DATE,
//                     status: 'APPROVED'
//                 });
                
//             }
//         });
//         alert('Approved records updated successfully!');
//     };

//     // Handle Cancel button
//     const handleCancel = () => {
//         selectedRows.forEach(async (row) => {
//             await axios.post('http://13.127.57.224:2081/api/teacher-approval', {
//                 assignmentId: row.ASSIGNMENT_ID,
//                 studentId: row.STUDENT_ID,
//                 submittedDate: row.STUDENT_SUBMITTED_DATE,
//                 status: 'CANCEL'
//             });
//         });
//         alert('Cancelled records updated successfully!');
//     };

//     return (
//         <> 
//       <Staffnavbar />
//         <div>
//             <h3>Teacher Approval Page</h3>

//             {/* AG Grid Table */}
//             <div className="ag-theme-alpine" style={{ height: 400, width: '100%' }}>
//                 <AgGridReact
//                     rowData={rowData}
//                     columnDefs={columnDefs}
//                     rowSelection="multiple"
//                     onSelectionChanged={onSelectionChanged}
//                 />
//             </div>

//             {/* Buttons for Submit and Cancel */}
//             <div style={{ marginTop: '20px' }}>
//                 <button onClick={handleSubmit} style={buttonStyle}>Submit</button>
//                 <button onClick={handleCancel} style={buttonStyle}>Cancel</button>
//             </div>
//         </div>
//         </>
//     );
// };

// // Styles for the buttons
// const buttonStyle = {
//     padding: '10px 20px',
//     marginRight: '10px',
//     backgroundColor: '#007bff',
//     color: '#fff',
//     border: 'none',
//     borderRadius: '5px',
//     cursor: 'pointer'
// };

// export default StaffApproveAssignment;















// import React, { useEffect, useState } from 'react';
// import { AgGridReact } from 'ag-grid-react';
// import 'ag-grid-community/styles/ag-grid.css';
// import 'ag-grid-community/styles/ag-theme-alpine.css';
// import axios from 'axios';
// import Staffnavbar from './Staff_navbar.js';
// function StaffApproveAssignment() {
//   const [rowData, setRowData] = useState([]); // Initialize with an empty array for row data

//   const columnDefs = [
//     {
//       headerCheckboxSelection: true, // Enables select all checkbox in header
//       checkboxSelection: true, // Enables checkbox for each row
//       headerName: "Select",
//       width: 50,
//     },
//     { field: "ASSIGNMENT_ID", headerName: "Assignment ID", filter: true },
//     { field: "STUDENT_ID", headerName: "Student ID", filter: true },
//     { field: "STUDENT_NAME", headerName: "Student Name", filter: true },
//     { field: "CLASS_ID", headerName: "Class ID", filter: true },
//     { field: "SUBJECT_NAME", headerName: "Subject Name", filter: true },
//     { field: "CLASS_TEACHER", headerName: "Class Teacher", filter: true },
//     { field: "ASSIGNMENT_TYPE", headerName: "Assignment Type", filter: true },
//     { field: "ASSIGNMENT_DESC", headerName: "Assignment Description", filter: true },
//     {
//       field: "SUBMISSION_START_DATE",
//       headerName: "Submission Start Date",
//       filter: true,
//     },
//     {
//       field: "SUBMISSION_END_DATE",
//       headerName: "Submission End Date",
//       filter: true,
//     },
//     {
//       field: "TeacherApprovalStatus",
//       headerName: "Teacher Approval Status",
//       filter: true,
//     },
//     {
//       field: "STUDENT_SUBMITTED_DATE",
//       headerName: "Student Submitted Date",
//       filter: true,
//     },
//     {
//       field: "SUBMISSION_DATE",
//       headerName: "Submission Date",
//       filter: true,
//     },
//     { field: "IS_SUBMITTED", headerName: "Is Submitted", filter: true },
//     {
//       field: "StudentStatus",
//       headerName: "Student Status",
//       filter: true,
//     },
//   ];

//   useEffect(() => {
//     const fetchAssignments = async () => {
//       try {
//         const response = await axios.get('http://13.127.57.224:2081/api/get-assignmentrecord'); // API call to fetch data
//         setRowData(response.data); // Set the fetched data to rowData state
//       } catch (error) {
//         console.error('Error fetching assignments:', error);
//       }
//     };

//     fetchAssignments();
//   }, []);

//   return (
//     <> 
//        <Staffnavbar />
//        <div className="container-fluid" style={{marginTop: '7vh', }}>

//     <div style={{ padding: '20px' }}>
//       <div className="ag-theme-alpine" style={{ height: '600px', width: '100%' }}>
//         <AgGridReact
//           rowData={rowData} // Assign fetched data to rowData
//           columnDefs={columnDefs} // Assign column definitions
//           rowSelection="multiple" // Enable multiple row selection
//           domLayout='autoHeight' // Adjust table height automatically
//         />
//       </div>
//     </div>
//     </div>
//     </>
//   );
// }

// export default StaffApproveAssignment;






import React, { useEffect, useState } from 'react';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import axios from 'axios';
 import Staffnavbar from './Staff_navbar.js';

function StaffApproveAssignment() {
  const [rowData, setRowData] = useState([]); // Initialize with an empty array for row data

  const columnDefs = [
    {
      headerCheckboxSelection: true, // Enables select all checkbox in header
      checkboxSelection: true, // Enables checkbox for each row
      headerName: "Select",
      width: 50,
    },
    { field: "ASSIGNMENT_ID", headerName: "Assignment ID", filter: true },
    { field: "STUDENT_ID", headerName: "Student ID", filter: true },
    { field: "STUDENT_NAME", headerName: "Student Name", filter: true },
    { field: "CLASS_ID", headerName: "Class ID", filter: true },
    { field: "SUBJECT_NAME", headerName: "Subject Name", filter: true },
    { field: "CLASS_TEACHER", headerName: "Class Teacher", filter: true },
    { field: "ASSIGNMENT_TYPE", headerName: "Assignment Type", filter: true },
    { field: "ASSIGNMENT_DESC", headerName: "Assignment Description", filter: true },
    {
      field: "SUBMISSION_START_DATE",
      headerName: "Submission Start Date",
      filter: true,
      valueFormatter: ({ value }) => formatDate(value), // Format date
    },
    {
      field: "SUBMISSION_END_DATE",
      headerName: "Submission End Date",
      filter: true,
      valueFormatter: ({ value }) => formatDate(value), // Format date
    },
    {
      field: "TeacherApprovalStatus",
      headerName: "Teacher Approval Status",
      filter: true,
    },
    {
      field: "STUDENT_SUBMITTED_DATE",
      headerName: "Student Submitted Date",
      filter: true,
      valueFormatter: ({ value }) => formatDate(value), // Format date
    },
    {
      field: "SUBMISSION_DATE",
      headerName: "Submission Date",
      filter: true,
      valueFormatter: ({ value }) => formatDate(value), // Format date
    },
    { field: "IS_SUBMITTED", headerName: "Is Submitted", filter: true },
    {
      field: "STUDENT_STATUS",
      headerName: "Student Status",
      filter: true,
    },
  ];

  // Format the date to DD-MM-YYYY format
  const formatDate = (date) => {
    if (!date) return ''; // If date is empty, return an empty string
    const d = new Date(date);
    const day = String(d.getDate()).padStart(2, '0');
    const month = String(d.getMonth() + 1).padStart(2, '0'); // Months are 0-indexed
    const year = d.getFullYear();
    return `${day}-${month}-${year}`;
  };

  useEffect(() => {
    const fetchAssignments = async () => {
      try {
        const response = await axios.get('http://13.127.57.224:2081/api/get-assignmentrecord'); // API call to fetch data
        setRowData(response.data); // Set the fetched data to rowData state
      } catch (error) {
        console.error('Error fetching assignments:', error);
      }
    };

    fetchAssignments();
  }, []);

  return (
    <> 
       <Staffnavbar />
    <div style={{ padding: '20px' ,marginTop: '7vh' }}>
      <div className="ag-theme-alpine" style={{ height: '600px', width: '100%' }}>
        <AgGridReact
          rowData={rowData} // Assign fetched data to rowData
          columnDefs={columnDefs} // Assign column definitions
          rowSelection="multiple" // Enable multiple row selection
          domLayout="autoHeight" // Adjust table height automatically
        />
      </div>
    </div>
    </>
  );
}

export default StaffApproveAssignment;