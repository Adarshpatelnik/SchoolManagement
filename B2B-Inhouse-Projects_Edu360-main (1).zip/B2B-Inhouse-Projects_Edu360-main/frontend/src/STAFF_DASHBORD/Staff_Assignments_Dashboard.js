
import React, { useState, useEffect } from 'react';
import styled from 'styled-components';
// import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
// import { faClipboardList as faClipboardListSolid } from '@fortawesome/free-solid-svg-icons';
import { useNavigate } from 'react-router-dom';

const ChartContainer = styled.div`
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
  margin-bottom: 30%;
  // margin-right: 50px;
  // margin-left: 50px;
  width: 100%;
`;

const ChartCard = styled.div`
  flex: 1 1 25%;
  background-color: #ffffff;
  border-radius: 20px;
  // box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
  overflow: hidden;
  transition: transform 0.3s;
 
`;

// const ChartHeader = styled.div`
//   background: linear-gradient(#92ea89, #859d9d, #c2e2e2);
//   color: white;
//   padding: 15px;
//   border-radius: 20px 20px 0 0;
//   display: flex;
//   align-items: center;
//   font-weight: bold;
//   svg {
//     margin-right: 10px;
//     font-size: 20px;
//   }
// `;

const ChartContent = styled.div`
  padding: px;
  min-height: 150px;
  height: 150px;
  text-align: center;
`;

const LoadingSpinner = styled.div`
  text-align: center;
  font-size: 20px;
  color: #007bff;
`;

const FilterContainer = styled.div`
  padding: 10px;
  margin: 20px 0;
  display: flex;
  justify-content: center;
`;

const CountButton = styled.button`
  background-color: ${props => props.color || '#007bff'};
  color: white;
  border: none;
  padding: 10px 15px;
  border-radius: 5px;
  cursor: pointer;
  margin: 5px;
  &:hover {
    background-color: ${props => props.hoverColor || '#0056b3'};
  }
`;

const StaffAssignmentsDashboard = () => {
  const [assignments, setAssignments] = useState([]);
  const [filteredAssignments, setFilteredAssignments] = useState([]);
  const [classes, setClasses] = useState([]);
  const [selectedClass, setSelectedClass] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const navigate = useNavigate(); // Use the navigate hook from react-router-dom

  useEffect(() => {
    const fetchAssignmentData = async () => {
      try {
        const response = await fetch('http://13.127.57.224:2081/api/StaffAssignmentDashboard');
        if (!response.ok) throw new Error(`Error: ${response.statusText}`);
        const data = await response.json();
        setAssignments(data);
        setFilteredAssignments(data); // Set initial data as filtered
        setClasses(data);
        setLoading(false);
      } catch (error) {
        setError(error.message);
        setLoading(false);
      }
    };

    fetchAssignmentData();
  }, []);

  // Filter assignments based on the selected category
  const filterAssignments = (type) => {
    let filtered = [];
    switch (type) {
      case 'dueToday':
        filtered = assignments.filter(assignment => assignment.OnTimeAssignments > 0);
        break;
      case 'dueDatePassed':
        filtered = assignments.filter(assignment => assignment.LateAssignments > 0);
        break;
      case 'dueLatter':
        filtered = assignments.filter(assignment => assignment.UpcomingAssignments > 0);
        break;
      default:
        filtered = assignments;
    }
    setFilteredAssignments(filtered);
  };

  const handleCountClick = (countType) => {
    // Filter the assignments based on the selected count type
    filterAssignments(countType);

    // Navigate to the detailed list of assignments for the selected count type
    navigate(`/StaffAssignmentList/${countType}`);
  };

  return (
    <div>
      <ChartContainer>
        <ChartCard>
        
          <FilterContainer>
            <select onChange={(e) => setSelectedClass(e.target.value)} value={selectedClass}>
              <option value="">All Classes</option>
              {Array.from(new Set(classes.map(classItem => classItem.CLASS_ID))).map((classID, index) => (
                <option key={index} value={classID}>
                  {classID}
                </option>
              ))}
            </select>
          </FilterContainer>

          <ChartContent>
            {loading ? (
              <LoadingSpinner>Loading...</LoadingSpinner>
            ) : error ? (
              <p>Error: {error}</p>
            ) : (
              <>
                <CountButton
                  color="#748049"
                  hoverColor="#218838"
                  onClick={() => handleCountClick('dueToday')}
                >
                  DUE TODAY: {filteredAssignments.reduce((acc, assignment) => acc + assignment.OnTimeAssignments, 0)}
                </CountButton>
                <CountButton
                  color="#149d6d"
                  hoverColor="#c82333"
                  onClick={() => handleCountClick('dueDatePassed')}
                >
                  DUE DATE PASSED: {filteredAssignments.reduce((acc, assignment) => acc + assignment.LateAssignments, 0)}
                </CountButton>
                <CountButton
                  color="#173666"
                  hoverColor="#e0a800"
                  onClick={() => handleCountClick('dueLatter')}
                >
                  DUE LATTER: {filteredAssignments.reduce((acc, assignment) => acc + assignment.UpcomingAssignments, 0)}
                </CountButton>
              </>
            )}
          </ChartContent>
        </ChartCard>
      </ChartContainer>
    </div>
  );
};

export default StaffAssignmentsDashboard;
