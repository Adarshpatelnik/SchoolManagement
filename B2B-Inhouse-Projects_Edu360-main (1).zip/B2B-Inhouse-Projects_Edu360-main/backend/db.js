

// // const mysql = require('mysql2/promise');

// // // Function to create MySQL pool using environment variables
// // const createPool = () => {
// //   const pool = mysql.createPool({
// //     host: process.env.DB_HOST,
// //     user: process.env.DB_USER,
// //     database: process.env.DB_DATABASE,
// //     password: process.env.DB_PASSWORD,
// //     waitForConnections: true,
// //     connectionLimit: 10,
// //     queueLimit: 0
// //   });

// //   return pool;
// // };


// // // Function to connect to a specific school's database using provided credentials
// // const connectToSchoolDatabase = async (SCHOOL_DB_CREDENTIAL) => {
// //   try {
// //     const schoolPool = mysql.createPool({
// //       host: SCHOOL_DB_CREDENTIAL.DATABASE_HOST,
// //       user: SCHOOL_DB_CREDENTIAL.DATABASE_USERNAME,
// //       database: SCHOOL_DB_CREDENTIAL.DATABASE_NAME,
// //       password: SCHOOL_DB_CREDENTIAL.DATABASE_PASSWORD,
// //       waitForConnections: true,
// //       connectionLimit: 10,
// //       queueLimit: 0
// //     });

// //     // Test the connection by executing a simple query
// //     const [rows] = await schoolPool.query('SELECT 1');
// //     console.log('Connected to school database successfully');
// //     return schoolPool;
// //   } catch (error) {
// //     console.error('Error connecting to school database:', error.message, error.stack);
// //     throw error; // Rethrow the error to handle it in the caller function
// //   }
// // };

// // module.exports = { createPool, connectToSchoolDatabase };



// // // const mysql = require('mysql2/promise');

// // // // Function to create MySQL pool using environment variables
// // // const createPool = () => {
// // //   const pool = mysql.createPool({
// // //     host: process.env.DB_HOST,
// // //     user: process.env.DB_USER,
// // //     database: process.env.DB_DATABASE,
// // //     password: process.env.DB_PASSWORD,
// // //     waitForConnections: true,
// // //     connectionLimit: 10,
// // //     queueLimit: 0
// // //   });

// // //   return pool;
// // // };

// // // // Function to connect to a specific school's database using provided credentials
// // // const connectToSchoolDatabase = async (schoolDbCredentials) => {
// // //   try {
// // //     const schoolPool = mysql.createPool({
// // //       host: schoolDbCredentials.DATABASE_HOST,
// // //       user: schoolDbCredentials.DATABASE_USERNAME,
// // //       database: schoolDbCredentials.DATABASE_NAME,
// // //       password: schoolDbCredentials.DATABASE_PASSWORD,
// // //       waitForConnections: true,
// // //       connectionLimit: 10,
// // //       queueLimit: 0
// // //     });

// // //     // Test the connection by executing a simple query
// // //     const [rows] = await schoolPool.query('SELECT 1');
// // //     console.log('Connected to school database successfully');
// // //     return schoolPool;
// // //   } catch (error) {
// // //     console.error('Error connecting to school database:', error.message, error.stack);
// // //     throw error; // Rethrow the error to handle it in the caller function
// // //   }
// // // };

// // // // Create a new database connection pool
// // // const createNewDbPool = ({ host, user, password, database }) => {
// // //   const pool = mysql.createPool({
// // //     host,
// // //     user,
// // //     password,
// // //     database,
// // //     waitForConnections: true,
// // //     connectionLimit: 10,
// // //     queueLimit: 0
// // //   });

// // //   return pool.promise();
// // // };

// // // module.exports = { createPool, connectToSchoolDatabase, createNewDbPool };








// const mysql = require('mysql2/promise');

// // Function to create MySQL pool using environment variables
// const createPool = () => {
//   const pool = mysql.createPool({
//     host: process.env.DB_HOST,
//     user: process.env.DB_USER,
//     database: process.env.DB_DATABASE,
//     password: process.env.DB_PASSWORD,
//     waitForConnections: true,
//     connectionLimit: 10,
//     queueLimit: 0
//   });

//   return pool;
// };

// // Function to connect to a specific school's database using provided credentials
// const connectToSchoolDatabase = async (schoolDbCredentials) => {
//   try {
//     const schoolPool = mysql.createPool({
//       host: schoolDbCredentials.DATABASE_HOST,
//       user: schoolDbCredentials.DATABASE_USERNAME,
//       database: schoolDbCredentials.DATABASE_NAME,
//       password: schoolDbCredentials.DATABASE_PASSWORD,
//       waitForConnections: true,
//       connectionLimit: 10,
//       queueLimit: 0
//     });

//     // Test the connection by executing a simple query
//     const [rows] = await schoolPool.query('SELECT 1');
//     console.log('Connected to school database successfully');
//     return schoolPool;
//   } catch (error) {
//     console.error('Error connecting to school database:', error.message, error.stack);
//     throw error; // Rethrow the error to handle it in the caller function
//   }
// };

// // Function to create a new connection pool based on provided database details
// const createNewDbPool = (dbDetails) => {
//   const newDbPool = mysql.createPool({
//     host: dbDetails.DATABASE_HOST,
//     user: dbDetails.DATABASE_USERNAME,
//     user: dbDetails.DATABASE_NAME,
//     password: dbDetails.DATABASE_PASSWORD,
//     waitForConnections: true,
//     connectionLimit: 10,
//     queueLimit: 0
//   });

//   return newDbPool;
// };



// module.exports = { createPool, connectToSchoolDatabase, createNewDbPool };










// db.js

const mysql = require('mysql2/promise');
require('dotenv').config();

// Function to create MySQL pool using environment variables for the main database
const createPool = () => {
  const pool = mysql.createPool({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    database: process.env.DB_DATABASE,
    password: process.env.DB_PASSWORD,
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
  });

  return pool;
};

// Function to connect to a specific school's database using provided credentials
const connectToSchoolDatabase = async (schoolDbCredentials) => {
  try {
    const schoolPool = mysql.createPool({
      host: schoolDbCredentials.DATABASE_HOST,
      user: schoolDbCredentials.DATABASE_USERNAME,
      database: schoolDbCredentials.DATABASE_NAME,
      password: schoolDbCredentials.DATABASE_PASSWORD,
      waitForConnections: true,
      connectionLimit: 10,
      queueLimit: 0
    });

    // Test the connection by executing a simple query
    const [rows] = await schoolPool.query('SELECT 1');
    console.log('Connected to school database successfully');
    return schoolPool;
  } catch (error) {
    console.error('Error connecting to school database:', error.message, error.stack);
    throw error; // Rethrow the error to handle it in the caller function
  }
};

// Function to create a new connection pool based on provided database details
const createNewDbPool = (dbDetails) => {
  const newDbPool = mysql.createPool({
    host: dbDetails.DATABASE_HOST,
    user: dbDetails.DATABASE_USERNAME,
    database: dbDetails.DATABASE_NAME,
    password: dbDetails.DATABASE_PASSWORD,
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
  });

  return newDbPool;
};

module.exports = { createPool, connectToSchoolDatabase, createNewDbPool };
