
// const sendgrid = require('@sendgrid/mail');
// const bodyParser = require('body-parser');
// const twilio = require('twilio');
// const { parsePhoneNumberFromString } = require('libphonenumber-js');
// const multer = require('multer');
// const path = require('path');
// const fs = require('fs');
// const express = require('express');
// const cors = require('cors');
// const bcrypt = require('bcrypt');
// const crypto = require('crypto');
// const winston = require('winston'); // Import winston for logging
// require('dotenv').config();
// const { createPool, connectToSchoolDatabase, createNewDbPool } = require('./db');
// const CreateTables = require('./CreateTables');
// const app = express();
// app.use(cors());
// app.use(express.json());

// // Increase the payload size limit
// app.use(bodyParser.json({ limit: '50mb' }));
// app.use(bodyParser.urlencoded({ limit: '50mb', extended: true }));
const sendgrid = require('@sendgrid/mail');
const bodyParser = require('body-parser');
const twilio = require('twilio');
const { parsePhoneNumberFromString } = require('libphonenumber-js');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const express = require('express');
const cors = require('cors');
const bcrypt = require('bcrypt');
const crypto = require('crypto');
const winston = require('winston'); // Import winston for logging
require('dotenv').config();
const { createPool, connectToSchoolDatabase, createNewDbPool } = require('./db');
const CreateTables = require('./CreateTables');

const app = express();

// Enable CORS
app.use(cors());

// Set up body parser with increased payload size limits
app.use(bodyParser.json({ limit: '500mb' }));
app.use(bodyParser.urlencoded({ limit: '500mb', extended: true }));

// Middleware to handle PayloadTooLargeError
app.use((err, req, res, next) => {
    if (err.type === 'entity.too.large') {
        res.status(413).json({ error: 'Payload too large. Please reduce the size of the data and try again.' });
    } else {
        next(err);
    }
});

// Set up SendGrid API key from environment variable
sendgrid.setApiKey(process.env.SENDGRID_API_KEY);

// Error handling API route
app.post('/api/send-error', async (req, res) => {
  const { error, errorInfo, timestamp } = req.body;

  const message = {
    to: 'eng.adarshpatel@gmail.com', // Developer's email address
    from: process.env.FROM_EMAIL,       // Using FROM_EMAIL from .env
    subject: 'React App Error Alert',
    text: `An error occurred in the React app at ${timestamp}:\n\nError: ${error}\n\nAdditional Info: ${JSON.stringify(errorInfo)}`,
  };

  try {
    await sendgrid.send(message);
    res.status(200).send('Error email sent successfully');
  } catch (err) {
    console.error('Error sending email:', err);
    res.status(500).send('Error sending email');
  }
});
const logDirectory = path.join(__dirname, 'logs');
fs.existsSync(logDirectory) || fs.mkdirSync(logDirectory); // Ensure logs directory exists

const logger = winston.createLogger({
    level: 'info',
    format: winston.format.combine(
        winston.format.timestamp(),
        winston.format.json()
    ),
    transports: [
        new winston.transports.File({ filename: path.join(logDirectory, 'combined.log') }),
        new winston.transports.File({
            filename: path.join(logDirectory, 'error.log'),
            level: 'error', // Only log error messages to this file
        }),
        new winston.transports.Console() // Optional: log to console as well
    ],
});


app.post('/log', express.json(), (req, res) => {
  const { message } = req.body;
  logger.info(`Frontend log: ${message}`);
  res.status(200).send('Log received');
});

// Middleware
//app.use(bodyParser.json());

// Twilio Account SID and Auth Token
const accountSid = process.env.REACT_APP_TWILIO_ACCOUNT_SID;
const authToken = process.env.REACT_APP_TWILIO_AUTH_TOKEN;
const twilioPhoneNumber = process.env.REACT_APP_TWILIO_PHONE_NUMBER;

// Twilio client setup
const client = new twilio(accountSid, authToken);

// Multer setup for file uploads
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads/');
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + path.extname(file.originalname));
  }
});
const upload = multer({ storage: storage, limits: { fileSize: 5 * 1024 * 1024 } }); // 5 MB file size limit

// Ensure uploads directory exists
if (!fs.existsSync('uploads')) {
  fs.mkdirSync('uploads');
}


const port = process.env.PORT || 2081;

// MySQL pool setup using environment variables for the main database
const pool = createPool();
let studentId;
let userstaffId;
// Helper function to check if username exists
const usernameExists = async (username) => {
  const userCheckSql = "SELECT 1 FROM ADMINISTRATOR_USER WHERE ADMINISTRATOR_USERNAME = ?";
  const [userCheckResult] = await pool.query(userCheckSql, [username]);
  return userCheckResult.length > 0;
};

// Helper function to check if email exists
const emailExists = async (email) => {
  const emailCheckSql = "SELECT 1 FROM ADMINISTRATOR_USER WHERE EMAIL = ?";
  const [emailCheckResult] = await pool.query(emailCheckSql, [email]);
  return emailCheckResult.length > 0;
};

// Helper function to check if database exists
const databaseExists = async (dbName) => {
  const checkDbSql = "SHOW DATABASES LIKE ?";
  const [dbResult] = await pool.query(checkDbSql, [dbName]);
  return dbResult.length > 0;
};





// Function to send messages
const sendMessage = (to, body, isWhatsApp, mediaUrl) => {
  const toStr = String(to).trim();
  console.log(`Original phone number: ${toStr}`);
  
  const phoneNumberStr = toStr.startsWith('+') ? toStr : `+91${toStr}`;
  console.log(`Processed phone number: ${phoneNumberStr}`);

  try {
    const phoneNumber = parsePhoneNumberFromString(phoneNumberStr, 'IN');
    if (!phoneNumber) {
      throw new Error('Phone number parsing failed.');
    }

    if (phoneNumber.isValid()) {
      const formattedNumber = phoneNumber.format('E.164');
      console.log(`Formatted phone number: ${formattedNumber}`);
      
      const messageType = isWhatsApp ? 'whatsapp' : 'sms';
      const fromNumber = isWhatsApp ? `whatsapp:${twilioPhoneNumber}` : twilioPhoneNumber;

      const messageData = {
        body: body,
        to: `${messageType}:${formattedNumber}`,
        from: fromNumber
      };

      if (mediaUrl) {
        messageData.mediaUrl = mediaUrl;
      }

      client.messages.create(messageData)
        .then((message) => console.log(`Message sent successfully to ${formattedNumber} with SID: ${message.sid}`))
        .catch((error) => console.error(`Failed to send message to ${formattedNumber}:`, error));
    } else {
      console.error(`Invalid phone number format: ${phoneNumberStr}`);
    }
  } catch (error) {
    console.error(`Error processing phone number: ${error.message}`);
  }

};

 



// Fetch options for filters
app.get('/api/studentstwilio', async (req, res) => {
  console.log("GET /studentstwilio");
  try {
    // Check database connection
    if (!schoolDbConnection) {
      console.log("GET /studentstwilio: School database connection not established.");
      return res.status(500).json({ error: "School database connection not established" });
    }
    const query = "SELECT name, phone_number FROM students;";
   
  console.log('Executing query:', query); // Log the query being executed
  const [studentstwilioResult] = await schoolDbConnection.query(query);

  console.log("GET /studentstwilio: studentstwilio fetched successfully.");
  return res.status(200).json(studentstwilioResult);

  } catch (err) {
    console.error('Error fetching options:', err.message);
    res.status(500).json({ error: 'Database query error' });
  }
});


// Fetch options for filters
app.get('/api/classestwilio', async (req, res) => {
  console.log("GET /classestwilio");
  try {
    // Check database connection
    if (!schoolDbConnection) {
      console.log("GET /classestwilio: School database connection not established.");
      return res.status(500).json({ error: "School database connection not established" });
    }
    const query = "SELECT DISTINCT CLASS FROM CLASS_DETAIL;";
   
  console.log('Executing query:', query); // Log the query being executed
  const [classestwilioResult] = await schoolDbConnection.query(query);

  console.log("GET /classestwilio: classestwilio fetched successfully.");
  return res.status(200).json(classestwilioResult);

  } catch (err) {
    console.error('Error fetching options:', err.message);
    res.status(500).json({ error: 'Database query error' });
  }
});



// Fetch options for filters
app.get('/api/stafftwilio', async (req, res) => {
  console.log("GET /stafftwilio");
  try {
    // Check database connection
    if (!schoolDbConnection) {
      console.log("GET /stafftwilio: School database connection not established.");
      return res.status(500).json({ error: "School database connection not established" });
    }
    const query = "SELECT STAFF_NAME FROM STAFF;";
   
  console.log('Executing query:', query); // Log the query being executed
  const [stafftwilioResult] = await schoolDbConnection.query(query);

  console.log("GET /stafftwilio: stafftwilio fetched successfully.");
  return res.status(200).json(stafftwilioResult);

  } catch (err) {
    console.error('Error fetching options:', err.message);
    res.status(500).json({ error: 'Database query error' });
  }
});



app.post('/api/broadcast', upload.single('file'), async (req, res) => {
  const { message, recipientsOption, specificClass, specificTeacher, specificStudent } = req.body;
  const file = req.file;

  let query = 'SELECT phone_number FROM students sp WHERE 1=1';
  const queryParams = [];

  if (recipientsOption === 'Specific Class' && specificClass) {
    query += ' AND sp.STUDENT_ID IN (SELECT STUDENT_ID FROM CLASS_DETAIL WHERE CLASS = ?)';
    queryParams.push(specificClass);
  } else if (recipientsOption === 'Specific Teacher' && specificTeacher) {
    query += ' AND sp.STUDENT_ID IN (SELECT STUDENT_ID FROM TEACHER_ASSIGNMENT WHERE TEACHER_NAME = ?)';
    queryParams.push(specificTeacher);
  } else if (recipientsOption === 'Specific Student' && specificStudent) {
    query += ' AND sp.name = ?';
    queryParams.push(specificStudent);
  }

  try {
    // Check if schoolDbConnection is established
    if (!schoolDbConnection) {
      console.error("School database connection not established.");
      return res.status(500).json({ error: "School database connection not established" });
    }

    // Execute the query to fetch contact numbers
    const [results] = await schoolDbConnection.query(query, queryParams);

    // Prepare media URL if file is uploaded
    const mediaUrl = file ? `http://13.127.57.224:2081/uploads/${file.filename}` : null;

    // Send messages to the fetched contacts
    results.forEach(row => {
      const contactNumber = row.phone_number;
      sendMessage(contactNumber, message, false, mediaUrl); // Sending SMS
      sendMessage(contactNumber, message, true, mediaUrl);  // Sending WhatsApp
    });

    res.status(200).json({ message: 'Broadcast sent successfully' });

  } catch (err) {
    console.error('Error fetching contacts:', err.message);
    res.status(500).json({ error: 'Internal server error', details: err.message });
  }
});

// Serve uploaded files statically
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

 


app.post('/signup', async (req, res) => {
  const { FullName, SchoolName, SchoolBranch,SchoolCode, City, State, PostalCode, Email, MobileNumber, UserName, Password, Role } = req.body;

  if (!FullName || !SchoolName || !SchoolBranch || !SchoolCode || !City || !State || !PostalCode || !Email || !MobileNumber || !UserName || !Password || !Role) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  try {
    // Check if username and email exist
    if (await usernameExists(UserName)) {
      return res.status(409).json({ error: 'This Username already exists. Try something else.' });
    }

    if (await emailExists(Email)) {
      return res.status(409).json({ error: 'This Email is already registered.' });
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(Password, 10);

    // Insert user into ADMINISTRATOR_USER table
    const sql = "INSERT INTO ADMINISTRATOR_USER (ADMINISTRATOR_USERNAME, FULL_NAME, SCHOOL_NAME, SCHOOL_BRANCH, SCHOOL_CODE , CITY, STATE, POSTAL_CODE, EMAIL, MOBILE_NO, PASSWORD, ROLE) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    const values = [UserName, FullName, SchoolName, SchoolBranch, SchoolCode, City, State, PostalCode, Email, MobileNumber, hashedPassword, Role];
    await pool.query(sql, values);

    console.log('ADMINISTRATOR USER created successfully');

    const trimmedSchoolName = SchoolName.replace(/[^a-zA-Z0-9]/g, '').toUpperCase();
    const trimmedSchoolBranch = SchoolBranch.replace(/[^a-zA-Z0-9]/g, '').toUpperCase();
    const trimmedCity = City.replace(/[^a-zA-Z0-9]/g, '').toUpperCase();
    const trimmedSchoolCode = SchoolCode.replace(/[^a-zA-Z0-9]/g, '').toUpperCase();
    
    const DATABASE_NAME = `${trimmedSchoolName}_${trimmedSchoolBranch}_${trimmedCity}_${trimmedSchoolCode}`;

    // Check if the database already exists
    if (await databaseExists(DATABASE_NAME)) {
      return res.status(409).json({ error: `Database ${DATABASE_NAME} already exists.` });
    }
    
    // Insert database credentials into SCHOOL_DB_CREDENTIAL table
    const sqlCredentials = 'INSERT INTO SCHOOL_DB_CREDENTIAL (ADMINISTRATOR_USERNAME, DATABASE_NAME, DATABASE_HOST, DATABASE_USERNAME, DATABASE_PASSWORD) VALUES (?, ?, ?, ?, ?)';
    const valuesCredential = [UserName, DATABASE_NAME, process.env.DB_HOST, process.env.DB_USER, process.env.DB_PASSWORD];
    await pool.query(sqlCredentials, valuesCredential);

    console.log('Database credentials inserted successfully');

    // Create the new database
    const createDbSql = `CREATE DATABASE IF NOT EXISTS ${DATABASE_NAME}`;
    await pool.query(createDbSql);

    console.log(`Database ${DATABASE_NAME} created successfully!`);

    // Retrieve all details from SCHOOL_DB_CREDENTIAL for the current user
    const fetchCredentialSql = "SELECT * FROM SCHOOL_DB_CREDENTIAL WHERE ADMINISTRATOR_USERNAME = ?";
    const [credentialRows] = await pool.query(fetchCredentialSql, [UserName]);

    if (credentialRows.length === 0) {
      throw new Error('Database credentials not found after insertion');
    }

    const dbDetails = credentialRows[0];
    const SCHOOL_INFO = dbDetails.ROW_ID ;
    
    // Create a new pool for the newly created database
    const newDbPool = createNewDbPool(dbDetails);

    // Create tables in the new database
    await CreateTables(newDbPool, DATABASE_NAME,SCHOOL_INFO, (errors) => {
      if (errors) {
        console.error('Error creating tables:', errors);
        throw new Error('Failed to create tables in the new database');
      }
      console.log('Tables created successfully');
      res.status(201).json({ message: "User registered and database/tables created successfully!" });
    });

  } catch (err) {
    console.error('Error registering user:', err.message);
    return res.status(500).json({ error: 'Internal server error' });
  }
});
 

// Login route
app.post('/login', async (req, res) => {
  const { UserName, Password, Role } = req.body;
 
  if (!UserName || !Password || !Role) {
    return res.status(400).json({ error: 'Missing UserName, Password, or Role' });
  }

  try {
    let sql, tableName;
    switch (Role) {
      case 'administrator':
        sql = "SELECT * FROM ADMINISTRATOR_USER WHERE ADMINISTRATOR_USERNAME = ?";
        tableName = 'ADMINISTRATOR_USER';
        break;
      case 'admin':
        sql = "SELECT * FROM ADMIN_USER WHERE ADMIN_USERNAME= ?";
        tableName = 'ADMIN_USER';
        break;
      case 'staff':
        sql = "SELECT * FROM STAFF_USER WHERE STAFF_USER_ID = ?";
        tableName = 'STAFF_USER';
        break;
      case 'student':
        sql = "SELECT * FROM STUDENT_USER WHERE STUDENT_USER_ID = ?";
        tableName = 'STUDENT_USER';
        break;
      default:
        return res.status(400).json({ error: 'Invalid Role' });
    }

    const [result] = await pool.query(sql, [UserName]);

    if (result.length === 0) {
      return res.status(401).json({ error: "UserName not registered" });
    }

    const user = result[0];
  
   studentId =  user.STUDENT_ID;
   userstaffId =  user.STAFF_ID;
   console.log('Error fetching staff assignment dashboard:', userstaffId);
    const isPasswordValid = await bcrypt.compare(Password, user.PASSWORD);
 
    if (!isPasswordValid) {
      return res.status(401).json({ error: "Invalid Password" });
    }
    
 
    console.log('User authenticated successfully');
 
    // Check if user's email exists in schoolcredentials
    const schoolSql = "SELECT * FROM SCHOOL_DB_CREDENTIAL WHERE ADMINISTRATOR_USERNAME = ?";
    const [schoolResult] = await pool.query(schoolSql, [user.ADMINISTRATOR_USERNAME]);

    if (schoolResult.length === 0) {
      return res.status(404).json({ error: "Student database not found" });
    }

    const SCHOOL_DB_CREDENTIAL = schoolResult[0];

    // Securely connect to the school database and store the connection globally
    schoolDbConnection = await connectToSchoolDatabase(SCHOOL_DB_CREDENTIAL);

    console.log('Connected to the school database successfully');

    // Return the user, along with the school database details, excluding sensitive information
    return res.status(200).json({
      message: "Login successful",
      user: { UserName: user.ADMINISTRATOR_USERNAME, Name: user.NAME, Role },
      schoolDb: {
        host: SCHOOL_DB_CREDENTIAL.DATABASE_HOST,
        database: SCHOOL_DB_CREDENTIAL.DATABASE_NAME,
      },
    });

  } catch (err) {
    console.error('Error during login process:', err);
    return res.status(500).json({ error: 'Internal server error' });
  }
});



// Login route
app.post('/logindev', async (req, res) => { 
  const { UserName, Password, Role } = req.body;

  // Check for missing fields
  if (!UserName || !Password || !Role) {
    logger.warn('Missing UserName, Password, or Role in login request', { reqBody: req.body });
    return res.status(400).json({ error: 'Missing UserName, Password, or Role' });
  }

  try {
    // Check for invalid role
    if (Role !== 'developer') {  // Example check, adjust the condition based on your requirement
      logger.warn('Invalid Role provided in login request', { Role });
      return res.status(400).json({ error: 'Invalid Role' });
    }

    // Query the user based on the username
    const sql = "SELECT * FROM DEVLOPER_USER WHERE DEVLOPER_ID = ?";
    const [result] = await pool.query(sql, [UserName]);

    if (result.length === 0) {
      logger.warn('UserName not registered', { UserName });
      return res.status(401).json({ error: "UserName not registered" });
    }

    const user = result[0];
    
    // Check password validity
    const isPasswordValid = await bcrypt.compare(Password, user.PASSWORD);
    if (!isPasswordValid) {
      logger.warn('Invalid Password attempt', { UserName });
      return res.status(401).json({ error: "Invalid Password" });
    }

    logger.info('User authenticated successfully', { UserName });
    return res.status(200).json({ message: 'Authentication successful' });

  } catch (err) {
    logger.error('Error during login process', { message: err.message });
    return res.status(500).json({ error: 'Internal server error' });
  }
});





// Route to fetch StudentAttendance
app.get('/api/schooldata', async (req, res) => {
  try {
    console.log("GET /schooldata: Fetching schooldata...");
    if (!pool) {
      console.log("GET /schooldata: School database connection not established.");
      return res.status(500).json({ error: "School database connection not established" });
    }

    // Fetch all students from the students table
    const schooldataSql = `  
   SELECT ROW_ID, ADMINISTRATOR_USERNAME, DATABASE_NAME, DATABASE_HOST, DATABASE_USERNAME, DATABASE_PASSWORD
FROM B2B_S360_ADMIN.SCHOOL_DB_CREDENTIAL`;

    console.log("GET /schooldata: Executing SQL query:", schooldataSql);

    

    const [schooldataResult] = await pool.query(schooldataSql);


       // Log all values fetched from the database
       console.log("Fetched schooldata:");
       schooldataResult.forEach(student => {
           console.log(student);
       });
    console.log("GET /schooldata: schooldata fetched successfully.");
    return res.status(200).json(schooldataResult);

  } catch (err) {
    console.error('Error fetching schooldata:', err.message);
    return res.status(500).json({ error: 'Internal server error' });
  }
});

// Developer Login Route
app.post('/login/developer', async (req, res) => {
  const { school} = req.body; // Extract 'userName' from request body
  console.log(school);

  try {
    // Fetch school database credentials
    const sql = "SELECT * FROM SCHOOL_DB_CREDENTIAL WHERE DATABASE_NAME = ?";
    const [schoolResults] = await pool.query(sql, [school]);

    if (schoolResults.length === 0) {
      logger.warn('School database credentials not found', { school });
      return res.status(404).json({ error: "School database credentials not found" });
    }

    const SCHOOL_DB_CREDENTIAL = schoolResults[0];

    // Connect to the school database
    schoolDbConnection = await connectToSchoolDatabase(SCHOOL_DB_CREDENTIAL);
    logger.info('Connected to the school database successfully for developer');

    return res.status(200).json({
      message: "Developer login successful",
    });

  } catch (err) {
    logger.error('Error during developer login process', { error: err.message, stack: err.stack });
    return res.status(500).json({ error: 'Internal server error' });
  }
});




//-------------------------------------------------------------------------------------------------------------------------------------


app.post('/api/enroll', async (req, res) => {
  const {
    applicationId, firstName, middleName, lastName, gender, contactNumber,stream,optional,house_number,house_building_name,street_name,landmark,city, state, postalCode, dateOfBirth, email,
    enrollmentDate, nationality, orphanStudent, birthCertificateNumber, cast, religion, bloodGroup, diseaseIfAny, additionalNote,
    identificationMark, previousschool, emergencyContactName, emergencyContactNumber, aadharnumber, fatherName, fatherAadharId,
    fatherOccupation, fatherEducation, fatherMobileNumber, fatherIncome, motherName, motherAadharId, motherOccupation,
    motherEducation, motherMobileNumber, motherIncome, primaryContactNumber, class: studentClass
  } = req.body;

  const connection = await schoolDbConnection.getConnection();
  try {
    await connection.beginTransaction();

    // Insert data into ENROLLMENT table
    const enrollmentSql = `
      INSERT INTO ENROLLMENT (APPLICATION_ID, FIRST_NAME, MIDDLE_NAME, LAST_NAME, GENDER, CONTACT_NUMBER, CLASS,STREAM,OPTIONAL,HOUSE_NUMBER,HOUSE_BUILDING_NAME,STREET_NAME,LANDMARK, CITY, STATE,
        POSTAL_CODE, DATE_OF_BIRTH, EMAIL, ENROLLMENT_DATE, NATIONALITY, ORPHAN_STUDENT, BIRTH_CERTIFICATE_NUMBER, CAST, RELIGION,
        BLOOD_GROUP, DISEASE_IF_ANY, ADDITIONAL_NOTE, IDENTIFICATION_MARK, PREVIOUS_SCHOOL, EMERGENCY_CONTACT_NAME, EMERGENCY_CONTACT_NUMBER,
        AADHAR_NUMBER, FATHER_NAME, FATHER_ADHAR_ID, FATHER_OCCUPATION, FATHER_EDUCATION, FATHER_MOBILE_NUMBER, FATHER_INCOME, MOTHER_NAME,
        MOTHER_ADHAR_ID, MOTHER_OCCUPATION, MOTHER_EDUCATION, MOTHER_MOBILE_NUMBER, MOTHER_INCOME, PRIMARY_CONTACT_NUMBER
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?, ?, ?, ?, ?, ?, ?, ?)
    `;

    const enrollmentValues = [applicationId, firstName, middleName, lastName, gender, contactNumber,stream,optional,house_number,house_building_name,street_name,landmark, city, state, postalCode,
      dateOfBirth, email, enrollmentDate, nationality, orphanStudent, birthCertificateNumber, cast, religion, bloodGroup, diseaseIfAny,
      additionalNote, identificationMark, previousschool, emergencyContactName, emergencyContactNumber, aadharnumber, fatherName,
      fatherAadharId, fatherOccupation, fatherEducation, fatherMobileNumber, fatherIncome, motherName, motherAadharId, motherOccupation,
      motherEducation, motherMobileNumber, motherIncome, primaryContactNumber
    ];

    await connection.query(enrollmentSql, enrollmentValues);




    // Generate new IDs for STUDENT_ID and STUDENT_USER_ID
    const maxSeqQuery = 'SELECT MAX(CAST(SUBSTRING(STUDENT_ID, 5) AS UNSIGNED)) AS MAX_SEQ, MAX(CAST(SUBSTRING_INDEX(STUDENT_USER_ID, "_", -1) AS UNSIGNED)) AS MAX_STUDENT_USER_SEQ FROM STUDENT_PROFILE';
    const [results] = await connection.query(maxSeqQuery);
    const maxSequence = results[0].MAX_SEQ || 0;
    const maxStudentUserSeq = results[0].MAX_STUDENT_USER_SEQ || 0;

    const newSeq = maxSequence + 1;
    const newStudentUserSeq = maxStudentUserSeq + 1;

    const newStudentId = `SID-${String(newSeq).padStart(5, '0')}`;
    const newStudentUserId = `${firstName}_${String(newSeq).padStart(5, '0')}`;
    const newParentsId = `PID-${String(newSeq).padStart(5, '0')}`;

    // Insert data into STUDENT_PROFILE table
    const studentProfileSql = `
      INSERT INTO STUDENT_PROFILE (
        STUDENT_ID, STUDENT_USER_ID, PARENT_ID, FIRST_NAME, MIDDLE_NAME, LAST_NAME, GENDER, CONTACT_NUMBER,STREAM,OPTIONAL,HOUSE_NUMBER,HOUSE_BUILDING_NAME,STREET_NAME,LANDMARK, CITY, STATE,
        POSTAL_CODE, DATE_OF_BIRTH, EMAIL, ENROLLMENT_DATE, NATIONALITY, ORPHAN_STUDENT, BIRTH_CERTIFICATE_NUMBER, CAST, RELIGION,
        BLOOD_GROUP, DISEASE_IF_ANY, ADDITIONAL_NOTE, IDENTIFICATION_MARK, PREVIOUS_SCHOOL, EMERGENCY_CONTACT_NAME, EMERGENCY_CONTACT_NUMBER, AADHAAR_NUMBER
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?,?, ?, ?, ?, ?,?)
    `;

    const studentProfileValues = [
      newStudentId, newStudentUserId, newParentsId, firstName, middleName, lastName, gender, contactNumber, stream,optional,house_number,house_building_name,street_name,landmark, city, state,
      postalCode, dateOfBirth, email, enrollmentDate, nationality, orphanStudent, birthCertificateNumber, cast, religion, bloodGroup,
      diseaseIfAny, additionalNote, identificationMark, previousschool, emergencyContactName, emergencyContactNumber, aadharnumber
    ];

    await connection.query(studentProfileSql, studentProfileValues);

    // Fetch current max SEQ for PARENT_PROFILE
    const maxParentSeqQuery = 'SELECT MAX(CAST(SUBSTRING(PARENT_ID, 5) AS UNSIGNED)) AS MAX_SEQ FROM PARENT_PROFILE';
    const [parentSeqResults] = await connection.query(maxParentSeqQuery);
    const maxSeq = parentSeqResults[0].MAX_SEQ || 0;
    const newParentId = `PID-${String(maxSeq + 1).padStart(5, '0')}`;

    // Insert data into PARENT_PROFILE table
    const parentProfileSql = `
      INSERT INTO PARENT_PROFILE (
        PARENT_ID, STUDENT_ID, FATHER_NAME, FATHER_ADHAR_ID, FATHER_OCCUPATION, FATHER_EDUCATION, FATHER_MOBILE_NUMBER,
        FATHER_INCOME, MOTHER_NAME, MOTHER_ADHAR_ID, MOTHER_OCCUPATION, MOTHER_EDUCATION, MOTHER_MOBILE_NUMBER, MOTHER_INCOME, PRIMARY_CONTACT_NUMBER
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;

    const parentProfileValues = [
      newParentId, newStudentId, fatherName, fatherAadharId, fatherOccupation, fatherEducation, fatherMobileNumber, fatherIncome,
      motherName, motherAadharId, motherOccupation, motherEducation, motherMobileNumber, motherIncome, primaryContactNumber
    ];

    await connection.query(parentProfileSql, parentProfileValues);

    // Determine section assignment dynamically based on total students in class
    const totalstudentQuery = 'SELECT COUNT(*) AS TOTAL_STUDENTS FROM CLASS_DETAIL WHERE CLASS = ?';
    const [totalStudentsInClassResults] = await connection.query(totalstudentQuery, [studentClass]);

    const totalStudentsInClass = totalStudentsInClassResults[0].TOTAL_STUDENTS || 0;
    let sectionName;

    if (totalStudentsInClass <= 60) {
      sectionName = 'A';
    } else if (totalStudentsInClass <= 120) {
      sectionName = 'B';
    } else {
      sectionName = 'C';
    }
 
    // Insert data into CLASS_DETAIL table
    const classDetailSql = 'INSERT INTO CLASS_DETAIL (STUDENT_ID, CLASS, SECTION) VALUES ( ?, ?, ?)';
    await connection.query(classDetailSql, [newStudentId, studentClass, sectionName]);
console.log(newStudentId);
    // Update FLAG in APPLICATION table to TRUE
    const updateApplicationSql = 'UPDATE APPLICATION SET FLAG = "TRUE" WHERE APPLICATION_ID = ?';
    await connection.query(updateApplicationSql, [applicationId]);

    await connection.commit();
    console.log('Transaction committed successfully.');
     

    // Fetch all students from the students table
    const studentdataSql = `SELECT 
      STUDENT_ID, STUDENT_USER_ID, SCHOOL_INFO
    FROM 
      STUDENT_PROFILE where STUDENT_USER_ID =  ? `;
     
    console.log("GET /students: Executing SQL query:", studentdataSql);

    const [student] = await schoolDbConnection.query(studentdataSql,[newStudentUserId]);
    const studentdata = student[0];
    console.log(studentdata);
// Function to generate a random password
function generateRandomPassword(length = 8) {
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()_+[]{}|;:,.<>?';
 
  let password = '';
  for (let i = 0; i < length; i++) {
    const randomIndex = Math.floor(Math.random() * characters.length);
    password += characters[randomIndex];
  }
  return password;
}

const Random_Genrated_pass = generateRandomPassword(); 
// Generate a random password
console.log(`This is the password: ${Random_Genrated_pass}`)

// SQL query with placeholders
 // Hash password
 const hashedRandom_Genrated_pass = await bcrypt.hash(Random_Genrated_pass, 10);

 
const STUDENT_USER_ID_Details = 'INSERT INTO STUDENT_USER (ADMINISTRATOR_USERNAME, STUDENT_USER_ID, STUDENT_ID, PASSWORD) VALUES (?, ?, ?, ?)';

// Array of values to insert into the database
const Details_values = [
  studentdata.SCHOOL_INFO,
  studentdata.STUDENT_USER_ID,
  studentdata.STUDENT_ID,
  hashedRandom_Genrated_pass
];
console.log (studentdata.SCHOOL_INFO)
  const [result] = await pool.query(STUDENT_USER_ID_Details, Details_values);

  console.log('STUDENT_USER_ID And Password inserted:', result);
  res.json({ message: 'Data inserted successfully into all tables.' });


  } catch (err) {
    console.error('Error inserting data:', err);
    await connection.rollback();
    if (err.code === 'ER_DUP_ENTRY') {
      res.status(400).json({ error: 'Duplicate entry. Check your input data.' });
    } else {
      res.status(500).json({ error: 'Internal server error' });
    }
  } finally {
    connection.release();
  }
});

// Route to fetch StudentAcademic
app.get('/api/enrollment', async (req, res) => {
  try {
    console.log("GET /enrollment: Fetching StudentAcademic...");
    if (!schoolDbConnection) {
      console.log("GET /enrollment: School database connection not established.");
      return res.status(500).json({ error: "School database connection not established" });
    }

    // Fetch all students from the students table
    const enrollmentSql =  `SELECT * FROM APPLICATION`;
    // Adjust this query as per your schema
    console.log("GET /enrollment: Executing SQL query:", enrollmentSql);

    const [enrollmentResult] = await schoolDbConnection.query(enrollmentSql);

    console.log("GET /enrollment: enrollment fetched successfully.");
    return res.status(200).json(enrollmentResult);

  } catch (err) {
    console.error('Error fetching enrollment:', err.message);
    return res.status(500).json({ error: 'Internal server error' });
  }
});


// Route to fetch StudentAcademic
app.get('/api/studentAcademic',   async (req, res) => {
  try {
    console.log("GET /StudentAcademic: Fetching StudentAcademic...");
    if (!schoolDbConnection) {
      console.log("GET /StudentAcademic: School database connection not established.");
      return res.status(500).json({ error: "School database connection not established" });
    }
    // Fetch all students from the students table
    const studentsSql =  ` SELECT B2B_ACADEMICS.*, B2B_STUDENT.First_Name, B2B_STUDENT.Middle_Name, 
    B2B_STUDENT.Last_Name, B2B_STUDENT.Gender, B2B_STUDENT.Student_Id, B2B_SUBJECTS.Class ,  B2B_SUBJECTS.Subject
    FROM B2B_ACADEMICS
    left JOIN B2B_STUDENT ON B2B_ACADEMICS.Student_Id = B2B_STUDENT.Student_Id
    left JOIN B2B_SUBJECTS ON B2B_ACADEMICS.Student_Id = B2B_SUBJECTS.Subject_ID limit 100
    `;
    // Adjust this query as per your schema
    console.log("GET /StudentAcademic: Executing SQL query:", studentsSql);

    const [studentsResult] = await schoolDbConnection.query(studentsSql);

    console.log("GET /StudentAcademic: StudentAcademic fetched successfully.");
    return res.status(200).json(studentsResult);


  } catch (err) {
    console.error('Error fetching StudentAcademic:', err.message);
    return res.status(500).json({ error: 'Internal server error' });
  }
});


// Route to fetch StudentAcademic
app.get('/api/Student_health',   async (req, res) => {
  try {
    console.log("GET /Student_health: Fetching Student_health...");
    if (!schoolDbConnection) {
      console.log("GET /Student_health: School database connection not established.");
      return res.status(500).json({ error: "School database connection not established" });
    }

    // Fetch all students from the students table
    const Student_healthSql =  `
    SELECT 
      sp.STUDENT_ID,  CONCAT(sp.FIRST_NAME, ' ', sp.MIDDLE_NAME, ' ', sp.LAST_NAME) AS STUDENT_NAME, sh.WEIGHT_IN_KG, 
       sh.HEIGHT_IN_CM,  sh.BMI,  sh.VISION_LEFT,  sh.VISION_RIGHT,  sh.ALLERGIES,  sh.MEDICAL_HISTORY,  sh.LAST_CHECKUP_DATE,
        CASE    WHEN sh.LAST_CHECKUP_DATE < DATE_SUB(NOW(), INTERVAL 60 DAY)    THEN 'RECHECK-REQUIRED'    ELSE 'NOT REQUIRED'  END AS HEALTH_STATUS,
         sh.DOCTOR_NAME,  sh.DOCTOR_CONTACT_NUMBER  
    FROM 
      STUDENT_PROFILE sp
    JOIN 
      STUDENT_HEALTH sh ON sp.STUDENT_ID = sh.STUDENT_ID limit 50
    `;
    // Adjust this query as per your schema
    console.log("GET /Student_health: Executing SQL query:", Student_healthSql);

    const [Student_healthResult] = await schoolDbConnection.query(Student_healthSql);

    console.log("GET /Student_health: StudentAcademic fetched successfully.");
    return res.status(200).json(Student_healthResult);

  } catch (err) {
    console.error('Error fetching Student_health:', err.message);
    return res.status(500).json({ error: 'Internal server error' });
  }
});




// Route to fetch StudentAttendance
app.get('/api/studentAttendance', async (req, res) => {
  try {
    console.log("GET /StudentAttendance: Fetching StudentAttendance...");
    if (!schoolDbConnection) {
      console.log("GET /StudentAttendance: School database connection not established.");
      return res.status(500).json({ error: "School database connection not established" });
    }

    // Fetch all students from the students table
    const studentsSql = `  
   SELECT sp.STUDENT_ID, CONCAT(sp.FIRST_NAME,' ',sp.MIDDLE_NAME,' ',sp.LAST_NAME) AS STUDENT_NAME,
    cd.CLASS_ID AS CLASS, sp.GENDER, sa.SESSION, sa.DATE, sa.STATUS 
    FROM STUDENT_PROFILE sp
    INNER JOIN STUDENT_ATTENDANCE sa ON sp.STUDENT_ID = sa.STUDENT_ID
    INNER JOIN CLASS_DETAIL cd ON sp.STUDENT_ID = cd.STUDENT_ID
    ORDER BY sa.DATE DESC limit 50`;

    console.log("GET /StudentAttendance: Executing SQL query:", studentsSql);

    

    const [studentsResult] = await schoolDbConnection.query(studentsSql);


       // Log all values fetched from the database
       console.log("Fetched Students:");
       studentsResult.forEach(student => {
           console.log(student);
       });
    console.log("GET /StudentAttendance: StudentAttendance fetched successfully.");
    return res.status(200).json(studentsResult);

  } catch (err) {
    console.error('Error fetching StudentAttendance:', err.message);
    return res.status(500).json({ error: 'Internal server error' });
  }
});

   





// Route to fetch studentcount
app.get('/api/studentcount', async (req, res) => {
  try {
    console.log("GET /studentcount: Fetching student count...");
    if (!schoolDbConnection) {
      console.log("GET /studentcount: School database connection not established.");
      return res.status(500).json({ error: "School database connection not established" });
    }

    // Updated SQL query to fetch students with their class and gender
    const studentsSql = `  
      SELECT SP.GENDER, CD.CLASS, COUNT(*) AS STUDENT_COUNT
      FROM STUDENT_PROFILE SP
      JOIN CLASS_DETAIL CD ON SP.STUDENT_ID = CD.STUDENT_ID
      WHERE SP.GENDER IN ('MALE', 'FEMALE')
      GROUP BY SP.GENDER, CD.CLASS;`

    console.log("GET /studentcount: Executing SQL query:", studentsSql);
    const [studentsResult] = await schoolDbConnection.query(studentsSql);

    // Log all values fetched from the database
    console.log("Fetched Students:");
    studentsResult.forEach(student => {
      console.log(student);
    });
    
    console.log("GET /studentcount: student count fetched successfully.");
    return res.status(200).json(studentsResult);

  } catch (err) {
    console.error('Error fetching student count:', err.message);
    return res.status(500).json({ error: 'Internal server error' });
  }
});


// Route to fetch StudentAcademic
app.get('/api/staffAttendance',   async (req, res) => {
  try {
    console.log("GET /staffAttendance: Fetching staffAttendance...");
    if (!schoolDbConnection) {
      console.log("GET /staffAttendance: School database connection not established.");
      return res.status(500).json({ error: "School database connection not established" });
    }
    // Fetch all students from the students table
    const staffAttendanceSql =  ` 
          SELECT a.STAFF_ID, a.STAFF_NAME,a.STAFF_ROLE,b.SESSION,b.DATE,b.STATUS  
FROM STAFF a, STAFF_ATTENDANCE b
where a.STAFF_ID = b.STAFF_ID`;
    // Adjust this query as per your schema
    console.log("GET /staffAttendance: Executing SQL query:",staffAttendanceSql);

    const [staffAttendanceResult] = await schoolDbConnection.query(staffAttendanceSql);

    console.log("GET /staffAttendance: staffAttendance fetched successfully.");
    return res.status(200).json(staffAttendanceResult);

    
  } catch (err) {
    console.error('Error fetching StudentAcademic:', err.message);
    return res.status(500).json({ error: 'Internal server error' });
  }
});



// Route to fetch StudentAttendance
app.get('/api/dashboard_studentAttendance', async (req, res) => {
  try {
    console.log("GET /dashboard_studentAttendance: Fetching StudentAttendance...");
    if (!schoolDbConnection) {
      console.log("GET /dashboard_studentAttendance: School database connection not established.");
      return res.status(500).json({ error: "School database connection not established" });
    }

    // Fetch all students from the students table
    const dashboard_studentAttendanceSql = `  
    SELECT CONCAT(sp.FIRST_NAME,' ',sp.MIDDLE_NAME,' ',sp.LAST_NAME) AS STUDENT_NAME,
      cd.CLASS_ID as CLASS, SESSION, DATE, STATUS
    FROM STUDENT_PROFILE sp, STUDENT_ATTENDANCE sa, CLASS_DETAIL cd
    WHERE sp.STUDENT_ID = sa.STUDENT_ID
      AND sp.STUDENT_ID = cd.STUDENT_ID limit 100
  `;

    console.log("GET /StudentAttendance: Executing SQL query:", dashboard_studentAttendanceSql);

    const [dashboard_studentAttendanceResult] = await schoolDbConnection.query(dashboard_studentAttendanceSql);

    console.log("GET /StudentAttendance: StudentAttendance fetched successfully.");
    return res.status(200).json(dashboard_studentAttendanceResult);

  } catch (err) {
    console.error('Error fetching dashboard_studentAttendance:', err.message);
    return res.status(500).json({ error: 'Internal server error' });
  }
});

   

// Route to fetch StudentAcademic
app.get('/api/dashboard_staffAttendance',   async (req, res) => {
  try {
    console.log("GET /dashboard_staffAttendance: Fetching staffAttendance...");
    if (!schoolDbConnection) {
      console.log("GET /dashboard_staffAttendance: School database connection not established.");
      return res.status(500).json({ error: "School database connection not established" });
    }
    // Fetch all students from the students table
    const dashboard_staffAttendanceSql =  ` 
           SELECT
      t1.DATE,
      DATE_FORMAT(t1.DATE, '%M') AS MONTH_NAME, -- Ensuring this is returned
      t1.SESSION,
      t1.STATUS,
      t2.Attendance_Percentage,
      t3.STAFF_ROLE
    FROM (
      SELECT
        sa.DATE,
        sa.SESSION,
        sa.STATUS,
        s.STAFF_ID
      FROM STAFF_ATTENDANCE sa
      INNER JOIN STAFF s
        ON sa.STAFF_ID = s.STAFF_ID
      LIMIT 100
    ) t1
    JOIN (
      SELECT
        sa.DATE,
        sa.SESSION,
        COUNT(CASE WHEN sa.STATUS = 'Present' THEN 1 END) * 100.0 / COUNT(*) AS Attendance_Percentage
      FROM STAFF_ATTENDANCE sa
      GROUP BY sa.DATE, sa.SESSION
    ) t2
      ON t1.DATE = t2.DATE
      AND t1.SESSION = t2.SESSION
    JOIN STAFF t3
      ON t1.STAFF_ID = t3.STAFF_ID  limit 100;
  `;
    // Adjust this query as per your schema
    console.log("GET /dashboard_staffAttendance: Executing SQL query:",dashboard_staffAttendanceSql);

    const [dashboard_staffAttendanceResult] = await schoolDbConnection.query(dashboard_staffAttendanceSql);

    console.log("GET /dashboard_staffAttendanceSql: dashboard_staffAttendanceSql fetched successfully.");
    return res.status(200).json(dashboard_staffAttendanceResult);

    
  } catch (err) {
    console.error('Error fetching dashboard_staffAttendanceSql:', err.message);
    return res.status(500).json({ error: 'Internal server error' });
  }
});


// Route to fetch holidays
app.get('/api/holidays', async (req, res) => {
  try {
    console.log("GET /holidays: Fetching holidays...");
    if (!schoolDbConnection) {
      console.log("GET /holidays: School database connection not established.");
      return res.status(500).json({ error: "School database connection not established" });
    }

    // Fetch all holidays from the VW_EVENT_HOLIDAY_SCHEDULE table
    const holidaysSql = `SELECT HOLIDAY_NAME, HOLIDAY_MONTH, HOLIDAY_YEAR, START_DATE, END_DATE, TYPE
    FROM VW_EVENT_HOLIDAY_SCHEDULE`;
    console.log("GET /holidays: Executing SQL query:", holidaysSql);

    const [holidaysResult] = await schoolDbConnection.query(holidaysSql);

    console.log("GET /holidays: Holidays fetched successfully.");
    return res.status(200).json(holidaysResult);

  } catch (err) {
    console.error('Error fetching holidays:', err.message);
    return res.status(500).json({ error: 'Internal server error' });
  }
});

// Route to fetch Studentprofile
app.get('/api/studentprofile',  async (req, res) => {
  try {
    console.log("GET /Studentprofile: Fetching Studentprofile...");
    if (!schoolDbConnection) {
      console.log("GET /Studentprofile: School database connection not established.");
      return res.status(500).json({ error: "School database connection not established" });
    }

    // Fetch all students from the students table
    const studentsSql = 
`SELECT
      sp.STUDENT_ID,
      sp.FIRST_NAME,
      sp.MIDDLE_NAME,
      sp.LAST_NAME,
      sp.GENDER,
      sp.CONTACT_NUMBER,
      sp.HOUSE_NUMBER,  
      sp.HOUSE_BUILDING_NAME,
      sp.STREET_NAME,
      sp.LANDMARK,
      sp.CITY,
      sp.STATE,
      sp.POSTAL_CODE,
      sp.NATIONALITY,
      sp.DATE_OF_BIRTH,
      sp.EMAIL,
      sp.ENROLLMENT_DATE,
      sp.ORPHAN_STUDENT,
      sp.BIRTH_CERTIFICATE_NUMBER,
      sp.CAST,
      sp.RELIGION,
      sp.BLOOD_GROUP,
      sp.IDENTIFICATION_MARK,
      sp.PREVIOUS_SCHOOL,
      sp.EMERGENCY_CONTACT_NAME,
      sp.EMERGENCY_CONTACT_NUMBER,
      sp.AADHAAR_NUMBER,
      sp.DISEASE_IF_ANY,
      sp.ADDITIONAL_NOTE,
      cd.CLASS_ID,
      s.STAFF_NAME AS CLASS_TEACHER
FROM
    STUDENT_PROFILE sp
JOIN
    CLASS_DETAIL cd ON sp.STUDENT_ID = cd.STUDENT_ID
JOIN
    CLASS_INFO ci ON cd.CLASS_ID = ci.CLASS_ID
JOIN
     STAFF s ON ci.STAFF_ID = s.STAFF_ID
  `;

    console.log("GET /students: Executing SQL query:", studentsSql);

    const [studentsResult] = await schoolDbConnection.query(studentsSql);

    console.log("GET /Studentprofile: Studentprofile fetched successfully.");
    return res.status(200).json(studentsResult);

  } catch (err) {
    console.error('Error fetching Studentprofile:', err.message);
    return res.status(500).json({ error: 'Internal server error' });
  }
});



// Route to fetch total profit
app.get('/api/ParentProfile', async (req, res) => {
  try {
    console.log("GET /api/parent_Profile: Fetching parent_details...");
    if (!schoolDbConnection) {
      console.log("GET /api/parent_Profile: School database connection not established.");
      return res.status(500).json({ error: "School database connection not established" });
    }

    const ParentProfileSql = `SELECT  pp.PARENT_ID,CONCAT(sp.FIRST_NAME, ' ', sp.MIDDLE_NAME, ' ', sp.LAST_NAME) AS STUDENT_NAME,
           FATHER_NAME, FATHER_OCCUPATION, FATHER_EDUCATION, FATHER_ADHAR_ID, FATHER_MOBILE_NUMBER, FATHER_INCOME,
           MOTHER_NAME, MOTHER_OCCUPATION, MOTHER_EDUCATION, MOTHER_ADHAR_ID, MOTHER_MOBILE_NUMBER, MOTHER_INCOME,
           PRIMARY_CONTACT_NUMBER 
    FROM PARENT_PROFILE pp,
    STUDENT_PROFILE sp  
    WHERE pp.PARENT_ID = sp.PARENT_ID limit 100
  `;
console.log("GET /api/parent_details: Executing SQL query:", ParentProfileSql);

    const [ParentProfileResult] = await schoolDbConnection.query(ParentProfileSql);

    console.log("GET /api/parent_Profile: parent_detailsSql fetched successfully.");
    return res.status(200).json(ParentProfileResult);

  } catch (err) {
    console.error('Error fetching ParentProfileResult', err.message);
    return res.status(500).json({ error: 'Internal server error' });
  }
});
 


// Route to fetch total profit
app.get('/api/Staff_Profile', async (req, res) => {
  try {
    console.log("GET /api/Staff_Profile: Fetching Staff_Profile...");
    if (!schoolDbConnection) {
      console.log("GET /api/Staff_Profile: School database connection not established.");
      return res.status(500).json({ error: "School database connection not established" });
    }

    const Staff_ProfileSql =  `SELECT STAFF_ID, STAFF_USER_ID, STAFF_NAME, CONTACT_NUMBER, STAFF_ROLE, DATE_OF_JOINING, MONTHLY_SALARY,
    FATHER_HUSBAND_NAME, GENDER, EXPERIENCE, ADHAR_ID, RELIGION, EMAIL, EDUCATION, BLOOD_GROUP,
    DATE_OF_BIRTH, ADDRESS, CITY, STATE, POSTAL_CODE, EXIT_DATE, IS_ACTIVE
FROM STAFF
`;

console.log("GET /api/Staff_Profile: Executing SQL query:", Staff_ProfileSql);

    const [Staff_ProfileResult] = await schoolDbConnection.query(Staff_ProfileSql);

    console.log("GET /api/parent_details: Staff_ProfileSql fetched successfully.");
    return res.status(200).json(Staff_ProfileResult);

  } catch (err) {
    console.error('Error fetching Staff_Profile:', err.message);
    return res.status(500).json({ error: 'Internal server error' });
  }
});
 





// // Route to fetch assignment
// app.get('/api/assignment', async (req, res) => {
//   try {
//     console.log("GET /api/assignment: Fetching Staff_Profile...");
//     if (!schoolDbConnection) {
//       console.log("GET /api/assignment: School database connection not established.");
//       return res.status(500).json({ error: "School database connection not established" });
//     }

//     const assignmentSql =  `SELECT DISTINCT CLASS AS CLASS, SUBJECT AS SUBJECT FROM VW_ACADEMIC_MARKS`;


// console.log("GET /api/assignment: Executing SQL query:", assignmentSql);

//     const [assignmentResult] = await schoolDbConnection.query(assignmentSql);

//     console.log("GET /api/assignment: assignment fetched successfully.");
//     return res.status(200).json(assignmentResult);

//   } catch (err) {
//     console.error('Error fetching assignment:', err.message);
//     return res.status(500).json({ error: 'Internal server error' });
//   }
// });
  
// app.post('/api/assignmentdata', async (req, res) => {
//   console.log("post /assignmentdata: insert assignme  111...");

//   try {
//     console.log("post /assignmentdata: insert assignment data ...");

//     // Check if schoolDbConnection is established
//     if (!schoolDbConnection) {
//       console.log("post /assignmentdata: School database connection not established.");
//       return res.status(500).json({ error: "School database connection not established" });
//     }

//     const {
//       Class,
//       AssignmentType,
//       Subject,
//       AssignmentDescription,
//       StartDate,
//       SubmissionStartDate,
//       SubmissionEndDate
//     } = req.body;

//     // Validate the input data
//     if (!Class || !AssignmentType || !Subject || !AssignmentDescription || !StartDate || !SubmissionStartDate || !SubmissionEndDate) {
//       return res.status(400).json({ error: 'Missing required fields' });
//     }

//     // Fetch student IDs from CLASS_DETAIL based on CLASS_ID
//     const fetchStudentIdsQuery = 'SELECT STUDENT_ID FROM CLASS_DETAIL WHERE CLASS_ID = ?';
//     const [studentResults] = await schoolDbConnection.query(fetchStudentIdsQuery, [Class]);

//     console.log("post /assignmentdata: insert assignme  222...");
//     if (studentResults.length === 0) {
//       return res.status(404).json({ message: 'No students found for the given class' });
//     }

//     // Prepare SQL query for inserting data into STUDENT_ASSIGNMENT
//     const insertAssignmentQuery = `
//       INSERT INTO STUDENT_ASSIGNMENT (STUDENT_ID, CLASS_ID, ASSIGNMENT_TYPE, SUBJECT, ASSIGNMENT_DESC, START_DATE, SUBMISSION_START_DATE, SUBMISSION_END_DATE)
//       VALUES (?, ?, ?, ?, ?, ?, ?, ?)
//     `;

//     // Perform batch insertions using promises
//     const insertPromises = studentResults.map(async (row) => {
//       const values = [
//         row.STUDENT_ID,
//         Class,
//         AssignmentType,
//         Subject,
//         AssignmentDescription,
//         StartDate,
//         SubmissionStartDate,
//         SubmissionEndDate
//       ];
//       return schoolDbConnection.query(insertAssignmentQuery, values);
//     });
//     console.log("post /assignmentdata: insert assignme  33...");

//     const results = await Promise.all(insertPromises);

//     // Count the number of successful insertions
//     const successfulInsertions = results.filter(result => result.affectedRows > 0).length;

//     console.log('Assignment Data inserted successfully.');
//     res.json({ message: 'Assignment Data inserted successfully.', insertedRecords: successfulInsertions });

//   } catch (err) {
//     console.error('Error inserting assignment data:', err.message);
//     res.status(500).json({ error: 'Internal server error', details: err.message });
//   }
// });


// // Route to fetch StudentEvents
// app.get('/api/assignmentlist',  async (req, res) => {
//   try {
//     console.log("GET /assignmentlist: Fetching StudentEvents...");
//     if (!schoolDbConnection) {
//       console.log("GET /assignmentlist: School database connection not established.");
//       return res.status(500).json({ error: "School database connection not established" });
//     }

//     // Fetch all students from the students table
//     const assignmentlistSql =`SELECT 
//     sp.STUDENT_ID, 
//     CONCAT(sp.FIRST_NAME, ' ', sp.MIDDLE_NAME, ' ', sp.LAST_NAME) AS STUDENT_NAME,
//     ci.CLASS_ID, 
//     s.STAFF_NAME AS CLASS_TEACHER,
//     sa.ASSIGNMENT_TYPE,
//     sa.SUBJECT,
//     sa.ASSIGNMENT_DESC,
//     sa.START_DATE,
//     sa.IS_SUBMITTED,
//     sa.SUBMISSION_START_DATE,
//     sa.SUBMISSION_END_DATE,
//     sa.SUBMISSION_DATE,
//     sa.STATUS
// FROM 
//     STUDENT_PROFILE sp
// JOIN 
//     CLASS_DETAIL cd ON sp.STUDENT_ID = cd.STUDENT_ID
// JOIN 
//     CLASS_INFO ci ON cd.CLASS_ID = ci.CLASS_ID
// JOIN 
//     STAFF s ON ci.STAFF_ID = s.STAFF_ID
// JOIN 
//     STUDENT_ASSIGNMENT sa ON sp.STUDENT_ID = sa.STUDENT_ID AND ci.CLASS_ID = sa.CLASS_ID

// `;
//     console.log("GET /assignmentlist: Executing SQL query:", assignmentlistSql);

//     const [assignmentlistResult] = await schoolDbConnection.query(assignmentlistSql);

//     console.log("GET /assignmentlis: assignmentlis fetched successfully.");
//     return res.status(200).json(assignmentlistResult);

//   } catch (err) {
//     console.error('Error fetching assignmentlis:', err.message);
//     return res.status(500).json({ error: 'Internal server error' });
//   }
// });

 

// app.put('/api/assignmentupdate/:studentId', async (req, res) => {
//   try {
//     console.log("PUT /api/assignmentupdate: Request received");
//     const studentId = req.params.studentId;
//     const { IS_SUBMITTED, STATUS, SUBMISSION_DATE } = req.body;
    
//     console.log(`Updating assignment for student ID ${studentId} with data:`, req.body);

//     if (!schoolDbConnection) {
//       console.log("Database connection not established.");
//       return res.status(500).json({ error: "Database connection not established" });
//     }

//     if (typeof IS_SUBMITTED === 'undefined' || typeof STATUS === 'undefined' || typeof SUBMISSION_DATE === 'undefined') {
//       return res.status(400).json({ error: 'Missing required fields' });
//     }

//     const query = `
//       UPDATE STUDENT_ASSIGNMENT
//       SET
//         IS_SUBMITTED = ?,
//         STATUS = ?,
//         SUBMISSION_DATE = ?
//       WHERE STUDENT_ID = ?
//     `;
    
//     await schoolDbConnection.query(query, [IS_SUBMITTED, STATUS, SUBMISSION_DATE, studentId]);

//     console.log('Update successful.');
//     res.json({ message: 'Assignment updated successfully' });

//   } catch (err) {
//     console.error('Error executing query:', err.message);
//     res.status(500).json({ error: 'Database query error' });
//   }
// });


// API Endpoint to get assignments for a student
// app.get('/api/assignments', async (req, res) => {
//   const studentId = req.query.studentId; // Assuming studentId is passed as a query param

//   if (!studentId) {
//     return res.status(400).json({ message: 'Student ID is required' });
//   }

//   try {
//     // Check if the database connection is established
//     if (!schoolDbConnection) {
//       console.log("GET /api/assignments: School database connection not established.");
//       return res.status(500).json({ error: "School database connection not established" });
//     }

//     // Fetch class ID for the student
//     const classidSql = `SELECT CLASS_ID FROM STUDENT_ASSIGNMENT WHERE STUDENT_ID = ?`;
//     const [classidSqlResult] = await schoolDbConnection.query(classidSql, [studentId]);

//     // Check if class ID is found
//     if (classidSqlResult.length === 0) {
//       return res.status(404).json({ message: "No class found for the provided student." });
//     }

//     const classId = classidSqlResult[0].CLASS_ID;

//     // Fetch assignment data
//     const assignmentsSql = `
//       SELECT
//         STUDENT_ID,
//         ASSIGNMENT_ID,
//         STUDENT_NAME,
//         CLASS_ID,
//         ASSIGNMENT_TYPE,
//         SUBJECT_NAME,
//         ASSIGNMENT_DESC,
//         SUBMISSION_START_DATE,
//         SUBMISSION_END_DATE
//       FROM STUDENT_ASSIGNMENT
//       WHERE STUDENT_ID = ? AND CLASS_ID = ?
//     `;
//     const [assignmentsResult] = await schoolDbConnection.query(assignmentsSql, [studentId, classId]);

//     // Check if assignments are found
//     if (assignmentsResult.length === 0) {
//       return res.status(404).json({ message: "No assignments found for the provided student and class." });
//     }

//     return res.status(200).json(assignmentsResult);

//   } catch (err) {
//     console.error("Error fetching assignment data:", err.message);
//     return res.status(500).json({ error: "Internal server error" });
//   }
// });

// // API Endpoint to submit an assignment

// // API Endpoint to submit an assignment

app.get('/api/studentcountdetails', async (req, res) => {
  try {
    console.log("GET /api/studentcountdetails: Fetching student count...");
    if (!schoolDbConnection) {
      console.log("GET /api/studentcountdetails: School database connection not established.");
      return res.status(500).json({ error: "School database connection not established" });
    }

    const studentsSql = `SELECT COUNT(*) AS TOTAL_STUDENTS FROM STUDENT_PROFILE`;
    console.log("GET /api/studentcountdetails: Executing SQL query:", studentsSql);

    const [studentsResult] = await schoolDbConnection.query(studentsSql);
    const totalStudents = studentsResult[0].TOTAL_STUDENTS;

    console.log("GET /api/studentcountdetails: Student count fetched successfully. Total students:", totalStudents);
    return res.status(200).json({ totalStudents });

  } catch (err) {
    console.error('Error fetching student count:', err.message);
    return res.status(500).json({ error: 'Internal server error' });
  }
});

app.get('/api/staffcount', async (req, res) => {
  try {
    console.log("GET /api/staffcount: Fetching staff count...");
    if (!schoolDbConnection) {
      console.log("GET /api/staffcount: School database connection not established.");
      return res.status(500).json({ error: "School database connection not established" });
    }

    const staffSql = `SELECT COUNT(*) AS TOTAL_STAFF FROM STAFF`;
    console.log("GET /api/staffcount: Executing SQL query:", staffSql);

    const [staffResult] = await schoolDbConnection.query(staffSql);
    const totalStaff = staffResult[0].TOTAL_STAFF;

    console.log("GET /api/staffcount: Staff count fetched successfully. Total staff:", totalStaff);
    return res.status(200).json({ totalStaff });

  } catch (err) {
    console.error('Error fetching staff count:', err.message);
    return res.status(500).json({ error: 'Internal server error' });
  }
});

app.get('/api/workingStaff', async (req, res) => {
  try {
    console.log("GET /api/workingStaff: Fetching total working staff...");
    if (!schoolDbConnection) {
      console.log("GET /api/workingStaff: School database connection not established.");
      return res.status(500).json({ error: "School database connection not established" });
    }

    const workingStaffSql = `SELECT COUNT(*) AS TOTALTEACHER_STAFF
FROM STAFF
WHERE STAFF_ROLE = 'TEACHER'`;
    console.log("GET /api/workingStaff: Executing SQL query:", workingStaffSql);

    const [workingStaffResult] = await schoolDbConnection.query(workingStaffSql);
     const workingStaff = workingStaffResult[0].TOTALTEACHER_STAFF;

    console.log("GET /api/workingStaff: Working staff count fetched successfully. Total working staff:", workingStaff);
    return res.status(200).json( { workingStaff } );

  } catch (err) {
    console.error('Error fetching working staff count:', err.message);
    return res.status(500).json({ error: 'Internal server error' });
  }
});


 
//  Route to insert data into APPLICATION table
app.post('/api/application', async (req, res) => {
  const {
    FIRST_NAME,
    MIDDLE_NAME,
    LAST_NAME,
    GENDER,
    CONTACT_NUMBER,
    CLASS,
    STREAM,
    OPTIONAL,
    HOUSE_NUMBER,
    HOUSE_BUILDING_NAME	,
    STREET_NAME,
    LANDMARK,
    CITY,
    STATE,
    POSTAL_CODE,
    DATE_OF_BIRTH,
    EMAIL,
    ENROLLMENT_DATE,
    NATIONALITY,
    ORPHAN_STUDENT,
    BIRTH_CERTIFICATE_NUMBER,
    CAST,
    RELIGION,
    BLOOD_GROUP,
    DISEASE_IF_ANY,
    ADDITIONAL_NOTE,
    IDENTIFICATION_MARK,
    PREVIOUS_SCHOOL,
    EMERGENCY_CONTACT_NAME,
    EMERGENCY_CONTACT_NUMBER,
    AADHAAR_NUMBER,
    FATHER_NAME,
    FATHER_ADHAR_ID,
    FATHER_OCCUPATION,
    FATHER_EDUCATION,
    FATHER_MOBILE_NUMBER,
    FATHER_INCOME,
    MOTHER_NAME,
    MOTHER_ADHAR_ID,
    MOTHER_OCCUPATION,
    MOTHER_EDUCATION,
    MOTHER_MOBILE_NUMBER,
    MOTHER_INCOME,
    PRIMARY_CONTACT_NUMBER
} = req.body;
  try {
    console.log("post /application: insert application data ...");
    // Check if schoolDbConnection is established
    if (!schoolDbConnection) {
      console.log("post /application: School database connection not established.");
      return res.status(500).json({ error: "School database connection not established" });
    }
  // SQL query to insert data into APPLICATION table
  const INSERT_APPLICATION_QUERY = `
      INSERT INTO APPLICATION (    
    FIRST_NAME,
    MIDDLE_NAME,
    LAST_NAME,
    GENDER,
    CONTACT_NUMBER,
    CLASS,
    STREAM,
    OPTIONAL,
    HOUSE_NUMBER,
    HOUSE_BUILDING_NAME	,
    STREET_NAME,
    LANDMARK,
    CITY,
    STATE,
    POSTAL_CODE,
    DATE_OF_BIRTH,
    EMAIL,
    ENROLLMENT_DATE,
    NATIONALITY,
    ORPHAN_STUDENT,
    BIRTH_CERTIFICATE_NUMBER,
    CAST,
    RELIGION,
    BLOOD_GROUP,
    DISEASE_IF_ANY,
    ADDITIONAL_NOTE,
    IDENTIFICATION_MARK,
    PREVIOUS_SCHOOL,
    EMERGENCY_CONTACT_NAME,
    EMERGENCY_CONTACT_NUMBER,
    AADHAAR_NUMBER,
    FATHER_NAME,
    FATHER_ADHAR_ID,
    FATHER_OCCUPATION,
    FATHER_EDUCATION,
    FATHER_MOBILE_NUMBER,
    FATHER_INCOME,
    MOTHER_NAME,
    MOTHER_ADHAR_ID,
    MOTHER_OCCUPATION,
    MOTHER_EDUCATION,
    MOTHER_MOBILE_NUMBER,
    MOTHER_INCOME,
    PRIMARY_CONTACT_NUMBER
        ) VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?,?,?,?,?)`;
        const values = [
          FIRST_NAME,
    MIDDLE_NAME,
    LAST_NAME,
    GENDER,
    CONTACT_NUMBER,
    CLASS,
    STREAM,
    OPTIONAL,
    HOUSE_NUMBER,
    HOUSE_BUILDING_NAME	,
    STREET_NAME,
    LANDMARK,
    CITY,
    STATE,
    POSTAL_CODE,
    DATE_OF_BIRTH,
    EMAIL,
    ENROLLMENT_DATE,
    NATIONALITY,
    ORPHAN_STUDENT,
    BIRTH_CERTIFICATE_NUMBER,
    CAST,
    RELIGION,
    BLOOD_GROUP,
    DISEASE_IF_ANY,
    ADDITIONAL_NOTE,
    IDENTIFICATION_MARK,
    PREVIOUS_SCHOOL,
    EMERGENCY_CONTACT_NAME,
    EMERGENCY_CONTACT_NUMBER,
    AADHAAR_NUMBER,
    FATHER_NAME,
    FATHER_ADHAR_ID,
    FATHER_OCCUPATION,
    FATHER_EDUCATION,
    FATHER_MOBILE_NUMBER,
    FATHER_INCOME,
    MOTHER_NAME,
    MOTHER_ADHAR_ID,
    MOTHER_OCCUPATION,
    MOTHER_EDUCATION,
    MOTHER_MOBILE_NUMBER,
    MOTHER_INCOME,
    PRIMARY_CONTACT_NUMBER
      ];
  await schoolDbConnection.query(INSERT_APPLICATION_QUERY, values);
  console.log('APPLICATION Data inserted successfully.');
  res.json({ message: 'APPLICATION Data inserted successfully .' });

} catch (err) {
  console.error('Error registering user:', err.message);
  return res.status(500).json({ error: 'Internal server error' });
}
});
// Route to fetch total profit
app.get('/api/Studentperformancetable', async (req, res) => {
  try {
    console.log("GET /api/Studentperformance: Fetching parent_details...");
    if (!schoolDbConnection) {
      console.log("GET /api/Studentperformance: School database connection not established.");
      return res.status(500).json({ error: "School database connection not established" });
    }

    const StudentperformancetableSql = `SELECT STUDENT_ID, STUDENT_NAME, ACADEMIC_YEAR,CLASS, SUBJECT,
       PERIODIC_TEST_1 AS TERM_1_PT, NOTE_BOOK_1 AS TERM_1_NB,SUBJECT_ENRICHMENT_1 AS TERM_1_SE,HALF_YEARLY, TERM_1_TOTAL,
       WORK_EDUCATION_1,ART_EDUCATION_1, HEALTH_AND_HYGIENE_1,REGULARITY_AND_PUNCTUALLITY_1,
       PERIODIC_TEST_2 AS TERM_2_PT, NOTE_BOOK_2 AS TERM_2_NB,SUBJECT_ENRICHMENT_2 AS TERM_2_SE,ANNUAL, TERM_2_TOTAL,
       WORK_EDUCATION_1,ART_EDUCATION_1, HEALTH_AND_HYGIENE_1,REGULARITY_AND_PUNCTUALLITY_1,
       GRAND_TOTAL,
       PERCENT
FROM VW_ACADEMIC_MARKS vam
ORDER BY STUDENT_ID ASC`  ; 
console.log("GET /api/Studentperformance: Executing SQL query:", StudentperformancetableSql);

    const [StudentperformancetableResult] = await schoolDbConnection.query(StudentperformancetableSql);

    console.log("GET /api/Studentperformance: StudentperformancetableSql fetched successfully.");
    return res.status(200).json(StudentperformancetableResult);

  } catch (err) {
    console.error('Error fetching Studentperformance:', err.message);
    return res.status(500).json({ error: 'Internal server error' });
  }
});

 

app.get('/api/studentupdate/:studentId', async (req, res) => {
  try {
    console.log("GET /api/studentupdate: Fetching student ...");
    if (!schoolDbConnection) {
      console.log("GET /api/studentupdate: School database connection not established.");
      return res.status(500).json({ error: "School database connection not established" });
    }
    
    const studentId = req.params.studentId;
    console.log(studentId);
    const studentSql = `
      SELECT sp.STUDENT_ID, sp.FIRST_NAME, sp.MIDDLE_NAME, sp.LAST_NAME, sp.GENDER, cd.CLASS_ID,sp.CONTACT_NUMBER, sp.HOUSE_NUMBER,sp.HOUSE_BUILDING_NAME,sp.STREET_NAME,sp.LANDMARK,
  sp.CITY, 
      sp.STATE, sp.POSTAL_CODE, sp.NATIONALITY, sp.DATE_OF_BIRTH, sp.EMAIL, sp.ENROLLMENT_DATE, sp.ORPHAN_STUDENT,
      sp.BIRTH_CERTIFICATE_NUMBER, sp.CAST, sp.RELIGION, sp.BLOOD_GROUP, sp.IDENTIFICATION_MARK, sp.PREVIOUS_SCHOOL, 
      sp.EMERGENCY_CONTACT_NAME, sp.EMERGENCY_CONTACT_NUMBER, sp.AADHAAR_NUMBER, sp.DISEASE_IF_ANY, sp.ADDITIONAL_NOTE
      
      FROM STUDENT_PROFILE sp 
      JOIN CLASS_DETAIL cd ON sp.STUDENT_ID = cd.STUDENT_ID
      JOIN CLASS_INFO ci ON cd.CLASS_ID = ci.CLASS_ID
      JOIN STAFF s ON ci.STAFF_ID = s.STAFF_ID
      WHERE sp.STUDENT_ID = ?
    `;

    console.log("GET /api/studentupdate: Executing SQL query:", studentSql);

    const [studentdataResult] = await schoolDbConnection.query(studentSql, [studentId]);

    console.log("GET /api/studentupdate: Retrieved student:", studentdataResult);

    if (studentdataResult.length === 0) {
      return res.status(404).json({ error: 'Student not found' });
    }

    console.log("GET /api/studentupdate: studentupdate successfully.");
    return res.status(200).json(studentdataResult[0]);

  } catch (err) {
    console.error('Error fetching studentupdate:', err.message);
    return res.status(500).json({ error: 'Internal server error' });
  }
});


// Route to update a specific studentupdate by ID
app.put('/api/studentupdate/:studentId', async (req, res) => {
  try {

    console.log("GET /api/student: Fetching student ...");
    if (!schoolDbConnection) {
      console.log("GET /api/student: School database connection not established.");
      return res.status(500).json({ error: "School database connection not established" });
    }
    const studentId = req.params.studentId;
  const updatedData = req.body;

  const studentProfileFields = [
    'FIRST_NAME', 'MIDDLE_NAME', 'LAST_NAME', 'GENDER', 'CONTACT_NUMBER', 'ADDRESS', 'CITY', 'STATE', 'POSTAL_CODE',
    'NATIONALITY', 'DATE_OF_BIRTH', 'EMAIL', 'ENROLLMENT_DATE', 'ORPHAN_STUDENT',
    'BIRTH_CERTIFICATE_NUMBER', 'CAST', 'RELIGION', 'BLOOD_GROUP', 'IDENTIFICATION_MARK',
    'PREVIOUS_SCHOOL', 'EMERGENCY_CONTACT_NAME', 'EMERGENCY_CONTACT_NUMBER', 'AADHAAR_NUMBER',
    'DISEASE_IF_ANY', 'ADDITIONAL_NOTE', 'ACADEMIC_YEAR' 
  ];

  let setClauseStudentProfile = '';
  let values = [];

  studentProfileFields.forEach(field => {
    if (field in updatedData) {
      if (setClauseStudentProfile !== '') setClauseStudentProfile += ', ';
      setClauseStudentProfile += `sp.${field} = ?`;
      values.push(updatedData[field]);
    }
  });

  const query = `
    UPDATE 
      STUDENT_PROFILE sp
    JOIN 
      CLASS_DETAIL cd ON sp.STUDENT_ID = cd.STUDENT_ID
    SET 
      ${setClauseStudentProfile}
    WHERE 
      sp.STUDENT_ID = ?
  `;

  values.push(studentId);

    const [result] = await schoolDbConnection.query(query, values);

    console.log('PUT /api/student: Student updated successfully.');
    res.json({ message: 'Student updated successfully' });

  } catch (err) {
    console.error('Error executing query:', err.message);
    res.status(500).json({ error: 'Database query error' });
  }
});




//  // get  parent_Detail_Update profile //

app.get('/api/parent_Detail_Update/:parentId', async (req, res) => {
  try {
    console.log("GET /api/studentupdate: Fetching student ...");
    if (!schoolDbConnection) {
      console.log("GET /api/studentupdate: School database connection not established.");
      return res.status(500).json({ error: "School database connection not established" });
    }
    const studentId = req.params.studentId;
    const parentdeatailSql = `
    SELECT pp.PARENT_ID,
       CONCAT(sp.FIRST_NAME, ' ', sp.MIDDLE_NAME, ' ', sp.LAST_NAME) AS STUDENT_NAME,
       pp.FATHER_NAME, pp.FATHER_OCCUPATION, pp.FATHER_EDUCATION, pp.FATHER_ADHAR_ID, pp.FATHER_MOBILE_NUMBER, pp.FATHER_INCOME,
       pp.MOTHER_NAME, pp.MOTHER_OCCUPATION, pp.MOTHER_EDUCATION, pp.MOTHER_ADHAR_ID, pp.MOTHER_MOBILE_NUMBER, pp.MOTHER_INCOME,
       pp.PRIMARY_CONTACT_NUMBER
FROM PARENT_PROFILE pp
JOIN STUDENT_PROFILE sp ON pp.PARENT_ID = sp.PARENT_ID
 
    `;
    console.log("GET /api/parentdeatailResult: Executing SQL query:", parentdeatailSql);

    const [parentdeatailResult] = await schoolDbConnection.query(parentdeatailSql, [studentId]);

    if (parentdeatailResult.length === 0) {
      return res.status(404).json({ error: 'parent not found' });
    }
[]
    console.log("GET /api/parentdeatailResult: parentdeatailupdate successfully.");
    return res.status(200).json(parentdeatailResult[0]);

  } catch (err) {
    console.error('Error fetching studentupdate :', err.message);
    return res.status(500).json({ error: 'Internal server error' });
  }
}); 

 





// Route to parent_Detail_Update a specific student by ID
app.put('/api/parent_Detail_Update/:parentId', async (req, res) => {
  try {

    console.log("GET /api/parent_Detail_Update: parent_Detail_Update  ...");
    if (!schoolDbConnection) {
      console.log("GET /api/parent_Detail_Update: School database connection not established.");
      return res.status(500).json({ error: "School database connection not established" });
    }const parentId = req.params.parentId;
    const updatedData = req.body;
  
    const parentProfileFields = [
      'FATHER_NAME', 'FATHER_OCCUPATION', 'FATHER_EDUCATION', 'FATHER_ADHAR_ID', 'FATHER_MOBILE_NUMBER', 'FATHER_INCOME',
      'MOTHER_NAME', 'MOTHER_OCCUPATION', 'MOTHER_EDUCATION', 'MOTHER_ADHAR_ID', 'MOTHER_MOBILE_NUMBER', 'MOTHER_INCOME',
      'PRIMARY_CONTACT_NUMBER'
    ];
  
    let setClauseParentProfile = '';
    let values = [];
  
    parentProfileFields.forEach(field => {
      if (field in updatedData) {
        if (setClauseParentProfile !== '') setClauseParentProfile += ', ';
        setClauseParentProfile += `pp.${field} = ?`;
        values.push(updatedData[field]);
      }
    });
  
    const query = `
      UPDATE 
        PARENT_PROFILE pp
      JOIN 
        STUDENT_PROFILE sp ON  pp.PARENT_ID = sp.PARENT_ID
      SET 
        ${setClauseParentProfile}
      WHERE 
        pp.PARENT_ID = ?
    `;
  
    values.push(studentId);
    const [result] = await schoolDbConnection.query(query, values);

    console.log('PUT /api/parent_Detail_Update: parent deatils updated successfully.');
    res.json({ message: 'parent deatils updated successfully' });

  } catch (err) {
    console.error('Error executing query:', err.message);
    res.status(500).json({ error: 'Database query error' });
  }
});
 
 
 // Route to fetch PerformanceSummary
app.get('/api/PerformanceSummary', async (req, res) => {
  
  try {
    console.log("GET /PerformanceSummary: Fetching PerformanceSummary...");

    // Ensure the database connection is established
    if (!schoolDbConnection) {
      console.log("GET /PerformanceSummary: School database connection not established.");
      return res.status(500).json({ error: "School database connection not established" });
    }
    const { CLASS, ACADEMIC_YEAR, TERM, PERFORMANCE } = req.query;
  let query = `
    SELECT
      STUDENT_ID,
      CLASS,
      ACADEMIC_YEAR,
      TERM,
      COUNT(*) AS student_count,
      TERM_TOTAL,
      PERCENT,
      PERFORMANCE
    FROM
      VW_ACADEMIC_PERFORMACE
  `;
  const queryParams = [];
  const conditions = [];
 
  if (CLASS) {
    conditions.push('CLASS = ?');
    queryParams.push(CLASS);
  }
  if (ACADEMIC_YEAR) {
    conditions.push('ACADEMIC_YEAR = ?');
    queryParams.push(ACADEMIC_YEAR);
  }
  if (TERM) {
    conditions.push('TERM COLLATE utf8mb4_unicode_ci = ?');
    queryParams.push(TERM);
  }
  if (PERFORMANCE) {
    conditions.push('PERFORMANCE = ?');
    queryParams.push(PERFORMANCE);
  }
 
  if (conditions.length > 0) {
    query += ' WHERE ' + conditions.join(' AND ');
  }
  query += ' GROUP BY CLASS, ACADEMIC_YEAR, TERM, PERFORMANCE ORDER BY ACADEMIC_YEAR, TERM, PERFORMANCE';
  const[PerformanceSummarydata] = await schoolDbConnection.query(query,queryParams);

    console.log("GET /PerformanceSummary: PerformanceSummary fetched and formatted successfully.");
    return res.status(200).json(PerformanceSummarydata);

  } catch (err) {
    console.error('Error fetching PerformanceSummary:', err.message);
    return res.status(500).json({ error: 'Internal server error' });
  }
});




 



app.get('/api/staffupdate/:staffId', async (req, res) => {
  try {
    console.log("GET /api/staffupdate: Fetching staff ...");
    if (!schoolDbConnection) {
      console.log("GET /api/staffupdate: School database connection not established.");
      return res.status(500).json({ error: "School database connection not established" });
    }
    
    const staffId = req.params.staffId;
    console.log(staffId);
    const staffupdateSql = `
     SELECT STAFF_ID, STAFF_NAME, CONTACT_NUMBER, STAFF_ROLE, DATE_OF_JOINING, MONTHLY_SALARY,
           FATHER_HUSBAND_NAME, GENDER, EXPERIENCE, ADHAR_ID, RELIGION, EMAIL, EDUCATION, BLOOD_GROUP,
           DATE_OF_BIRTH, ADDRESS, CITY, STATE, POSTAL_CODE, EXIT_DATE, IS_ACTIVE
    FROM STAFF
    WHERE STAFF_ID = ?
  `;

    console.log("GET /api/staffupdate: Executing SQL query:", staffupdateSql);

    const [staffupdateResult] = await schoolDbConnection.query(staffupdateSql, [staffId]);

    console.log("GET /api/studentupdate: Retrieved staffupdate:", staffupdateResult);

    if (staffupdateResult.length === 0) {
      return res.status(404).json({ error: 'Student not found' });
    }

    console.log("GET /api/staffupdate: staffupdateResult successfully.");
    return res.status(200).json(staffupdateResult[0]);

  } catch (err) {
    console.error('Error fetching staffupdateResult:', err.message);
    return res.status(500).json({ error: 'Internal server error' });
  }
});


// Route to update a specific studentupdate by ID
app.put('/api/staffupdate/:staffId', async (req, res) => {
  try {

    console.log("GET /api/staffupdate: Fetching staffupdate ...");
    if (!schoolDbConnection) {
      console.log("GET /api/staffupdate: School database connection not established.");
      return res.status(500).json({ error: "School database connection not established" });
    } const staffId = req.params.staffId;
    const updatedData = req.body;
  
    const staffupdateFields = [
      'STAFF_NAME', 'CONTACT_NUMBER', 'STAFF_ROLE', 'DATE_OF_JOINING', 'MONTHLY_SALARY',
      'FATHER_HUSBAND_NAME', 'GENDER', 'EXPERIENCE', 'ADHAR_ID', 'RELIGION', 'EMAIL', 'EDUCATION', 'BLOOD_GROUP',
      'DATE_OF_BIRTH', 'ADDRESS', 'CITY', 'STATE', 'POSTAL_CODE', 'EXIT_DATE', 'IS_ACTIVE'
    ];
  
    let setClausestaffupdate = '';
    let values = [];
  
    staffupdateFields.forEach(field => {
      if (field in updatedData) {
        if (setClausestaffupdate !== '') setClausestaffupdate += ', ';
        setClausestaffupdate += `${field} = ?`;
        values.push(updatedData[field]);
      }
    });
  
    const query = `
      UPDATE STAFF
      SET ${setClausestaffupdate}
      WHERE STAFF_ID = ?
    `;
  
    values.push(staffId);
  

    const [result] = await schoolDbConnection.query(query, values);

    console.log('PUT /api/staffupdate: staff updated successfully.');
    res.json({ message: 'staff updated successfully' });

  } catch (err) {
    console.error('Error executing query:', err.message);
    res.status(500).json({ error: 'Database query error' });
  }
});




// Route to insert or update student attendance
app.post('/api/studentAttendances', async (req, res) => {
  console.log('Request received to submit attendance:', req.body);

  const attendanceData = req.body;
  console.log('School database 1');
  try {
    // Check if schoolDbConnection is established
    if (!schoolDbConnection) {
      console.log('School database connection not established.');
      return res.status(500).json({ error: 'School database connection not established' });
    }
    console.log('School database 2');
    
    // Use Promise.all to execute multiple queries asynchronously
    const results = await Promise.all(attendanceData.map(async ({ studentId, date, status }) => {
      try {
        console.log('School database 3');
        const checkQuery = 'SELECT * FROM STUDENT_ATTENDANCE WHERE STUDENT_ID = ? AND DATE = ? limit 100';
        const updateQuery = 'UPDATE STUDENT_ATTENDANCE SET STATUS = ? WHERE STUDENT_ID = ? AND DATE = ? limit 100';
        const insertQuery = 'INSERT INTO STUDENT_ATTENDANCE (STUDENT_ID, DATE, STATUS) VALUES (?, ?, ?) limit 100';

        // Check if record exists
        const [rows] = await schoolDbConnection.execute(checkQuery, [studentId, date]);

        if (rows.length > 0) {
          // Record exists, update it
          await schoolDbConnection.execute(updateQuery, [status, studentId, date]);
          console.log('Attendance updated successfully for:', studentId, date);
          return { message: 'Attendance updated successfully' };
        } else {
          // Record does not exist, insert new record
          await schoolDbConnection.execute(insertQuery, [studentId, date, status]);
          console.log('Attendance inserted successfully for:', studentId, date);
          return { message: 'Attendance inserted successfully' };
        }
      } catch (error) {
        console.error('Error processing attendance for:', studentId, date, error);
        throw error; // Propagate error to be caught by Promise.all
      }
    }));
    
    // Send success response
    res.status(200).json(results);
  } catch (error) {
    console.error('Error handling request:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});





// Route to fetch VW_ACADEMIC_MARKSe data joined with VW_ACADEMIC_MARKS

app.get('/api/VWACADEMICMARKS',  async (req, res) => {
  try {
    console.log("GET /VWACADEMICMARKS: Fetching VWACADEMICMARKS...");
    if (!schoolDbConnection) {
      console.log("GET /VWACADEMICMARKS: School database connection not established.");
      return res.status(500).json({ error: "School database connection not established" });
    }

    // fetch classfilterSql
    const VWACADEMICMARKSSql =` select * from VW_ACADEMIC_MARKS`;
    console.log("GET /VWACADEMICMARKS: Executing SQL query:", VWACADEMICMARKSSql);

    const [VWACADEMICMARKSResult] = await schoolDbConnection.query(VWACADEMICMARKSSql);

    console.log("GET /VWACADEMICMARKS: VWACADEMICMARKS fetched successfully.");
    return res.status(200).json(VWACADEMICMARKSResult);

  } catch (err) {
    console.error('Error fetching VWACADEMICMARKS:', err.message);
    return res.status(500).json({ error: 'Internal server error' });
  }
});
 
//for filter this api/classfilter
app.get('/api/classfilter',  async (req, res) => {
  try {
    console.log("GET /classfilter: Fetching classfilter...");
    if (!schoolDbConnection) {
      console.log("GET /classfilter: School database connection not established.");
      return res.status(500).json({ error: "School database connection not established" });
    }

    // fetch classfilterSql
    const classfilterSql =`SELECT DISTINCT class
FROM CLASS_DETAIL
WHERE class != 'Alumni';  `;
    console.log("GET /classfilter: Executing SQL query:", classfilterSql);

    const [classfilterSqlResult] = await schoolDbConnection.query(classfilterSql);

    console.log("GET /classfilter: classfilter fetched successfully.");
    return res.status(200).json(classfilterSqlResult);

  } catch (err) {
    console.error('Error fetching classfilter:', err.message);
    return res.status(500).json({ error: 'Internal server error' });
  }
});



 
//  Route to insert data into insertmarks 
app.post('/api/insertmarks', async (req, res) => {
  const {  STUDENT_ID, SUBJECT_NAME, PERIODIC_TEST_1, NOTE_BOOK_1, SUBJECT_ENRICHMENT_1, HALF_YEARLY,
    WORK_EDUCATION_1, ART_EDUCATION_1, HEALTH_AND_HYGIENE_1, REGULARITY_AND_PUNCTUALLITY_1,
    PERIODIC_TEST_2, NOTE_BOOK_2, SUBJECT_ENRICHMENT_2, ANNUAL, WORK_EDUCATION_2, ART_EDUCATION_2,
    HEALTH_AND_HYGIENE_2, REGULARITY_AND_PUNCTUALLITY_2, term
  } = req.body;

  try {
    console.log("post /insertmarks: insert insertmarks data ...");

    // Check if schoolDbConnection is established
    if (!schoolDbConnection) {
      console.log("post /insertmarks: School database connection not established.");
      return res.status(500).json({ error: "School database connection not established" });
    }
  
    let query;
    let queryParams;
  
    if (term === 'Term 1') {
      query = `
        INSERT INTO MARKS (STUDENT_ID, SUBJECT_NAME, PERIODIC_TEST_1, NOTE_BOOK_1, SUBJECT_ENRICHMENT_1, HALF_YEARLY, 
          WORK_EDUCATION_1, ART_EDUCATION_1, HEALTH_AND_HYGIENE_1, REGULARITY_AND_PUNCTUALLITY_1)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE
          PERIODIC_TEST_1 = VALUES(PERIODIC_TEST_1),
          NOTE_BOOK_1 = VALUES(NOTE_BOOK_1),
          SUBJECT_ENRICHMENT_1 = VALUES(SUBJECT_ENRICHMENT_1),
          HALF_YEARLY = VALUES(HALF_YEARLY),
          WORK_EDUCATION_1 = VALUES(WORK_EDUCATION_1),
          ART_EDUCATION_1 = VALUES(ART_EDUCATION_1),
          HEALTH_AND_HYGIENE_1 = VALUES(HEALTH_AND_HYGIENE_1),
          REGULARITY_AND_PUNCTUALLITY_1 = VALUES(REGULARITY_AND_PUNCTUALLITY_1)
      `;
      queryParams = [
        STUDENT_ID, SUBJECT_NAME, PERIODIC_TEST_1, NOTE_BOOK_1, SUBJECT_ENRICHMENT_1, HALF_YEARLY,
        WORK_EDUCATION_1, ART_EDUCATION_1, HEALTH_AND_HYGIENE_1, REGULARITY_AND_PUNCTUALLITY_1
      ];
    } else if (term === 'Term 2') {
      query = `
        INSERT INTO MARKS (STUDENT_ID, SUBJECT_NAME, PERIODIC_TEST_2, NOTE_BOOK_2, SUBJECT_ENRICHMENT_2, ANNUAL, 
          WORK_EDUCATION_2, ART_EDUCATION_2, HEALTH_AND_HYGIENE_2, REGULARITY_AND_PUNCTUALLITY_2)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE
          PERIODIC_TEST_2 = VALUES(PERIODIC_TEST_2),
          NOTE_BOOK_2 = VALUES(NOTE_BOOK_2),
          SUBJECT_ENRICHMENT_2 = VALUES(SUBJECT_ENRICHMENT_2),
          ANNUAL = VALUES(ANNUAL),
          WORK_EDUCATION_2 = VALUES(WORK_EDUCATION_2),
          ART_EDUCATION_2 = VALUES(ART_EDUCATION_2),
          HEALTH_AND_HYGIENE_2 = VALUES(HEALTH_AND_HYGIENE_2),
          REGULARITY_AND_PUNCTUALLITY_2 = VALUES(REGULARITY_AND_PUNCTUALLITY_2)
      `;
      queryParams = [
        STUDENT_ID, SUBJECT_NAME
        , PERIODIC_TEST_2, NOTE_BOOK_2, SUBJECT_ENRICHMENT_2, ANNUAL,
        WORK_EDUCATION_2, ART_EDUCATION_2, HEALTH_AND_HYGIENE_2, REGULARITY_AND_PUNCTUALLITY_2
      ];
    }
  await schoolDbConnection.query(query, queryParams);

  
  console.log('insertmarks Data inserted successfully.');
  res.json({ message: 'insertmarks Data inserted successfully .' });


} catch (err) {
  console.error('Errorinserting  insertmarks data :', err.message);
  return res.status(500).json({ error: 'Internal server error' });
}
});





// //for filter this api/classfilter
// app.get('/api/promotestudent',  async (req, res) => {
//   try {
//     console.log("GET /classfilter: Fetching classfilter...");
//     if (!schoolDbConnection) {
//       console.log("GET /classfilter: School database connection not established.");
//       return res.status(500).json({ error: "School database connection not established" });
//     }

//     const query = `
//     SELECT stu.STUDENT_ID,
//            CONCAT(stu.FIRST_NAME, ' ', stu.MIDDLE_NAME, ' ', stu.LAST_NAME) AS STUDENT_NAME,
//            cls.SESSION,
//            cls.CLASS,
//            cls.SECTION,
//            mks.PERCENT,
//            mks.STATUS
//     FROM STUDENT_PROFILE stu
//     INNER JOIN CLASS_DETAIL cls ON cls.STUDENT_ID = stu.STUDENT_ID
//     INNER JOIN VW_ACADEMIC_MARKS mks ON stu.STUDENT_ID = mks.STUDENT_ID
//     WHERE cls.SESSION = CONCAT(YEAR(CURDATE()) - 1, '-', YEAR(CURDATE()))
//       AND cls.isPromoted = 'FALSE'
//     GROUP BY stu.STUDENT_ID`;
//     const [promotestudentResult] = await schoolDbConnection.query(query);

//     console.log("GET /promotestudent: promotestudent fetched successfully.");
//     return res.status(200).json(promotestudentResult);

//   } catch (err) {
//     console.error('Error fetching classfilter:', err.message);
//     return res.status(500).json({ error: 'Internal server error' });
//   }
// });






// // Fetch options for filters
// app.get('/api/options', async (req, res) => {
//   const queries = {
//     classes: 'SELECT DISTINCT CLASS FROM CLASS_DETAIL',
//     academicyears: 'SELECT DISTINCT ACADEMIC_YEAR FROM CLASS_DETAIL',
//     statuses: 'SELECT DISTINCT STATUS FROM VW_ACADEMIC_MARKS'
//   };

//   try {
//     // Check database connection
//     if (!schoolDbConnection) {
//       console.log("GET /options: School database connection not established.");
//       return res.status(500).json({ error: "School database connection not established" });
//     }

//     // Execute all queries
//     const results = await Promise.all(
//       Object.values(queries).map(query => schoolDbConnection.query(query))
//     );

//     // Process and map results
//     const [classes, academicyears, statuses] = results.map(result => 
//       result[0].map(row => Object.values(row)[0])
//     );

//     // Send response
//     res.status(200).json({ classes, academicyears, statuses });

//   } catch (err) {
//     console.error('Error fetching options:', err.message);
//     res.status(500).json({ error: 'Database query error' });
//   }
// });




// app.post('/api/promoteStudents', async (req, res) => {
//   const { selectedStudents } = req.body;

//   if (!selectedStudents || !Array.isArray(selectedStudents)) {
//     return res.status(400).json({ error: 'Invalid request data' });
//   }

//   try {
//     // Check if schoolDbConnection is established
//     if (!schoolDbConnection) {
//       console.log('post /promoteStudents: School database connection not established.');
//       return res.status(500).json({ error: 'School database connection not established' });
//     }

//     // Fetch student marks to filter those with PERCENT > 40
//     const getStudentMarksQuery = `SELECT STUDENT_ID, PERCENT FROM VW_ACADEMIC_MARKS WHERE STUDENT_ID IN (?)`;
//     const [marksResults] = await schoolDbConnection.query(getStudentMarksQuery, [selectedStudents]);

//     // Fetch student details (e.g., CLASS, SECTION, ACADEMIC_YEAR) from CLASS_DETAIL
//     const getStudentDetailsQuery = `SELECT STUDENT_ID, CLASS, SECTION, ACADEMIC_YEAR FROM CLASS_DETAIL WHERE STUDENT_ID IN (?)`;
//     const [detailsResults] = await schoolDbConnection.query(getStudentDetailsQuery, [selectedStudents]);

//     const studentDetailsMap = new Map(detailsResults.map(detail => [detail.STUDENT_ID, detail]));

//     // Filter student IDs with PERCENT > 40 and determine next class and session
//     const studentsToPromote = marksResults
//       .filter(student => student.PERCENT > 40)
//       .map(student => {
//         const details = studentDetailsMap.get(student.STUDENT_ID) || {};
//         const currentClass = details.CLASS || 'Unknown';
//         const currentAcademicYear = details.ACADEMIC_YEAR || 'Unknown';

//         let nextClass;
//         let nextAcademicYear;

//         // Determine the next class
//         if (currentClass === '12') {
//           nextClass = 'Alumni';
//         } else if (['LKG', 'UKG'].includes(currentClass)) {
//           nextClass = currentClass === 'LKG' ? 'UKG' : '1';
//         } else if (!isNaN(currentClass)) {
//           nextClass = (parseInt(currentClass, 10) + 1).toString();
//         } else {
//           nextClass = currentClass; // No change if class is unknown
//         }

//         // Determine the next session
//         const [startYear, endYear] = currentAcedemicYear.split('-').map(Number);
//         nextAcademicYear = `${endYear}-${endYear + 1}`;

//         return {
//           id: student.STUDENT_ID,
//           nextClass,
//           section: details.SECTION || 'Unknown',
//           nextAcademicYear
//         };
//       });

//     console.log('Students to promote:', studentsToPromote);

//     if (studentsToPromote.length === 0) {
//       return res.status(404).json({ message: 'No students meet the promotion criteria' });
//     }

//     // Insert new records for promoted students and update isPromoted flag
//     const updateQueries = studentsToPromote.map(student => {
//       const insertQuery = `INSERT INTO CLASS_DETAIL (STUDENT_ID, CLASS, SECTION, ACADEMIC_YEAR)
//         SELECT ?, ?, ?, ?
//         FROM DUAL
//         WHERE NOT EXISTS (
//           SELECT 1
//           FROM CLASS_DETAIL
//           WHERE STUDENT_ID = ? AND CLASS = ? AND SECTION = ? AND ACADEMIC_YEAR = ?
//         )`;

//       const updatePromoteFlagQuery = `UPDATE CLASS_DETAIL SET isPromoted = TRUE WHERE STUDENT_ID = ?`;

//       return new Promise((resolve, reject) => {
//         schoolDbConnection.query(insertQuery, [student.id, student.nextClass, student.section, student.nextAcademicYear, student.id, student.nextClass, student.section, student.nextAcademicYear], (err, result) => {
//           if (err) {
//             console.error('Error executing insert query for student ID:', student.id, err.message);
//             reject(err);
//           } else {
//             schoolDbConnection.query(updatePromoteFlagQuery, [student.id], (updateErr) => {
//               if (updateErr) {
//                 console.error('Error executing update promote flag query for student ID:', student.id, updateErr.message);
//                 reject(updateErr);
//               } else {
//                 resolve(result);
//               }
//             });
//           }
//         });
//       });
//     });

//     await Promise.all(updateQueries);

//     res.json({ message: 'Students promoted successfully' });

//   } catch (err) {
//     console.error('Error promoting students:', err.message);
//     res.status(500).json({ error: 'Internal server error' });
//   }
// });


// // Fail Students Session Update Route
// app.post('/api/changeFailSession', async (req, res) => {
//   const { studentIds, newSession } = req.body;

//   if (!studentIds || !Array.isArray(studentIds) || !newSession) {
//     return res.status(400).json({ error: 'Invalid request data' });
//   }

//   try {
//     // Check if schoolDbConnection is established
//     if (!schoolDbConnection) {
//       console.log('post /changeFailSession: School database connection not established.');
//       return res.status(500).json({ error: 'School database connection not established' });
//     }

//     // Fetch student details
//     const getStudentDetailsQuery = `SELECT STUDENT_ID, CLASS, SECTION FROM CLASS_DETAIL WHERE STUDENT_ID IN (?)`;
//     const [detailsResults] = await schoolDbConnection.query(getStudentDetailsQuery, [studentIds]);

//     // Prepare queries to insert new records with updated session
//     const updateQueries = detailsResults.map(student => {
//       const insertQuery = `INSERT INTO CLASS_DETAIL (STUDENT_ID, CLASS, SECTION, SESSION)
//         SELECT ?, ?, ?, ?
//         FROM DUAL
//         WHERE NOT EXISTS (
//           SELECT 1
//           FROM CLASS_DETAIL
//           WHERE STUDENT_ID = ? AND CLASS = ? AND SECTION = ? AND SESSION = ?
//         )`;

//       return new Promise((resolve, reject) => {
//         schoolDbConnection.query(insertQuery, [student.STUDENT_ID, student.CLASS, student.SECTION, newSession, student.STUDENT_ID, student.CLASS, student.SECTION, newSession], (err, result) => {
//           if (err) {
//             console.error('Error executing insert query for student ID:', student.STUDENT_ID, err.message);
//             reject(err);
//           } else {
//             resolve(result);
//           }
//         });
//       });
//     });

//     await Promise.all(updateQueries);

//     res.json({ message: 'Fail students session updated successfully' });

//   } catch (err) {
//     console.error('Error updating fail students session:', err.message);
//     res.status(500).json({ error: 'Internal server error' });
//   }
// });



// For filter this api/classfilter
app.get('/api/promotestudent',  async (req, res) => {
  try {
    console.log("GET /classfilter: Fetching classfilter...");
    if (!schoolDbConnection) {
      console.log("GET /classfilter: School database connection not established.");
      return res.status(500).json({ error: "School database connection not established" });
    }

    const query = `
    SELECT stu.STUDENT_ID,
           CONCAT(stu.FIRST_NAME, ' ', stu.MIDDLE_NAME, ' ', stu.LAST_NAME) AS STUDENT_NAME,
           cls.ACADEMIC_YEAR,
           cls.CLASS,
           cls.SECTION,
           mks.PERCENT,
           mks.STATUS
    FROM STUDENT_PROFILE stu
    INNER JOIN CLASS_DETAIL cls ON cls.STUDENT_ID = stu.STUDENT_ID
    INNER JOIN VW_ACADEMIC_MARKS mks ON stu.STUDENT_ID = mks.STUDENT_ID
    GROUP BY stu.STUDENT_ID`;
    const [promotestudentResult] = await schoolDbConnection.query(query);

    console.log("GET /promotestudent: promotestudent fetched successfully.");
    return res.status(200).json(promotestudentResult);

  } catch (err) {
    console.error('Error fetching classfilter:', err.message);
    return res.status(500).json({ error: 'Internal server error' });
  }
});


// Fetch options for filters
app.get('/api/options', async (req, res) => {
  const queries = {
    classes: 'SELECT DISTINCT CLASS FROM CLASS_DETAIL',
    academicyears: 'SELECT DISTINCT ACADEMIC_YEAR FROM CLASS_DETAIL',
    statuses: 'SELECT DISTINCT STATUS FROM VW_ACADEMIC_MARKS'
  };

  try {
    // Check database connection
    if (!schoolDbConnection) {
      console.log("GET /options: School database connection not established.");
      return res.status(500).json({ error: "School database connection not established" });
    }

    // Execute all queries
    const results = await Promise.all(
      Object.values(queries).map(query => schoolDbConnection.query(query))
    );

    // Process and map results
    const [classes, academicyears, statuses] = results.map(result => 
      result[0].map(row => Object.values(row)[0])
    );

    // Send response
    res.status(200).json({ classes, academicyears, statuses });

  } catch (err) {
    console.error('Error fetching options:', err.message);
    res.status(500).json({ error: 'Database query error' });
  }
});


// POST: Promote students
app.post('/api/promoteStudents', async (req, res) => {
  const { selectedStudents } = req.body;

  if (!selectedStudents || !Array.isArray(selectedStudents)) {
    return res.status(400).json({ error: 'Invalid request data' });
  }

  try {
    // Check if schoolDbConnection is established
    if (!schoolDbConnection) {
      console.log('post /promoteStudents: School database connection not established.');
      return res.status(500).json({ error: 'School database connection not established' });
    }

    // Fetch student marks to filter those with PERCENT > 40
    const getStudentMarksQuery = `SELECT STUDENT_ID, PERCENT FROM VW_ACADEMIC_MARKS WHERE STUDENT_ID IN (?)`;
    const [marksResults] = await schoolDbConnection.query(getStudentMarksQuery, [selectedStudents]);

    // Fetch student details (e.g., CLASS, SECTION, ACADEMIC_YEAR) from CLASS_DETAIL
    const getStudentDetailsQuery = `SELECT STUDENT_ID, CLASS, SECTION, ACADEMIC_YEAR FROM CLASS_DETAIL WHERE STUDENT_ID IN (?)`;
    const [detailsResults] = await schoolDbConnection.query(getStudentDetailsQuery, [selectedStudents]);

    const studentDetailsMap = new Map(detailsResults.map(detail => [detail.STUDENT_ID, detail]));

    // Filter student IDs with PERCENT > 40 and determine next class and academic year
    const studentsToPromote = marksResults
      .filter(student => student.PERCENT > 40)
      .map(student => {
        const details = studentDetailsMap.get(student.STUDENT_ID) || {};
        const currentClass = details.CLASS || 'Unknown';
        const currentAcademicYear = details.ACADEMIC_YEAR || 'Unknown';

        let nextClass;
        let nextAcademicYear;

        // Determine the next class
        if (currentClass === '12') {
          nextClass = 'Alumni';
        } else if (['LKG', 'UKG'].includes(currentClass)) {
          nextClass = currentClass === 'LKG' ? 'UKG' : '1';
        } else if (!isNaN(currentClass)) {
          nextClass = (parseInt(currentClass, 10) + 1).toString();
        } else {
          nextClass = currentClass; // No change if class is unknown
        }

        // Determine the next academic year
        const [startYear, endYear] = currentAcademicYear.split('-').map(Number);
        nextAcademicYear = `${endYear}-${endYear + 1}`;

        return {
          id: student.STUDENT_ID,
          nextClass,
          section: details.SECTION || 'Unknown',
          nextAcademicYear
        };
      });

    console.log('Students to promote:', studentsToPromote);

    if (studentsToPromote.length === 0) {
      return res.status(404).json({ message: 'No students meet the promotion criteria' });
    }

    // Insert new records for promoted students and update isPromoted flag
    const updateQueries = studentsToPromote.map(student => {
      const insertQuery = `INSERT INTO CLASS_DETAIL (STUDENT_ID, CLASS, SECTION, ACADEMIC_YEAR)
        SELECT ?, ?, ?, ?
        FROM DUAL
        WHERE NOT EXISTS (
          SELECT 1
          FROM CLASS_DETAIL
          WHERE STUDENT_ID = ? AND CLASS = ? AND SECTION = ? AND ACADEMIC_YEAR = ?
        )`;

      const updatePromoteFlagQuery = `UPDATE CLASS_DETAIL SET IS_PROMOTED = TRUE WHERE STUDENT_ID = ?`;

      return new Promise((resolve, reject) => {
        schoolDbConnection.query(insertQuery, [student.id, student.nextClass, student.section, student.nextAcademicYear, student.id, student.nextClass, student.section, student.nextAcademicYear], (err, result) => {
          if (err) {
            console.error('Error executing insert query for student ID:', student.id, err.message);
            reject(err);
          } else {
            schoolDbConnection.query(updatePromoteFlagQuery, [student.id], (updateErr) => {
              if (updateErr) {
                console.error('Error executing update promote flag query for student ID:', student.id, updateErr.message);
                reject(updateErr);
              } else {
                resolve(result);
              }
            });
          }
        });
      });
    });

    await Promise.all(updateQueries);

    res.json({ message: 'Students promoted successfully' });

  } catch (err) {
    console.error('Error promoting students:', err.message);
    res.status(500).json({ error: 'Internal server error' });
  }
});


// POST: Fail Students Session Update Route
app.post('/api/changeFailSession', async (req, res) => {
  const { studentIds, newAcademicYear } = req.body;

  if (!studentIds || !Array.isArray(studentIds) || !newAcademicYear) {
    return res.status(400).json({ error: 'Invalid request data' });
  }

  try {
    // Check if schoolDbConnection is established
    if (!schoolDbConnection) {
      console.log('post /changeFailSession: School database connection not established.');
      return res.status(500).json({ error: 'School database connection not established' });
    }

    // Fetch student details
    const getStudentDetailsQuery = `SELECT STUDENT_ID, CLASS, SECTION FROM CLASS_DETAIL WHERE STUDENT_ID IN (?)`;
    const [detailsResults] = await schoolDbConnection.query(getStudentDetailsQuery, [studentIds]);

    // Prepare queries to insert new records with updated academic year
    const updateQueries = detailsResults.map(student => {
      const insertQuery = `INSERT INTO CLASS_DETAIL (STUDENT_ID, CLASS, SECTION, ACADEMIC_YEAR)
        SELECT ?, ?, ?, ?
        FROM DUAL
        WHERE NOT EXISTS (
          SELECT 1
          FROM CLASS_DETAIL
          WHERE STUDENT_ID = ? AND CLASS = ? AND SECTION = ? AND ACADEMIC_YEAR = ?
        )`;

      return new Promise((resolve, reject) => {
        schoolDbConnection.query(insertQuery, [student.STUDENT_ID, student.CLASS, student.SECTION, newAcademicYear, student.STUDENT_ID, student.CLASS, student.SECTION, newAcademicYear], (err, result) => {
          if (err) {
            console.error('Error executing insert query for student ID:', student.STUDENT_ID, err.message);
            reject(err);
          } else {
            resolve(result);
          }
        });
      });
    });

    await Promise.all(updateQueries);

    res.json({ message: 'Fail students session updated successfully' });

  } catch (err) {
    console.error('Error updating fail students session:', err.message);
    res.status(500).json({ error: 'Internal server error' });
  }
});



// Fetch options for filters
app.get('/api/profile', async (req, res) => {
  console.log("proffile: " ,studentId); 
  try {
    // Check database connection
    if (!schoolDbConnection) {
      console.log("GET /profile: School database connection not established.");
      return res.status(500).json({ error: "School database connection not established" });
    }
    const query = `
    SELECT
      STUDENT_ID,
      CONCAT(FIRST_NAME, ' ', MIDDLE_NAME, ' ', LAST_NAME) AS STUDENT_NAME,
      GENDER,
      CONTACT_NUMBER,
      CITY,
      STATE,
      POSTAL_CODE,
      ACADEMIC_YEAR,
      DATE_OF_BIRTH,
      EMAIL,
      NATIONALITY,
      CAST,
      RELIGION,
      BLOOD_GROUP,
      DISEASE_IF_ANY
    FROM STUDENT_PROFILE
    WHERE
    STUDENT_ID =?
  `;
  console.log('profile ........Executing query:', studentId); // Log the query being executed
  const [profileResult] = await schoolDbConnection.query(query, [studentId]);

  console.log("GET /promotestudent: promotestudent fetched successfully.");
  return res.status(200).json(profileResult);



  } catch (err) {
    console.error('Error fetching options:', err.message);
    res.status(500).json({ error: 'Database query error' });
  }
});
 



// Fetch options for filters
app.get('/api/Studentsummary', async (req, res) => {
  console.log("GET /Studentsummary");
  try {
    // Check database connection
    if (!schoolDbConnection) {
      console.log("GET /Studentsummary: School database connection not established.");
      return res.status(500).json({ error: "School database connection not established" });
    }
    const query = `
    select
STUDENT_ID,
ACADEMIC_YEAR,
CLASS,
SUBJECT,
TERM_1_TOTAL,
HALF_YEARLY_PERFORAMCE,
 TERM_2_TOTAL,
ANNUAL_PERFORMANCE,
GRADE
from VW_ACADEMIC_MARKS
WHERE
  STUDENT_ID = ?
GROUP BY  
  SUBJECT
`;
  console.log('Studentsummary ........Executing query:', studentId); // Log the query being executed
  const [StudentsummaryResult] = await schoolDbConnection.query(query, [studentId]);

  console.log("GET /Studentsummary: Studentsummary fetched successfully.");
  return res.status(200).json(StudentsummaryResult);



  } catch (err) {
    console.error('Error fetching options:', err.message);
    res.status(500).json({ error: 'Database query error' });
  }
});
 






app.get('/api/dashboradstudentattendance', async (req, res) => {
  console.log("GET /dashboradstudentattendance endpoint hit");
  try {
    // Ensure the database connection is established
    if (!schoolDbConnection) {
      console.error("Database connection not established");
      return res.status(500).json({ error: "School database connection not established" });
    }
    
    const query = `
    SELECT
    sa.STUDENT_ID,
    CONCAT(sp.FIRST_NAME, ' ', sp.MIDDLE_NAME, ' ', sp.LAST_NAME) AS STUDENT_NAME,
    cd.CLASS_ID AS CLASS,
    sa.SESSION,
    sa.DATE,
    sa.STATUS
FROM
    STUDENT_ATTENDANCE sa
JOIN
    CLASS_DETAIL cd ON sa.STUDENT_ID = cd.STUDENT_ID
JOIN
    STUDENT_PROFILE sp ON sa.STUDENT_ID = sp.STUDENT_ID
WHERE
    sa.STUDENT_ID = ?
    `;

    console.log('Executing query:', query);
    const [dashboradstudentattendanceResult] = await schoolDbConnection.query(query);

    console.log("Data fetched successfully:", dashboradstudentattendanceResult);
    return res.status(200).json(dashboradstudentattendanceResult);
  } catch (err) {
    console.error('Error fetching options:', err.message);
    res.status(500).json({ error: 'Database query error' });
  }
});


// Edit Form API
app.get('/api/Edit_Form', async (req, res) => {
  

  console.log('GET /Edit_Form');
  try {
    // Check database connection
    if (!schoolDbConnection) {
      console.log("GET /Edit_Form: School database connection not established.");
      return res.status(500).json({ error: "School database connection not established" });
    }
 
    const query = `
      SELECT 
        STUDENT_ID,
        FIRST_NAME,
        CONTACT_NUMBER,
        CITY,
        POSTAL_CODE,
        EMAIL,
        EMERGENCY_CONTACT_NUMBER
      FROM STUDENT_PROFILE
      WHERE STUDENT_ID = ?;
    `;

    const [rows] = await schoolDbConnection.query(query, [studentId]);
    if (rows.length === 0) {
      console.warn(`No data found for student ID: ${studentId}`);
      return res.status(404).json({ error: 'No data found for this student ID' });
    }

    console.log('Data fetched successfully:', rows[0]);
    res.json(rows[0]);
  } catch (err) {
    console.error('Error executing SQL query:', err);
    res.status(500).json({ error: 'Error fetching data', details: err.message });
  }
});

// Submit Edit Request API
app.post('/api/submit-edit-request', async (req, res) => {
  const { STUDENT_ID, FIRST_NAME, TYPE, OLDDATA, NEWDATA, STATUS, ISSUE } = req.body;

  console.log('POST /submit-edit-request');
  try {
    // Check database connection
    if (!schoolDbConnection) {
      console.log("POST /submit-edit-request: School database connection not established.");
      return res.status(500).json({ error: "School database connection not established" });
    }

    const REQUESTER_ID = STUDENT_ID;
    const REQUESTER_TYPE = 'Student';

    const sql = `
      INSERT INTO STUDENT_EDIT_REQUEST 
      (REQUESTER_ID, REQUESTER_TYPE, FIRST_NAME, TYPE, OLDDATA, NEWDATA, STATUS, ISSUE) 
      VALUES (?, ?, ?, ?, ?, ?, ?, ?);
    `;

    const [results] = await schoolDbConnection.query(sql, [REQUESTER_ID, REQUESTER_TYPE, FIRST_NAME, TYPE, OLDDATA, NEWDATA, STATUS, ISSUE]);
    
    res.status(200).json({ message: 'Data inserted successfully', results });
  } catch (error) {
    console.error('Error inserting data:', error);
    res.status(500).json({ error: 'Error inserting data' });
  }
});

// Fetch Student Edit Request API
app.get('/api/student-edit-request', async (req, res) => {
  console.error("student-edit-request call");
  try {
    // Check database connection
    if (!schoolDbConnection) {
      console.log("GET /student-edit-request/:REQUESTER_ID: School database connection not established.");
      return res.status(500).json({ error: "School database connection not established" });
    }
 

    const query = `
      SELECT REQUESTER_ID, FIRST_NAME, ISSUE, REQUEST_ID
      FROM STUDENT_EDIT_REQUEST 
      WHERE STATUS = 'Pending';
    `;

    const [results] = await schoolDbConnection.query(query);
    console.log('Query results:', results);
    res.json(results);
  } catch (error) {
    console.error('Error fetching student edit request:', error);
    res.status(500).send('Server error');
  }
});

// Fetch Student Data API
app.get('/api/student-data', async (req, res) => {
  console.log('GET /student-data');
  try {
    // Check database connection
    if (!schoolDbConnection) {
      console.log("GET /student-data: School database connection not established.");
      return res.status(500).json({ error: "School database connection not established" });
    }

    
    const [rows] = await schoolDbConnection.query(`
      SELECT 
        REQUEST_ID,
        REQUESTER_ID,
        REQUESTER_TYPE,
        FIRST_NAME,
        TYPE,
        OLDDATA,
        NEWDATA,
        STATUS,
        ISSUE
      FROM STUDENT_EDIT_REQUEST
    WHERE STATUS = 'Pending'
    `
);

    res.json(rows);
  } catch (error) {
    console.error('Error fetching student data:', error);
    res.status(500).json({ message: 'Error fetching student data', error });
  }
});

// Update Status API
app.post('/api/update-status', async (req, res) => {
  const { REQUEST_ID, STATUS } = req.body;

  console.log('POST /update-status');
  try {
    // Check database connection
    if (!schoolDbConnection) {
      console.log("POST /update-status: School database connection not established.");
      return res.status(500).json({ error: "School database connection not established" });
    }

    console.log('Received REQUEST_ID:', REQUEST_ID);
    console.log('Received STATUS:', STATUS);

    if (STATUS !== 'Approved' && STATUS !== 'Rejected') {
      console.log('Invalid status received:', STATUS);
      return res.status(400).send('Invalid status');
    }

    const query = `
      UPDATE STUDENT_EDIT_REQUEST 
      SET STATUS = ? 
      WHERE REQUEST_ID = ?;
    `;

    console.log('Executing query:', query, 'with STATUS:', STATUS, 'and REQUEST_ID:', REQUEST_ID);
    const [result] = await schoolDbConnection.query(query, [STATUS, REQUEST_ID]);

    console.log('Query result:', result);

    if (result.affectedRows > 0) {
      res.status(200).send('Status updated successfully');
    } else {
      console.log('Request not found for REQUEST_ID:', REQUEST_ID);
      res.status(404).send('Request not found');
    }
  } catch (error) {
    console.error('Error updating status:', error);
    res.status(500).send('Server error');
  }
});

// Update Student Profile API
app.post('/api/update-student-profile', async (req, res) => {
  const { REQUESTER_ID } = req.body;

  console.log('POST /update-STUDENT_PROFILE');
  try {
    // Check database connection
    if (!schoolDbConnection) {
      console.log("POST /update-STUDENT_PROFILE: School database connection not established.");
      return res.status(500).json({ error: "School database connection not established" });
    }

    if (!REQUESTER_ID) {
      return res.status(400).json({ error: 'REQUESTER_ID is required' });
    }

    console.log('Received REQUESTER_ID:', REQUESTER_ID);

    const query = `
      UPDATE STUDENT_PROFILE sp
      LEFT JOIN (
        SELECT 
          REQUESTER_ID, 
          MAX(CASE WHEN TYPE = 'CONTACT_NUMBER' THEN NEWDATA END) AS CONTACT_NUMBER,
             MAX(CASE WHEN TYPE = 'CITY' THEN NEWDATA END) AS CITY,
          MAX(CASE WHEN TYPE = 'EMAIL' THEN NEWDATA END) AS EMAIL,
          MAX(CASE WHEN TYPE = 'EMERGENCY_CONTACT_NUMBER' THEN NEWDATA END) AS EMERGENCY_CONTACT_NUMBER,
          MAX(CASE WHEN TYPE = 'POSTAL_CODE' THEN NEWDATA END) AS POSTAL_CODE
        FROM STUDENT_EDIT_REQUEST 
        WHERE REQUESTER_ID = ?
        GROUP BY REQUESTER_ID
      ) AS req ON req.REQUESTER_ID = sp.STUDENT_ID
      SET 
        sp.CONTACT_NUMBER = req.CONTACT_NUMBER,
        sp.CITY = req.CITY,
        sp.EMAIL = req.EMAIL,
        sp.EMERGENCY_CONTACT_NUMBER = req.EMERGENCY_CONTACT_NUMBER,
        sp.POSTAL_CODE = req.POSTAL_CODE
      WHERE sp.STUDENT_ID = ?;
    `;

    const [result] = await schoolDbConnection.query(query, [REQUESTER_ID, REQUESTER_ID]);

    if (result.affectedRows > 0) {
      res.status(200).send('Student profile updated successfully');
    } else {
      res.status(404).send('No profile found for the provided REQUESTER_ID');
    }
  } catch (error) {
    console.error('Error updating student profile:', error);
    res.status(500).send('Server error');
  }
});



// API endpoint to get marks filter
app.get('/api/marksfilter', async (req, res) => {
  console.log('GET /marksfilter');
  try {
    // Check school database connection
    if (!schoolDbConnection) {
      console.log("GET /marksfilter: School database connection not established.");
      return res.status(500).json({ error: "School database connection not established" });
    }

    const query = `
    SELECT
    sp.STUDENT_ID,            
    cd.CLASS ,
    cd.CLASS_ID,                
    s.SUBJECT_NAME,              
    td.TEACHER_ID,               
    td.TEACHER_NAME  from
    STUDENT_PROFILE sp
JOIN
    CLASS_DETAIL cd ON cd.STUDENT_ID = sp.STUDENT_ID  
JOIN
    SUBJECT s ON s.CLASS = cd.CLASS                 
JOIN
    TEACHER_DETAIL td ON s.SUBJECT_NAME = td.SUBJECT
    AND cd.CLASS_ID = td.CLASS_ID   
WHERE
    td.TEACHER_ID = 'TID-09002' and  td.CLASS_ID='LKG A'                   
ORDER BY
    cd.CLASS_ID, cd.CLASS ,s.SUBJECT_NAME, sp.STUDENT_ID  `;

    const [rows] = await schoolDbConnection.query(query);
    res.json(rows);
  } catch (error) {
    console.error('Error fetching marks filter data:', error);
    res.status(500).json({ message: 'Error fetching marks filter data', error });
  }
});

 

// API endpoint to fetch class schedule
app.get('/api/schedule', async (req, res) => {
  console.log('GET /schedule');
  try {
    // Check school database connection
    if (!schoolDbConnection) {
      console.log("GET /schedule: School database connection not established.");
      return res.status(500).json({ error: "School database connection not established" });
    }

    const query = `
       SELECT A.CLASS_ID,PERIOD,TIME_SLOT,
       MAX(CASE WHEN DAY = 'Monday' THEN B.SUBJECT END) AS 'MONDAY',
       MAX(CASE WHEN DAY = 'Tuesday' THEN B.SUBJECT END) AS 'TUESDAY',
       MAX(CASE WHEN DAY = 'Wednesday' THEN B.SUBJECT END) AS 'WEDNESDAY',
       MAX(CASE WHEN DAY = 'Thursday' THEN B.SUBJECT END) AS 'THURSDAY',
       MAX(CASE WHEN DAY = 'Friday' THEN B.SUBJECT END) AS 'FRIDAY',
       MAX(CASE WHEN DAY = 'Saturday' THEN B.SUBJECT END) AS 'SATURDAY',
       B.SUBJECT 
FROM CLASS_SCHEDULE A
INNER JOIN TEACHER_DETAIL B ON A.CLASS_ID = B.CLASS_ID
AND A.SUBJECT = B.SUBJECT
WHERE TEACHER_NAME ='KRISTOPHER CASTILLO'
GROUP BY
   CLASS_ID,PERIOD, TIME_SLOT
ORDER BY DAY_ID, PERIOD  ASC
    `;

    const [rows] = await schoolDbConnection.query(query);
    res.json(rows);
  } catch (error) {
    console.error('Error fetching staff schedule:', error);
    res.status(500).json({ message: 'Error fetching staff schedule', error });
  }
});


// Fetch Assignment Data
app.get('/api/assignmentform', async (req, res) => {
  try {
    console.log("GET /api/assignment: Fetching assignment data...");
    
    if (!schoolDbConnection) {
      console.log("GET /api/assignment: School database connection not established.");
      return res.status(500).json({ error: "School database connection not established" });
    }

    const assignmentSql = `
      SELECT
        cd.CLASS_ID,
        s.SUBJECT_NAME
      FROM STUDENT_PROFILE sp
      JOIN CLASS_DETAIL cd ON cd.STUDENT_ID = sp.STUDENT_ID
      JOIN SUBJECT s ON s.CLASS = cd.CLASS
      LEFT JOIN TEACHER_DETAIL td ON s.SUBJECT_NAME = td.SUBJECT
                                AND cd.CLASS_ID = td.CLASS_ID
      LEFT JOIN STAFF s2 ON td.TEACHER_ID = s2.STAFF_ID
      GROUP BY cd.CLASS_ID, s.SUBJECT_NAME
    `;

    const [assignmentResult] = await schoolDbConnection.query(assignmentSql);
    return res.status(200).json(assignmentResult);

  } catch (err) {
    console.error('Error fetching assignment:', err);
    return res.status(500).json({ error: 'Internal server error' });
  }
});

// Insert Assignment Data
app.post('/api/assignmentformdata', async (req, res) => {
  try {
    if (!schoolDbConnection) {
      return res.status(500).json({ error: "School database connection not established" });
    }

    const {
      Class, AssignmentType, Subject, AssignmentDescription,
      StartDate, SubmissionStartDate, SubmissionEndDate
    } = req.body;

    if (!Class || !AssignmentType || !Subject || !AssignmentDescription || !StartDate || !SubmissionStartDate || !SubmissionEndDate) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    const fetchStudentIdsQuery = 'SELECT STUDENT_ID FROM CLASS_DETAIL WHERE CLASS_ID = ?';
    const [studentResults] = await schoolDbConnection.query(fetchStudentIdsQuery, [Class]);

    if (studentResults.length === 0) {
      return res.status(404).json({ message: 'No students found for the given class' });
    }

    const insertAssignmentQuery = `
      INSERT INTO STUDENT_ASSIGNMENT 
      (STUDENT_ID, CLASS_ID, ASSIGNMENT_TYPE, SUBJECT_NAME, ASSIGNMENT_DESC, START_DATE, SUBMISSION_START_DATE, SUBMISSION_END_DATE)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `;

    const insertPromises = studentResults.map(async (row) => {
      const values = [
        row.STUDENT_ID, Class, AssignmentType, Subject,
        AssignmentDescription, StartDate, SubmissionStartDate, SubmissionEndDate
      ];
      return schoolDbConnection.query(insertAssignmentQuery, values);
    });

    const results = await Promise.all(insertPromises);
    const successfulInsertions = results.filter(result => result.affectedRows > 0).length;

    res.json({ message: 'Assignment Data inserted successfully.', insertedRecords: successfulInsertions });

  } catch (err) {
    console.error('Error inserting assignment data:', err.message);
    res.status(500).json({ error: 'Internal server error', details: err.message });
  }
});

// Fetch Assignment List
app.get('/api/assignmentlist', async (req, res) => {
  try {
    if (!schoolDbConnection) {
      return res.status(500).json({ error: "School database connection not established" });
    }

    const assignmentlistSql = `
      SELECT
        sp.STUDENT_ID,
        CONCAT(sp.FIRST_NAME, ' ', COALESCE(sp.MIDDLE_NAME, ''), ' ', sp.LAST_NAME) AS STUDENT_NAME,
        cd.CLASS_ID, td.TEACHER_NAME AS CLASS_TEACHER, s.SUBJECT_NAME, 
        sa.ASSIGNMENT_TYPE, sa.ASSIGNMENT_DESC, sa.SUBMISSION_START_DATE, sa.SUBMISSION_END_DATE, 
        sa.IS_SUBMITTED, sa.STATUS, GROUP_CONCAT(sa.ASSIGNMENT_DESC SEPARATOR ', ') AS ASSIGNMENTS,
         MAX(sa.SUBMISSION_END_DATE) AS SUBMISSION_END_DATE
      FROM STUDENT_PROFILE sp
      JOIN CLASS_DETAIL cd ON cd.STUDENT_ID = sp.STUDENT_ID
      JOIN STUDENT_ASSIGNMENT sa ON sp.STUDENT_ID = sa.STUDENT_ID AND cd.CLASS_ID = sa.CLASS_ID
      JOIN SUBJECT s ON s.CLASS = cd.CLASS AND s.SUBJECT_NAME = sa.SUBJECT_NAME
      JOIN TEACHER_DETAIL td ON s.SUBJECT_NAME = td.SUBJECT AND cd.CLASS_ID = td.CLASS_ID
      GROUP BY s.SUBJECT_NAME, td.TEACHER_NAME, sp.STUDENT_ID, sp.FIRST_NAME, sp.MIDDLE_NAME, sp.LAST_NAME, cd.CLASS_ID
    `;

    const [assignmentlistResult] = await schoolDbConnection.query(assignmentlistSql);
    return res.status(200).json(assignmentlistResult);

  } catch (err) {
    console.error('Error fetching assignment list:', err.message);
    return res.status(500).json({ error: 'Internal server error' });
  }
});

// Update Assignment Data
app.put('/api/assignmentupdate/:studentId', async (req, res) => {
  try {
    const studentId = req.params.studentId;
    const { IS_SUBMITTED, STATUS, SUBMISSION_DATE } = req.body;

    if (!schoolDbConnection) {
      return res.status(500).json({ error: "School database connection not established" });
    }

    if (typeof IS_SUBMITTED === 'undefined' || typeof STATUS === 'undefined' || typeof SUBMISSION_DATE === 'undefined') {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    const query = `
      UPDATE STUDENT_ASSIGNMENT
      SET IS_SUBMITTED = ?, STATUS = ?, SUBMISSION_DATE = ?
      WHERE STUDENT_ID = ?
    `;
    
    await schoolDbConnection.query(query, [IS_SUBMITTED, STATUS, SUBMISSION_DATE, studentId]);

    res.json({ message: 'Assignment updated successfully' });

  } catch (err) {
    console.error('Error updating assignment:', err.message);
    res.status(500).json({ error: 'Database query error' });
  }
});

// Fetch Assignment Table Data
app.get('/api/assignmenttable', async (req, res) => {
  try {
    if (!schoolDbConnection) {
      return res.status(500).json({ error: "School database connection not established" });
    }

    const assignmenttableSql = `
      SELECT 
        START_DATE, CLASS_ID, SUBJECT_NAME, ASSIGNMENT_TYPE, ASSIGNMENT_DESC, 
        SUBMISSION_START_DATE, SUBMISSION_END_DATE,
        (SELECT COUNT(*) FROM STUDENT_ASSIGNMENT sa WHERE sa.STATUS = 'Yes' AND sa.CLASS_ID = a.CLASS_ID) AS SUBMITTED, 
        (SELECT COUNT(*) FROM STUDENT_ASSIGNMENT sa WHERE sa.STATUS = 'No' AND sa.CLASS_ID = a.CLASS_ID) AS NOT_SUBMITTED
      FROM STUDENT_ASSIGNMENT a
      GROUP BY CLASS_ID, SUBJECT_NAME, ASSIGNMENT_TYPE, ASSIGNMENT_DESC
    `;

    const [assignmenttableResult] = await schoolDbConnection.query(assignmenttableSql);
    return res.status(200).json(assignmenttableResult);

  } catch (err) {
    console.error("Error fetching assignment table:", err);
    return res.status(500).json({ error: "Internal server error" });
  }
});



// API Endpoint to get all class data
app.get('/api/schedule_class', async (req, res) => {
  try {
    if (!schoolDbConnection) {
      return res.status(500).json({ error: "School database connection not established" });
    }

    const sql = `SELECT DISTINCT CLASS_ID FROM CLASS_SCHEDULE`;

    const [result] = await schoolDbConnection.query(sql);
    if (!result.length) {
      return res.status(404).json({ message: 'No class data found' });
    }

    console.log('Data fetched successfully:', result);
    return res.json(result);

  } catch (err) {
    console.error('Error fetching class data:', err.message);
    return res.status(500).json({ error: 'An error occurred while fetching data' });
  }
});

// API Endpoint to get data by selected class
app.get('/api/class_data', async (req, res) => {
  const selectedClass = req.query.class; // Get the selected class from query params

  if (!selectedClass) {
    return res.status(400).json({ message: 'Class parameter is required' });
  }

  try {
    if (!schoolDbConnection) {
      return res.status(500).json({ error: "School database connection not established" });
    }

    const sql = `
    SELECT
    PERIOD,
    TIME_SLOT,
    CLASS_ID,
    MAX(CASE WHEN DAY = 'MONDAY' THEN SUBJECT END) AS Monday,
    MAX(CASE WHEN DAY = 'TUESDAY' THEN SUBJECT END) AS Tuesday,
    MAX(CASE WHEN DAY = 'WEDNESDAY' THEN SUBJECT END) AS Wednesday,
    MAX(CASE WHEN DAY = 'THURSDAY' THEN SUBJECT END) AS Thursday,
    MAX(CASE WHEN DAY = 'FRIDAY' THEN SUBJECT END) AS Friday,
    MAX(CASE WHEN DAY = 'SATURDAY' THEN SUBJECT END) AS Saturday
  FROM
    CLASS_SCHEDULE sc
 WHERE
    sc.CLASS_ID = ?
  GROUP BY
    sc.PERIOD, sc.TIME_SLOT, sc.CLASS_ID
  ORDER BY
    sc.PERIOD;`

    const [result] = await schoolDbConnection.query(sql, [selectedClass]);
    if (!result.length) {
      return res.status(404).json({ message: 'No data found for the selected class' });
    }

    console.log('Class data fetched successfully:', result);
    return res.json(result);

  } catch (err) {
    console.error('Error fetching class data:', err.message);
    return res.status(500).json({ error: 'An error occurred while fetching data' });
  }
});

// Fetch Staff Assignment Dashboard
app.get('/api/StaffAssignmentDashboard', async (req, res) => {
  try {

    
    if (!schoolDbConnection) {
      return res.status(500).json({ error: "School database connection not established" });
    }
 
    const staffAssignmentSql = `
     SELECT  
    CONCAT(sp.FIRST_NAME, ' ', sp.LAST_NAME) AS STUDENT_NAME,
    td.CLASS_ID,
AG.ASSIGNMENT_TYPE ,
AG.SUBJECT_NAME,
AG.ASSIGNMENT_DESC,
    COUNT(CASE WHEN AG.SUBMISSION_END_DATE <= CURDATE() AND AG.SUBMISSION_END_DATE >= CURDATE() THEN 1 ELSE NULL END) AS OnTimeAssignments,
    COUNT(CASE WHEN AG.SUBMISSION_END_DATE < CURDATE() THEN 1 ELSE NULL END) AS LateAssignments,
    COUNT(CASE WHEN AG.SUBMISSION_END_DATE > CURDATE() THEN 1 ELSE NULL END) AS UpcomingAssignments
FROM
    STUDENT_ASSIGNMENT AG
JOIN
    TEACHER_DETAIL td ON td.CLASS_ID = AG.CLASS_ID
JOIN 
    STUDENT_PROFILE sp ON sp.STUDENT_ID = AG.STUDENT_ID 
WHERE
    td.TEACHER_ID = ?
GROUP BY
    td.CLASS_ID, STUDENT_NAME,AG.ASSIGNMENT_TYPE ,
AG.SUBJECT_NAME,
AG.ASSIGNMENT_DESC;
 
`;
 
    const [staffAssignmentResult] = await schoolDbConnection.query(staffAssignmentSql,[userstaffId]);
    return res.status(200).json(staffAssignmentResult);
 
  } catch (err) {
    console.error('Error fetching staff assignment dashboard:', err.message);
    return res.status(500).json({ error: 'Internal server error' });
  }
});

 
// Fetch Student Information for Assignment
app.get('/api/StudentInformationForAssignment', async (req, res) => {
  try {
    if (!schoolDbConnection) {
      return res.status(500).json({ error: "School database connection not established" });
    }
 
    const studentInfoSql = `
      SELECT  sp.STUDENT_ID,
CONCAT(FIRST_NAME, ' ', LAST_NAME) AS STUDNET_NAME,
    td.CLASS_ID,
AG.ASSIGNMENT_TYPE ,
AG.SUBJECT_NAME,
AG.ASSIGNMENT_DESC,
 
    COUNT(CASE WHEN AG.SUBMISSION_START_DATE <= CURDATE() AND AG.SUBMISSION_END_DATE >= CURDATE() THEN 1 ELSE NULL END) AS OnTimeAssignments,
    COUNT(CASE WHEN AG.SUBMISSION_END_DATE < CURDATE() THEN 1 ELSE NULL END) AS LateAssignments,
    COUNT(CASE WHEN AG.SUBMISSION_START_DATE > CURDATE() THEN 1 ELSE NULL END) AS UpcomingAssignments
FROM
    STUDENT_ASSIGNMENT AG
JOIN
    TEACHER_DETAIL td ON td.CLASS_ID = AG.CLASS_ID
join STUDENT_PROFILE sp on sp.STUDENT_ID = AG.STUDENT_ID 
GROUP BY
    td.CLASS_ID,STUDNET_NAME;
 
`;
 
    const [studentInfoResult] = await schoolDbConnection.query(studentInfoSql);
    return res.status(200).json(studentInfoResult);
 
  } catch (err) {
    console.error('Error fetching student information for assignment:', err.message);
    return res.status(500).json({ error: 'Internal server error' });
  }
});

// Fetch Assignment Dashboard

app.get('/api/ASSIGNMENTDASH', async (req, res) => {

  try {

    if (!schoolDbConnection) {

      return res.status(500).json({ error: "School database connection not established" });

    }
 
    const assignmentDashSql = `

      SELECT 

        ASSIGNMENT_TYPE,

        SUBJECT,

        SUBMISSION_END_DATE,

        CONCAT(cd.CLASS, ' ', cd.SECTION) AS ClassSection,

        COUNT(CASE WHEN sa.STATUS = 'On time' THEN 1 END) AS OnTimeCount,

        COUNT(CASE WHEN sa.STATUS = 'Late' THEN 1 END) AS LateCount

      FROM 

        STUDENT_ASSIGNMENT sa

      JOIN 

        CLASS_DETAIL cd ON sa.STUDENT_ID = cd.STUDENT_ID

    `;
 
    const [assignmentDashResult] = await schoolDbConnection.query(assignmentDashSql);

    return res.status(200).json(assignmentDashResult);
 
  } catch (err) {

    console.error('Error fetching assignment dashboard data:', err.message);

    return res.status(500).json({ error: 'Internal server error' });

  }

});


app.get('/api/get-assignmentoverview-data', (req, res) => {
  // Check if the database connection is established
  if (!schoolDbConnection) {
    console.error('Failed to establish a connection to the schooldb database.');
    return res.status(500).json({ error: 'Database connection failed' });
  }
 
  console.log('School database connection not established.'); // Log successful connection
 
  const query = `
    SELECT  
      ut.ASSIGNMENT_ID,
      ut.STUDENT_ID,
      sa.STUDENT_NAME,
      sa.CLASS_ID,
      sa.SUBJECT_NAME,
      sa.SUBMISSION_START_DATE,
      sa.SUBMISSION_END_DATE,
      sa.SUBMISSION_DATE,
      sa.IS_SUBMITTED,
      sa.STATUS AS STUDENT_STATUS,  
      ut.STATUS
    FROM USER_TABLE ut
    JOIN STUDENT_ASSIGNMENT sa ON sa.ASSIGNMENT_ID = ut.ASSIGNMENT_ID;
  `;
 
  console.log('Executing query:', query); // Log the query being executed
 
  schoolDbConnection.query(query, (err, results) => {
    if (err) {
      console.error('Error executing the query:', err); // Log any errors from the query
      return res.status(500).json({ error: 'Database query failed' });
    }
   
    console.log('Query executed successfully.'); // Log success message
    console.log('Query Results:', results); // Log the query results
    res.json(results); // Send the results as JSON
  });
});
 

 
// Fetch Staff Dashboard

app.get('/api/STAFFDASHBOARD', async (req, res) => {

  try {

    if (!schoolDbConnection) {

      return res.status(500).json({ error: "School database connection not established" });

    }
 
    const staffDashboardSql = `

      SELECT 

        COUNT(CASE WHEN a.status = 'PRESENT' THEN 1 END) AS present_count,

        COUNT(CASE WHEN a.status = 'ABSENT' THEN 1 END) AS absent_count,

        COUNT(CASE WHEN a.status = 'LEAVE' THEN 1 END) AS leave_count,

        COUNT(a.status) AS total_count

      FROM STAFF_ATTENDANCE a

      WHERE a.STAFF_ID = 'ACID-09003'

    `;
 
    const [staffDashboardResult] = await schoolDbConnection.query(staffDashboardSql);

    const { present_count, absent_count, leave_count, total_count } = staffDashboardResult[0];
 
    // Calculate percentages

    const present_percentage = total_count ? (present_count / total_count) * 100 : 0;

    const absent_percentage = total_count ? (absent_count / total_count) * 100 : 0;

    const leave_percentage = total_count ? (leave_count / total_count) * 100 : 0;
 
    return res.status(200).json({

      present_count,

      absent_count,

      leave_count,

      present_percentage: present_percentage.toFixed(2),

      absent_percentage: absent_percentage.toFixed(2),

      leave_percentage: leave_percentage.toFixed(2)

    });
 
  } catch (err) {

    console.error('Error fetching staff dashboard data:', err.message);

    return res.status(500).json({ error: 'Internal server error' });

  }

});


// API Endpoint to fetch Joining Latter For Teacher data
app.get('/api/JoiningLatter', async (req, res) => {
  try {
    if (!schoolDbConnection) {
      return res.status(500).json({ error: "School database connection not established" });
    }

    const sql = `
     SELECT 
    s.STAFF_ID,
    s.CONTACT_NUMBER,
    s.EMAIL,
    (SELECT s2.STAFF_NAME
     FROM STAFF s2
     WHERE s2.STAFF_ROLE = 'PRINCIPAL'
     LIMIT 1) AS PRINCIPAL_NAME,  -- Get the principal's name once
    s.STAFF_ROLE,
    s.DATE_OF_JOINING,
    s.MONTHLY_SALARY,
    td.TEACHER_NAME,
    sd.SCHOOL_NAME,
    sd.ADDRESS,
    sd.CITY,
    sd.POSTAL_CODE,
s.STAFF_INITIALS
FROM
    STAFF s
LEFT JOIN
    TEACHER_DETAIL td ON s.STAFF_ID = td.TEACHER_ID
JOIN
    SCHOOL_DETAILS sd ON 1=1
WHERE
    s.STAFF_ROLE IN ('TEACHER')  -- Only select teachers for the main query
GROUP BY
    s.CONTACT_NUMBER,          -- Add this to the GROUP BY clause
    s.EMAIL,                   -- Add this to the GROUP BY clause
    td.TEACHER_NAME,           -- Group by teacher name to ensure uniqueness
    s.STAFF_ROLE,
    s.DATE_OF_JOINING,
    s.MONTHLY_SALARY,
    sd.SCHOOL_NAME;
`;


    const [results] = await schoolDbConnection.query(sql);
    if (!results.length) {
      return res.status(404).json({ message: 'No data found for the selected teachers' });
    }

    console.log('Joining Latter For Teacher data fetched successfully:', results);
    return res.json(results);

  } catch (err) {
    console.error('Error fetching Joining Latter For Teacher data:', err.message);
    return res.status(500).json({ error: 'An error occurred while fetching data' });
  }
});

// Fetch assignment data
app.get('/api/assignment', async (req, res) => {
  try {
    console.log("GET /api/assignment: Fetching assignment data...");
    if (!schoolDbConnection) {
      console.log("GET /api/assignment: School database connection not established.");
      return res.status(500).json({ error: "School database connection not established" });
    }

    const assignmentSql = `  
       SELECT
    cd.CLASS_ID ,
    s.SUBJECT_NAME
   -- td.TEACHER_NAME
FROM
    STUDENT_PROFILE sp
JOIN
    CLASS_DETAIL cd ON cd.STUDENT_ID = sp.STUDENT_ID
JOIN
    SUBJECT s ON s.CLASS= cd.CLASS  
LEFT JOIN
    TEACHER_DETAIL td ON s.SUBJECT_NAME = td.SUBJECT AND cd.CLASS_ID = td.CLASS_ID
left join   STAFF s2  ON td.TEACHER_ID  = s2.STAFF_ID
group by cd.CLASS_ID  ,s.SUBJECT_NAME
    `;

    console.log("GET /api/assignment: Executing SQL query:", assignmentSql);
    const [assignmentResult] = await schoolDbConnection.query(assignmentSql);
    console.log("GET /api/assignment: Assignments fetched successfully:", assignmentResult);
    return res.status(200).json(assignmentResult);

  } catch (err) {
    console.error('Error fetching assignment:', err);
    return res.status(500).json({ error: 'Internal server error' });
  }
});



// Insert assignment data
app.post('/api/assignmentdata', async (req, res) => {
  console.log("POST /api/assignmentdata: Inserting assignment data...");
  const { Class, AssignmentType, Subject, AssignmentDescription, SubmissionStartDate, SubmissionEndDate } = req.body;

  try {
    if (!schoolDbConnection) {
      return res.status(500).json({ error: "Database connection not established" });
    }

    if (!Class || !AssignmentType || !Subject || !AssignmentDescription || !SubmissionStartDate || !SubmissionEndDate) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    const fetchStudentIdsQuery = 'SELECT STUDENT_ID FROM CLASS_DETAIL WHERE CLASS_ID = ?';
    const [studentResults] = await schoolDbConnection.query(fetchStudentIdsQuery, [Class]);
    if (studentResults.length === 0) {
      return res.status(404).json({ message: 'No students found for the given class' });
    }

    const fetchMaxAssignmentIdQuery = 'SELECT MAX(ASSIGNMENT_ID) AS MAX_ASSIGNMENT_ID FROM STUDENT_ASSIGNMENT';
    const [assignmentIdResult] = await schoolDbConnection.query(fetchMaxAssignmentIdQuery);
    const newAssignmentId = (assignmentIdResult[0]?.MAX_ASSIGNMENT_ID || 0) + 1;

    const insertAssignmentQuery = `
       INSERT INTO STUDENT_ASSIGNMENT
      (ASSIGNMENT_ID, STUDENT_ID, CLASS_ID, ASSIGNMENT_TYPE, SUBJECT_NAME, ASSIGNMENT_DESC, SUBMISSION_START_DATE, SUBMISSION_END_DATE)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `;

    const insertPromises = studentResults.map(row => {
      const values = [
        newAssignmentId, row.STUDENT_ID, Class, AssignmentType, Subject,
        AssignmentDescription, SubmissionStartDate, SubmissionEndDate
      ];
      return schoolDbConnection.query(insertAssignmentQuery, values);
    });

    const results = await Promise.all(insertPromises);
    const successfulInsertions = results.filter(result => result.affectedRows > 0).length;

    console.log('Assignment data inserted successfully.', successfulInsertions);
    return res.json({ message: 'Assignment data inserted successfully.', insertedRecords: successfulInsertions });

  } catch (err) {
    console.error('Error inserting assignment data:', err.sqlMessage || err.message);
    return res.status(500).json({ error: 'Internal server error', details: err.sqlMessage || err.message });
  }
});
// Update submission dates

app.get('/api/get-assignment-data', async (req, res) => {
  try {
      if (!schoolDbConnection) {
          console.log("School database connection not established.");
          return res.status(500).json({ error: "School database connection not established" });
      }
 
      const query = `
          SELECT
    ut.ASSIGNMENT_ID,
    ut.STUDENT_ID,
    CONCAT(sp.FIRST_NAME, ' ', COALESCE(sp.MIDDLE_NAME, ''), ' ', sp.LAST_NAME) AS STUDENT_NAME,
    sa.CLASS_ID,
    sa.SUBJECT_NAME,
    td.TEACHER_NAME AS CLASS_TEACHER,
    sa.ASSIGNMENT_TYPE,
    sa.ASSIGNMENT_DESC,
    sa.SUBMISSION_START_DATE,
    sa.SUBMISSION_END_DATE,
    ut.STATUS AS TeacherApprovalStatus,
    ut.STUDENT_SUBMITTED_DATE,
    sa.SUBMISSION_DATE,
    sa.IS_SUBMITTED,
    sa.STUDENT_STATUS
FROM USER_TABLE ut
JOIN STUDENT_ASSIGNMENT sa ON ut.STUDENT_ID = sa.STUDENT_ID AND sa.ASSIGNMENT_ID = ut.ASSIGNMENT_ID
LEFT JOIN STUDENT_PROFILE sp ON sp.STUDENT_ID = ut.STUDENT_ID
LEFT JOIN CLASS_DETAIL cd ON cd.STUDENT_ID = sp.STUDENT_ID
LEFT JOIN TEACHER_DETAIL td ON sa.SUBJECT_NAME = td.SUBJECT AND cd.CLASS_ID = td.CLASS_ID
where ut.STATUS = 'PENDING'
`;
 
      const [rows] = await schoolDbConnection.query(query);
      return res.status(200).json(rows);
  } catch (error) {
      console.error("Error fetching assignment data:", error); // Log full error object
      return res.status(500).json({ error: "Error fetching assignment data", details: error.message });
  }
});
 // Update submission dates


app.post('/api/teacher-approval', async (req, res) => {
  const { assignmentId, studentId, submittedDate, status } = req.body;
 
  if (!schoolDbConnection) {
      console.log("School database connection not established.");
      return res.status(500).json({ error: "Database connection not established" });
  }
 
  try {
    if (status === 'APPROVED') {
        await schoolDbConnection.query(`UPDATE STUDENT_ASSIGNMENT SET SUBMISSION_DATE = ?, SUBMITTED = 1 WHERE ASSIGNMENT_ID = ?`, [submittedDate, assignmentId]);
        await schoolDbConnection.query(`UPDATE USER_TABLE SET STATUS = 'APPROVED' WHERE ASSIGNMENT_ID = ?`, [assignmentId]);
    } else if (status === 'CANCEL') {
        await schoolDbConnection.query(`UPDATE USER_TABLE SET STATUS = 'CANCEL' WHERE ASSIGNMENT_ID = ?`, [assignmentId]);
    }
 
      res.status(200).send({ message: "Update successful!" });
  } catch (error) {
      console.error("Error updating assignment status:", error.message);  // Log the actual error message
      res.status(500).json({ error: "Internal server error" });
  }
});
//

// Update submission dates
app.put('/api/updateSubmissionDates', async (req, res) => {
  const updates = req.body;
  console.log("PUT /api/updateSubmissionDates: Updating submission dates...");

  try {
    if (!schoolDbConnection) {
      console.log("PUT /api/updateSubmissionDates: School database connection not established.");
      return res.status(500).json({ error: "School database connection not established" });
    }

    for (const update of updates) {
      const { assignmentId, studentId } = update;
      const updateSql = `
        UPDATE STUDENT_ASSIGNMENT sa
        JOIN USER_TABLE u ON sa.ASSIGNMENT_ID = u.ASSIGNMENT_ID AND sa.STUDENT_ID = u.STUDENT_ID
        SET sa.SUBMISSION_DATE = u.STUDENT_SUBMITTED_DATE
        WHERE sa.ASSIGNMENT_ID = ?
      `;
      const [result] = await schoolDbConnection.query(updateSql, [assignmentId, studentId]);
      console.log(`Updated rows for Assignment ID ${assignmentId} and Student ID ${studentId}:`, result.affectedRows);
    }

    return res.status(200).json({ message: 'Submission dates updated successfully for all provided students.' });

  } catch (error) {
    console.error('Error updating submission dates:', error);
    return res.status(500).json({ error: 'Internal server error' });
  }
});

// Fetch assignment record with detailed student and teacher info
app.get('/api/get-assignmentrecord', async (req, res) => {
  try {
    if (!schoolDbConnection) {
      console.log("School database connection not established.");
      return res.status(500).json({ error: "School database connection not established" });
    }

    const query = `
      SELECT
    ut.ASSIGNMENT_ID,
    ut.STUDENT_ID,
    CONCAT(sp.FIRST_NAME, ' ', COALESCE(sp.MIDDLE_NAME, ''), ' ', sp.LAST_NAME) AS STUDENT_NAME,
    sa.CLASS_ID,
    sa.SUBJECT_NAME,
    td.TEACHER_NAME AS CLASS_TEACHER,
    sa.ASSIGNMENT_TYPE,
    sa.ASSIGNMENT_DESC,
    sa.SUBMISSION_START_DATE,
    sa.SUBMISSION_END_DATE,
    ut.STATUS AS TeacherApprovalStatus,
    ut.STUDENT_SUBMITTED_DATE,
    sa.SUBMISSION_DATE,
    sa.IS_SUBMITTED,
    sa.STUDENT_STATUS
FROM USER_TABLE ut
JOIN STUDENT_ASSIGNMENT sa ON ut.STUDENT_ID = sa.STUDENT_ID AND sa.ASSIGNMENT_ID = ut.ASSIGNMENT_ID
JOIN STUDENT_PROFILE sp ON sp.STUDENT_ID = ut.STUDENT_ID
JOIN CLASS_DETAIL cd ON cd.STUDENT_ID = sp.STUDENT_ID
JOIN TEACHER_DETAIL td ON sa.SUBJECT_NAME = td.SUBJECT AND cd.CLASS_ID = td.CLASS_ID
where ut.STATUS <> 'PENDING'
    `;

    const [rows] = await schoolDbConnection.query(query);
    return res.status(200).json(rows);

  } catch (error) {
    console.error("Error fetching assignment data:", error);
    return res.status(500).json({ error: "Error fetching assignment data", details: error.message });
  }
});



// Fetch assignment record with detailed student and teacher info


 // Fetch assignment record with detailed student and teacher info


// API Endpoint to get all class data
app.get('/api/Stafftimetable', async (req, res) => {
  try {
    if (!schoolDbConnection) {
      return res.status(500).json({ error: "School database connection not established" });
    }

    const sql = `SELECT DISTINCT CLASS_ID FROM CLASS_SCHEDULE`;

    const [result] = await schoolDbConnection.query(sql);
    if (!result.length) {
      return res.status(404).json({ message: 'No class data found' });
    }

    console.log('Data fetched successfully:', result);
    return res.json(result);

  } catch (err) {
    console.error('Error fetching class data:', err.message);
    return res.status(500).json({ error: 'An error occurred while fetching data' });
  }
});

// API Endpoint to get data by selected class
app.get('/api/class_data', async (req, res) => {
  const selectedClass = req.query.class; // Get the selected class from query params

  if (!selectedClass) {
    return res.status(400).json({ message: 'Class parameter is required' });
  }

  try {
    if (!schoolDbConnection) {
      return res.status(500).json({ error: "School database connection not established" });
    }

    const sql = `
    
SELECT
t.TEACHER_NAME ,
    sc.PERIOD,
    sc.TIME_SLOT,
    sc.CLASS_ID,
    MAX(CASE WHEN sc.DAY = 'MONDAY' THEN sc.SUBJECT END) AS Monday,
    MAX(CASE WHEN sc.DAY = 'TUESDAY' THEN sc.SUBJECT END) AS Tuesday,
    MAX(CASE WHEN sc.DAY = 'WEDNESDAY' THEN sc.SUBJECT END) AS Wednesday,
    MAX(CASE WHEN sc.DAY = 'THURSDAY' THEN sc.SUBJECT END) AS Thursday,
    MAX(CASE WHEN sc.DAY = 'FRIDAY' THEN sc.SUBJECT END) AS Friday,
    MAX(CASE WHEN sc.DAY = 'SATURDAY' THEN sc.SUBJECT END) AS Saturday
FROM
    CLASS_SCHEDULE sc
    JOIN TEACHER_DETAIL t ON t.CLASS_ID = sc.CLASS_ID AND t.SUBJECT = sc.SUBJECT
--     where t.TEACHER_NAME ='ASA MCLEAN'
GROUP BY
    sc.PERIOD, sc.TIME_SLOT, sc.CLASS_ID
ORDER BY
    sc.PERIOD
 ;`

    const [result] = await schoolDbConnection.query(sql, [selectedClass]);
    if (!result.length) {
      return res.status(404).json({ message: 'No data found for the selected class' });
    }

    console.log('Class data fetched successfully:', result);
    return res.json(result);

  } catch (err) {
    console.error('Error fetching class data:', err.message);
    return res.status(500).json({ error: 'An error occurred while fetching data' });
  }
});


// API Endpoint to get data by selected class


app.get('/api/class_data', async (req, res) => {
  const selectedClass = req.query.class; // Retrieve selected class from query parameters

  if (!selectedClass) {
    console.log("GET /api/class_data: Missing class parameter.");
    return res.status(400).json({ message: 'Class parameter is required' });
  }

  try {
    if (!schoolDbConnection) {
      console.log("GET /api/class_data: School database connection not established.");
      return res.status(500).json({ error: "School database connection not established" });
    }

    const sql = `
      SELECT
        PERIOD,
        TIME_SLOT,
        CLASS_ID,
        MAX(CASE WHEN DAY = 'MONDAY' THEN SUBJECT END) AS Monday,
        MAX(CASE WHEN DAY = 'TUESDAY' THEN SUBJECT END) AS Tuesday,
        MAX(CASE WHEN DAY = 'WEDNESDAY' THEN SUBJECT END) AS Wednesday,
        MAX(CASE WHEN DAY = 'THURSDAY' THEN SUBJECT END) AS Thursday,
        MAX(CASE WHEN DAY = 'FRIDAY' THEN SUBJECT END) AS Friday,
        MAX(CASE WHEN DAY = 'SATURDAY' THEN SUBJECT END) AS Saturday
      FROM
        CLASS_SCHEDULE sc
      WHERE
        sc.CLASS_ID = ?
      GROUP BY
        sc.PERIOD, sc.TIME_SLOT, sc.CLASS_ID
      ORDER BY
        sc.PERIOD;
    `;

    console.log("GET /api/class_data: Executing SQL query:", sql);
    const [result] = await schoolDbConnection.query(sql, [selectedClass]);

    if (!result.length) {
      console.log("GET /api/class_data: No data found for selected class:", selectedClass);
      return res.status(404).json({ message: 'No data found for the selected class' });
    }

    console.log('GET /api/class_data: Class data fetched successfully:', result);
    return res.json(result);

  } catch (err) {
    console.error('Error fetching class data:', err.message);
    return res.status(500).json({ error: 'An error occurred while fetching data' });
  }
});


// API Endpoint to get data by selected class


// app.get('/api/dashboradstudentattendance', async (req, res) => {
//   console.log("GET /dashboradstudentattendance");
//   try {
//     // Check database connection
//     if (!schoolDbConnection) {
//       console.log("GET /studentattendance: School database connection not established.");
//       return res.status(500).json({ error: "School database connection not established" });
//     }
//     const query = `
       
// SELECT
//     sa.STUDENT_ID,
//     CONCAT(sp.FIRST_NAME, ' ', sp.MIDDLE_NAME, ' ', sp.LAST_NAME) AS STUDENT_NAME,
//     cd.CLASS_ID AS CLASS,
//     sa.SESSION,
//     sa.DATE,
//     sa.STATUS
// FROM
//     STUDENT_ATTENDANCE sa
// JOIN
//     CLASS_DETAIL cd ON sa.STUDENT_ID = cd.STUDENT_ID
// JOIN
//     STUDENT_PROFILE sp ON sa.STUDENT_ID = sp.STUDENT_ID
// WHERE
//     sa.STUDENT_ID = ?
//   `;
//   console.log('Executing query:', query); // Log the query being executed
//   const [dashboradstudentattendanceResult] = await schoolDbConnection.query(query, [studentId]);
 
//   console.log("GET /studentattendance: promotestudent fetched successfully.");
//   return res.status(200).json(dashboradstudentattendanceResult);
 
 
 
//   } catch (err) {
//     console.error('Error fetching options:', err.message);
//     res.status(500).json({ error: 'Database query error' });
//   }
// });
 





// Define the GET endpoint for announcements without filters
app.get('/api/noticeboard', async (req, res) => {
  console.log("GET /noticeboard");

  try {
    // Check database connection
    if (!schoolDbConnection) {
      console.log("GET /noticeboard: School database connection not established.");
      return res.status(500).json({ error: "School database connection not established" });
    }

    const query = 'SELECT DESCRIPTION FROM EVENTS_HOLIDAYS';
    console.log('Executing query:', query); // Log the query being executed

    const [noticeboardResults] = await schoolDbConnection.query(query);
    
    console.log("GET /noticeboard: Noticeboard fetched successfully.");
    return res.status(200).json(noticeboardResults);

  } catch (err) {
    console.error('Error fetching noticeboard:', err.message);
    res.status(500).json({ error: 'Database query error' });
  }
});



// Route to fetch my student list for dashboard
app.get('/api/Mystudent', async (req, res) => {
  console.log("GET /Mystudent");

  const teacherName = req.query.teacherName || ''; // Get teacher name from the query params

  try {
    // Check database connection
    if (!schoolDbConnection) {
      console.log("GET /Mystudent: School database connection not established.");
      return res.status(500).json({ error: "School database connection not established" });
    }

    const query = `
     SELECT sp.STUDENT_ID,
           sp.PARENT_ID,
           pp.FATHER_NAME,
           pp.MOTHER_NAME,
           CONCAT(sp.FIRST_NAME, ' ', sp.LAST_NAME) AS FULL_NAME,
           sp.GENDER,
           sp.CONTACT_NUMBER,
           td.SUBJECT,
           td.TEACHER_NAME,
           CONCAT(cd.CLASS, ' ', cd.SECTION) AS CLASS_SECTION
    FROM STUDENT_PROFILE sp
    JOIN CLASS_DETAIL cd ON sp.STUDENT_ID = cd.STUDENT_ID
    join PARENT_PROFILE pp on sp.PARENT_ID = pp.PARENT_ID
    JOIN TEACHER_DETAIL td ON cd.CLASS_ID = td.CLASS_ID
`;  // Use teacherName for filtering

    console.log('Executing query:', query); // Log the query being executed

    // Execute the query with the teacherName filter
    const [studentResults] = await schoolDbConnection.query(query, [`%${teacherName}%`]);

    console.log("GET /Mystudent: Students fetched successfully.");
    return res.status(200).json(studentResults);

  } catch (err) {
    console.error('Error fetching students:', err.message);
    return res.status(500).json({ error: 'Database query error' });
  }
});

// Route to fetch my student list for dashboard

app.get('/api/assignmentstable', async (req, res) => {
  try {
    // Check if the database connection is established
    if (!schoolDbConnection) {
      console.log("School database connection not established.");
      return res.status(500).json({ error: "School database connection not established" });
    }
 
    // Log before executing the query
    console.log("Executing the query to fetch assignment data...");
 
    const query = `
      SELECT
        ASSIGNMENT_ID,
        CLASS_ID,
        ASSIGNMENT_TYPE,
        SUBJECT_NAME,
        ASSIGNMENT_DESC,
        MIN(SUBMISSION_START_DATE) AS SUBMISSION_START_DATE,
        MAX(SUBMISSION_END_DATE) AS SUBMISSION_END_DATE
      FROM
        STUDENT_ASSIGNMENT
      GROUP BY
        CLASS_ID, ASSIGNMENT_ID;
    `;
 
    // Execute the query
    const [rows] = await schoolDbConnection.query(query);
 
    // Log the number of rows fetched
    console.log(`Query executed successfully. Number of records fetched: ${rows.length}`);
 
    // Respond with the data
    return res.status(200).json(rows);
  } catch (error) {
    // Log detailed error information
    console.error("Error fetching assignment data:", error);
    console.error("Error details:", {
      message: error.message,
      stack: error.stack,
    });
 
    // Return a detailed error response to the client
    return res.status(500).json({
      error: "Error fetching assignment data",
      details: error.message
    });
  }
});

// Fetch assignment record with detailed student and teacher info

app.get('/api/assignments', async (req, res) => {
  try {
     
 
    // Check if the database connection is established
    if (!schoolDbConnection) {
      console.log("GET /api/assignments: School database connection not established."); // Debugging
      return res.status(500).json({ error: "School database connection not established" });
    }
 
    // Fetch class ID for the student
    const classidSql = `SELECT CLASS_ID FROM STUDENT_ASSIGNMENT WHERE STUDENT_ID = ?`;
    console.log('Executing class ID query for student:', studentId); // Debugging
 
    const [classidSqlResult] = await schoolDbConnection.query(classidSql, [studentId]);
    console.log('Class ID query result:', classidSqlResult); // Debugging
 
    // Check if class ID is found
    if (classidSqlResult.length === 0) {
      console.log('No class found for the provided student:', studentId); // Debugging
      return res.status(404).json({ message: "No class found for the provided student." });
    }
 
    const classId = classidSqlResult[0].CLASS_ID;
    console.log('Class ID found:', classId); // Debugging
 
    // Fetch assignment data
    const assignmentsSql = `
      SELECT
        STUDENT_ID,
        ASSIGNMENT_ID,
        STUDENT_NAME,
        CLASS_ID,
        ASSIGNMENT_TYPE,
        SUBJECT_NAME,
        ASSIGNMENT_DESC,
        SUBMISSION_START_DATE,
        SUBMISSION_END_DATE
      FROM STUDENT_ASSIGNMENT
      WHERE STUDENT_ID = ? AND CLASS_ID = ? AND SUBMITTED = 0
    `;
    console.log('Executing assignment query for student:', studentId, 'and class ID:', classId); // Debugging
 
    const [assignmentsResult] = await schoolDbConnection.query(assignmentsSql, [studentId, classId]);
    console.log('Assignments query result:', assignmentsResult); // Debugging
 
    // Check if assignments are found
    if (assignmentsResult.length === 0) {
      console.log('No assignments found for student:', studentId, 'and class ID:', classId); // Debugging
      return res.status(404).json({ message: "No assignments found for the provided student and class." });
    }
 
    console.log('Returning assignments data:', assignmentsResult); // Debugging
    return res.status(200).json(assignmentsResult);
 
  } catch (err) {
    console.error("Error fetching assignment table:", err); // Debugging
    return res.status(500).json({ error: "Internal server error" });
  }
});
 
 
 
 // Fetch assignment record with detailed student and teacher info

app.post('/api/submit-assignment', (req, res) => {
  console.log('Received a submission request:', req.body);
  const assignments = req.body; // Expecting an array of assignments
 
  if (!Array.isArray(assignments) || assignments.length === 0) {
    console.log('No assignments provided or not an array');
    return res.status(400).json({ error: 'No assignments provided' });
  }
 
  const insertPromises = assignments.map(({ assignmentId, studentId }) => {
    if (!assignmentId || !studentId) {
      console.log('Missing assignmentId or studentId');
      return Promise.reject('Missing assignmentId or studentId');
    }
 
    const query = 'INSERT INTO USER_TABLE (ASSIGNMENT_ID, STUDENT_ID) VALUES (?, ?)';
    const values = [assignmentId, studentId];
 
    return new Promise((resolve, reject) => {
      schoolDbConnection.execute(query, values, (err, results) => {
        if (err) {
          console.error('Database query error:', err.message);
          reject('Internal server error.');
        } else {
          console.log('Assignment submitted successfully:', results);
          resolve();
        }
      });
    });
  });
 
  Promise.all(insertPromises)
    .then(() => {
      res.status(201).json({ message: 'Assignments submitted successfully' });
    })
    .catch(error => {
      console.error('Error during submission:', error);
      res.status(500).json({ message: 'Internal server error.' });
    });
});
 













// Fetch assignment record with detailed student and teacher info

app.get('/api/Studenttimetable', async (req, res) => {
  const selectedClass = req.query.class; // Get the selected class from query params
 
  if (!selectedClass) {
    return res.status(400).json({ message: 'Class parameter is required' });
  }
 
  try {
    if (!schoolDbConnection) {
      return res.status(500).json({ error: "School database connection not established" });
    }
 
    const sql = `
    SELECT
    PERIOD,
    TIME_SLOT,
    CLASS_ID,
    MAX(CASE WHEN DAY = 'MONDAY' THEN SUBJECT END) AS Monday,
    MAX(CASE WHEN DAY = 'TUESDAY' THEN SUBJECT END) AS Tuesday,
    MAX(CASE WHEN DAY = 'WEDNESDAY' THEN SUBJECT END) AS Wednesday,
    MAX(CASE WHEN DAY = 'THURSDAY' THEN SUBJECT END) AS Thursday,
    MAX(CASE WHEN DAY = 'FRIDAY' THEN SUBJECT END) AS Friday,
    MAX(CASE WHEN DAY = 'SATURDAY' THEN SUBJECT END) AS Saturday
  FROM
    CLASS_SCHEDULE sc
 WHERE
    sc.CLASS_ID = ?
  GROUP BY
    sc.PERIOD, sc.TIME_SLOT, sc.CLASS_ID
  ORDER BY
    sc.PERIOD;`
 
    const [result] = await schoolDbConnection.query(sql, [selectedClass]);
    if (!result.length) {
      return res.status(404).json({ message: 'No data found for the selected class' });
    }
 
    console.log('Class data fetched successfully:', result);
    return res.json(result);
 
  } catch (err) {
    console.error('Error fetching class data:', err.message);
    return res.status(500).json({ error: 'An error occurred while fetching data' });
  }
});
 


// Upload Application Data
app.post('/api/BulkLoad', async (req, res) => {
  console.log("POST /BulkLoad");

  try {
    // Check database connection
    if (!schoolDbConnection) {
      console.log("POST /BulkLoad: School database connection not established.");
      return res.status(500).json({ error: "Database connection not established" });
    }

    const { data } = req.body;

    if (!data || !Array.isArray(data) || data.length === 0) {
      console.log("POST /BulkLoad: Invalid or empty data provided.");
      return res.status(400).json({ error: "Invalid or empty data provided" });
    }

    // Define the INSERT query
    const query = `
      INSERT INTO APPLICATION (    
        FIRST_NAME, MIDDLE_NAME, LAST_NAME, GENDER, CONTACT_NUMBER, CLASS, STREAM, OPTIONAL,
        HOUSE_NUMBER, HOUSE_BUILDING_NAME, STREET_NAME, LANDMARK, CITY, STATE, POSTAL_CODE,
        DATE_OF_BIRTH, EMAIL, ENROLLMENT_DATE, NATIONALITY, ORPHAN_STUDENT,
        BIRTH_CERTIFICATE_NUMBER, CAST, RELIGION, BLOOD_GROUP, DISEASE_IF_ANY, ADDITIONAL_NOTE,
        IDENTIFICATION_MARK, PREVIOUS_SCHOOL, EMERGENCY_CONTACT_NAME, EMERGENCY_CONTACT_NUMBER,
        AADHAAR_NUMBER, FATHER_NAME, FATHER_ADHAR_ID, FATHER_OCCUPATION, FATHER_EDUCATION,
        FATHER_MOBILE_NUMBER, FATHER_INCOME, MOTHER_NAME, MOTHER_ADHAR_ID, MOTHER_OCCUPATION,
        MOTHER_EDUCATION, MOTHER_MOBILE_NUMBER, MOTHER_INCOME, PRIMARY_CONTACT_NUMBER
      ) VALUES ?
    `;

    // Map the data into arrays for the bulk INSERT query
    const values = data.map(row => [
      row.FIRST_NAME, row.MIDDLE_NAME, row.LAST_NAME, row.GENDER, row.CONTACT_NUMBER,
      row.CLASS, row.STREAM, row.OPTIONAL, row.HOUSE_NUMBER, row.HOUSE_BUILDING_NAME,
      row.STREET_NAME, row.LANDMARK, row.CITY, row.STATE, row.POSTAL_CODE,
      row.DATE_OF_BIRTH, row.EMAIL, row.ENROLLMENT_DATE, row.NATIONALITY, row.ORPHAN_STUDENT,
      row.BIRTH_CERTIFICATE_NUMBER, row.CAST, row.RELIGION, row.BLOOD_GROUP, row.DISEASE_IF_ANY,
      row.ADDITIONAL_NOTE, row.IDENTIFICATION_MARK, row.PREVIOUS_SCHOOL, row.EMERGENCY_CONTACT_NAME,
      row.EMERGENCY_CONTACT_NUMBER, row.AADHAAR_NUMBER, row.FATHER_NAME, row.FATHER_ADHAR_ID,
      row.FATHER_OCCUPATION, row.FATHER_EDUCATION, row.FATHER_MOBILE_NUMBER, row.FATHER_INCOME,
      row.MOTHER_NAME, row.MOTHER_ADHAR_ID, row.MOTHER_OCCUPATION, row.MOTHER_EDUCATION,
      row.MOTHER_MOBILE_NUMBER, row.MOTHER_INCOME, row.PRIMARY_CONTACT_NUMBER
    ]);

    console.log(`POST /BulkLoad: Attempting to insert ${values.length} records.`);

    // Execute the query
    await schoolDbConnection.query(query, [values]);

    console.log("POST /BulkLoad: Data uploaded successfully.");
    return res.status(200).json({ message: "Data uploaded successfully" });
  } catch (err) {
    console.error("POST /BulkLoad: Error uploading data:", err.message);
    return res.status(500).json({ error: "Database query error" });
  }
});



// Start the server
app.listen(port, () => {
  console.log(`Server is running on ${port}`);
});
