module.exports = {
    apps: [
      {
        name: 'SchoolManagement',
        script: 'npm',
        args: 'run start', // This runs the start script that handles both frontend and backend
        cwd: './', // Current working directory
        watch: true,
      },
    ],
  };
  